﻿var globalIspublish=0;

 
function GetAdmissionProcessedResultByClassShiftVersion(classShiftVersionID) {
    var listType = $('#hdListType').text();//1=For Merit 2 for waiting
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: "/Service/SchoolService.asmx/GetAdmissionProcessedResultByClassShiftVersion",
        data: "{listType:" + listType + ",classShiftVersionID:'" + classShiftVersionID + "'}",
        //dataType: "json",
        async: false,
        success: function (data, textStatus) {
            if (textStatus == "success") { 
                var id = '#inner' + classShiftVersionID + '';
                $('#inner' + classShiftVersionID + '').empty();
                $('#inner' + classShiftVersionID + '').append(data.d);
                $('.applicantClass').bind('click', function (e) {
                    return;
                    e.preventDefault();
                    $("#divMarks").empty();
                    $("#divTotal").empty();
                    $("#divMarks").html('');
                    $("#divTotal").html('');
                    var id = $(this).attr('id');
                    GenerateMarksTable($(this).attr('id'));
                    $("#divMarks").append('<div class="lblAplicantInfo">' + $(this).next().html() + "</div>");
                    $('#element_to_pop_up').bPopup();

                });
            }
        },

        error: function (data, status, error) {
            alert("error");
        }
    });
}
function GenerateClassShiftVersionDiv(listType) {
    //var listType = 1;//1=For Merit
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: "/Service/SchoolService.asmx/GetClassNameListAdmissionProcessedResult",
        data: "{listType:" + listType + "}",
        //dataType: "json",
        async: false,
        success: function (data, textStatus) {
            if (textStatus == "success") {
                $('#divContent').append(data.d); 
            }
        },

        error: function (data, status, error) {
            alert("error");
        }
    });
}
function GenerateResult() {
    var listType = 1;//1=For Merit
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: "/Service/SchoolService.asmx/GetAdmissionProcessedResult",
        data: "{listType:" + listType + "}",
        //dataType: "json",
        async: false,
        success: function (data, textStatus) {
            if (textStatus == "success") { 
                $('#divContent').append(data.d);

            }
        },

        error: function (data, status, error) {
            alert("error");
        }
    });
}

(function ($) {

    // DOM Ready
    $(function () {
        
        // Binding a click event
        // From jQuery v.1.7.0 use .on() instead of .bind()

        //$('.applicantClass').bind('click', function (e) {
        //    $("#divMarks").empty();
        //    $("#divTotal").empty();
        //    var id = $(this).attr('id');
        //    // Prevents the default action to be triggered. 
        //    e.preventDefault();
        //    //alert($(this).attr('id'));
        //    GenerateMarksTable($(this).attr('id'));
        //    //debugger;
        //    //var test = $('' + id + '').next().text();
        //    // $(this).next().addClass("lblAplicantInfo"); 
        //    $("#divMarks").append('<div class="lblAplicantInfo">' + $(this).next().text()+"</div>");
        //   // $("#divMarks").append($(''+id+'').next().text());
        //    // Triggering bPopup when click event is fired
        //    $('#element_to_pop_up').bPopup();

        //});

    });

})(jQuery);
function GenerateMarksTable(applicantID) { 
    //
    $("#users tbody").empty();
    //var trHTML = '';
    var totalMarks = 0;
    
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: "/Service/SchoolService.asmx/GetMarksByApplicantID", 
        data: "{ApplicantID:'" + applicantID + "'}",
        dataType: "json",
        async: false,
        success: function (data, textStatus) {
            if (textStatus == "success") {
                if (data.hasOwnProperty('d')) {
                    msg = data.d; 
                    $.each(data.d, function (index, item) {
                        totalMarks = totalMarks + item.ObtainMarks;
                        
                        // trHTML += '<tr><td>' + item.SubjectName + '</td><td>' + item.ObtainMarks + '</td></tr>';
                        $("#users tbody").append("<tr>" +
                        "<td>" + item.SubjectName + "</td>" + 
                        "<td>" + item.ObtainMarks + "</td>" + 
                       "</tr>"); 
                    });
                    $("#divTotal").text(totalMarks);
                   // $('#records_table').append(trHTML);
                } else {
                    msg = data;
                }

            }
        },

        error: function (data, status, error) {
            alert("error");
        }
    });
}
function GetMarksBySearchResult(applicantID) {
    //
    var marksObtain = 0;
    var subjectName = '';
    $("#users tbody").empty();
    //var trHTML = '';
    var totalMarks = 0;
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: "/Service/SchoolService.asmx/SearchMarksByApplicantID",
        data: "{ApplicantID:'" + applicantID + "'}",
        dataType: "json",
        async: false,
        success: function (data, textStatus) {
            if (textStatus == "success") {
                if (data.hasOwnProperty('d')) {
                    msg = data.d;
                    if (msg == '[]')
                    {
                        $("#users tbody").empty();
                        $("#divMarks").empty();
                        $("#divTotal").empty();
                        $("#divMarks").html('');
                        $("#divTotal").html('');
                        $(".lblAplicantInfo").empty();
                        $(".lblAplicantInfo").html('');
                        alert('No record found');
                        return;
                    }
                    $.each(data.d, function (index, item) {
                        $("#divMarks").empty();
                        $("#divTotal").empty();
                        $("#divMarks").html('');
                        $("#divTotal").html('');
                        $(".lblAplicantInfo").empty();
                        $(".lblAplicantInfo").html('');
                       
                        totalMarks = totalMarks + item.ObtainMarks;
                        if (item.ResultStatus == 'Fail' || item.ResultStatus == 'fail') {
                            marksObtain = '<span class="failCls">' + item.ObtainMarks + '</div>';
                            subjectName = '<span class="failCls">' + item.SubjectName + '</div>';
                        }
                        else {
                            marksObtain = item.ObtainMarks;
                            subjectName = item.SubjectName;
                        }
                        $("#divMarks").append('<div Class="lblAplicantInfo">' + item.FullName + '</div>');
                        $("#users tbody").append("<tr>" +
                        "<td>" + subjectName + "</td>" +
                         "<td>" + marksObtain + "</td>" +
                       "</tr>");
                    });
                    $("#divTotal").text(totalMarks);
                    $('#element_to_pop_up').bPopup();
                   
                } else {
                    $("#divMarks").append("No Record Found");
                    msg = data;
                }

            }
        },

        error: function (data, status, error) {
            alert("error");
        }
    });
}

function GetAdmissionStatusIsPublish(classShiftVersionID) {
   
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: "/Service/SchoolService.asmx/GetAdmissionStatusIsPublish",
        data: "{classShiftVersionID:'" + classShiftVersionID + "'}",
        //dataType: "json",
        async: false,
        success: function (data, textStatus) {
            if (textStatus == "success") { 
                if (data.d==1)
                {
                    globalIspublish = 1;
                }
                else
                {
                    globalIspublish = 0;
                }
            }
        },

        error: function (data, status, error) {
            alert("error");
        }
    });
}
function GetAdmissionStatusIsPublishByApplicantID(applicantID) {
   
    $.ajax({
        type: "POST",
        contentType: "application/json; charset=utf-8",
        url: "/Service/SchoolService.asmx/GetAdmissionStatusIsPublishByApplicantID",
        data: "{applicantID:'" + applicantID + "'}",
        //dataType: "json",
        async: false,
        success: function (data, textStatus) {
            if (textStatus == "success") { 
                if (data.d == 1) {
                    globalIspublish = 1;
                }
                else {
                    globalIspublish = 0;
                }
            }
        },

        error: function (data, status, error) {
            alert("error");
        }
    });
}