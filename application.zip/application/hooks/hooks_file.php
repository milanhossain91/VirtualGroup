<?php

if(!defined('BASEPATH'))
    exit('No direct script access allowed');

class Profile
{

    function crew_hooks($name)
    {
       // dumpVar($name);
        echo $name[0];
        $_SESSION['hook_session'] = 'hasantarif';
        $CI =&get_instance();
        $CI->load->controllers->welcome;
    }

}

?>