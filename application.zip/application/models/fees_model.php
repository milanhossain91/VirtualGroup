<?php 
	if(!defined('BASEPATH'))
    exit('No direct script access allowed');

class Fees_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

    
    function get_fees_cat($school_id)
    {           
        $sql = "SELECT * FROM tbl_fees_category left join tbl_fcoa_bkdn on tbl_fees_category.acc_head=tbl_fcoa_bkdn.fcoa_bkdn_id WHERE tbl_fees_category.school_id = $school_id ORDER BY tbl_fees_category.fees_cat_id ASC";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_fees_cat_info_by_id($school_id, $fees_cat_id)
    {           
        $sql = "SELECT * FROM tbl_fees_category WHERE school_id = $school_id and fees_cat_id = $fees_cat_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
	function get_class_list($school_id)
    {           
        $sql = "SELECT * FROM tbl_class where school_id = $school_id order by class_short_form asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	function get_class_wise_fees_management_entry($school_id)
    {           
       $sql = "SELECT * FROM tbl_fees_category where tbl_fees_category.school_id = $school_id order by tbl_fees_category.fees_cat_id ASC";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_class_wise_fees_management_count($school_id, $class_id, $group_id, $session_id,$shift_id)
    {           
        $sql = "SELECT count(fee_mngt_id) as count from tbl_fee_management WHERE school_id = $school_id and class_id = $class_id and group_id = $group_id and shift_id = $shift_id and session_id = $session_id";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
	
	
   function get_class_wise_fees_management($school_id, $class_id, $group_id,$shift_id, $session_id)
    {           
       $sql = "SELECT tbl_fee_management.fee_mngt_id, tbl_fee_management.school_id, tbl_fee_management.class_id, tbl_fee_management.fees_cat_id, tbl_fee_management.amount, tbl_fee_management.period, tbl_fees_category.fees_particulars, tbl_fees_category.status FROM tbl_fee_management INNER JOIN tbl_fees_category ON tbl_fee_management.fees_cat_id = tbl_fees_category.fees_cat_id WHERE tbl_fee_management.school_id = $school_id and tbl_fee_management.class_id = $class_id and tbl_fee_management.group_id = $group_id and tbl_fee_management.shift_id = $shift_id and tbl_fee_management.session_id = $session_id order by tbl_fees_category.fees_cat_id ASC";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	function get_class_wise_student_list($school_id, $class_id, $group_id,$shift_id, $session_id,$student_id)
    {
		if($student_id)
			$where=' and tbl_student.student_id = '.$student_id.' ';
		else
			$where='';
       $sql = "SELECT tbl_student.student_id,tbl_student.student_name,tbl_student.fees_aid,tbl_student.aid_amount,tbl_student.mobile_contact FROM tbl_student 
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id
				where tbl_student.school_id = $school_id 
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.group_id = $group_id 
				and tbl_student_class.shift_id = $shift_id 
				and tbl_student_class.session_id = $session_id 
				and tbl_student.financial_aid != 3 $where
				order by tbl_student.student_id asc";
       
		$query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
	function get_class_wise_fees_details($school_id, $class_id, $group_id,$shift_id, $session_id, $fees_type)
    {           
       $sql = "SELECT tbl_fee_management.fee_mngt_id, 
					tbl_fee_management.school_id, 
					tbl_fee_management.class_id, 
					tbl_fee_management.fees_cat_id, 
					tbl_fee_management.amount, 
					tbl_fee_management.period, 
					tbl_fees_category.fees_particulars, 
					tbl_fees_category.status 
					FROM tbl_fee_management 
					INNER JOIN tbl_fees_category ON tbl_fee_management.fees_cat_id = tbl_fees_category.fees_cat_id 
					WHERE tbl_fee_management.school_id = $school_id 
					and tbl_fee_management.session_id = $session_id 
					and tbl_fee_management.class_id = $class_id 
					and tbl_fee_management.group_id = $group_id 
					and tbl_fee_management.shift_id = $shift_id 
					and tbl_fee_management.period IN $fees_type
					order by tbl_fees_category.fees_cat_id ASC";
		$query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
    function get_class_wise_student_count($school_id, $class_id)
    {           
        $sql = "SELECT count(student_id) as count from tbl_student_class where school_id = $school_id and class_id = $class_id";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
	function count_sudents_fees($school_id, $class_id,$group_id,$shift_id, $session_id, $fees_date,$student_id)
    {
		if($student_id)
			$where=' and tbl_students_fees.student_id = '.$student_id.' ';
		else
			$where='';
		
        $sql = "SELECT distinct(student_id) from tbl_students_fees WHERE school_id = $school_id and session_id = $session_id and class_id = $class_id and group_id = $group_id and shift_id = $shift_id and fees_date= '$fees_date'$where and status = '0'";
        
		$query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	function get_class_wise_generate_fees_details($school_id, $class_id, $group_id,$shift_id, $session_id, $fees_date)
	{
		 $sql = "SELECT `tbl_students_fees`.`billing_id`,`tbl_students_fees`.`student_id`,`tbl_student`.mobile_contact,`tbl_students_fees`.`school_id`,`tbl_students_fees`.`class_id`,`tbl_students_fees`.`fees_date`,`tbl_students_fees`.`status`,
				GROUP_CONCAT(`tbl_fees_category`.`fees_particulars`,' - ',`tbl_students_fees`.`amount`) as fees_details,
				sum(`tbl_students_fees`.`amount`) as total_amount
				FROM `tbl_students_fees`
				join  `tbl_student` on `tbl_student`.`student_id`=`tbl_students_fees`.`student_id`
				join  `tbl_fees_category` on `tbl_fees_category`.`fees_cat_id`=`tbl_students_fees`.`fees_cat_id`
				where `tbl_students_fees`.`school_id`=$school_id
				and `tbl_students_fees`.`session_id`=$session_id
				and `tbl_students_fees`.`class_id`=$class_id
				and `tbl_students_fees`.`group_id`=$group_id
				and `tbl_students_fees`.`shift_id`=$shift_id
				and `tbl_students_fees`.`fees_date`='$fees_date'
				GROUP BY `tbl_students_fees`.`billing_id`
				ORDER BY `tbl_students_fees`.`student_id`,`tbl_students_fees`.`fees_cat_id` asc";
		$query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
	}
	
	function student_wise_fees_json_details($school_id, $student_id, $session_id, $fees_year)
	{
		 $sql = "SELECT `tbl_students_fees`.`billing_id`,`tbl_students_fees`.`student_id`,`tbl_student`.mobile_contact,`tbl_students_fees`.`school_id`,`tbl_students_fees`.`class_id`,`tbl_students_fees`.`fees_date`,`tbl_students_fees`.`status`,
				GROUP_CONCAT(`tbl_fees_category`.`fees_particulars`,' - ',`tbl_students_fees`.`amount`) as fees_details,
				sum(`tbl_students_fees`.`amount`) as total_amount
				FROM `tbl_students_fees`
				join  `tbl_student` on `tbl_student`.`student_id`=`tbl_students_fees`.`student_id`
				join  `tbl_fees_category` on `tbl_fees_category`.`fees_cat_id`=`tbl_students_fees`.`fees_cat_id`
				where `tbl_students_fees`.`school_id`=$school_id and `tbl_students_fees`.`student_id`=$student_id and `tbl_students_fees`.`session_id`=$session_id and year(`tbl_students_fees`.`fees_date`) ='$fees_year'
				GROUP BY `tbl_students_fees`.`billing_id`
				ORDER BY `tbl_students_fees`.`fees_date` asc";
		$query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
	}
	
	function get_student_list($school_id, $class_id,$group_id,$shift_id,$session_id, $section_id)
    {           
        $sql = "SELECT tbl_student.student_id,tbl_student.student_name FROM tbl_student inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id where tbl_student.school_id = $school_id and tbl_student_class.session_id = $session_id and tbl_student_class.group_id = $group_id and tbl_student_class.class_id = $class_id and tbl_student_class.section_id = $section_id and tbl_student_class.shift_id = $shift_id order by tbl_student.student_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	/* report section */
	
	function get_class_wise_fees_report($school_id, $class_id, $group_id, $session_id, $fees_date, $status)
	{
		 $sql = "SELECT `tbl_students_fees`.`billing_id`,`tbl_students_fees`.`student_id`,`tbl_students_fees`.`school_id`,`tbl_students_fees`.`class_id`,`tbl_students_fees`.`fees_date`,`tbl_students_fees`.`status`,
				GROUP_CONCAT(`tbl_fees_category`.`fees_particulars`,' - ',`tbl_students_fees`.`amount`) as fees_details,
				sum(`tbl_students_fees`.`amount`) as total_amount
				FROM `tbl_students_fees`
				join  `tbl_fees_category` on `tbl_fees_category`.`fees_cat_id`=`tbl_students_fees`.`fees_cat_id`
				where `tbl_students_fees`.`school_id`=$school_id and `tbl_students_fees`.`session_id`=$session_id and `tbl_students_fees`.`class_id`=$class_id and `tbl_students_fees`.`group_id`=$group_id and `tbl_students_fees`.`fees_date`='$fees_date' and `tbl_students_fees`.`status`=$status
				GROUP BY `tbl_students_fees`.`billing_id`
				ORDER BY `tbl_students_fees`.`student_id`,`tbl_students_fees`.`fees_cat_id` asc";
		$query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
	}
	
	function get_fees_recepit($billing_id)
	{
		$sql="SELECT `tbl_student`.`student_name`, `tbl_class`.`class_name`, `tbl_section`.`section_name`,
			`tbl_group`.`group_name`, `tbl_students_fees`.`billing_id`,`tbl_student_class`.`roll_no`, `tbl_students_fees`.`amount`,`tbl_fees_category`.`fees_particulars` FROM `tbl_students_fees` 
			left join `tbl_fees_category` on `tbl_students_fees`.`fees_cat_id`=`tbl_fees_category`.`fees_cat_id`
			left join `tbl_student` on `tbl_students_fees`.`student_id`=`tbl_student`.`student_id`
			left join `tbl_student_class` on `tbl_students_fees`.`student_id`=`tbl_student_class`.`student_id`
			left join `tbl_class` on `tbl_student_class`.`class_id`=`tbl_class`.`class_id`
			left join `tbl_group` on `tbl_student_class`.`group_id`=`tbl_group`.`group_id`
			left join `tbl_section` on `tbl_student_class`.`section_id`=`tbl_section`.`section_id`
			WHERE tbl_students_fees.billing_id in $billing_id order by `tbl_student`.`student_id`, `tbl_fees_category`.`fees_particulars` ASC";
		$query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
	}
}
?>