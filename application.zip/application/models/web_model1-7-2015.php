<?php

if(!defined('BASEPATH'))
    exit('No direct script access allowed');

class Web_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	
	 function get_principal_message_by_school_id($school_id)
    {           
        $sql = "SELECT * FROM tbl_principal_message where school_id = $school_id order by type asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_principal_message_by_id($school_id, $message_id)
    {           
        $sql = "SELECT * FROM tbl_principal_message where school_id = $school_id and message_id = $message_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
	
	 function get_notice_list($school_id)
    {           
        $sql = "SELECT * FROM tbl_notice where school_id = $school_id order by notice_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
    function get_form_list($school_id)
    {           
        $sql = "SELECT * FROM tbl_form where school_id = $school_id order by notice_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }    
    function get_notice_list_by_id($school_id, $notice_id)
    {           
        $sql = "SELECT * FROM tbl_notice where school_id = $school_id AND notice_id = $notice_id order by notice_id asc";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
	
	    
    function get_form_list_by_id($school_id, $notice_id)
    {           
        $sql = "SELECT * FROM tbl_form where school_id = $school_id AND notice_id = $notice_id order by notice_id asc";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
	
	    function get_information_list($school_id)
    {           
        $sql = "SELECT * FROM tbl_important_information where school_id = $school_id order by important_information_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_information_list_by_id($school_id, $important_information_id)
    {           
        $sql = "SELECT * FROM tbl_important_information where school_id = $school_id AND important_information_id = $important_information_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
	
	function get_old_type($type,$school_id)
	{
		$sql = "SELECT information_type FROM tbl_important_information where school_id = $school_id AND information_type = $type";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
	}

       function get_all_slide_image($school_id)
    {           
        $sql = "SELECT * FROM tbl_slide_image where school_id = $school_id order by 	slide_image_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
}