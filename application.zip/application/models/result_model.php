<?php

if(!defined('BASEPATH')) exit('No direct script access allowed');

class Result_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
	
	/* function use for subject wise tabulation sheet */
	function mark_distribution_list_result($school_id,$subject_id,$class_id,$group_id,$term_id)
	{
		$sql="SELECT GROUP_CONCAT(`tbl_mark_distribution`.`exam_short_name`,':', `tbl_mark_distribution`.`term_mark_per`) as mark_dist,
			`tbl_subject_wise_total_marks`.`subjective_marks`, `tbl_subject_wise_total_marks`.`objective_marks`, `tbl_subject_wise_total_marks`.`practical_marks`, `tbl_subject_wise_total_marks`.`pass_marks`
			FROM `tbl_mark_distribution`
			join `tbl_subject_wise_total_marks` on `tbl_mark_distribution`.`subject_id`=`tbl_subject_wise_total_marks`.`subject_id` 
				AND `tbl_mark_distribution`.`class_id`=`tbl_subject_wise_total_marks`.`class_id` 
				AND `tbl_mark_distribution`.`group_id`=`tbl_subject_wise_total_marks`.`group_id`
			where tbl_mark_distribution.school_id=$school_id
			and tbl_mark_distribution.subject_id=$subject_id
			and tbl_mark_distribution.class_id=$class_id
			and tbl_mark_distribution.group_id=$group_id
			and tbl_subject_wise_total_marks.term_id=$term_id
			group by `tbl_mark_distribution`.`subject_id`";
		$query = $this->db->query($sql);
      	$row= $query->row_array();
	  	return $row;
	}
	/* function use for subject wise tabulation sheet */
	function get_student_list_sub_tabu($school_id,$session_id,$class_id,$shift_id,$section_id,$group_id,$subject_id,$exam_year,$term_id)
	{
		$sql="SELECT `tbl_student`.`student_name`, `tbl_student_class`.`student_id`, `tbl_student_class`.`roll_no`, `tbl_ca_marks`.`obtained_marks` as `CA`, `tbl_cw_marks`.`obtained_marks` as `CW`, 
			`tbl_hw_marks`.`obtained_marks` as `HW`, `tbl_ct_marks`.`obtained_marks` as `CT`, `tbl_assignment_marks`.`obtained_marks` as `AS/PJ`, `tbl_term_marks`.`subjective_marks` as `sub`,
			`tbl_term_marks`.`objective_marks` as `obj`, `tbl_term_marks`.`practical_marks` as `prac` from `tbl_student_class`
			
			LEFT JOIN `tbl_student` on `tbl_student_class`.`school_id`=`tbl_student`.`school_id` AND `tbl_student_class`.`student_id`=`tbl_student`.`student_id` 

			LEFT JOIN `tbl_term_marks` on `tbl_student_class`.`school_id`=`tbl_term_marks`.`school_id` AND `tbl_student_class`.`class_id`=`tbl_term_marks`.`class_id` AND `tbl_student_class`.`session_id`=`tbl_term_marks`.`session_id` AND `tbl_student_class`.`student_id`=`tbl_term_marks`.`student_id` 
			
			LEFT JOIN `tbl_ca_marks` on `tbl_term_marks`.`school_id`=`tbl_ca_marks`.`school_id` AND `tbl_term_marks`.`class_id`=`tbl_ca_marks`.`class_id` AND `tbl_term_marks`.`session_id`=`tbl_ca_marks`.`session_id` AND `tbl_term_marks`.`student_id`=`tbl_ca_marks`.`student_id` AND `tbl_term_marks`.`subject_id`=`tbl_ca_marks`.`subject_id` 
			
			LEFT JOIN `tbl_cw_marks` on `tbl_term_marks`.`school_id`=`tbl_cw_marks`.`school_id` AND `tbl_term_marks`.`class_id`=`tbl_cw_marks`.`class_id` AND `tbl_term_marks`.`session_id`=`tbl_cw_marks`.`session_id` AND `tbl_term_marks`.`student_id`=`tbl_cw_marks`.`student_id` AND `tbl_term_marks`.`subject_id`=`tbl_cw_marks`.`subject_id` 
			
			LEFT JOIN `tbl_hw_marks` on `tbl_term_marks`.`school_id`=`tbl_hw_marks`.`school_id` AND `tbl_term_marks`.`class_id`=`tbl_hw_marks`.`class_id` AND `tbl_term_marks`.`session_id`=`tbl_hw_marks`.`session_id` AND `tbl_term_marks`.`student_id`=`tbl_hw_marks`.`student_id` AND `tbl_term_marks`.`subject_id`=`tbl_hw_marks`.`subject_id` 
			
			LEFT JOIN `tbl_ct_marks` on `tbl_term_marks`.`school_id`=`tbl_ct_marks`.`school_id` AND `tbl_term_marks`.`class_id`=`tbl_ct_marks`.`class_id` AND `tbl_term_marks`.`session_id`=`tbl_ct_marks`.`session_id` AND `tbl_term_marks`.`student_id`=`tbl_ct_marks`.`student_id`  AND `tbl_term_marks`.`subject_id`=`tbl_ct_marks`.`subject_id` 
			
			LEFT JOIN `tbl_assignment_marks` on `tbl_term_marks`.`school_id`=`tbl_assignment_marks`.`school_id` AND `tbl_term_marks`.`student_id`=`tbl_assignment_marks`.`student_id` AND `tbl_term_marks`.`class_id`=`tbl_assignment_marks`.`class_id` AND `tbl_term_marks`.`session_id`=`tbl_assignment_marks`.`session_id` AND `tbl_term_marks`.`student_id`=`tbl_assignment_marks`.`student_id` AND `tbl_term_marks`.`subject_id`=`tbl_assignment_marks`.`subject_id` 

			where `tbl_student_class`.`school_id`=$school_id
			AND `tbl_student_class`.`session_id`=$session_id
			AND `tbl_student_class`.`class_id`=$class_id
			AND `tbl_student_class`.`shift_id`=$shift_id
			AND `tbl_student_class`.`section_id`=$section_id
			AND `tbl_student_class`.`group_id`=$group_id
			
			AND `tbl_term_marks`.`subject_id`=$subject_id
			AND `tbl_term_marks`.`exam_year`='$exam_year'
			AND `tbl_term_marks`.`term_id`=$term_id
			order by `tbl_student_class`.`roll_no`";
		$query = $this->db->query($sql);
      	$row= $query->result_array();
	  	return $row;
	}
	/* function use for mark sheet */
	
	function selece_student_marksheet($data)
    {
        $this->db->select('`tbl_student`.student_name,`tbl_student_class`.student_id');
		$this->db->from('tbl_student_class');
		$this->db->join('tbl_student', 'tbl_student_class.student_id = tbl_student.student_id');
		$this->db->where($data);
        $query = $this->db->get();
        $result = $query->result_array();
        return $result;   
    }

    function mark_sheet_student_info($school_id,$session_id,$student_id,$class_id)
    {           
        $sql = "SELECT tbl_student.student_name, tbl_student.student_id, tbl_group.group_name, tbl_class.class_name, tbl_section.section_name, tbl_student_class.roll_no, tbl_shift.shift_name FROM tbl_student
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id
				inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id
				inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id
				inner join tbl_group on tbl_student_class.group_id = tbl_group.group_id
				inner join tbl_shift on tbl_student_class.shift_id = tbl_shift.shift_id
				where tbl_student.school_id = $school_id
				and tbl_student_class.session_id = $session_id
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.student_id = $student_id";
        $query = $this->db->query($sql);
        return $query->row_array();
    }
	function mark_sheet_student_info_with_optional($school_id,$session_id,$student_id,$class_id)
    {           
        $sql = "SELECT tbl_student_subject.subject_id, tbl_student.student_name, tbl_student.student_id, tbl_group.group_name, tbl_class.class_name, tbl_section.section_name, tbl_student_class.roll_no, tbl_shift.shift_name FROM tbl_student
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id
				inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id
				inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id
				inner join tbl_group on tbl_student_class.group_id = tbl_group.group_id
				inner join tbl_shift on tbl_student_class.shift_id = tbl_shift.shift_id
                left join tbl_student_subject on tbl_student_class.student_id=tbl_student_subject.student_id
				where tbl_student.school_id = $school_id
				and tbl_student_class.session_id = $session_id
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.student_id = $student_id
				and tbl_student_subject.optional_id=1";
        $query = $this->db->query($sql);
        return $query->row_array();
    }
	/* for student att count SELECT sum(if(status=1,1,0)) as present,sum(if(status=0,1,0)) as absent FROM `tbl_student_attendance` where student_id=1000001 */
	function get_max_subject_number($school_id,$class_id,$term_id,$session)
    {           
        $sql = "SELECT subject_id, max(sub_total) as max_mark FROM `tbl_tabulation_marks` where school_id=$school_id and class_id=$class_id and exam_year='$session' and term_id=$term_id group by class_id , exam_year, term_id, subject_id";
        $query = $this->db->query($sql);
      	$row= $query->result_array();
	  	return $row;
    }
	function get_student_rank($school_id,$class_id,$term_id,$session)
    {      
        $sql = "SELECT tbl_student_class.roll_no,tbl_tabulation_marks.student_id, sum(tbl_tabulation_marks.sub_total) as rank FROM `tbl_tabulation_marks` join tbl_student_class on tbl_tabulation_marks.student_id=tbl_student_class.student_id where tbl_student_class.school_id=$school_id and tbl_tabulation_marks.class_id=$class_id and tbl_tabulation_marks.exam_year='$session' and tbl_tabulation_marks.term_id=$term_id GROUP by tbl_tabulation_marks.student_id ORDER BY rank DESC,tbl_student_class.roll_no ASC";
        $query = $this->db->query($sql);
      	$row= $query->result_array();
	  	return $row;
    }
    function get_student_marksheet_info($school_id,$class_id,$student_id,$term_id,$session)
    {           
        $sql = "SELECT tbl_tabulation_marks.*,tbl_subject.subject_name,tbl_subject.subject_code FROM `tbl_tabulation_marks` join tbl_subject on tbl_tabulation_marks.subject_id=tbl_subject.subject_id where tbl_tabulation_marks.school_id=$school_id and tbl_tabulation_marks.class_id=$class_id and tbl_tabulation_marks.exam_year='$session' and tbl_tabulation_marks.term_id=$term_id and tbl_tabulation_marks.student_id=$student_id order by tbl_subject.subject_code";
        $query = $this->db->query($sql);
      	$row= $query->result_array();
	  	return $row;
    }
}