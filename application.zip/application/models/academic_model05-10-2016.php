<?php

if(!defined('BASEPATH'))
    exit('No direct script access allowed');

class Academic_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

public function get_class_wise_student_list($school_id,$class_id,$section_id,$group_id,$shift_id)
    {           
        $sql = "SELECT * FROM tbl_student 
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id 
				inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id 
				inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id 
				inner join tbl_shift on tbl_student_class.shift_id = tbl_shift.shift_id 
				inner join tbl_group on tbl_student_class.group_id = tbl_group.group_id 
				where tbl_student.school_id = $school_id 
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.section_id = $section_id
				and tbl_student_class.group_id = $group_id
				and tbl_student_class.shift_id = $shift_id 
				order by tbl_student_class.roll_no asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
function get_group_list_by_id($class_id, $school_id)
	{
		$sql = "SELECT * FROM `tbl_class_assign` as ca INNER JOIN `tbl_class` as c ON ca.class_id = c.class_id inner join `tbl_group` as g on ca.department_id=g.group_id WHERE ca.school_id=$school_id AND ca.class_id=$class_id order by g.group_id";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res; 
	}
function get_sub_list_by_id($class_id, $school_id,$group_id)
    {  
        $sql = "SELECT * FROM `tbl_class_subject` as cs INNER JOIN `tbl_subject` as s ON cs.subject_id = s.subject_id WHERE cs.school_id=$school_id AND cs.class_id=$class_id AND cs.group_id=$group_id order by s.subject_id";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
function get_sub_list_by_id_ct($class_id, $school_id,$group_id)
    {  
        $sql = "SELECT distinct(md.subject_id ) as `subject_id`, s.subject_name as `subject_name` FROM `tbl_class_subject` as cs INNER JOIN `tbl_subject` as s ON cs.subject_id = s.subject_id INNER JOIN `tbl_mark_distribution` as md ON cs.subject_id = md.subject_id WHERE cs.school_id=$school_id AND md.class_id=$class_id AND md.group_id=$group_id AND md.exam_type=4 order by s.subject_id";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
function get_assignment_list($school_id){
  
    
       $sql = "SELECT * FROM `tbl_project_assignment` as A INNER JOIN tbl_class ON A.class = tbl_class.class_id INNER JOIN tbl_group ON tbl_group.group_id = A.group_id INNER JOIN tbl_section ON A.section= tbl_section.section_id INNER JOIN tbl_subject ON tbl_subject.subject_id = A.sub INNER JOIN tbl_term ON tbl_term.term_id = A.term WHERE A.school_id = $school_id ORDER BY A.id ASC";
	  $query = $this->db->query($sql);
        $row= $query->result_array();
		return $row;
    }

 function delete_assignment_by_id($id, $school_id)
    {		
        $sql = "DELETE FROM `tbl_project_assignment` WHERE `id` = $id AND school_id = $school_id";
        $this->db->query($sql);
        return true;
    }
function get_assignment_info($school_id, $id)
    {           
        $sql = "SELECT * FROM `tbl_project_assignment` as A INNER JOIN tbl_class ON A.class = tbl_class.class_id INNER JOIN tbl_section ON A.section = tbl_section.section_id INNER JOIN tbl_subject ON tbl_subject.subject_id = A.sub INNER JOIN tbl_term ON tbl_term.term_id = A.term WHERE A.school_id = $school_id  and id = $id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
function get_class_wise_student_list_project_marks($school_id, $class_id,$section_id,$ct_id)
    {           
        $sql = "SELECT * FROM tbl_project_marks inner join tbl_student_class on tbl_project_marks.student_id = tbl_student_class.student_id inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id where tbl_project_marks.school_id = $school_id and tbl_student_class.class_id = $class_id and tbl_student_class.section_id = $section_id order by tbl_project_marks.student_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }

function get_project_list_by_class_id($school_id,$class_id,$section_id,$group_id,$term_id,$sub_id)
    {           
        $sql = "SELECT * FROM tbl_project_assignment WHERE school_id = $school_id and class='$class_id' and term='$term_id' and section='$section_id' and sub='$sub_id' and group_id='$group_id'";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	
    function get_project_info_by_id($school_id, $project_id)
    {           
        $sql = "SELECT * FROM tbl_project_assignment as P inner join tbl_term on P.term = tbl_term.term_id WHERE P.school_id = $school_id and P.id = $project_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
	
	function delete_project_marks_info($school_id, $project_id,$term_id,$exam_year,$subject_id)
	{
		$sql = "DELETE FROM `tbl_project_marks` WHERE `school_id` = '$school_id' AND `project_id` = '$project_id' AND `term_id` = '$term_id' AND `exam_year` = '$exam_year' AND `subject_id` = '$subject_id'";
        $this->db->query($sql);
        return true;
	}
    	/********** / project ************/
		
		/********** ct ****************/
		    
   
	function get_class_wise_student_list_ct($school_id, $class_id,$section_id)
    {           
        $sql = "SELECT * FROM tbl_student 
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id 
				inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id 
				inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id 
				where tbl_student.school_id = $school_id 
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.section_id = $section_id
				order by tbl_student.student_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
		
	function delete_ct_marks_info($school_id,$class_id,$section_id,$group_id,$shift_id,$term_id,$exam_year,$subject_id)
	{
		$sql = "DELETE FROM `tbl_ct_marks` WHERE `school_id` = '$school_id' AND `class_id` = '$class_id' AND `section_id` = '$section_id' AND `group_id` = '$group_id' AND `shift_id` = '$shift_id' AND `term_id` = '$term_id' AND `exam_year` = '$exam_year' AND `subject_id` = '$subject_id'";
        $this->db->query($sql);
        return true;
	}

		/********** / ct ****************/
		
		/********** CW *******************/
	
	function delete_cw_info($school_id, $class_id,$section_id,$group_id,$term_id,$exam_year,$subject_id)
    {     
		 $sql = "DELETE FROM `tbl_cw_marks` WHERE school_id = $school_id and class_id = $class_id and section_id = $section_id and group_id = $group_id and exam_year='$exam_year' and subject_id = '$subject_id' and term_id=$term_id";
        $this->db->query($sql);
        return true;      
        
    }
	
    /************ /CW *******************/
	
		/********** HW *******************/
	
	function delete_hw_info($school_id, $class_id,$section_id,$group_id,$term_id,$exam_year,$subject_id)
    {     
		 $sql = "DELETE FROM `tbl_hw_marks` WHERE school_id = $school_id and class_id = $class_id and section_id = $section_id and group_id = $group_id and exam_year='$exam_year' and subject_id = '$subject_id' and term_id=$term_id";
        $this->db->query($sql);
        return true;      
        
    }
	
    /************ /HW *******************/
	
		/********** term ****************/
		
		function get_term_list($school_id){
      $sql = "SELECT * FROM `tbl_term` ORDER BY term_id asc";
	  $query = $this->db->query($sql);
      $row= $query->result_array();
	  return $row;
	}
function get_term_list_by_id($id,$school_id){
      $sql = "SELECT * FROM `tbl_term` WHERE `term_id` = $id";
	  $query = $this->db->query($sql);
      $row= $query->result_array();
	  return $row;


	}

function delete_term_by_id($id,$school_id){
        $sql = "DELETE FROM `tbl_term` WHERE `term_id` = $id AND school_id = $school_id";
        $this->db->query($sql);
        return true;
	}	


		function delete_term_marks( $school_id,$class_id,$section_id,$group_id,$term_id,$sub_id,$exam_year,$shift_id)
    {           
        $sql = "delete FROM tbl_term_marks WHERE school_id = $school_id and class_id='$class_id' and section_id='$section_id' and group_id='$group_id' and shift_id='$shift_id' and term_id='$term_id' and sub_id='$sub_id' and exam_year='$exam_year'";
        $query = $this->db->query($sql);
        return true;
    }
	
	function get_class_wise_student_list_term_marks($school_id, $class_id,$section_id,$term_id)
    {           
        $sql = "SELECT * FROM tbl_term_marks inner join tbl_student_class on tbl_term_marks.student_id = tbl_student_class.student_id inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id where tbl_term_marks.school_id = $school_id and tbl_student_class.class_id = $class_id and tbl_student_class.section_id = $section_id order by tbl_term_marks.student_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	 function get_term_info_by_id($school_id, $term_id)
    {           
        $sql = "SELECT * FROM tbl_term WHERE school_id = $school_id and term_id = $term_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }

	/********** /term ****************/	
	
	 /**** /Class Routine model (sharif) ****/
	 
	  function get_class_wise_subject_list($class_id, $school_id)
    {            
        $sql = "select a.subject_id as `subject_id`, b.subject_name as `subject_name` from tbl_class_subject as a inner join tbl_subject as b on a.subject_id=b.subject_id WHERE a.school_id=$school_id AND a.class_id=$class_id";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
	
   
	
    function get_class_time($school_id)
    {           
        $sql = "SELECT * FROM tbl_class_time_input where school_id = $school_id order by row_no asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	 function get_class_time_count($school_id)
    {           
        $sql = "SELECT * from tbl_class_time_input where school_id = $school_id";
        $query = $this->db->query($sql);
        $row= $query->num_rows();
        return $row;
    }
	function get_weekdays($school_id)
    {           
        $sql = "SELECT * FROM tbl_weekdays where school_id = $school_id and status!=0 order by id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
    function get_class_routine_info_by_id($school_id, $class_id)
    {           
        $sql = "SELECT * FROM tbl_class where school_id = $school_id and class_id = $class_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
	function delete_class_wise_routine($school_id,$class_id,$section_id)
    {      
		if($this->db->delete('tbl_class_routine', array('school_id' => $school_id ,'class_id' => $class_id,'section_id'=>$section_id)))
			{
				return TRUE;
			}
		else
			{
				return FALSE;
			}    
    }
	function save_class_routine($data)
    {           
        if($this->db->insert('tbl_class_routine', $data))
        	{
				return TRUE;
			}
		else
			{
				return FALSE;
			}   
    }
	
	function get_id_per_class_section($class_id, $school_id,$section_id)
    {            
        $sql = "select distinct id from tbl_class_routine WHERE school_id=$school_id AND class_id=$class_id AND section_id=$section_id order by column_no, row_no";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
	function get_old_routine_by_section_class($id)
	{
		$sql="select * from tbl_class_routine where id=$id";
		$query = $this->db->query($sql);
		$row= $query->row_array();
        return $row;
	}
	
	function get_old_routine_by_section_class_show($id)
	{
		$sql="SELECT * FROM `tbl_class_routine` inner join tbl_subject on tbl_class_routine.subject_id = tbl_subject.subject_id inner join tbl_teacher_registration on tbl_class_routine.teacher_id = tbl_teacher_registration.teacher_id WHERE id=$id";
		$query = $this->db->query($sql);
		$row= $query->row_array();
        return $row;
	}
	
	
	function get_old_routine_by_section_class_download($school_id, $class_id, $section_id)
	{
		$sql="SELECT tbl_class_routine.row_no, tbl_class_routine.class_period, tbl_class_routine.column_no, tbl_teacher_registration.teacher_name, tbl_subject.subject_name FROM `tbl_class_routine` inner join tbl_subject on tbl_class_routine.subject_id = tbl_subject.subject_id inner join tbl_teacher_registration on tbl_class_routine.teacher_id = tbl_teacher_registration.teacher_id WHERE tbl_class_routine.school_id=$school_id AND tbl_class_routine.class_id=$class_id AND tbl_class_routine.section_id=$section_id order by tbl_class_routine.row_no , tbl_class_routine.column_no";
		$query = $this->db->query($sql);
		$row= $query->result_array();
        return $row;
	}
    /*******************  /Class Routine  ******************/
	
		/******************* exam routine ******************/
	function exam_get_class_count($school_id)
    {           
        $sql = "SELECT * from tbl_class where school_id = $school_id";
        $query = $this->db->query($sql);
        $row= $query->num_rows();
        return $row;
    }
	
	function exam_get_subject_count($school_id)
    {           
        $sql = "SELECT * from tbl_subject where school_id = $school_id";
        $query = $this->db->query($sql);
        $row= $query->num_rows();
        return $row;
    }
	
	function exam_routine_time($school_id)
	{
	$sql="SELECT * from tbl_exam_time where school_id=$school_id";
	 $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
	}
	
	function get_id_per_exam_term($school_id,$exam_term_id)
    {            
        $sql = "select distinct id from tbl_exam_routine WHERE school_id=$school_id AND exam_term_id=$exam_term_id order by id";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
	
	function get_old_exam_routine_by_term($id)
	{
		$sql="select * from tbl_exam_routine where id=$id";
		$query = $this->db->query($sql);
		$row= $query->row_array();
        return $row;
	}
	
	 function exam_show_get_class_count($school_id,$exam_term_id)
    {           
        $sql = "SELECT distinct column_no from tbl_exam_routine where school_id = $school_id AND exam_term_id = $exam_term_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	function exam_show_get_day_count($school_id,$exam_term_id)
    {           
        $sql = "SELECT distinct row_no from tbl_exam_routine where school_id = $school_id AND exam_term_id = $exam_term_id order by row_no";
        $query = $this->db->query($sql);
        $row= $query->num_rows();
        return $row;
    }
	
	function get_old_exam_routine_by_term_show($id)
	{
		$sql="SELECT * FROM `tbl_exam_routine` inner join tbl_subject on tbl_exam_routine.exam_subject_id = tbl_subject.subject_id inner join tbl_class on tbl_exam_routine.class_id = tbl_class.class_id WHERE id=$id";
		$query = $this->db->query($sql);
		$row= $query->row_array();
        return $row;
	}
	
	function get_old_exam_routine_by_term_download($school_id,$term_id)
	{
		$sql="SELECT * FROM `tbl_exam_routine` inner join tbl_subject on tbl_exam_routine.exam_subject_id = tbl_subject.subject_id inner join tbl_class on tbl_exam_routine.class_id = tbl_class.class_id WHERE tbl_exam_routine.school_id=$school_id AND tbl_exam_routine.exam_term_id=$term_id order by tbl_exam_routine.row_no, tbl_exam_routine.column_no";
		$query = $this->db->query($sql);
		$row= $query->result_array();
        return $row;
	}
	
	function get_old_exam_routine_by_term_download_class($school_id,$term_id)
	{
		$sql="SELECT distinct tbl_exam_routine.column_no, tbl_exam_routine.exam_time , tbl_exam_routine.class_id, tbl_class.class_name  FROM `tbl_exam_routine` inner join tbl_class on tbl_exam_routine.class_id = tbl_class.class_id WHERE tbl_exam_routine.school_id=$school_id AND tbl_exam_routine.exam_term_id=$term_id order by tbl_exam_routine.column_no, tbl_exam_routine.row_no";
		$query = $this->db->query($sql);
		$row= $query->result_array();
        return $row;
	}
	function get_old_exam_routine_by_term_download_day_date($school_id,$term_id)
	{
		$sql="SELECT distinct tbl_exam_routine.row_no, tbl_exam_routine.exam_day , tbl_exam_routine.exam_date FROM `tbl_exam_routine` WHERE tbl_exam_routine.school_id=$school_id AND tbl_exam_routine.exam_term_id=$term_id order by tbl_exam_routine.column_no, tbl_exam_routine.row_no";
		$query = $this->db->query($sql);
		$row= $query->result_array();
        return $row;
	}
	/********************* / exam routine ************************/

	/************** admit card *************/
	
	 function get_student_wise_admitcard_view($student_id)
    {           
        $sql = "SELECT * FROM tbl_admitcard WHERE student_id = $student_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }   
	
	 function get_exam_wise_class_list($school_id,$exam_term_id)
    {            
        $sql = "SELECT distinct tbl_class.class_id, tbl_class.class_name FROM tbl_class INNER JOIN tbl_exam_routine ON tbl_class.class_id = tbl_exam_routine.class_id WHERE tbl_exam_routine.school_id=$school_id AND tbl_exam_routine.exam_term_id=$exam_term_id";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
	
	function admit_card_view_school($school_id)
    {            
        $sql = "SELECT * FROM tbl_school_information WHERE school_id=$school_id limit 1";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
	
	
	 function admit_card_view_term($school_id, $term_id)
    {            
        $sql = "SELECT term FROM tbl_term WHERE school_id=$school_id AND term_id=$term_id limit 1";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
	
	 function admit_card_view_class($school_id, $class_id)
    {            
        $sql = "SELECT class_name FROM tbl_class WHERE school_id=$school_id AND class_id=$class_id limit 1";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
	
	function admit_card_view_section($school_id, $section_id)
    {            
        $sql = "SELECT section_name FROM tbl_section WHERE school_id=$school_id AND section_id=$section_id limit 1";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
	
	 function admit_card_view_student($school_id, $class_id, $section_id)
    {            
        $sql = "SELECT tbl_student.student_name , tbl_group.group_name, tbl_student_class.student_id FROM tbl_student_class INNER JOIN tbl_student ON tbl_student.student_id = tbl_student_class.student_id left JOIN tbl_group ON tbl_group.group_id = tbl_student_class.group_id WHERE tbl_student_class.school_id=$school_id AND tbl_student_class.class_id=$class_id AND tbl_student_class.section_id=$section_id";
		
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
	
	function admit_card_view_exam_date($school_id ,$term_id)
    {            
        $sql = "SELECT exam_date FROM tbl_exam_routine WHERE school_id = $school_id AND exam_term_id = $term_id order by exam_date limit 1";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
	
	function admit_card_view_teacher($school_id, $class_id, $section_id)
    {            
        $sql = "SELECT tbl_teacher_registration.teacher_name FROM tbl_teacher_registration INNER JOIN tbl_class_teacher_assign ON tbl_teacher_registration.teacher_id = tbl_class_teacher_assign.teacher_id WHERE tbl_class_teacher_assign.school_id = $school_id AND tbl_class_teacher_assign.section_id = $section_id AND tbl_class_teacher_assign.class_id = $class_id limit 1";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
	
	function admit_card_view_head_teacher($school_id)
    {            
        $sql = "SELECT teacher_name FROM tbl_teacher_registration WHERE school_id=$school_id AND designation_id=1 limit 1";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
	
	 function get_class_wise_student_list_admit($school_id, $class_id,$section_id)
    {           
        $sql = "SELECT * FROM tbl_student 
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id 
				inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id 
				inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id 
				where tbl_student.school_id = $school_id 
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.section_id = $section_id 
				order by tbl_student.student_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	/****************** / admit card *******************/
	
	/****************** result *******************/
	
	function get_class_wise_student_info_marksheet($school_id, $class_id,$section_id,$student_id,$shift_id,$group_id)
	{           
        $sql = "SELECT * FROM tbl_student 
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id 
				inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id 
				inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id
				inner join tbl_group on tbl_student_class.group_id = tbl_group.group_id
				inner join tbl_shift on tbl_student_class.shift_id = tbl_shift.shift_id  
				where tbl_student.school_id = $school_id 
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.section_id = $section_id
				and tbl_student_class.shift_id = $shift_id
				and tbl_student_class.group_id = $group_id
				and tbl_student_class.student_id = $student_id 
				order by tbl_student.student_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	function get_merk_distribution($school_id,$class_id,$group_id)
    {           
       $sql = "SELECT * FROM `tbl_mark_distribution` as A WHERE A.school_id = '$school_id' and A.class_id = '$class_id' and A.group_id='$group_id' and A.exam_type!=0 order by A.exam_type";
        $query = $this->db->query($sql);
         $row= $query->result_array();
        return $row;
    }
	
	function delete_tabulation_marks($school_id,$class_id,$section_id,$group_id,$term_id,$exam_year,$shift_id)
    {
		if($this->db->delete('tbl_tabulation_marks', array('school_id' => $school_id,'class_id' => $class_id, 'section_id' => $section_id, 'group_id' => $group_id,'shift_id' => $shift_id, 'term_id' => $term_id, 'exam_year'=>$exam_year)))
			{
				return TRUE;
			}
		else
			{
				return FALSE;
			}             
      
    }
	
	/****************** / result *******************/
	
	/****************** subject wise marks *******************/
	
	function subject_wise_total_marks($school_id)
    {           
        //$sql = "SELECT * FROM `tbl_subject_wise_total_marks` as A INNER JOIN tbl_class ON A.class_id = tbl_class.class_id INNER JOIN tbl_section ON A.section_id= tbl_section.section_id INNER JOIN tbl_subject ON tbl_subject.subject_id = A.subject_id INNER JOIN tbl_term ON tbl_term.term_id = A.term_id WHERE A.school_id = $school_id ORDER BY A.subject_marks_id ASC";
		$sql = "SELECT * FROM `tbl_subject_wise_total_marks` as A INNER JOIN tbl_class ON A.class_id = tbl_class.class_id INNER JOIN tbl_subject ON tbl_subject.subject_id = A.subject_id inner join tbl_group as g on A.group_id=g.group_id inner join tbl_term as t on A.term_id=t.term_id WHERE A.school_id = $school_id ORDER BY A.subject_marks_id ASC";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	function subject_wise_total_marks_by_id($school_id,$subject_marks_id)
    {           
		$sql = "SELECT * FROM `tbl_subject_wise_total_marks` as A WHERE A.school_id = '$school_id' and A.subject_marks_id= '$subject_marks_id' limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
	
	function subject_wise_total_marks_class_wise($school_id,$sub_id,$class_id)
	{
		$sql = "SELECT * FROM `tbl_subject_wise_total_marks` as A WHERE A.school_id = '$school_id' and A.subject_id= '$sub_id' and A.class_id= '$class_id' limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
	}
	/*function subject_wise_total_marks_class_wise_result($school_id,$class_id)
	{
		$sql = "SELECT * FROM `tbl_subject_wise_total_marks` as A WHERE A.school_id = '$school_id' and A.class_id= '$class_id' order by subject_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
	}*/
	/****************** / subject wise marks *******************/
	
	/****************** term subject *******************/
	
	function get_term_subject_list($school_id)
    {           
        $sql = "SELECT * FROM `tbl_term_subject` as A INNER JOIN tbl_class ON A.class_id = tbl_class.class_id INNER JOIN tbl_group ON A.group_id= tbl_group.group_id INNER JOIN tbl_subject ON tbl_subject.subject_id = A.subject_id INNER JOIN tbl_term ON tbl_term.term_id = A.term_id WHERE A.school_id = $school_id ORDER BY A.class_id ASC, tbl_subject.subject_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	 function get_term_subject_info_by_id($school_id, $ts_id)
    {           
        $sql = "SELECT * FROM `tbl_term_subject` as A INNER JOIN tbl_class ON A.class_id = tbl_class.class_id INNER JOIN tbl_group ON A.group_id = tbl_group.group_id INNER JOIN tbl_subject ON tbl_subject.subject_id = A.subject_id INNER JOIN tbl_term ON tbl_term.term_id = A.term_id WHERE A.school_id = $school_id  and A.id = $ts_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
	/****************** / term subject *******************/
	
	function get_mark_dis_info($school_id, $class_id,$group_id)
    {           
        $sql = "SELECT * FROM `tbl_mark_distribution` as A WHERE A.school_id = $school_id and A.class_id = $class_id and A.group_id = $group_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
		function get_mark_dis_info_subject_wise($school_id, $class_id,$group_id,$subject_id)
    {           
        $sql = "SELECT * FROM `tbl_mark_distribution` as A WHERE A.school_id = $school_id and A.class_id = $class_id and A.group_id = $group_id and A.subject_id = $subject_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	function get_subject_info($school_id, $subject_id)
    {           
        $sql = "SELECT * FROM `tbl_subject` as A WHERE A.school_id = $school_id and A.subject_id = $subject_id limit 1";
        $query = $this->db->query($sql);
         $row= $query->row_array();
        return $row;
    }
	/*********** ca ***************/
	
	function delete_ca_info($school_id, $class_id,$section_id,$group_id,$term_id,$exam_year,$subject_id)
    {     
		 $sql = "DELETE FROM `tbl_ca_marks` WHERE school_id = $school_id and class_id = $class_id and section_id = $section_id and group_id = $group_id and exam_year='$exam_year' and subject_id = '$subject_id' and term_id=$term_id";
        $this->db->query($sql);
        return true;      
        
    }
	
	/********** /ca ************/
	
	function get_shift_list($school_id){
      $sql = "SELECT * FROM `tbl_shift` ORDER BY shift_id asc";
	  $query = $this->db->query($sql);
      $row= $query->result_array();
	  return $row;
	}
	function subject_info_for_tabulation_sheet_subject_wise($school_id,$term_id,$exam_year,$class_id,$section_id,$subject_id)
	{
      $sql = "SELECT * FROM tbl_subject 
	  									inner join tbl_term_marks on tbl_term_marks.sub_id = tbl_subject.subject_id 
										inner join tbl_class on tbl_class.class_id = tbl_term_marks.class_id 
										inner join tbl_section on tbl_section.section_id = tbl_term_marks.section_id
										inner join tbl_group on tbl_group.group_id = tbl_term_marks.group_id 
										inner join tbl_shift on tbl_shift.shift_id = tbl_term_marks.shift_id
										inner join tbl_term on tbl_term.term_id = tbl_term_marks.term_id 
										inner join tbl_mark_distribution on tbl_mark_distribution.subject_id = tbl_subject.subject_id 
										where tbl_term_marks.term_id='$term_id' 
										and tbl_term_marks.exam_year='$exam_year' 
										and tbl_term_marks.class_id='$class_id' 
										and tbl_term_marks.section_id='$section_id' 
										and tbl_term_marks.sub_id='$subject_id' 
										and tbl_term_marks.school_id='$school_id' 
										order by tbl_subject.subject_id limit 1";
	  $query = $this->db->query($sql);
      $row= $query->result_array();
	  return $row;
	}
	
	function get_gpa_list($school_id)
	{
		$sql = "SELECT * FROM tbl_grd_system where tbl_grd_system.school_id=$school_id ORDER BY tbl_grd_system.type_id asc,tbl_grd_system.start_marks desc";
	  $query = $this->db->query($sql);
      $row= $query->result_array();
	  return $row;
	}
	
	function get_gpa_list_id($id)
	{
		$sql = "SELECT * FROM tbl_grd_system where tbl_grd_system.id=$id";
	    $query = $this->db->query($sql);
        $row= $query->row_array();
	    return $row;
	}
	
	function delete_gpa_info($school_id,$class_id)
    {     
		 $sql = "DELETE FROM `tbl_grd_system` WHERE school_id = $school_id and class_id = $class_id";
        $this->db->query($sql);
        return true;      
        
    }
	
	
	
	 function get_group_info_by_id($school_id, $group_id)
    {           
        $sql = "SELECT * FROM tbl_group where school_id = $school_id and group_id = $group_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
	
	
	
	function get_ct_mark_status($school_id,$class_id,$section_id,$group_id,$shift_id,$term_id,$exam_year,$subject_id)
	{
		$sql = "SELECT status as status FROM tbl_ct_marks where WHERE `school_id` = '$school_id' AND `class_id` = '$class_id' AND `section_id` = '$section_id' AND `group_id` = '$group_id' AND `shift_id` = '$shift_id' AND `term_id` = '$term_id' AND `exam_year` = '$exam_year' AND `subject_id` = '$subject_id' limit 1";
	    $query = $this->db->query($sql);
        $row= $query->row_array();
	    return $row;
	}
}