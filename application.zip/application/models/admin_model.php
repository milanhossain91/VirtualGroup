<?php

if(!defined('BASEPATH'))
    exit('No direct script access allowed');

class Admin_model extends CI_Model
{
    function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }

    /**For Admin Login Portion**/
  function login_check($data)
    {
	$this->db->from('tbl_login');
        $this->db->where($data);
        $query = $this->db->get();
        $result = $query->row_array();
        return $result;
    }
    
    /**For Teacher Management**/
    function get_teacher_list($school_id)
    {           
        $sql = "SELECT * FROM tbl_teacher_registration where school_id = $school_id order by teacher_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_teacher_list_list($school_id)
    {           
        $sql = "SELECT `tbl_teacher_registration`.teacher_name,`tbl_teacher_registration`.department_id,`tbl_teacher_registration`.joining_date,`tbl_teacher_registration`.designation_id,`tbl_teacher_registration`.teacher_id,`tbl_teacher_registration`.present_contact,`tbl_teacher_registration`.teacher_image, tbl_department.department_name,tbl_designation.designation_name FROM `tbl_teacher_registration` left join tbl_designation on tbl_teacher_registration.designation_id=tbl_designation.designation_id left join tbl_department on tbl_teacher_registration.department_id=tbl_department.department_id where `tbl_teacher_registration`.school_id = $school_id order by `tbl_teacher_registration`.designation_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_teacher_info($school_id, $teacher_id)
    {           
        $sql = "SELECT * FROM tbl_teacher_registration where school_id = $school_id and teacher_id = $teacher_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    function delete_teacher_by_id($teacher_id, $school_id)
    {		
        $sql = "DELETE FROM `tbl_teacher_registration` WHERE `teacher_id` = $teacher_id AND school_id = $school_id";
        $this->db->query($sql);
        return true;
    }
    
    function get_appoint_list($school_id)
    {           
        $sql = "SELECT * FROM tbl_appointment inner join tbl_teacher_registration on tbl_appointment.teacher_id = tbl_teacher_registration.teacher_id inner join tbl_department on tbl_teacher_registration.department_id = tbl_department.department_id inner join tbl_designation on tbl_teacher_registration.designation_id = tbl_designation.designation_id where tbl_appointment.school_id = $school_id order by tbl_appointment.appointment_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
	function get_teacher_dept_short_name($school_id)
    {           
        $sql = "SELECT * FROM tbl_teacher_registration inner join tbl_department on tbl_teacher_registration.department_id = tbl_department.department_id inner join tbl_designation on tbl_teacher_registration.designation_id = tbl_designation.designation_id where tbl_teacher_registration.school_id = $school_id order by tbl_teacher_registration.teacher_id ASC";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
    function get_appoint_list_by_id($school_id, $appointment_id)
    {           
        $sql = "SELECT * FROM tbl_appointment inner join tbl_teacher_registration on tbl_appointment.teacher_id = tbl_teacher_registration.teacher_id inner join tbl_department on tbl_teacher_registration.department_id = tbl_department.department_id inner join tbl_designation on tbl_teacher_registration.designation_id = tbl_designation.designation_id where tbl_appointment.appointment_id = $appointment_id and tbl_appointment.school_id = $school_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    
    function get_teacher_salary_stucture_list($school_id)
    {           
        $sql = "SELECT DISTINCT(tbl_teacher_salary.teacher_id), tbl_teacher_registration.teacher_name, tbl_department.department_name, tbl_designation.designation_name FROM tbl_teacher_salary left join tbl_teacher_registration on tbl_teacher_salary.teacher_id = tbl_teacher_registration.teacher_id left join tbl_department on tbl_teacher_registration.department_id = tbl_department.department_id inner join tbl_designation on tbl_teacher_registration.designation_id = tbl_designation.designation_id where tbl_teacher_salary.school_id = $school_id order by tbl_teacher_salary.teacher_salary_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_teacher_salary_stucture_by_id($teacher_id)
    {           
        $sql = "SELECT tbl_teacher_salary.teacher_salary_id,tbl_salary_cat.id,tbl_salary_cat.salary_particulars,tbl_salary_cat.effect,tbl_teacher_salary.amount FROM tbl_teacher_salary inner join tbl_salary_cat on tbl_teacher_salary.`salary_particulars` = tbl_salary_cat.id where tbl_teacher_salary.teacher_id = $teacher_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    
    
    /**For Student Management**/
    function get_section_list_by_id($class_id, $school_id)
    {            
        $sql = "SELECT tbl_section.section_id, tbl_section.section_name FROM tbl_section INNER JOIN tbl_class_section ON tbl_section.section_id = tbl_class_section.section_id WHERE tbl_class_section.school_id=$school_id AND tbl_class_section.class_id=$class_id;";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
    
    function get_sub_list_by_id($class_id, $school_id)
    {  
        //SELECT * FROM `tbl_class_subject` cs INNER JOIN `tbl_subject` s ON cs.subject_id = s.subject_id
        $sql = "SELECT * FROM `tbl_class_subject` cs INNER JOIN `tbl_subject` s ON cs.subject_id = s.subject_id WHERE cs.school_id=$school_id AND cs.class_id=$class_id order by s.subject_id";
        $query = $this->db->query($sql);
        $res = $query->result_array();
        return $res;        
    }
    
    function get_latest_id_number($school_id)
    {            
        $sql = "SELECT id FROM tbl_student WHERE school_id = $school_id order by id desc limit 1";
        $query = $this->db->query($sql);
        $res = $query->row_array();
        return $res;        
    }
    
    function get_class_no_by_id($school_id, $class_id)
    {            
        $sql = "SELECT class_short_form FROM tbl_class WHERE school_id = $school_id AND class_id = $class_id limit 1";
        $query = $this->db->query($sql);
        $res = $query->row_array();
        return $res;        
    }
      
    function get_all_student_list($school_id,$where)
    {           
        $sql = "SELECT * FROM tbl_student inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id where tbl_student.school_id = $school_id $where order by tbl_student_class.class_id,tbl_student_class.roll_no asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_student_info_by_id($school_id, $student_id)
    {           
        $sql = "SELECT * FROM tbl_student inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id inner join tbl_session on tbl_student_class.session_id = tbl_session.session_id where tbl_student.school_id = $school_id and tbl_student.student_id = $student_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    public function get_class_wise_student_list($school_id, $class_id)
    {           
        $sql = "SELECT * FROM tbl_student 
				inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id 
				inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id 
				inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id 
				where tbl_student.school_id = $school_id 
				and tbl_student_class.class_id = $class_id 
				order by tbl_student.student_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
    function get_class_wise_student_count($school_id, $class_id)
    {           
        $sql = "SELECT count(student_id) as count from tbl_student_class where school_id = $school_id and class_id = $class_id";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
	

    
    function get_section_wise_student_list($school_id, $class_id, $section_id)
    {           
        $sql = "SELECT * FROM tbl_student inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id inner join tbl_class on tbl_student_class.class_id = tbl_class.class_id inner join tbl_section on tbl_student_class.section_id = tbl_section.section_id where tbl_student.school_id = $school_id and tbl_student_class.class_id = $class_id and tbl_student_class.section_id = $section_id order by tbl_student.student_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	function get_class_list_sub_assign($school_id)
    {           
        $sql = "SELECT distinct(tbl_class_subject.class_id), tbl_class.class_name FROM tbl_class
left join tbl_class_subject on tbl_class_subject.class_id=tbl_class.class_id
LEFT JOIN tbl_subject on tbl_subject.subject_id=tbl_class_subject.subject_id
where tbl_class.school_id=$school_id AND tbl_subject.is_optional = 1 order by tbl_class.class_short_form ASC";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
	
	function get_student_list_for_subject_assign_json($school_id, $class_id, $group_id, $session_id)
    {           
        $sql = "SELECT tbl_student.student_id, tbl_student.student_name FROM tbl_student inner join tbl_student_class on tbl_student.student_id = tbl_student_class.student_id
				where tbl_student.school_id = $school_id
				and tbl_student_class.class_id = $class_id
				and tbl_student_class.group_id = $group_id
				and tbl_student_class.session_id = $session_id order by tbl_student.student_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_section_wise_student_count($school_id, $class_id, $section_id)
    {           
        $sql = "SELECT count(student_id) as count from tbl_student_class where school_id = $school_id and class_id = $class_id and section_id = $section_id";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    
    
    function get_class_wise_subject_for_subect_assign($school_id, $class_id, $group_id)
    {           
        $sql = "SELECT * FROM tbl_class_subject INNER JOIN tbl_subject on tbl_class_subject.subject_id = tbl_subject.subject_id WHERE tbl_class_subject.school_id = $school_id AND tbl_class_subject.class_id = $class_id AND tbl_class_subject.group_id = $group_id AND tbl_subject.is_optional=1";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    
    function get_class_wise_optional_subject_subject_list($school_id, $class_id)
    {           
        $sql = "SELECT * FROM tbl_class_subject INNER JOIN tbl_subject on tbl_class_subject.subject_id = tbl_subject.subject_id WHERE tbl_class_subject.school_id = $school_id AND tbl_class_subject.class_id = $class_id AND tbl_subject.is_optional=1";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_student_subject_view($school_id, $class_id, $group_id, $session_id)
    {           
        $sql = "SELECT tbl_student_subject.student_id,tbl_student.student_name, tbl_student_subject.session_id,
				GROUP_CONCAT(if(tbl_student_subject.optional_id=1,tbl_subject.subject_name,'')) as opt,
				GROUP_CONCAT(if(tbl_student_subject.optional_id=0,tbl_subject.subject_name,'')) as com
				FROM tbl_student_subject 
				INNER JOIN tbl_student ON tbl_student_subject.student_id = tbl_student.student_id 
				INNER JOIN tbl_subject ON tbl_student_subject.subject_id = tbl_subject.subject_id 
				WHERE tbl_student_subject.school_id = $school_id AND
					  tbl_student_subject.class_id = $class_id AND
					  tbl_student_subject.group_id = $group_id AND
					  tbl_student_subject.session_id = $session_id
					  group by tbl_student_subject.student_id ORDER BY tbl_student_subject.student_id ASC";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_subject_info_by_student_id($school_id,$student_id,$class_id,$group_id,$session_id)
    {           
        $sql = "SELECT tbl_student_subject.student_id,tbl_student.student_name,
				GROUP_CONCAT(if(tbl_student_subject.optional_id=1,tbl_subject.subject_id,'')) as opt,
				GROUP_CONCAT(if(tbl_student_subject.optional_id=0,tbl_subject.subject_id,'')) as com
				FROM tbl_student_subject 
				INNER JOIN tbl_student ON tbl_student_subject.student_id = tbl_student.student_id 
				INNER JOIN tbl_subject ON tbl_student_subject.subject_id = tbl_subject.subject_id 
				WHERE tbl_student_subject.school_id = $school_id AND
					  tbl_student_subject.student_id = $student_id AND
					  tbl_student_subject.class_id = $class_id AND
					  tbl_student_subject.group_id = $group_id AND
					  tbl_student_subject.session_id = $session_id
					  group by tbl_student_subject.student_id ORDER BY tbl_student_subject.student_id ASC";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
      
    /**Setings Portion**/
	
    function get_class_list($school_id)
    {           
        $sql = "SELECT * FROM tbl_class where school_id = $school_id order by class_short_form asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_class_info_by_id($school_id, $class_id)
    {           
        $sql = "SELECT * FROM tbl_class where school_id = $school_id and class_id = $class_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    /**Section**/
    function get_section_list($school_id){           
        $sql = "SELECT * FROM tbl_section where school_id = $school_id order by section_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_section_info_by_id($school_id, $section_id){
        $sql = "SELECT * FROM tbl_section where school_id = $school_id and section_id = $section_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    function delete_record($class_id,$school_id){
        $sql = "DELETE FROM `tbl_class_section` WHERE `class_id` = $class_id AND school_id = $school_id";
        $this->db->query($sql);
        return true;
    }
    
    /**Session**/
    function get_session_list($school_id){
        $sql = "SELECT * FROM tbl_session where school_id = $school_id order by session_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_session_info_by_id($school_id, $session_id){
        $sql = "SELECT * FROM tbl_session where school_id = $school_id and session_id = $session_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    /**Group**/
    function get_group_list($school_id){
        $sql = "SELECT * FROM tbl_group WHERE school_id = $school_id ORDER BY group_id ASC";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    /**voucher list **/
    function get_voucher_list($school_id){
        $sql = "SELECT * FROM tbl_vouchers WHERE school_id = $school_id AND tttype ='debit' AND status ='1' ORDER BY voucher_id ASC";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    function get_credit_voucher_list($school_id){
        $sql = "SELECT * FROM tbl_vouchers WHERE school_id = $school_id AND tttype ='credit' AND status ='1' ORDER BY voucher_id ASC";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_voucher_info_by_id($school_id, $voucher_id){
        $sql = "SELECT * FROM tbl_vouchers WHERE school_id = $school_id and voucher_id = $voucher_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    /** /voucher list ***/
    
    /**Department**/
    function get_department_list($school_id){
        $sql = "SELECT * FROM tbl_department where school_id = $school_id order by department_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_department_info_by_id($school_id, $department_id){
        $sql = "SELECT * FROM tbl_department where school_id = $school_id and department_id = $department_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    /**Shift**/
    function get_shift_list($school_id){
        $sql = "SELECT * FROM tbl_shift where school_id = $school_id order by shift_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_shift_info_by_id($school_id, $shift_id){
        $sql = "SELECT * FROM tbl_shift where school_id = $school_id and shift_id = $shift_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    /**Subject**/
    function get_subject_list($school_id){
        $sql = "SELECT * FROM tbl_subject where school_id = $school_id order by subject_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_subject_info_by_id($school_id, $subject_id){
        $sql = "SELECT * FROM tbl_subject where school_id = $school_id and subject_id = $subject_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    /**Designation**/
    
    function get_designation_list($school_id){
        $sql = "SELECT * FROM tbl_designation where school_id = $school_id order by designation_id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
    }
    
    function get_designation_info_by_id($school_id, $designation_id){
        $sql = "SELECT * FROM tbl_designation where school_id = $school_id and designation_id = $designation_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }
    
    
    /**Institute Information**/
    
    function get_school_information($school_id){
        $sql = "SELECT * FROM tbl_school_information where school_id = $school_id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }

	/* class teacher assign  */  

	public function get_class_teacher_list($school_id){
        $sql = "SELECT tbl_class_teacher_assign.id AS `id`, tbl_class_teacher_assign.school_id AS `school_id`, tbl_teacher_registration.teacher_name AS `teacher_name`, tbl_class.class_name AS `class_name`, tbl_section.section_name AS `section_name` FROM tbl_class_teacher_assign inner join tbl_teacher_registration on tbl_class_teacher_assign.teacher_id = tbl_teacher_registration.teacher_id inner join tbl_class on tbl_class_teacher_assign.class_id = tbl_class.class_id inner join tbl_section on tbl_class_teacher_assign.section_id = tbl_section.section_id where tbl_class_teacher_assign.school_id = $school_id";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
	}

	public function get_class_teacher_list_limit($school_id,$id)      
    {           
        $sql = "SELECT * FROM tbl_class_teacher_assign where school_id = $school_id and id = $id limit 1";
        $query = $this->db->query($sql);
        $row= $query->row_array();
        return $row;
    }

	/* weekly holiday */
	
	public function get_week_list($school_id)
	{
		$sql = "SELECT * FROM tbl_weekdays where school_id = $school_id ";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;
	}
  /* Website */


    public function mechanical_support_get_all(){

        $sql = "SELECT * FROM tbl_mechanical_support order by id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;

    }

    public function mechanical_support_edit_get_all($op_id){

        $sql = "SELECT * FROM tbl_mechanical_support where id = $op_id order by id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;

    }

    public function spares_stores_get_all(){

        $sql = "SELECT * FROM tbl_spares_stores order by id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;

  
    }

    public function equipment_rental_get_all(){

        $sql = "SELECT * FROM tbl_equipment_rental order by id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;

      

    }

   public function service_center_get_all(){

        $sql = "SELECT * FROM tbl_service_center order by id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;

      

    }

  public function portfolio_get_all(){

        $sql = "SELECT * FROM tbl_portfolio order by id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;

      

    }

    public function products_get_all(){

        $sql = "SELECT * FROM products order by id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;

      

    }
    public function csr_get_all(){

        $sql = "SELECT * FROM tbl_csr order by id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;

      

    }

    public function blog_get_all(){

        $sql = "SELECT * FROM tbl_blog order by id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;

      

    }

    public function career_get_all(){

        $sql = "SELECT * FROM tbl_career order by id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;

      

    }

    public function virtual_constructionltd_get_all(){

        $sql = "SELECT * FROM tbl_virtual_constructionltd order by id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;

      

    }

    public function virtual_constructionltd_get_all_view(){

        $sql = "SELECT * FROM tbl_virtual_constructionltd LIMIT 1";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;

      

    }


    public function virtual_ready_mix_get_all(){

        $sql = "SELECT * FROM tbl_virtual_ready_mix order by id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;

      

    }

   public function virtual_ready_mix_get_all_view(){

        $sql = "SELECT * FROM tbl_virtual_ready_mix LIMIT 1";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;

      

    }

   public function virtual_marketing_tradingco_get_all(){

        $sql = "SELECT * FROM tbl_virtual_marketing_tradingco order by id asc";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;

      

    }

   public function virtual_marketing_tradingco_get_all_view(){

        $sql = "SELECT * FROM tbl_virtual_marketing_tradingco LIMIT 1";
        $query = $this->db->query($sql);
        $row= $query->result_array();
        return $row;

      

    }

  public function welcome_to_virtual_properties_ltd_get_all(){

     $sql = "SELECT * FROM tbl_welcome_to_virtual_properties_ltd order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

 public function welcome_to_virtual_properties_ltd_get_all_view(){

     $sql = "SELECT * FROM tbl_welcome_to_virtual_properties_ltd LIMIT 1";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }


    public function schwing_stetter_get_all(){

     $sql = "SELECT * FROM tbl_schwing_stetter order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

  public function soilmec_get_all(){

     $sql = "SELECT * FROM tbl_soilmec order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

  public function corporate_office_get_all(){

     $sql = "SELECT * FROM tbl_corporate_office order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

  public function branch_office_get_all(){

     $sql = "SELECT * FROM tbl_branch_office order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

 public function md_message_get_all(){

     $sql = "SELECT * FROM tbl_md_message order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

   public function spares_stores_edit_get_all($op_id){

     $sql = "SELECT * FROM tbl_spares_stores where id = $op_id order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

  public function equipment_rental_edit_get_all($op_id){

     $sql = "SELECT * FROM tbl_equipment_rental where id = $op_id order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

    public function service_center_edit_get_all($op_id){

     $sql = "SELECT * FROM tbl_service_center where id = $op_id order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

  public function portfolio_edit_get_all($op_id){

     $sql = "SELECT * FROM tbl_portfolio where id = $op_id order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

  public function products_edit_get_all($op_id){

     $sql = "SELECT * FROM products where id = $op_id order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

 public function csr_edit_get_all($op_id){

     $sql = "SELECT * FROM tbl_csr where id = $op_id order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

  public function blog_edit_get_all($op_id){

     $sql = "SELECT * FROM tbl_blog where id = $op_id order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

    public function md_message_edit_get_all($op_id){

     $sql = "SELECT * FROM tbl_md_message where id = $op_id order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }



  public function blog_get_all_view(){

    $sql = "SELECT * FROM tbl_blog LIMIT 3";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

  public function career_edit_get_all($op_id){

     $sql = "SELECT * FROM tbl_career where id = $op_id order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

  public function virtual_constructionltd_edit_get_all($op_id){

     $sql = "SELECT * FROM tbl_virtual_constructionltd where id = $op_id order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

 public function virtual_ready_mix_edit_get_all($op_id){

     $sql = "SELECT * FROM tbl_virtual_ready_mix where id = $op_id order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

   public function virtual_marketing_tradingco_edit_get_all($op_id){

     $sql = "SELECT * FROM tbl_virtual_marketing_tradingco where id = $op_id order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

    public function virtual_properties_ltd_edit_get_all($op_id){

     $sql = "SELECT * FROM tbl_welcome_to_virtual_properties_ltd where id = $op_id order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

    public function schwing_stetter_edit_get_all($op_id){

     $sql = "SELECT * FROM tbl_schwing_stetter where id = $op_id order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

 public function soilmec_edit_get_all($op_id){

     $sql = "SELECT * FROM tbl_soilmec where id = $op_id order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }

  public function corporate_office_edit_get_all($op_id){

     $sql = "SELECT * FROM tbl_corporate_office where id = $op_id order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }


  public function branch_office_edit_get_all($op_id){

     $sql = "SELECT * FROM tbl_branch_office where id = $op_id order by id asc";
     $query = $this->db->query($sql);
     $row= $query->result_array();
     return $row;

  }






}
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         