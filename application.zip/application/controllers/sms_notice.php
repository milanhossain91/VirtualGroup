<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Sms_notice extends CI_Controller {

    public function __construct()
        {            
            session_start();
            parent::__construct();
            $this->load->helper('form');
            $this->load->helper('url');
            $this->load->model('admin_model', 'Admin_model', true);
            $this->load->model('common_model', 'Common_model', true);
           if(!is_loggedin())
            {
               redirect('login');
               exit;
            }
					
        }
	
	/* Students sms notice */
	
	public function student_sms(){
            #$school_id = $_SESSION['school_id'];
        $school_id = 1;
		$data['shift_list'] = $this->Admin_model->get_shift_list($school_id);
		$data['class_list'] = $this->Admin_model->get_class_list($school_id);
		$data['group_list'] = $this->Admin_model->get_group_list($school_id);
		$where='';
		if($_POST['class_id']){
			if($_POST['class_id']!="all"){
				$this->session->set_userdata('class_id', $_POST['class_id']);
			}
			elseif($_POST['class_id']=="all"){
				$this->session->unset_userdata('class_id');
				$this->session->unset_userdata('section_id');
				$this->session->unset_userdata('group_id');
			}
		}
		if($_POST['section_id']){
			
			if($_POST['section_id']!="all"){
				$this->session->set_userdata('section_id', $_POST['section_id']);
			}
			elseif($_POST['section_id']=="all"){
				$this->session->unset_userdata('section_id');
			}
		}
		if($_POST['group_id']){
			
			if($_POST['group_id']!="all"){
				$this->session->set_userdata('group_id', $_POST['group_id']);
			}
			elseif($_POST['group_id']=="all"){
				$this->session->unset_userdata('group_id');
			}
		}
		if($_POST['shift_id']){
			
			if($_POST['shift_id']!="all"){
				$this->session->set_userdata('shift_id', $_POST['shift_id']);
			}
			elseif($_POST['shift_id']=="all"){
				$this->session->unset_userdata('shift_id');
			}
		}
		if($_POST['gender_id']){
			
			if($_POST['gender_id']!="all"){
				$this->session->set_userdata('gender_id', $_POST['gender_id']);
			}
			elseif($_POST['gender_id']=="all"){
				$this->session->unset_userdata('gender_id');
			}
		}
		
		if($this->session->userdata('class_id'))
			$where.=' and tbl_student_class.class_id='.$this->session->userdata('class_id').' ';
		
		if($this->session->userdata('section_id'))
			$where.=' and tbl_student_class.section_id='.$this->session->userdata('section_id').' ';
		
		if($this->session->userdata('group_id'))
			$where.=' and tbl_student_class.group_id='.$this->session->userdata('group_id').' ';

		if($this->session->userdata('shift_id'))
			$where.=' and tbl_student_class.shift_id='.$this->session->userdata('shift_id').' ';

		if($this->session->userdata('gender_id'))
			$where.=' and tbl_student.gender="'.$this->session->userdata('gender_id').'" ';
		
        $data['student_list'] = $this->Admin_model->get_all_student_list($school_id,$where);
        $this->load->view('sms_notice/student_sms', $data);
    }
	
    public function student_sms_notice(){
        $phone = json_encode($_POST['student_cont']);
        $msg_text = json_encode($_POST['msg']);
	
                if($phone=='null'){
			$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>SMS has not been sent. No phone number was selected.</div>');
		}
		elseif($msg_text==''){
			$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>SMS has not been sent. No message was written.</div>');
		}
		else{
			$return=$this->send_sms_notice_all($phone,$msg_text);
		
			if($return=='error'){
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>SMS has not been sent. Please try again.</div>');
			}
			else{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>'.$return.' SMS has been sent.</div>');
			}
		}

		redirect('sms_notice/student_sms');exit;
    }
    /* Students sms notice end */
    /* Teacher sms notice */
    public function teacher_sms(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['teacher_list'] = $this->Admin_model->get_teacher_list_list($school_id);
		$data['appoint_list'] = $this->Admin_model->get_teacher_dept_short_name($school_id);
        $this->load->view('sms_notice/teacher_sms', $data);
    }
    
    public function teacher_sms_notice(){
        $phone = json_encode($_POST['sms_contact']);
	//print_r($phone);
        $msg_text = json_encode($_POST['msg']);  
//print_r($phone);print_r($msg_text);die();
	if($phone=='null'){
			$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>SMS has not been sent. No phone number was selected.</div>');
		}
		elseif($msg_text==''){
			$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>SMS has not been sent. No message was written.</div>');
		}
		else{
			$return=$this->send_sms_notice_all($phone,$msg_text);
		//print_r($return); die();
			if($return=='error'){
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>SMS has not been sent. Please try again.</div>');
			}
			else{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>'.$return.' SMS has been sent.</div>');
			}
		}

		redirect('sms_notice/teacher_sms');exit;
    }
    /* /managing_committee_sms */
	public function managing_committee_sms(){
        $data1['member_list'] = $this->Common_model->common_result_array('tbl_managing_committee');
        $this->load->view('sms_notice/managing_committee_sms',$data1);
    }
	    public function managing_committee_sms_notice(){
        $phone = json_encode($_POST['mang_cont']);
        $msg_text = json_encode($_POST['msg']);

	        if($phone=='null'){
			$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>SMS has not been sent. No phone number was selected.</div>');
		}
		elseif($msg_text==''){
			$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>SMS has not been sent. No message was written.</div>');
		}
		else{
			$return=$this->send_sms_notice_all($phone,$msg_text);
		
			if($return=='error'){
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>SMS has not been sent. Please try again.</div>');
			}
			else{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>'.$return.' SMS has been sent.</div>');
			}
		}

		redirect('sms_notice/managing_committee_sms');exit;
    }
    /* managing_committee_sms end */
	/* /Donor_sms */
	public function donor_sms(){
        $data['donor_list'] = $this->Common_model->common_result_array('tbl_donor');
        $this->load->view('sms_notice/donor_sms',$data);
    }
	    public function donor_sms_notice(){
        $phone = json_encode($_POST['donor_cont']);
        $msg_text = json_encode($_POST['msg']);

		if($phone=='null'){
			$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>SMS has not been sent. No phone number was selected.</div>');
		}
		elseif($msg_text==''){
			$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>SMS has not been sent. No message was written.</div>');
		}
		else{
			$return=$this->send_sms_notice_all($phone,$msg_text);
		
			if($return=='error'){
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>SMS has not been sent. Please try again.</div>');
			}
			else{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>'.$return.' SMS has been sent.</div>');
			}
		}

		redirect('sms_notice/donor_sms');exit;
    }
    /* donor_sms end */
    
    /* sent sms api */
    public function send_sms_notice_all($phone,$msg_text){
       
		$curl = curl_init();
		curl_setopt_array($curl, array(
		CURLOPT_URL => "http://107.20.199.106/restapi/sms/1/text/single",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_ENCODING => "",
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "POST",
		CURLOPT_POSTFIELDS => '{ "from":"MMLHS", "to":'.$phone.', "text":'.$msg_text.' }',
		CURLOPT_HTTPHEADER => array(
		"accept: application/json",
		"authorization: Basic d2VibGluazI6VWJ4dlNMeHU=",
		"content-type: application/json"
		),
		));
		$response = curl_exec($curl);
		$err = curl_error($curl);
		curl_close($curl);
		if ($err) {
		echo "cURL Error #:" . $err;
		return "cURL Error #:" .$err;//'error';
		} else {
			$arr=json_decode($response,true);
			$total_sms=0;
			foreach($arr['messages'] as $msg){
				$sms_data[] = array(
					'sms_datas' => $msg['messageId'],
					'mobile' => $msg['to'],
					'sms_count' => $msg['smsCount'],
					'created_on' => date('Y-m-d H:i:s',time())
				);
				$total_sms+=$msg['smsCount'];
			}
			$this->Common_model->common_insert_batch($sms_data,'tbl_notice_sms');
			return $total_sms;
		}
		
		
    }
    
    /* /Students sms notice */
}

?>