<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Guardian_panel extends CI_Controller {

    public function __construct(){
		
		parent::__construct();
		$this->load->helper('form');
		$this->load->helper('url');
		$this->load->model('academic_model', 'Academic_model', true);
		$this->load->model('result_model', 'Result_model', true);
		$this->load->model('admin_model', 'Admin_model', true);
		$this->load->model('common_model', 'Common_model', true);
		$this->load->library('form_validation');
	}
	function index(){
		$this->load->view('home/guardian_panle');
	}
	public function student_data()
    {
         #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $student_id = $_SESSION['student_id'];
        $data['school_info'] = $this->Admin_model->get_school_information($school_id);
        $data['student_info'] = $this->Admin_model->get_student_info_by_id($school_id, $student_id);
		$data['student_exam_info'] = $this->Common_model->common_select_by_condition($student_id,'student_id','tbl_student_board_exam');
        $data['class_list'] = $this->Admin_model->get_class_list($school_id);
        $data['group_list'] = $this->Admin_model->get_group_list($school_id);
		$data['shift_list'] = $this->Admin_model->get_shift_list($school_id);
		$data['division_list'] = $this->Common_model->common_result_array('tbl_divisions');
		$data['district_list'] = $this->Common_model->common_result_array('tbl_districts');
		$data['upazila_list'] = $this->Common_model->common_result_array('tbl_upazilas');
		$data['fees_list'] = $this->Common_model->common_result_array('tbl_fees_category');
        
            $mainContent=$this->load->view('home/student_information_view', $data, true);
			
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }

	public function subject_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$group_id = $_POST['group_id'];
        
		//$sectionInfo = $this->Admin_model->get_section_list_by_id($class_id, $school_id); 
        $subInfo = $this->Academic_model->get_sub_list_by_id($class_id, $school_id,$group_id); 
        
		$str = '<option value="">----Select Subject----</option>';
        
		if($subInfo)
        {
           foreach($subInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['subject_id']."'>".$sInfo['subject_name']."</option>";
           }
        }
        echo $str;exit;
    }
	
	function group_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
        $sectionInfo = $this->Academic_model->get_group_list_by_id($class_id, $school_id); 
        $str = '<option value="">----Select Group----</option>';
        if($sectionInfo)
        {
           foreach($sectionInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['group_id']."'>".$sInfo['group_name']."</option>";
           }
        }
        echo $str;exit;
    }
	
	
  

	
	/************** /result ***************/
    

  public function result_view()
      {
      #$school_id = $_SESSION['school_id'];
        $school_id = 1;
       $data['class_list'] = $this->Admin_model->get_class_list($school_id);
       $data['term'] = $this->Academic_model->get_term_list($school_id); 

      $this->load->view('result/result_view',$data);
      }
      
      
   	  function result_marks_json()
	  {
  #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$term_id = $_GET['term_id'];
        $exam_year = $_GET['exam_year'];
        $data['student_list'] = $this->Academic_model->get_class_wise_student_list_admit($school_id, $class_id,$section_id);
        $data['term'] = $this->Academic_model->get_term_list_by_id($term_id,$school_id); 

        $data['details'] =  array("class"=>$class_id,"section_id"=>$section_id,"term_id"=>$term_id,"exam_year"=>$exam_year,'sub_id'=>$sub_id);
	
					$mainContent=$this->load->view('result/result_view_json', $data, true);
        
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
  
  }
		
	/*	
   public function tabulation_sheet()
      {
      #$school_id = $_SESSION['school_id'];
        $school_id = 1;
		
       $data['class_list'] = $this->Admin_model->get_class_list($school_id);
       $data['term'] = $this->Academic_model->get_term_list($school_id); 
		$data['shift_list'] = $this->Academic_model->get_shift_list($school_id);
      $this->load->view('academic/tabulation_sheet',$data);
      }
	  
	public function tabulation_marks_json()
	{
  #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$group_id = $_GET['group_id'];
		$shift_id = $_GET['shift_id'];
		$term_id = $_GET['term_id'];
        $exam_year = $_GET['exam_year'];
		$passing_id = $_GET['passing_id'];
		$type_id = $_GET['type_id'];
        $data['student_list'] = $this->Academic_model->get_class_wise_student_list($school_id, $class_id,$section_id,$group_id,$shift_id);
        $data['term'] = $this->Academic_model->get_term_list_by_id($term_id,$school_id);
        $data['details'] =  array("class_id"=>$class_id,"section_id"=>$section_id,"term_id"=>$term_id,"exam_year"=>$exam_year,'school_id'=>$school_id,'group_id'=>$group_id,'shift_id'=>$shift_id,'passing_id'=>$passing_id,"type_id"=>$type_id);

		$mainContent=$this->load->view('academic/tabulation_marks_json', $data, true);
        
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
  
  }
  
   public function tabulation_marks_save()
  {
	    #$school_id = $_SESSION['school_id'];
		
        $school_id = 1;
	$class_id = $_POST['class_id'];
	$section_id = $_POST['section_id'];
	$group_id = $_POST['group_id'];
	$term_id = $_POST['term_id'];
	$exam_year = $_POST['exam_year'];
	$passing_id = $_POST['passing_id'];
	$type_id = $_POST['type_id'];
	$shift_id = $_POST['shift_id'];
    $created_on = date('Y-m-d H:i:s',time());
	$status = 1 ;
	
	 $this->Academic_model->delete_tabulation_marks($school_id,$class_id,$section_id,$group_id,$term_id,$exam_year,$shift_id);
	// echo count($_POST['student_id']); die();
	$subi=0;
	$i=0;
	while($i<count($_POST['student_id']))
	{
		$student_id = $_POST['student_id'][$i];
		$s=0;
		while($s<$_POST['sub_count'])
		{
			$subject_id = $_POST['subject_id'][$subi];
			$sub_total_marks = $_POST['sub_total_marks'][$subi];
			$sub_grade_point = $_POST['sub_grade_point'][$subi];
	
	$data = array ('school_id'=>$school_id,'class_id'=>$class_id,'section_id'=>$section_id,'group_id'=>$group_id,'shift_id'=>$shift_id,'term_id'=>$term_id,'exam_year'=>$exam_year,'student_id'=>$student_id,'subject_id'=>$subject_id,'sub_total_marks'=>$sub_total_marks,'sub_grade_point'=>$sub_grade_point,'passing_id'=>$passing_id,'type_id'=>$type_id,'status'=>$status,'created_on'=>$created_on);
               
               $this->Common_model->common_insert($data,'tbl_tabulation_marks');
		$subi++;
		$s++;
		}
	
	$i++;
	}
             $this->session->set_flashdata('message', " Tabulation sheet marks has been saved successfully ");
		
		redirect('academic/tabulation_sheet','refresh');exit;  
	
	 	}
		*/
		public function mark_sheet()
		{
			#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$data['class_list'] = $this->Admin_model->get_class_list($school_id);
			$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
			$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
			$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
			$this->load->view('result/mark_sheet',$data);
		}
	  
	public function get_student_list_marksheet()
    {
        #$school_id = $_SESSION['school_id'];
        $s_data['tbl_student_class.school_id'] = 1;
        $s_data['tbl_student_class.class_id'] = $_POST['class_id'];
		$s_data['tbl_student_class.session_id'] = $_POST['session_id'];
        $stuInfo =  $this->Result_model->selece_student_marksheet($s_data);
       
        $str = '<option value="">---- Select student ----</option>';
        if($stuInfo)
        {
           foreach($stuInfo as $stuInfos)
           {
              $str .= "<option value='".$stuInfos['student_id']."'>".$stuInfos['student_id'].'-'.$stuInfos['student_name']."</option>";
           }
        }
        echo $str;exit;
		
    }
	
	public function mark_sheet_json()
	{
  		#$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
        $class_short_form = $_GET['class_short_form'];
        $session_id = $_GET['session_id'];
		$student_id = $_GET['student_id'];
		$term_id = $_GET['term_id'];
		$term_name = $_GET['term_name'];
		$session = $_GET['session'];// this session use here as exam year
		//echo $exam_year; die();
        $data['student_mark_info'] = $this->Result_model->get_student_marksheet_info($school_id,$class_id,$student_id,$term_id,$session);
		if($class_short_form >= 9){
			$data['student_info'] = $this->Result_model->mark_sheet_student_info_with_optional($school_id,$session_id,$student_id,$class_id);
			$data['optional']=$data['student_info']['subject_id'];
		}else{
			$data['student_info'] = $this->Result_model->mark_sheet_student_info($school_id,$session_id,$student_id,$class_id);
			$data['optional']='151,134';
		}
        $data['max_mark'] = $this->Result_model->get_max_subject_number($school_id,$class_id,$term_id,$session);
        $data['ranks'] = $this->Result_model->get_student_rank($school_id,$class_id,$term_id,$session);
		$data['grd_system'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_grd_system');
        $data['details']=array('term_name'=>$term_name,'session'=>$session,'class_short_form'=>$class_short_form);
	
			$mainContent=$this->load->view('result/mark_sheet_json', $data, true);
        
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
  
  }
  
  public function print_mark_sheet()
	{
  		#$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$section_id = $_POST['section_id'];
		$group_id = $_POST['group_id'];
		$shift_id = $_POST['shift_id'];
		$student_id = $_POST['student_id'];
		$term_id = $_POST['term_id'];
        $exam_year = $_POST['exam_year'];
        $data['student_information'] = $this->Academic_model->get_class_wise_student_info_marksheet($school_id, $class_id,$section_id,$student_id,$shift_id,$group_id);
        $data['term'] = $this->Academic_model->get_term_list_by_id($term_id,$school_id); 
		$data['school_info'] = $this->Academic_model->admit_card_view_school($school_id);
        $data['details'] =  array("class_id"=>$class_id,"section_id"=>$section_id,"term_id"=>$term_id,"exam_year"=>$exam_year,'student_id'=>$student_id,'school_id'=>$school_id);
	
		$this->load->view('academic/print_mark_sheet', $data);
  }
	
  /************** /result ***************/
  	
	 /***  tabulation sheet subject wise ***/
		public function tabulation_sheet_subject_wise()
      	{
      		#$school_id = $_SESSION['school_id'];
       		$school_id = 1;
       		$data['class_list'] = $this->Admin_model->get_class_list($school_id);
			$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
			$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
			$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
		  	$this->load->view('result/tabulation_sheet_subject_wise',$data);
		}
	public function tabulation_marks_subject_wise_json()
	{
  #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$group_id = $_GET['group_id'];
		$shift_id = $_GET['shift_id'];
		$session_id = $_GET['session_id'];
		$subject_id = $_GET['subject_id'];
		$term_id = $_GET['term_id'];
        $exam_year = $_GET['exam_year'];
		$passing_id = $_GET['passing_id'];
		$type_id = $_GET['type_id'];
		$details_data = $_GET['details_data'];
		
		$data['subject_infos'] = $this->Result_model->mark_distribution_list_result($school_id,$subject_id,$class_id,$group_id,$term_id);
		
        $data['student_list']=$this->Result_model->get_student_list_sub_tabu($school_id,$session_id,$class_id,$shift_id,$section_id,$group_id,$subject_id,$exam_year,$term_id);
		
		$g_data['school_id']=$school_id;
		$g_data['type_id']=$type_id;
		$data['gp_list']=$this->Common_model->common_select_by_multycondition($g_data,'tbl_grd_system');
		
		$data['details']=array("class_id"=>$class_id,"section_id"=>$section_id,"session_id"=>$session_id,"details_data"=>$details_data,"subject_id"=>$subject_id,"term_id"=>$term_id,"exam_year"=>$exam_year,"school_id"=>$school_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"passing_id"=>$passing_id,"type_id"=>$type_id);
		$mainContent=$this->load->view('result/tabulation_marks_subject_wise_json', $data, true);
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
  }
  public function tabulation_marks_subject_wise_print()
	{
  		#$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$section_id = $_POST['section_id'];
		$group_id = $_POST['group_id'];
		$shift_id = $_POST['shift_id'];
		$subject_id = $_POST['subject_id'];
		$term_id = $_POST['term_id'];
        $exam_year = $_POST['exam_year'];
		 $passing_id = $_POST['passing_id'];
		 $type_id = $_POST['type_id'];
		
        $data['subject_infos'] = $this->Academic_model->subject_info_for_tabulation_sheet_subject_wise($school_id,$term_id,$exam_year,$class_id,$section_id,$subject_id);
		 $data['school_infos'] = $this->Academic_model->admit_card_view_school($school_id);
		$data['student_list']=$this->Academic_model->get_class_wise_student_list($school_id,$class_id,$section_id,$group_id,$shift_id);
        $data['term']=$this->Academic_model->get_term_list_by_id($term_id,$school_id);
		$data['details']=array("class_id"=>$class_id,"section_id"=>$section_id,"subject_id"=>$subject_id,"term_id"=>$term_id,"exam_year"=>$exam_year,"school_id"=>$school_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"passing_id"=>$passing_id,"type_id"=>$type_id);
		$this->load->view('academic/tabulation_marks_subject_wise_print', $data);
        
    }
  
   public function marks_status_change()
 {
	  	$school_id = $_POST['school_id'];
        $class_id = $_POST['class_id'];
		$section_id = $_POST['section_id'];
		$group_id = $_POST['group_id'];
		$shift_id = $_POST['shift_id'];
		$subject_id = $_POST['subject_id'];
		$term_id = $_POST['term_id'];
        $exam_year = $_POST['exam_year'];
		$status = $_POST['status'];
		
		$data_term = array ('status'=>$status);
	            $where_term = array("class_id"=>$class_id,"section_id"=>$section_id,"sub_id"=>$subject_id,"term_id"=>$term_id,"exam_year"=>$exam_year,"school_id"=>$school_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"status"=>0);		
				 $this->db->where($where_term);
                $this->db->update('tbl_term_marks', $data_term);
				
		$data = array ('status'=>$status);
	            $where = array("class_id"=>$class_id,"section_id"=>$section_id,"subject_id"=>$subject_id,"term_id"=>$term_id,"exam_year"=>$exam_year,"school_id"=>$school_id,"group_id"=>$group_id,"shift_id"=>$shift_id,"status"=>0);
                $this->db->where($where);
                $this->db->update('tbl_ct_marks', $data);
		
		
				
				 $this->session->set_flashdata('message', " Final submition successful ");
		redirect('school/tabulation_sheet_subject_wise','refresh');exit;  
	}
  
  public function tabulation_marks_save()
	{
		// single value
		$school_id = $_POST['school_id'];
		$exam_year = $_POST['exam_year'];
		$class_id = $_POST['class_id'];
		$term_id = $_POST['term_id'];
		$subject_id = $_POST['subject_id'];
		$f_mark = $_POST['f_mark'];
		$p_mark = $_POST['p_mark'];
		$type_id = $_POST['type_id'];
		$pass_id = $_POST['pass_id'];

		// full mark
		$sub_mark=$_POST['sub_mark'];
		$obj_mark=$_POST['obj_mark'];
		$prac_mark=$_POST['prac_mark'];
		$mark_dis = explode('*', $_POST['mark_dis']);
		$all_mark_name=array('CA','CW','HW','CT','ASPJ');
		// array values
		
		$student_id = $_POST['student_id'];
		$other_mark = $_POST['other_mark'];
		$sub = $_POST['sub'];
		$obj = $_POST['obj'];
		$prac = $_POST['prac'];
		$sub_total = $_POST['sub_total'];
		$gpa = $_POST['gpa'];
		

		// get array value to insert
		for($i=0; $i < count($student_id); $i++){
			
			
			if($other_mark)
			{
				$other_marks = explode('*', $other_mark[$i]);
			
				for($mia=0; $mia < count($other_marks)-1; $mia++){
					
					$other_mark_s[str_replace('/', '', explode(',', $other_marks[$mia])[0])]=explode(',', $other_marks[$mia])[1].'*'.explode(',', $mark_dis[$mia])[1];

					$mark_dis_names[] = str_replace('/', '', explode(',', $other_marks[$mia])[0]);
				};

				foreach($all_mark_name as $all_mark_name_arr )
				{
					if(!in_array($all_mark_name_arr, $mark_dis_names))
					{
						$other_mark_s[$all_mark_name_arr]='0*0';
					}
				}
			}
			else
			{
				foreach($all_mark_name as $all_mark_name_arr )
				{
					$other_mark_s[$all_mark_name_arr]='0*0';
				}

			}

			$data_mark_info=array(
								'school_id' => $school_id,
								'exam_year' => $exam_year,
								'class_id' => $class_id,
								'term_id' => $term_id,
								'student_id' => $student_id[$i],
								'subject_id' => $subject_id,
								'f_mark' => $f_mark,
								'p_mark' => $p_mark,
								'sub' => $sub[$i].'*'.$sub_mark,
								'obj' => $obj[$i].'*'.$obj_mark,
								'prac' => $prac[$i].'*'.$prac_mark,
								'sub_total' => $sub_total[$i],
								'gpa' => $gpa[$i],
								'pass_id' => $pass_id,
								'type_id' => $type_id,
								'status' => 0,
								'created_on' => date('Y-m-d H:i:s',time())
								);
				/*insert new data*/
				$data[] = array_merge($data_mark_info,$other_mark_s);
		}
		//print_r($data); die();
		/* insart batch data */
		if($this->Common_model->common_insert_batch($data,'tbl_tabulation_marks'))
			$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			else
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				
				
	redirect('result/tabulation_sheet_subject_wise', 'refresh');
}
  
 	/*** / tabulation sheet subject wise ***/ 
	
	 // student enrolment
	 
	 public function student_enrollment()
      {
      		#$school_id = $_SESSION['school_id'];
       		$school_id = 1;
       		$data['class_list'] = $this->Admin_model->get_class_list($school_id);
			$data['session'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
      		$this->load->view('result/student_enrollment',$data);
      }
      
      
   	  function student_enrollment_json()
	  {
			#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$class_id = $_GET['class_id'];
			$session_id = $_GET['session_id'];
			//$data['student_list'] = $this->Academic_model->get_class_wise_student_list_admit($school_id, $class_id,$section_id);

				$mainContent=$this->load->view('result/student_enrollment_json', $data, true);
			
			$result = 'success';
			$return = array('result' => $result, 'mainContent'=> $mainContent);
			print json_encode($return);
			exit;   
  
  	 }
	
	
}