<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller {

    public function __construct()
        {            
            session_start();
            parent::__construct();
            $this->load->helper('form');
            $this->load->helper('url');
            $this->load->model('admin_model', 'Admin_model', true);
            $this->load->model('common_model', 'Common_model', true); 
			$this->load->model('academic_model', 'Academic_model', true);            
            $this->load->model('general_model', 'General_model', true);            
            $this->load->model('result_model', 'Result_model', true);  
  
			$this->load->model('attendance_model', 'Attendance_model', true);	          

        }
	
	function section_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
        $sectionInfo = $this->Admin_model->get_section_list_by_id($class_id, $school_id); 
        $str = '<option value="">----Select Section----</option>';
        if($sectionInfo)
        {
           foreach($sectionInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['section_id']."'>".$sInfo['section_name']."</option>";
           }
        }
        echo $str;
		exit;
    }
	
	public function structure_exam_routine_by_term()
    {
    	#$school_id = $_SESSION['school_id'];
     	$school_id = 1;
        $exam_term_id = $_POST['exam_term_id'];
        $column_no = $this->Academic_model->exam_show_get_class_count($school_id,$exam_term_id);
        $row_no = $this->Academic_model->exam_show_get_day_count($school_id,$exam_term_id);
        
       // print_r($column_no); die();
        $table='<table class="table table-striped table-bordered"><thead><tr style="border-top:1px;"><th colspan="2"></th>';
        foreach ($column_no as $col_no)
				{
				$table.='<th id="exam_class_id" class="class_id'.$col_no['column_no'].'"></th>';
				}
                
        $table.='</tr><tr rowspan="2"><th style="min-width:125px; max-width:150px;">Exam Date</th><th style="min-width:125px; max-width:150px;">Exam Day</th>';
				foreach ($column_no as $col_no1)
				{
				 $table.='<th class="exam_time'.$col_no1['column_no'].'"></th>';
				}
				$table.='</tr></thead><tbody>';
				
				for($itdday=0; $itdday< $row_no;)
				{
					
					$table.='<tr class="date countvalue" id="'.$itdday.'"><td class="date'.$itdday.'"></td><td class="wkday'.$itdday.'"></td>';
					foreach ($column_no as $col_no2)
					{
						$table.='<td class="sub'.$col_no2['column_no'].'"></td>';
					}
					$table.='</tr>';
					$itdday++;
				}
				$table.='</tbody></table>';
        
        
		echo $table;
		exit;
    
    }
	 public function get_id_per_exam_term(){
        #$school_id = $_SESSION['school_id'];
     	$school_id = 1;
        $exam_term_id = $_POST['exam_term_id'];
        $sectionInfo = $this->Academic_model->get_id_per_exam_term($school_id,$exam_term_id);
		$str='';
        if($sectionInfo)
        {
           foreach($sectionInfo as $sInfo)
           {
              $str .= $sInfo['id']."|";
           }
		   echo $str;
        }
		exit;
    }



    function group_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
        $sectionInfo = $this->Academic_model->get_group_list_by_id($class_id, $school_id); 
        $str = '<option value="">----Select Section----</option>';
        if($sectionInfo)
        {
           foreach($sectionInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['group_id']."'>".$sInfo['group_name']."</option>";
           }
        }
        echo $str;exit;
    }
    
    public function index(){ 
		$school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
        $data['about'] = $this->General_model->get_about_by_school_id();
        $data['teacher_list'] = $this->Admin_model->get_teacher_list_list($school_id);
        $data['md_message'] = $this->Admin_model->md_message_get_all();
        $data['appoint_list'] = $this->Admin_model->get_teacher_dept_short_name($school_id);
        //$data['messages'] = $this->General_model->get_message_by_id('Principal');
		$data['gallery_images'] = $this->General_model->get_photo_gallery();
		$data['catagory_lists'] = $this->General_model->get_all_catagory_list($school_id);
        $data['notice_list'] = $this->General_model->get_all_latest_notice($school_id);
        $data['notice_list_last'] = $this->General_model->get_all_latest_notice_last();            
        $data['slide_image'] = $this->General_model->get_all_slide_image();
        $data['photo_gallery'] = $this->General_model->get_photo_gallery();
        $data['catagory_list'] = $this->General_model->get_all_catagory_list($school_id);
        $data['blog'] = $this->Admin_model->blog_get_all_view();
         $data['virtual_constructionltd'] = $this->Admin_model->virtual_constructionltd_get_all();
         $data['virtual_ready_mix'] = $this->Admin_model->virtual_ready_mix_get_all();
         $data['virtual_marketing_tradingco'] = $this->Admin_model->virtual_marketing_tradingco_get_all();
         $data['welcome_to_virtual_properties_ltd'] = $this->Admin_model->welcome_to_virtual_properties_ltd_get_all();
       // $data['class_list'] = $this->General_model->get_all_class();
		$this->load->view('home/index', $data);
    }
	public function managing_commettee(){
		//$this->load->view('home/managing_commettee',$data);
		$data['member_list'] = $this->Common_model->common_result_array('tbl_managing_committee');
		$this->load->view('home/commettee/managing_commettee',$data);
	}
    public function error(){
        //$data['messages'] = $this->General_model->get_message_by_school_id();
        //$this->load->view('home/managing_commettee',$data);
        $this->load->view('home/404');
    }
    public function rejulation_view(){
    $data1['rejulation_viewimage'] = $this->Common_model->common_result_array('tbl_rejulation_registration');
    //$s_data['r_id']  = 1;
   // $data['rejulation_viewimage'] = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_rejulation_registration');



    $this->load->view('home/rejulation_view',$data1);
    }
	public function headmasterMessage(){
		$data['messages'] = $this->General_model->get_message_by_id('Headmaster');
		$this->load->view('home/headmasterMessage',$data);
	}
	public function commettee_list(){
		$data['messages'] = $this->General_model->get_message_by_school_id();
		
		$this->load->view('home/commettee_list',$data);
	}
 public function freedom_fighter()
    {

        $data['freedom_fighter'] = $this->Common_model->common_select_field('tbl_freedom_fighter','order_by','ASC','*');
       
        $this->load->view('home/freedom_fighter', $data);
    }
    public function freedom_fighter_list()
    {
        $this->load->view('home/freedom_fighter_list');
    }
	public function rules(){
		$this->load->view('home/rules');
	}
    public function pending(){
        $this->load->view('home/pending');
    }
    public function landinfo(){
        $this->load->view('home/about/landinfo');
    }
    
    public function postinfo(){
        $this->load->view('home/about/postinfo');
    }
    public function buildinnginfo(){
        $this->load->view('home/about/buildinnginfo');
    }
     public function computer_lab(){
        $this->load->view('home/about/computer_lab');
    }
     public function other_assets(){
        $this->load->view('home/about/other_assets');
    }
	public function presidentmessage(){
		$data['messages'] = $this->General_model->get_message_by_id('Chairman');
		$this->load->view('home/PresidentMessage',$data);
	}
    public function ThirdgradeEmployee(){
         $school_id = 1;
            //$data['teacher_list'] = $this->Admin_model->get_teacher_list_list($school_id);
        $data['teacher_list'] = $this->Common_model->common_result_array('tbl_teacher_registration');
        $this->load->view('home/employee/ThirdgradeEmployee',$data);
    }
    public function FourthgradeEmployee(){
        $this->load->view('home/employee/FourthgradeEmployee');
    }
    public function management(){
        $this->load->view('home/management');
    }
    public function meritstudent(){
        $this->load->view('home/meritstudent/meritstudent');
    }
    public function donnor_list(){
        $data1['donor_list'] = $this->Common_model->common_result_array('tbl_donor');
        $this->load->view('home/commettee/donnor_list', $data1);
    }
    public function admission(){
        $this->load->view('home/admission/admission');
    } 
	public function admission_form(){
        $this->load->view('home/admission/admission_form');
    } 
    public function admission_result(){
        $this->load->view('home/result/admission_result');
    }
    public function studentinfo(){
		$data['student_count']=$this->General_model->total_student_count();
        $this->load->view('home/student/studentinfo',$data);
    }
     public function notice(){
		$data['notice_list'] = $this->General_model->get_all_admission_notice();
        $this->load->view('home/notice', $data);
    }
	public function single_notice($notice_id){
            $data['notice_info'] = $this->General_model->get_notice_info_by_id($notice_id);
            $this->load->view('home/notice/notice-detail',$data);
        }
    public function event(){
        $this->load->view('home/event', $data);
    }
    public function academic_schedule(){
        $this->load->view('home/academic/academic_schedule');
    }
	public function get_event(){
        #$school_id = $_SESSION['school_id'];
        $s_data['school_id'] = 1;
       echo json_encode($this->Common_model->common_select_by_multycondition($s_data,'tbl_academic_calendar'));
    }
    public function attendance(){
        $this->load->view('home/attendance/attendance');
    }
	public function student_for_att_report_daily_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $att_date = date('Y-m-d',strtotime($_GET['att_date']));
		$data['att_date']= date('d M Y',strtotime($_GET['att_date']));
		$data['att_day']= date('l',strtotime($_GET['att_date']));
		$data['att_details'] = $this->Attendance_model->get_class_wise_att_count_daily($school_id,$att_date);
		 
			$mainContent=$this->load->view('attendance/student_att_report_daily', $data, true);
			
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }

public function emp_attendance(){
        $this->load->view('home/attendance/emp_attendance');
    }
	
	// Teacher daily,monthly and teacher wise attendance report
	public function teacher_att_report_json(){
        #$school_id = $_SESSION['school_id'];
         $school_id = 1;
        $teacher_name_json = $this->Attendance_model->teacher_list('tbl_teacher_registration.school_id',$school_id,'tbl_teacher_registration.teacher_id,tbl_teacher_registration.teacher_name,tbl_designation.designation_name');
       
	$att_time=strtotime($_GET['att_date']);
	$att_date = date('Y-m-d',$att_time);
	//$att_date = $_GET['att_date'];
        $att_month = date('Y-').$_GET['month_id'];
        $teacher_id = $_GET['teacher_id'];
        $report_type = $_GET['report_type'];
		$repo_type='';
		if($report_type=='d'):
			$data['att_details'] = $this->Attendance_model->get_teacher_day_att($school_id,$att_date);
			$data['repo_type']='d';
			$data['teacher_name_json'] = $teacher_name_json;//$_GET['teacher_name_json'];
			$data['att_date']= date('d M Y',$att_time);
			$data['att_day']= date('l',$att_time);
		
		else:
			if($teacher_id):
				$data['att_details'] = $this->Attendance_model->get_teacher_wise_att($school_id,$teacher_id,$att_month);
				$data['repo_type']='t';
				$data['teacher_name_json']= $teacher_name_json;//$_GET['teacher_name_json'];
			else:
				$data['att_details'] = $this->Attendance_model->get_teacher_month_att($school_id,$att_month);
				$data['repo_type']='m';
				$data['teacher_name_json']= $teacher_name_json;//$_GET['teacher_name_json'];
			endif;
		endif;
		$data['month_name'] =$_GET['month_name'];
		$data['teacher_name'] =$_GET['teacher_name'];
		
		 $mainContent=$this->load->view('attendance/teacher_att_report_json', $data, true);
			
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=>$mainContent);
        print json_encode($return);
       // exit;   
    }
     public function schoolresult(){
        $this->load->view('home/result/schoolresult', $data);
    }
    public function PSCresult(){
        $this->load->view('home/result/PSCresult', $data);
    }
    public function JSCresult(){
        $this->load->view('home/result/JSCresult', $data);
    }
    public function SSCresult(){
        $this->load->view('home/result/SSCresult', $data);
    }
    public function latestnews(){
        $this->load->view('home/latestnews', $data);
    }
    public function careertest(){
        $this->load->view('home/careertest', $data);
    }
    public function digital_classroom(){
        $this->load->view('home/digital_classroom', $data);
    }
    public function login(){
        $this->load->view('home/student/login', $data);
    }
public function guardian_panle_login_check(){
		$s_data['student_id']=$_POST['student_id'];
		$s_data['password']=$_POST['password'];
		
		if($this->Common_model->common_select_by_multycondition($s_data,'tbl_student')){
		       $_SESSION['student_id']       = $_POST['student_id'];
			redirect('guardian_panel');
		}
		else{
		$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Your ID or Password is not valid.</div>');
		redirect('home/login');
		}
	} 
	function logout()
        {            
            session_destroy();
            redirect('home');
        }  
    public function about(){
     $s_data['school_id'] = 1;
       $data['about']       = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_about');
        $this->load->view('home/about/about', $data);
    }
    public function founder(){
        //$data['about'] = $this->General_model->get_about_by_school_id();
        $this->load->view('home/about/founder', $data);
    }
    public function history(){
        $this->load->view('home/about/history', $data);
    }
     public function contact_us(){
        $this->load->view('home/about/contact_us', $data);
    }
    public function contact(){
        $this->load->view('home/contact');
    }
	public function teacher(){
		$school_id = 1;
            $data['teacher_list'] = $this->Admin_model->get_teacher_list_list($school_id);
        $data['appoint_list'] = $this->Admin_model->get_teacher_dept_short_name($school_id);
		$this->load->view('home/employee/teacher', $data);
		//$this->load->view('home/teacher/teacher', $data);
	}
	public function gallery(){
		$school_id = 1;
		$data['photo_gallery'] = $this->General_model->get_photo_gallery();
		$data['catagory_list'] = $this->General_model->get_all_catagory_list($school_id);
		$this->load->view('home/gallery',$data);
	}
	
	public function admit_card(){
		$this->load->view('home/admit_card');
	}
	public function guardian_panle_login(){
		$this->load->view('home/guardian_panle_login');
	}    
        public function message($message_id){           
            $data['messages'] = $this->General_model->get_message_by_id($message_id);
            $this->load->view('welcome/message', $data);
        }
        
        public function important_information(){
            $information_type = 1;
            $data['info_list'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/important_information',$data);
        }
        
        public function rules_regulations(){            
            $information_type = 2;
            $data['rules_list'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/rules_regulations',$data);
        }
        
        public function steps(){
            $information_type = 3;
            $data['rules_list'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/steps',$data);
        }
        
        
        public function facilities(){
            $information_type = 4;
            $data['rules_list'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/facilities',$data);
        }
        
        public function principal_list(){
            $information_type = 5;
            $data['principal_list'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/principal_list',$data);
        }
        
        public function vice_principal_list(){
            $information_type = 6;
            $data['vice_principal_list'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/vice_principal_list',$data);
        }
        
        public function library(){
            $school_id = 1;
			$data['book_list'] = $this->General_model->get_all_book_list($school_id);
			$data['category_list'] = $this->General_model->get_all_book_category_list($school_id);
            $this->load->view('welcome/library', $data);
        }
        
         public function vacant_post(){
            $information_type = 8;
            $data['vacant_post'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/vacant_post',$data);
        }
		
		 public function teacher_panel(){
            $information_type = 9;
            $data['teacher_panel'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/teacher_panel',$data);
        }
		
		 public function student_panel(){
            $information_type = 10;
            $data['student_panel'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/student_panel',$data);
        }
		
		 public function guardian_panel(){
            $information_type = 11;
            $data['guardian_panel'] = $this->General_model->get_information_list_by_id($information_type);
            $this->load->view('welcome/guardian_panel',$data);
        }
        
        public function department(){
            $data['class_list'] = $this->General_model->get_all_class_assign_list();
            $this->load->view('welcome/department', $data);
        }
       public function classroutine()
		{
			 $school_id = 1;
			$data['class_list'] = $this->Common_model->common_result_array('tbl_class');
			$data['shift_list'] = $this->Academic_model->get_shift_list($school_id);
			//$c1 = $count['count'];
			$this->load->view('home/routine/classroutine', $data);
		}
		public function get_class_routine_json_show(){
        #$school_id = $_SESSION['school_id'];
        $s_data['school_id'] = 1;
        $s_data['class_id'] = $_GET['class_id'];
		$s_data['section_id'] = $_GET['section_id'];
		$s_data['group_id'] = $_GET['group_id'];
		$s_data['shift_id'] = $_GET['shift_id'];
		
        $data['class_time'] = $this->Common_model->common_select_by_multycondition($s_data,'tbl_class_time_input');
		$data['week']= $this->Academic_model->get_weekdays($s_data['school_id']);
		$data['teacher']= $this->Academic_model->get_class_wise_teacher_list_routine($s_data['school_id'],$s_data['class_id'],$s_data['section_id']);
		$data['subject']= $this->Academic_model->get_class_wise_subject_list($s_data['class_id'],$s_data['school_id']);
			$mainContent=$this->load->view('home/routine/get_class_routine_json_show', $data, true);
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
	public function get_old_routine_by_section_class_show()
	{
     	#$school_id = $_SESSION['school_id'];
     	$school_id = 1;
		$class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$group_id = $_GET['group_id'];
		$shift_id = $_GET['shift_id'];
		$data= $this->Academic_model->get_old_routine_by_section_class_show($class_id, $school_id,$section_id,$group_id,$shift_id);
		 print json_encode($data);
        exit;   
	}
        public function central_routine(){
            $data['central_routine'] = $this->General_model->get_central_routine();
            $this->load->view('welcome/central_routine', $data);
        }
       public function examroutine(){
			#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$data['class_list'] = $this->Admin_model->get_class_list($school_id);
			$data['term_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
			$this->load->view('home/routine/examroutine', $data);
		}
    
		public function exam_routine_json()
		{
			$school_id=1;
			$class_id=$_GET['class_id'];
			
			$data['exam_time']=$this->Common_model->common_select_by_condition($school_id,'school_id','tbl_exam_time');
			$data['subject']= $this->Academic_model->get_class_wise_subject_list($class_id, $school_id);
			if($data['exam_time'] && $data['subject'])
				$mainContent=$this->load->view('home/routine/exam_routine_json', $data, true);
			else
				$mainContent='<b>NB :</b>Ether no subject assigned for this class or no exam time set. Please go to setting->subject->subject assign to assign subject or setting -> exam -> exam setting -> set term exam time to set exam time.';
			$result = 'success';
			$return = array('result' => $result, 'mainContent'=> $mainContent);
			print json_encode($return);
			exit;   
	
		}
		
		public function get_old_exam_routine_by_term_show()
	{
    	#$school_id = $_SESSION['school_id'];
     	$school_id = 1;
		$class_id = $_GET['class_id'];
		$exam_term_id = $_GET['exam_term_id'];
		$data= $this->Academic_model->get_old_exam_routine_by_term_show($class_id,$exam_term_id);
		 print json_encode($data);
        exit;   
	}
     
        
        /**Ajax Data for Result View**/
        public function get_department_list_by_class_id(){            
            $class_id = $_GET['class_id'];
                        
            $department_list = $this->General_model->get_department_list_by_class_id($class_id);
            
            $mainContent='<option value="">---- Select Department ----</option>';
            if($department_list){
                foreach($department_list as $dl){
                    $department_id = $dl['department_id'];
                    $dept_name=$this->General_model->get_department_info_by_id($department_id);
                    $department_name=$dept_name['department_name'];
                    
                    $mainContent.='<option value="'.$dl['department_id'].'">'.$department_name.'</option>';
                }
            }           
            $result = 'success';
            $return = array('result' => $result, 'mainContent'=> $mainContent);
            print json_encode($return);
            exit;            
        }
		
		
        public function get_session_list_by_class_id(){
            $class_id = $_GET['class_id'];
            $session_list = $this->General_model->get_session_list_by_class_id($class_id);
            $mainContent='<option value="">---- Select Session ----</option>';
            if($session_list){
                foreach($session_list as $sl){
                    $session_id = $sl['session_id'];
                    $sess_name=$this->General_model->get_session_info_by_id($session_id);
                    $session_name=$sess_name['session_name'];
                    
                    $mainContent.='<option value="'.$sl['session_id'].'">'.$session_name.'</option>';
                }
            }           
            $result = 'success';
            $return = array('result' => $result, 'mainContent'=> $mainContent);
            print json_encode($return);
            exit;            
        }
		
            public function get_exam_list_by_class_id(){
            $class_id = $_GET['class_id'];
                        
            $exam_list = $this->General_model->get_exam_list_by_class_id($class_id);
            
            $mainContent='<option value="">---- Select Exam ----</option>';
            if($exam_list){
                foreach($exam_list as $el){
                    $exam_id = $el['exam_id'];
                    $ex_name=$this->General_model->get_exam_info_by_id($exam_id);
                    $exam_name=$ex_name['exam_name'];
                    
                    $mainContent.='<option value="'.$el['exam_id'].'">'.$exam_name.'</option>';
                }
            }           
            $result = 'success';
            $return = array('result' => $result, 'mainContent'=> $mainContent);
            print json_encode($return);
            exit;            
        }
        
		
        public function get_student_list_for_result_view(){
            $class_id = $_GET['class_id'];
            $department_id = $_GET['department_id'];
            $session_id = $_GET['session_id'];
            $exam_id = $_GET['exam_id'];
			
            $data['class_id']=$class_id;
            $data['department_id']=$department_id;
            $data['session_id']=$session_id;
            $data['exam_id']=$exam_id;

            $data['result_list']=$this->General_model->get_result_list_by_class_id($class_id, $department_id, $session_id, $exam_id);
            $data['fail_list']=$this->General_model->get_fail_list_by_class_id($class_id, $department_id, $session_id, $exam_id);           
            
            $data['result_type']=$this->General_model->get_result_type_by_class_id($class_id);
            
            
            $data['degree_result_list']=$this->General_model->get_degree_result_list_by_class_id($class_id, $department_id, $session_id, $exam_id);
            
            $data['degree_fail_list']=$this->General_model->get_degree_fail_list_by_class_id($class_id, $department_id, $session_id, $exam_id);
			
            $mainContent=$this->load->view('welcome/get_student_list_for_result_view', $data, true);
            
            $result = 'success';
            $return = array('result' => $result, 'mainContent'=> $mainContent);
            print json_encode($return);
            exit;              
        }
		
	   public function get_teacher_list_by_department_id(){
            $school_id = 1;
            $department_id = $_GET['department_id'];
			//echo $department_id; die();
            $data['tt']=$this->General_model->get_teacher_list_by_department($school_id, $department_id);
		 	$data['department_name']=$this->General_model->get_department_name($department_id);
			$mainContent=$this->load->view('welcome/teacher_department_wise', $data, true);
				
			$result = 'success';
            $return = array('result' => $result, 'mainContent'=>$mainContent);
            print json_encode($return);
            exit;            
        }		
		
		public function get_photo_list_by_catagory_id(){
            $school_id = 1;
            $catagory_id = $_GET['catagory_id'];
            $data['tt']=$this->General_model->get_photo_list_by_catagory($school_id, $catagory_id);
			$data['catagory_name']=$this->General_model->get_catagory_name($catagory_id);
			
			$mainContent=$this->load->view('welcome/photo_catagory_wise', $data, true);
 				
			$result = 'success';
            $return = array('result' => $result, 'mainContent'=>$mainContent);
           
            print json_encode($return);
            exit;            
        }
		
		public function get_book_list_by_category_id(){
			$school_id = 1;
            $category_id = $_GET['category_id'];
			//$data['category_id']= $_GET['category_id'];
			//$data['book_list'] = $this->Admin_model->get_all_book_list($school_id);
			//$data['category_list'] = $this->Admin_model->get_all_book_category_list($school_id);
            $data['tt']=$this->General_model->get_book_list_by_category($school_id, $category_id);
			$data['category_name']=$this->General_model->get_book_category_name($category_id);
			$mainContent=$this->load->view('welcome/book_category_wise', $data, true);
 				
			$result = 'success';
            $return = array('result' => $result, 'mainContent'=>$mainContent);
           
            print json_encode($return);
            exit;            
        }	
			
	/********************** result **************/
	public function mark_sheet()
		{
			#$school_id = $_SESSION['school_id'];
			$school_id = 1;
			$data['class_list'] = $this->Admin_model->get_class_list($school_id);
			$data['term_list'] =  $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_term');
			$data['session_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
			$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
			$this->load->view('home/mark_sheet',$data);
		}
	  
	public function get_student_list_marksheet()
    {
        #$school_id = $_SESSION['school_id'];
        $s_data['tbl_student_class.school_id'] = 1;
        $s_data['tbl_student_class.class_id'] = $_POST['class_id'];
		$s_data['tbl_student_class.session_id'] = $_POST['session_id'];
        $stuInfo =  $this->Result_model->selece_student_marksheet($s_data);
       
        $str = '<option value="">---- Select student ----</option>';
        if($stuInfo)
        {
           foreach($stuInfo as $stuInfos)
           {
              $str .= "<option value='".$stuInfos['student_id']."'>".$stuInfos['student_id'].'-'.$stuInfos['student_name']."</option>";
           }
        }
        echo $str;exit;
		
    }
	
	public function mark_sheet_json()
	{
  		#$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
        $class_short_form = $_GET['class_short_form'];
        $session_id = $_GET['session_id'];
		$student_id = $_GET['student_id'];
		$term_id = $_GET['term_id'];
		$term_name = $_GET['term_name'];
		$session = $_GET['session'];// this session use here as exam year
		//echo $exam_year; die();
        $data['student_mark_info'] = $this->Result_model->get_student_marksheet_info($school_id,$class_id,$student_id,$term_id,$session);
		if($class_short_form >= 9){
			$data['student_info'] = $this->Result_model->mark_sheet_student_info_with_optional($school_id,$session_id,$student_id,$class_id);
			$data['optional']=$data['student_info']['subject_id'];
		}else{
			$data['student_info'] = $this->Result_model->mark_sheet_student_info($school_id,$session_id,$student_id,$class_id);
			$data['optional']='151,134';
		}
        $data['max_mark'] = $this->Result_model->get_max_subject_number($school_id,$class_id,$term_id,$session);
        $data['ranks'] = $this->Result_model->get_student_rank($school_id,$class_id,$term_id,$session);
		$data['grd_system'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_grd_system');
        $data['details']=array('term_name'=>$term_name,'session'=>$session,'class_short_form'=>$class_short_form);
		$data['school_info'] = $this->Admin_model->get_school_information($school_id);
	
			$mainContent=$this->load->view('result/mark_sheet_json', $data, true);
        
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
  
  }
  
  public function print_mark_sheet()
	{
  		#$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$section_id = $_POST['section_id'];
		$student_id = $_POST['student_id'];
		$term_id = $_POST['term_id'];
        $exam_year = $_POST['exam_year'];
	//echo $exam_year.' class '.$class_id.' sec '.$section_id.' student '.$student_id.' term '.$term_id; die();
        $data['student_information'] = $this->Academic_model->get_class_wise_student_info_marksheet($school_id, $class_id,$section_id,$student_id);
        $data['term'] = $this->Academic_model->get_term_list_by_id($term_id,$school_id); 
		$data['school_info'] = $this->Academic_model->admit_card_view_school($school_id);
        $data['details'] =  array("class_id"=>$class_id,"section_id"=>$section_id,"term_id"=>$term_id,"exam_year"=>$exam_year,'student_id'=>$student_id,'school_id'=>$school_id);
	
		$this->load->view('welcome/print_mark_sheet', $data);
        
        
  
  }
  
   public function result_view()
      {
      #$school_id = $_SESSION['school_id'];
        $school_id = 1;
       $data['class_list'] = $this->Admin_model->get_class_list($school_id);
       $data['term'] = $this->Academic_model->get_term_list($school_id); 

      $this->load->view('welcome/result_view',$data);
      }
      
      
   	  function result_marks_json()
	  {
  #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$section_id = $_GET['section_id'];
		$term_id = $_GET['term_id'];
        $exam_year = $_GET['exam_year'];
        $data['student_list'] = $this->Academic_model->get_class_wise_student_list_admit($school_id, $class_id,$section_id);
        $data['term'] = $this->Academic_model->get_term_list_by_id($term_id,$school_id); 

        $data['details'] =  array("class"=>$class_id,"section_id"=>$section_id,"term_id"=>$term_id,"exam_year"=>$exam_year,'sub_id'=>$sub_id);
	
					$mainContent=$this->load->view('welcome/result_view_json', $data, true);
        
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
  
  }
  /************************** / result ******************/

  /************************** / Website View Page ******************/


   public function mechanical_support()
    {
       $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
       $data['mechanical_support'] = $this->Admin_model->mechanical_support_get_all();
       //var_dump($data['mechanical_support']);
       //exit();
        $this->load->view('home/virtual/mechanical_support', $data);
    }

  public function spares_stores()
    {
       $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
        $data['spares_stores'] = $this->Admin_model->spares_stores_get_all();
        $this->load->view('home/virtual/spares_stores', $data);
    }

 public function equipment_rental()
    {   
        $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
        $data['equipment_rental'] = $this->Admin_model->equipment_rental_get_all();
        //print_r($data['equipment_rental']);
        //exit();
        $this->load->view('home/virtual/equipment_rental', $data);
    }

     public function service_center()
    {
       $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information'); 
        $data['service_center'] = $this->Admin_model->service_center_get_all();
        $this->load->view('home/virtual/service_center', $data);
    }

   public function portfolio()
    {   
        $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
        $data['portfolio'] = $this->Admin_model->portfolio_get_all();
        $this->load->view('home/virtual/portfolio', $data);
    }

    public function products()
    {
       $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information'); 
        $data['photo_gallery'] = $this->General_model->get_photo_gallery();
        $data['catagory_list'] = $this->General_model->get_all_catagory_list($school_id);
        $data['vrproducts'] = $this->Admin_model->products_get_all();
        $this->load->view('home/virtual/products', $data);
    }

   public function csr()
    {
        $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
        $data['csr'] = $this->Admin_model->csr_get_all();
        $this->load->view('home/virtual/csr', $data);
    }

   public function blog()
    {
       $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
        $data['blog'] = $this->Admin_model->blog_get_all();
        $this->load->view('home/virtual/blog', $data);
    }


  public function virtual_constructionltd()
    {
        $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
        $data['virtual_constructionltd'] = $this->Admin_model->virtual_constructionltd_get_all();
        $this->load->view('home/virtual/virtual_constructionltd', $data);
    }

   public function md_message()
    {
        $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
        $data['md_message'] = $this->Admin_model->md_message_get_all();
        $this->load->view('home/virtual/md_message', $data);
    }
  public function virtual_ready_mix()
    {
        $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
        $data['virtual_ready_mix'] = $this->Admin_model->virtual_ready_mix_get_all();
        $this->load->view('home/virtual/virtual_ready_mix', $data);
    }

  public function virtual_marketing_tradingco()
    {
        $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
        $data['virtual_marketing_tradingco'] = $this->Admin_model->virtual_marketing_tradingco_get_all();
        $this->load->view('home/virtual/virtual_marketing_tradingco', $data);
    }
 
   public function welcome_to_virtual_properties_ltd()
    {
        $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
        $data['welcome_to_virtual_properties_ltd'] = $this->Admin_model->welcome_to_virtual_properties_ltd_get_all();
        $this->load->view('home/virtual/welcome_to_virtual_properties_ltd', $data);
    }
   
   public function schwing_stetter()
    {
        $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
        $data['schwing_stetter'] = $this->Admin_model->schwing_stetter_get_all();
        $this->load->view('home/virtual/schwing_stetter', $data);
    }

   public function soilmec()
    {
        $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
        $data['soilmec'] = $this->Admin_model->soilmec_get_all();
        $this->load->view('home/virtual/soilmec', $data);
    }

  public function corporate_office()
    {
        $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
        $data['corporate_office'] = $this->Admin_model->corporate_office_get_all();
        $this->load->view('home/virtual/corporate_office', $data);
    }

  public function branch_office()
    {
        $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
        $data['branch_office'] = $this->Admin_model->branch_office_get_all();
        $this->load->view('home/virtual/branch_office', $data);
    }
    public function career()
    {
        $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
        $data['career'] = $this->Admin_model->career_get_all();
        $this->load->view('home/virtual/career', $data);
    }

}