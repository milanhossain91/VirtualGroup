<?php
if (!defined('BASEPATH'))
    exit('No direct script access allowed');
class Web extends CI_Controller
{
    
    public function __construct()
    {
        session_start();
        parent::__construct();
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->model('common_model', 'Common_model', true);
        $this->load->model('admin_model', 'Admin_model', true);
        $this->load->library('form_validation');
        if (!is_loggedin()) {
            redirect('login');
            exit;
        }
    }
    /**F**/
     public function freedom_fighter()
    {
        if (isPostBack()) {
            
            if ($_FILES AND $_FILES['f_photo']['name']) {
            	
               
                 if ($_POST['f_photo_old'] == '0'){
                 $config['upload_path']   = "upload/freedom_fighter";
                $config['allowed_types'] = "jpg|jpeg|png|gif";
                #$config['encrypt_name']  = true;
                $config['max_size']      = "720";
                $config['max_width']     = "1500";
                $config['max_height']    = "1500";
            	 	$config['overwrite']     =   false;				
                	$config['file_name']     = "freedom_fighter";
            	 }
            	 else{
            	  $config['upload_path']   = "upload/freedom_fighter";
                $config['allowed_types'] = "jpg|jpeg|png|gif";
                #$config['encrypt_name']  = true;
                $config['max_size']      = "720";
                $config['max_width']     = "1500";
                $config['max_height']    = "1500";
            	  	$config['overwrite']     =   true;				
                	$config['file_name']     = substr($_POST['f_photo_old'], 0 , (strrpos($_POST['f_photo_old'], ".")));
                	
            	 }
                $this->load->library('upload', $config);
                
                if (!$this->upload->do_upload('f_photo')) {
                    echo $this->upload->display_errors();
                } else {
                    $spinfo               = $this->upload->data();
                    $data['f_photo'] = $spinfo['file_name'];
                }
                unset($config);
            }
            $school_id            = 1;
            $data['school_id']    = $school_id;
            $data['f_name']  = $_POST['f_name'];
            $data['f_des'] = $_POST['f_des'];
            $data['f_address'] = $_POST['f_address'];
            $data['f_phone'] = $_POST['f_phone'];
            $data['f_sector']     = $_POST['f_sector'];
            $data['order_by']     = $_POST['order_by'];
            if ($_POST['f_id'] != 0) {
                $save_data = $this->Common_model->common_update($data, $_POST['f_id'],'f_id','tbl_freedom_fighter');
            } else {
                $data['status']     = 1;
                $data['created_on'] = date('Y-m-d H:i:s', time());
                $save_data          = $this->Common_model->common_insert($data, 'tbl_freedom_fighter');
            }
          // print_r ($save_data);
          // die();
            if ($save_data)
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>A Freedom Fighter Added successfully</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
            redirect('web/freedom_fighter');
            exit;
        }
        $data['freedom_fighter_list'] = $this->Common_model->common_result_array('tbl_freedom_fighter');
        $this->load->view('web/freedom_fighter', $data);
        
    }

     public function institute_information(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
       
        $this->load->view('web/institute_information', $data);
    }
    
    public function institute_information_edit(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['school_info'] = $this->Common_model->common_row_by_condition($school_id,'school_information_id','tbl_school_information');
        $this->load->view('web/institute_information_edit', $data);
    }
    
    function institute_information_edit_save(){
        if(isPostBack())
        {
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $school_information_id = $_POST['school_information_id'];

            if ($_FILES AND $_FILES['school_logo']['name'] ) 
            {
                $config['upload_path']   =   "upload/institute_logo";
                $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']      =   "720";
                $config['max_width']     =   "1500";
                $config['max_height']    =   "1500";            
                $config['file_name']    =   $school_id."_logo";         

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('school_logo'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                   $spinfo=$this->upload->data();
                   $school_logo = $spinfo['file_name'];
                }
                $data['school_name'] = $_POST['school_name'];
                $data['school_id'] = $school_id;
                $data['school_title'] = $_POST['school_title'];
                $data['established'] = $_POST['established'];
                $data['eiin_no'] = $_POST['eiin_no'];
                $data['school_index_no'] = $_POST['school_index_no'];
                $data['school_code'] = $_POST['school_code'];
                $data['upazilla_code'] = $_POST['upazilla_code'];
                $data['district_code'] = $_POST['district_code'];
                $data['founder'] = $_POST['founder'];
                $data['address'] = $_POST['address'];
                $data['post_office'] = $_POST['post_office'];
                $data['district'] = $_POST['district'];
                $data['police_station'] = $_POST['police_station'];
                $data['contact_no'] = $_POST['contact_no'];
                $data['email'] = $_POST['email'];
                $data['website'] = $_POST['website'];
                $data['logo'] = $school_logo;
                $data['created_on'] = date('Y-m-d H:i:s',time()); 
                if($this->Common_model->common_update($data, $school_information_id,'school_information_id','tbl_school_information')){
                    $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
                }
                else{
                    $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
                }
                redirect('web/institute_information','refresh');exit;  
            }
            else{
                $data['school_name'] = $_POST['school_name'];
                $data['school_id'] = $school_id;
                $data['school_title'] = $_POST['school_title'];
                $data['established'] = $_POST['established'];
                $data['eiin_no'] = $_POST['eiin_no'];
                $data['school_index_no'] = $_POST['school_index_no'];
                $data['school_code'] = $_POST['school_code'];
                $data['upazilla_code'] = $_POST['upazilla_code'];
                $data['district_code'] = $_POST['district_code'];
                $data['founder'] = $_POST['founder'];
                $data['address'] = $_POST['address'];
                $data['post_office'] = $_POST['post_office'];
                $data['district'] = $_POST['district'];
                $data['police_station'] = $_POST['police_station'];
                $data['contact_no'] = $_POST['contact_no'];
                $data['email'] = $_POST['email'];
                $data['website'] = $_POST['website'];
                $data['created_on'] = date('Y-m-d H:i:s',time()); 
                            
                if($this->Common_model->common_update($data, $school_information_id,'school_information_id','tbl_school_information')){
                    $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
                }
                else{
                    $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
                }
                redirect('web/institute_information','refresh');exit;  
            }
        }
    }
    




      public  function freedom_fighter_delete($f_id, $f_photo)
    {
        $data['school_id'] = 1;
        $data['f_id'] = $f_id;
        #$img= explode("|", $member_image);
        $image_path        = "upload/freedom_fighter/" . $f_photo;
        unlink($image_path);
        //echo $image_path;
        #unlink(base_url("upload/freedom_fighter/".$f_photo));
        $this->Common_model->common_delete($data, 'tbl_freedom_fighter');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/freedom_fighter');
        exit;
    }
   public function freedom_fighter_edit($f_id)
    {
        $data1['freedom_fighter_list'] = $this->Common_model->common_result_array('tbl_freedom_fighter');
        $this->load->view('web/freedom_fighter_edit', $data1);
    }
   public function rejulation_view(){
    $data1['rejulation_viewimage'] = $this->Common_model->common_result_array('tbl_rejulation_registration');
    //$s_data['r_id']  = 1;
   // $data['rejulation_viewimage'] = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_rejulation_registration');



    $this->load->view('web/rejulation_view',$data1);

   }
   public function rejulation_save(){
   
            
            //Check whether user upload picture
            if(!empty($_FILES['rejulation_image']['name'])){
                $config['upload_path'] = 'upload/institute_logo';
                $config['allowed_types'] = 'jpg|jpeg|png|gif';
                $config['max_size']      =   "720";
                $config['max_width']     =   "1500";
                $config['max_height']    =   "1500";
                $config['overwrite']     =   true;
                $config['file_name'] = $_FILES['rejulation_image']['name'];
                
                //Load upload library and initialize configuration
                $this->load->library('upload',$config);
                $this->upload->initialize($config);
                
                if($this->upload->do_upload('rejulation_image')){
                    $uploadData = $this->upload->data();
                    $picture = $uploadData['file_name'];
                }else{
                    $picture = '';
                }
            }else{
                $picture = '';
            }
            
            //Prepare array of user data
            $data = array(
                
                'rejulation_image' => $picture
            );
            
            //Pass user data to model
            $insert=$this->Common_model->common_insert($data,'tbl_rejulation_registration');

         
            //Storing insertion status message.
            if($insert){
                $this->session->set_flashdata('success_msg', 'User data have been added successfully.');
            }else{
                $this->session->set_flashdata('error_msg', 'Some problems occured, please try again.');
            }
        
        //Form for adding user data
        $this->load->view('web/rejulation_view',$data);
  
    
     

   }


   function teacher_image_upload($file_data,$teacher_id){
            
            $config['upload_path']   =   "upload/teacher_image";
            $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
            #$config['encrypt_name']  = true;
            $config['max_size']      =   "720";
            $config['max_width']     =   "1500";
            $config['max_height']    =   "1500";
            $config['overwrite']     =   true;              
            $config['file_name']    =   $teacher_id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('teacher_image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['teacher_image']=$spinfo['file_name'];
                       $this->Common_model->common_update($data, $teacher_id,'teacher_id','tbl_teacher_registration');
                    }
                    unset($config);
            
        }
   public function managing_committee()
    {
        if (isPostBack()) {
            if ($_FILES AND $_FILES['m_image']['name']) {
                $config['upload_path']   = "upload/managing_committee";
                $config['allowed_types'] = "jpg|jpeg|png|gif";
                #$config['encrypt_name']  = true;
                $config['max_size']      = "720";
                $config['max_width']     = "1500";
                $config['max_height']    = "1500";
                #$config['overwrite']     =   true;				
                $config['file_name']     = "member";
                
                $this->load->library('upload', $config);
                
                if (!$this->upload->do_upload('m_image')) {
                    echo $this->upload->display_errors();
                } else {
                    $spinfo               = $this->upload->data();
                    $data['member_image'] = $spinfo['file_name'];
                }
                unset($config);
            }
            $school_id            = 1;
            $data['school_id']    = $school_id;
            $data['member_name']  = $_POST['m_name'];
            $data['member_desig'] = $_POST['m_des'];
            $data['mobile_no'] = $_POST['mobile_no'];
            $data['order_by']     = $_POST['m_order'];
            if ($_POST['member_id'] != 0) {
                $save_data = $this->Common_model->common_update($data, $_POST['member_id'], 'member_id', 'tbl_managing_committee');
            } else {
                $data['status']     = 1;
                $data['created_on'] = date('Y-m-d H:i:s', time());
                $save_data          = $this->Common_model->common_insert($data, 'tbl_managing_committee');
            }
            if ($save_data)
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>A New Member Added successfully</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
            redirect('web/managing_committee');
            exit;
        }
        $data1['member_list'] = $this->Common_model->common_result_array('tbl_managing_committee');
        $this->load->view('web/managing_committee', $data1);
    }
  public  function managing_committee_delete($member_id, $member_image)
    {
        $data['school_id'] = 1;
        $data['member_id'] = $member_id;
        #$img= explode("|", $member_image);
        $image_path        = "upload/managing_committee/" . $member_image;
        unlink($image_path);
        //echo $image_path;
        #unlink(base_url("upload/managing_committee/".$member_image));
        $this->Common_model->common_delete($data, 'tbl_managing_committee');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/managing_committee');
        exit;
    }
   public function managing_committee_edit($member_id)
    {
        $data1['member_list'] = $this->Common_model->common_result_array('tbl_managing_committee');
        $this->load->view('web/managing_committee_edit', $data1);
    }
   public function donor()
    {
if (isPostBack()) {
            #$school_id = $_SESSION['school_id'];
            $school_id              = 1;
            $data['school_id']      = $school_id;
            $data['donnor_name']    = $_POST['d_name'];
            $data['donnor_phone']   = $_POST['d_phone'];
            $data['donnor_address'] = $_POST['d_add'];
            $data['status']         = 1;
            $data['created_on']     = date('Y-m-d H:i:s', time());
            
            if ($_POST['id'] != 0) {
                $save_data = $this->Common_model->common_update($data, $_POST['id'], 'id', 'tbl_donor');
            } else {
                $data['status']     = 1;
                $data['created_on'] = date('Y-m-d H:i:s', time());
                $save_data          = $this->Common_model->common_insert($data, 'tbl_donor');
            }
            
            if ($save_data)
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
            
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
            redirect('web/donor');
            exit;
        }
        $data['donor_list'] = $this->Common_model->common_result_array('tbl_donor');
        $this->load->view('web/donor', $data);
    }
    
    function donor_delete($id)
    {

        $data['id'] = $id;

        $this->Common_model->common_delete($data, 'tbl_donor');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/donor');
        exit;
    }
    public function message()
    {
        //$school_id = $_SESSION['school_id'];
        $s_data['school_id']  = 1;
        $data['message_list'] = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_message');
        $this->load->view('web/message', $data);
    }
    
    public function message_update($message_id)
    {
        //$school_id = $_SESSION['school_id'];
        $s_data['school_id']  = 1;
        $s_data['message_id'] = $message_id;
        $data['message']      = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_message');
        $this->load->view('web/message_update', $data);
    }
    
    function message_save()
    {
        //$school_id = $_SESSION['school_id'];
        $school_id           = 1;
        $message_type        = $_POST['type'];
        $s_data['school_id'] = $school_id;
        $principal_message   = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_message');
        if (count($principal_message) >= 3) {
            $this->session->set_flashdata('message', '<div class="alert alert-danger"><strong>Danger!</strong><a href="#" class="close" data-dismiss="alert">&times;</a> You cannot add more then three (3) types of message.</div>');
            redirect('web/message');
            exit;
        } elseif ($message_type != '') {
            $data['type']       = $message_type;
            $data['name']       = 'No';
            $data['image']      = '';
            $data['message']    = 'No';
            $data['school_id']  = $school_id;
            $data['status']     = 1;
            $data['created_on'] = date('Y-m-d H:i:s', time());
            if ($this->Common_model->common_insert($data, 'tbl_message'))
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been saved. Please try again.</div>');
            redirect('web/message');
            exit;
            
        }
    }
    
    function message_update_save()
    {
        //$school_id=$_SESSION['school_id'];
        $school_id  = 1;
        $message_id = $_POST['message_id'];
        $type       = $_POST['type'];
        $name       = $_POST['name'];
        $message    = $_POST['message'];
        if ($_POST['image_name'])
            $image_name = $_POST['image_name'];
        else
            $image_name = date('dmYHis') . $school_id . "_message_image";
        
        if ($_FILES AND $_FILES['image']['name']) {
            $config['upload_path']   = "upload/message_image";
            $config['allowed_types'] = "jpg|jpeg|png|gif";
            $config['max_size']      = "320";
            $config['max_width']     = "700";
            $config['max_height']    = "800";
            $config['overwrite']     = TRUE;
            $config['file_name']     = $image_name;
            
            $this->load->library('upload', $config);
            
            if (!$this->upload->do_upload('image')) {
                echo $this->upload->display_errors();
            }
            
            else {
                $finfo = $this->upload->data();
                $image = $finfo['file_name'];
                
                $data['type']       = $type;
                $data['name']       = $name;
                $data['image']      = $image;
                $data['message']    = $message;
                $data['created_on'] = date('Y-m-d H:i:s', time());
                if ($this->Common_model->common_update($data, $message_id, 'message_id', 'tbl_message'))
                    $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
                else
                    $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been saved. Please try again.</div>');
                
                redirect('web/message');
                exit;
            }
        } else {
            $data['type']       = $type;
            $data['name']       = $name;
            $data['message']    = $message;
            $data['created_on'] = date('Y-m-d H:i:s', time());
            if ($this->Common_model->common_update($data, $message_id, 'message_id', 'tbl_message'))
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been saved. Please try again.</div>');
            redirect('web/message');
            exit;
        }
    }
    
    function message_delete($message_id)
    {
        //$school_id = $_SESSION['school_id'];
        $d_data['school_id']  = 1;
        $d_data['message_id'] = $message_id;
        if ($this->Common_model->common_delete($d_data, 'tbl_message'))
            $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been deleted successfully</div>');
        else
            $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
        
        redirect('web/message');
        exit;
    }
    
    /************** information ******************/
    
    public function information_list()
    {
        //$school_id = $_SESSION['school_id'];
        $s_data['school_id']      = 1;
        $data['information_list'] = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_important_information');
        $this->load->view('web/information_list', $data);
    }
    
    function information_save()
    {
        if (isPostBack()) {
            $c_data['information_type'] = $_POST['information_type'];
            $c_data['school_id']        = 1;
            $chk                        = $this->Common_model->common_select_by_multycondition($c_data, 'tbl_important_information');
            
            if (!$chk) {
                //$school_id = $_SESSION['school_id'];
                $data['school_id']           = 1;
                $data['information_type']    = $_POST['information_type'];
                $data['information_heading'] = $_POST['information_heading'];
                $data['information_details'] = $_POST['information_details'];
                $data['status']              = '1';
                $data['created_on']          = date('Y-m-d H:i:s', time());
                
                if ($this->Common_model->common_insert($data, 'tbl_important_information'))
                    $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
                else
                    $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Under this information type data had been saved. You can just edit old data from edit option.</div>');
            }
        }
        redirect('web/information_list');
        exit;
    }
    
    public function single_information_edit($info_id)
    {
        //$school_id = $_SESSION['school_id'];
        $s_data['info_id']        = $info_id;
        $s_data['school_id']      = 1;
        $data['information_list'] = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_important_information');
        $this->load->view('web/single_information_edit', $data);
    }
    
    function information_edit_save()
    {
        if (isPostBack()) {
            $info_id                     = $_POST['info_id'];
            $data['information_heading'] = $_POST['information_heading'];
            $data['information_details'] = $_POST['information_details'];
            if ($this->Common_model->common_update($data, $info_id, 'info_id', 'tbl_important_information'))
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
            
            redirect('web/information_list');
            exit;
        }
    }
    
    /********************** /information ******************/
    
    /********************** slide ******************/
    
    public function slide()
    {
        //$school_id = $_SESSION['school_id'];
        $s_data['school_id'] = 1;
        $data['slide_image'] = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_slide_image');
        $this->load->view("web/slide", $data);
    }
    
    function slide_image_save()
    {
        if (isPostBack()) {
            // $school_id = $_SESSION['school_id'];
            $school_id               = 1;
            $config['upload_path']   = "upload/slides";
            $config['allowed_types'] = "jpg|jpeg|png";
            $config['max_size']      = "3000";
            $config['max_width']     = "1940";
            $config['max_height']    = "892";
            $config['file_name']     = $school_id . "_slide_image";
            
            $this->load->library('upload', $config);
            
            if (!$this->upload->do_upload('slide_image')) {
                echo $this->upload->display_errors();
            }
            
            else {
                $finfo            = $this->upload->data();
                $slide_image_name = $finfo['file_name'];
                
                $data['school_id']        = $school_id;
                $data['slide_image_name'] = $slide_image_name;
                $data['slide_caption']    = $_POST['slide_caption'];
                $data['status']           = 1;
                $data['created_on']       = date('Y-m-d H:i:s', time());
                if ($this->Common_model->common_insert($data, 'tbl_slide_image'))
                    $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
                else
                    $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
                
                redirect('web/slide');
                exit;
            }
        }
    }
    
    
    function delete_slide_image($slide_image_id, $image_name)
    {
        //$school_id = $_SESSION['school_id'];
        $d_data['school_id']      = 1;
        $d_data['slide_image_id'] = $slide_image_id;
        $image_path               = 'upload/slides/' . $image_name;
        if ($this->Common_model->common_delete($d_data, 'tbl_slide_image')) {
            unlink($image_path);
            $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been deleted successfully</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
        }
        redirect('web/slide');
        exit;
    }
    
    
    /**************** /slide ***********************/
    
    /**************** about college ***********************/
     public function computer_lab_info()
    {

        $this->load->view('web/computer_lab_info');
    }
     public function founder()
    {

        $this->load->view('web/founder');
    }
    public function about()
    {
        //$school_id = $_SESSION['school_id'];
        $s_data['school_id'] = 1;
        $data['about']       = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_about');
        $this->load->view('web/about', $data);
    }
    
    function about_edit_save()
    {
        if (isPostBack()) {
            //$school_id=$_SESSION['school_id'];
            $school_id           = 1;
            $s_data['school_id'] = $school_id;
            if ($_FILES AND $_FILES['about_image']['name']) {
                $config['upload_path']   = "upload/about_image";
                $config['allowed_types'] = "jpg|jpeg|png|gif";
                $config['max_size']      = "400";
                $config['max_width']     = "750";
                $config['max_height']    = "300";
                $config['overwrite']     = TRUE;
                $config['file_name']     = $school_id . "_about_image";
                
                $this->load->library('upload', $config);
                
                if (!$this->upload->do_upload('about_image')) {
                    $error = $this->upload->display_errors();
                }
                
                else {
                    $chk = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_about');
                    if (!$chk) {
                        $finfo       = $this->upload->data();
                        $about_image = $finfo['file_name'];
                        
                        $data['school_id']     = $school_id;
                        $data['about_details'] = $_POST['about_details'];
                        $data['about_image']   = $about_image;
                        $data['status']        = 1;
                        $data['created_on']    = date('Y-m-d H:i:s', time());
                        if ($this->Common_model->common_insert($data, 'tbl_about'))
                            $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
                        else
                            $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
                    } else {
                        $finfo       = $this->upload->data();
                        $about_image = $finfo['file_name'];
                        
                        
                        $data['school_id']     = $school_id;
                        $data['about_details'] = $_POST['about_details'];
                        $data['about_image']   = $about_image;
                        if ($this->Common_model->common_update($data, $school_id, 'school_id', 'tbl_about'))
                            $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
                        else
                            $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
                    }
                }
            }
            
            else {
                
                $chk = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_about');
                if (!$chk) {
                    $finfo       = $this->upload->data();
                    $about_image = $finfo['file_name'];
                    
                    $data['school_id']     = $school_id;
                    $data['about_details'] = $_POST['about_details'];
                    $data['about_image']   = $about_image;
                    $data['status']        = 1;
                    $data['created_on']    = date('Y-m-d H:i:s', time());
                    if ($this->Common_model->common_insert($data, 'tbl_about'))
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
                    else
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
                } else {
                    $data['about_details'] = $_POST['about_details'];
                    
                    if ($this->Common_model->common_update($data, $school_id, 'school_id', 'tbl_about'))
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
                    else
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
                    
                    
                }
            }
        }
        if ($error)
            $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
        
        redirect('web/about');
        exit;
    }
    
    /**************** /about college ***********************/
    
    /**************** photo gallery  ***********************/
    
    
    public function catagory_list()
    {
        //$school_id = $_SESSION['school_id'];
        $s_data['school_id']   = 1;
        $data['catagory_list'] = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_photo_catagory');
        $this->load->view('web/catagory_list', $data);
    }
    
    function catagory_save()
    {
        if (isPostBack()) {
            //$data['school_id'] = $_SESSION['school_id'];
            $data['school_id']     = 1;
            $data['catagory_name'] = $_POST['catagory_name'];
            if ($_POST['catagory_id']) {
                $catagory_id = $_POST['catagory_id'];
                if ($this->Common_model->common_update($data, $catagory_id, 'catagory_id', 'tbl_photo_catagory'))
                    $save = 1;
                else
                    $save = 0;
            } else {
                $data['created_on'] = date('Y-m-d H:i:s', time());
                if ($this->Common_model->common_insert($data, 'tbl_photo_catagory'))
                    $save = 1;
                else
                    $save = 0;
            }
            
            if ($save == 1) {
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
            }
        }
        
        redirect('web/catagory_list');
        exit;
    }
    
    
    function catagory_delete($catagory_id)
    {
        $d_data['school_id']   = 1;
        $d_data['catagory_id'] = $catagory_id;
        if ($this->Common_model->common_delete($d_data, 'tbl_photo_catagory')) {
            $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been deleted successfully</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
        }
        redirect('web/catagory_list');
        exit;
    }
    
    
    public function picture_gallery()
    {
        //$school_id = $_SESSION['school_id'];
        $s_data['school_id']   = 1;
        $data['gallery_image'] = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_photo_gallery');
        $data['catagory_list'] = $this->Common_model->common_select_by_multycondition($s_data, 'tbl_photo_catagory');
        $this->load->view('web/picture_gallery', $data);
    }
    
    function picture_gallery_save()
    {
        if (isPostBack()) {
            //$school_id = $_SESSION['school_id'];
            $school_id               = 1;
            $config['upload_path']   = "upload/photo_gallery";
            $config['allowed_types'] = "jpg|jpeg|png";
            $config['max_size']      = "1000";
            $config['max_width']     = "1200";
            $config['max_height']    = "900";
            $config['file_name']     = $school_id . "_gallery_photo";
            
            $this->load->library('upload', $config);
            
            if (!$this->upload->do_upload('gallery_image_name')) {
                $error = $this->upload->display_errors();
            }
            
            else {
                $finfo              = $this->upload->data();
                $gallery_image_name = $finfo['file_name'];
                
                $data['school_id']          = $school_id;
                $data['photo_caption']      = $_POST['photo_caption'];
                $data['catagory_id']        = $_POST['catagory_id'];
                $data['gallery_image_name'] = $gallery_image_name;
                $data['status']             = 1;
                $data['created_on']         = date('Y-m-d H:i:s', time());
                if ($this->Common_model->common_insert($data, 'tbl_photo_gallery')) {
                    $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been saved</div>');
                } else {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
                }
                
            }
        }
        if ($error)
            $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
        
        redirect('web/picture_gallery');
        exit;
    }
    
    function delete_gallery_image($photo_gallery_id, $image_name)
    {
        //$school_id = $_SESSION['school_id'];
        $d_data['school_id']        = 1;
        $d_data['photo_gallery_id'] = $photo_gallery_id;
        $image_path                 = 'upload/photo_gallery/' . $image_name;
        if ($this->Common_model->common_delete($d_data, 'tbl_photo_gallery')) {
            unlink($image_path);
            $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been deleted successfully</div>');
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong> Data has not been deleted. Please try again.</div>');
        }
        redirect('web/picture_gallery');
        exit;
    }
    
    /**************** /photo gallery  ***********************/
        public function other_assets()
    {
        /* if (isPostBack()) {
            $school_id            = 1;
            $data['school_id']    = $school_id;
            $data['asset_name']  = $_POST['m_name'];
            $data['member_desig'] = $_POST['m_des'];
            $data['mobile_no'] = $_POST['mobile_no'];
            if ($_POST['member_id'] != 0) {
                $save_data = $this->Common_model->common_update($data, $_POST['member_id'], 'member_id', 'tbl_assets');
            } else {
                $data['status']     = 1;
                $data['created_on'] = date('Y-m-d H:i:s', time());
                $save_data          = $this->Common_model->common_insert($data, 'tbl_assets');
            }
            if ($save_data)
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Added successfully</div>');
            else
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved.</div>');
            redirect('web/other_assets');
            exit;
        }
        $data1['member_list'] = $this->Common_model->common_result_array('tbl_assets');*/
        $this->load->view('web/other_assets');
    }  
    public function land_info()
    {
        $this->load->view('web/land_info');
    }

    public function computer_lab()
    {
        $this->load->view('web/computer_lab');
    }
 //Application all menu set//


   public function md_message(){

        $data['md_message'] = $this->Admin_model->md_message_get_all();

        $this->load->view('web/md_message', $data);

   }

 
    public function md_message_edit($op_id){
         $condition['id']=$op_id;
         $data['md_message_edit'] = $this->Admin_model->md_message_edit_get_all($op_id);
         //var_dump($data['mechanical_support_edit']);
        // exit();
        $this->load->view('web/md_message_edit', $data);
    }


  function md_message_edit_save(){

   
        if(isPostBack())
        {               
              $id = $_POST['id'];
              $data['title'] = $_POST['title'];
              $data['content'] = $_POST['content'];
              $this->Common_model->common_update($data, $id,'id','tbl_md_message');
            
             if ( $_FILES AND $_FILES['image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/md_message";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
                    $config['overwrite']     =   true;              
                    $config['file_name']    =   $id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['title'] = $_POST['title'];
                       $id = $_POST['id'];
                        $data['content'] = $_POST['content'];
                        $data['image'] = $_POST['image'];
                       $data['image'] = $spinfo['file_name'];
                        $this->Common_model->common_update($data, $id,'id','tbl_md_message');
                    }

                 unset($config);
                    }else{
                        $student_photo = '';
                    }

                     if ($error){
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
               
                     }else{
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

                     }
                   
                   
                    
                    redirect('web/md_message');  
                    exit(); 
                } 





      
       

      }
   
   public function md_message_save(){

   if(isPostBack())
        {               
            $data['title'] = $_POST['title'];
            $data['content'] = $_POST['content'];
            $date=date("Y-m-d");     
            $data['date'] = $date;  


            $insert = $this->Common_model->common_insert($data,'tbl_md_message');
            
            if ( $_FILES AND $_FILES['image']['name'] ) 
            {
                $config['upload_path']  =   "upload/md_message";
                $config['allowed_types']=   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']     =   "720";
                $config['max_width']    =   "1500";
                $config['max_height']   =   "1500";
                $config['overwrite']    =   true;               
                $config['file_name']    =   $insert."_photo";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('image'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                    $spinfo = $this->upload->data();
                    $student_photo = $spinfo['file_name'];
                   
                    $data['image'] = $spinfo['file_name'];
                    $this->Common_model->common_update($data, $insert,'id','tbl_md_message');
                }
                unset($config);
            }else{
                $student_photo = '';
            }

             if ($error){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
       
             }else{
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

             }
           
           
            
            redirect('web/md_message');  
            exit();            
        }


   }

   public function md_message_delete($id, $ms_image){

        $data['id'] = $id;
        $image_path        = "upload/md_message/" . $ms_image;
        unlink($image_path);
        $this->Common_model->common_delete($data, 'tbl_md_message');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/md_message');
        exit;

   }







   public function mechanical_support()
    {
     //  $school_id = 1;
       $data['mechanical_support'] = $this->Admin_model->mechanical_support_get_all();
       //var_dump($data['mechanical_support']);
       //exit();
        $this->load->view('web/mechanical_support', $data);
    }

    public function mechanical_support_edit($op_id){
         $condition['id']=$op_id;
         $data['mechanical_support_edit'] = $this->Admin_model->mechanical_support_edit_get_all($op_id);
         //var_dump($data['mechanical_support_edit']);
        // exit();
        $this->load->view('web/mechanical_support_edit', $data);
    }





    function mechanical_support_edit_save(){

        // print_r($_POST);
        // exit();
       if(isPostBack())
        {               
              $id = $_POST['id'];
              $data['ms_title'] = $_POST['ms_title'];
              $data['ms_content'] = $_POST['ms_content'];
              $this->Common_model->common_update($data, $id,'id','tbl_mechanical_support');
            
             if ( $_FILES AND $_FILES['ms_image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/mechanical_support";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
                    $config['overwrite']     =   true;              
                    $config['file_name']    =   $id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('ms_image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['ms_title'] = $_POST['ms_title'];
                       $id = $_POST['id'];
                        $data['ms_content'] = $_POST['ms_content'];
                        $data['ms_image'] = $_POST['ms_image'];
                       $data['ms_image'] = $spinfo['file_name'];
                        $this->Common_model->common_update($data, $id,'id','tbl_mechanical_support');
                    }

                 unset($config);
                    }else{
                        $student_photo = '';
                    }

                     if ($error){
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
               
                     }else{
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

                     }
                   
                    
                    redirect('web/mechanical_support');  
                    exit(); 
                } 





      
       

      }
   
   public function mechanical_support_save(){

   // print_r($_POST);
   // exit();


       if(isPostBack())
        {               
            $data['ms_title'] = $_POST['ms_title'];
            $data['ms_content'] = $_POST['ms_content'];
            $date=date("Y-m-d");     
            $data['ms_date'] = $date;  


            $insert = $this->Common_model->common_insert($data,'tbl_mechanical_support');
            
            if ( $_FILES AND $_FILES['ms_image']['name'] ) 
            {
                $config['upload_path']  =   "upload/mechanical_support";
                $config['allowed_types']=   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']     =   "720";
                $config['max_width']    =   "1500";
                $config['max_height']   =   "1500";
                $config['overwrite']    =   true;               
                $config['file_name']    =   $insert."_photo";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('ms_image'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                    $spinfo = $this->upload->data();
                    $student_photo = $spinfo['file_name'];
                   
                    $data['ms_image'] = $spinfo['file_name'];
                    $this->Common_model->common_update($data, $insert,'id','tbl_mechanical_support');
                }
                unset($config);
            }else{
                $student_photo = '';
            }

             if ($error){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
       
             }else{
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

             }
           
            
            redirect('web/mechanical_support');  
            exit();            
        }


   }


   public function mechanical_support_delete($id){

          $data['id'] = $id;

        $this->Common_model->common_delete($data, 'tbl_mechanical_support');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/mechanical_support');
        exit;

   }





    public function spares_stores_edit($op_id){

        $condition['id']=$op_id;
        $data['spares_stores_edit'] = $this->Admin_model->spares_stores_edit_get_all($op_id);
        //var_dump($data['spares_stores_edit']);
       // exit();
        $this->load->view('web/spares_stores_edit', $data);
    }

    public function spares_stores_edit_save(){

        if(isPostBack())
        {               
              $id = $_POST['id'];
              $data['title'] = $_POST['title'];
              $data['content'] = $_POST['content'];
              $this->Common_model->common_update($data, $id,'id','tbl_spares_stores');
            
             if ( $_FILES AND $_FILES['image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/spares_stores";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
                    $config['overwrite']     =   true;              
                    $config['file_name']    =   $id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['title'] = $_POST['title'];
                       $id = $_POST['id'];
                        $data['content'] = $_POST['content'];
                        $data['image'] = $_POST['image'];
                       $data['image'] = $spinfo['file_name'];
                        $this->Common_model->common_update($data, $id,'id','tbl_spares_stores');
                    }

                 unset($config);
                    }else{
                        $student_photo = '';
                    }

                     if ($error){
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
               
                     }else{
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

                     }
                   
                    
                    redirect('web/spares_stores');  
                    exit(); 
                } 


    }

   public function spares_stores()
    {
       
        $data['spares_stores'] = $this->Admin_model->spares_stores_get_all();
        $this->load->view('web/spares_stores', $data);
    }

   public function spares_stores_save(){

     if(isPostBack())
        {               
            $data['title'] = $_POST['title'];
            $data['content'] = $_POST['content'];
            $date=date("Y-m-d");     
            $data['date'] = $date;  


            $insert = $this->Common_model->common_insert($data,'tbl_spares_stores');
            
            if ( $_FILES AND $_FILES['image']['name'] ) 
            {
                $config['upload_path']  =   "upload/spares_stores";
                $config['allowed_types']=   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']     =   "720";
                $config['max_width']    =   "1500";
                $config['max_height']   =   "1500";
                $config['overwrite']    =   true;               
                $config['file_name']    =   $insert."_photo";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('image'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                    $spinfo = $this->upload->data();
                    $student_photo = $spinfo['file_name'];
                   
                    $data['image'] = $spinfo['file_name'];
                    $this->Common_model->common_update($data, $insert,'id','tbl_spares_stores');
                }
                unset($config);
            }else{
                $student_photo = '';
            }

             if ($error){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
       
             }else{
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

             }
           
            
            redirect('web/spares_stores');  
            exit();            
        }

   }

   public function spares_stores_delete($id){

          $data['id'] = $id;

        $this->Common_model->common_delete($data, 'tbl_spares_stores');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/spares_stores');
        exit;

   }

    public function equipment_rental_edit($op_id){
        $condition['id']=$op_id;
         $data['equipment_rental_edit'] = $this->Admin_model->equipment_rental_edit_get_all($op_id);
       //var_dump($data['mechanical_support']);
       //exit();
        $this->load->view('web/equipment_rental_edit', $data);
    }

   public function equipment_rental()
    {
        $data['equipment_rental'] = $this->Admin_model->equipment_rental_get_all();
        //print_r($data['equipment_rental']);
        //exit();
        $this->load->view('web/equipment_rental', $data);
    }

  public function equipment_rental_edit_save(){

     if(isPostBack())
        {               
              $id = $_POST['id'];
              $data['title'] = $_POST['title'];
              $data['content'] = $_POST['content'];
              $this->Common_model->common_update($data, $id,'id','tbl_equipment_rental');
            
             if ( $_FILES AND $_FILES['image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/equipment_rental";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
                    $config['overwrite']     =   true;              
                    $config['file_name']    =   $id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['title'] = $_POST['title'];
                       $id = $_POST['id'];
                        $data['content'] = $_POST['content'];
                        $data['image'] = $_POST['image'];
                       $data['image'] = $spinfo['file_name'];
                        $this->Common_model->common_update($data, $id,'id','tbl_equipment_rental');
                    }

                 unset($config);
                    }else{
                        $student_photo = '';
                    }

                     if ($error){
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
               
                     }else{
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

                     }
                   
                    
                    redirect('web/equipment_rental');  
                    exit(); 
                } 


  }
   
   public function equipment_rental_save(){

          if(isPostBack())
        {               
            $data['title'] = $_POST['title'];
            $data['content'] = $_POST['content'];
            $date=date("Y-m-d");     
            $data['date'] = $date;  


            $insert = $this->Common_model->common_insert($data,'tbl_equipment_rental');
            
            if ( $_FILES AND $_FILES['image']['name'] ) 
            {
                $config['upload_path']  =   "upload/equipment_rental";
                $config['allowed_types']=   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']     =   "720";
                $config['max_width']    =   "1500";
                $config['max_height']   =   "1500";
                $config['overwrite']    =   true;               
                $config['file_name']    =   $insert."_photo";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('image'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                    $spinfo = $this->upload->data();
                    $student_photo = $spinfo['file_name'];
                   
                    $data['image'] = $spinfo['file_name'];
                    $this->Common_model->common_update($data, $insert,'id','tbl_equipment_rental');
                }
                unset($config);
            }else{
                $student_photo = '';
            }

             if ($error){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
       
             }else{
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

             }
           
            
            redirect('web/equipment_rental');  
            exit();            
        }

   }

    public function equipment_rental_delete($id){

          $data['id'] = $id;

        $this->Common_model->common_delete($data, 'tbl_equipment_rental');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/equipment_rental');
        exit;

   }

    public function service_center_edit($op_id){
        $condition['id']=$op_id;
        $data['service_center_edit'] = $this->Admin_model->service_center_edit_get_all($op_id);
        $this->load->view('web/service_center_edit', $data);
    }

   public function service_center_edit_save(){

         if(isPostBack())
        {               
              $id = $_POST['id'];
              $data['title'] = $_POST['title'];
              $data['content'] = $_POST['content'];
              $this->Common_model->common_update($data, $id,'id','tbl_service_center');
            
             if ( $_FILES AND $_FILES['image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/service_center";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
                    $config['overwrite']     =   true;              
                    $config['file_name']    =   $id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['title'] = $_POST['title'];
                       $id = $_POST['id'];
                        $data['content'] = $_POST['content'];
                        $data['image'] = $_POST['image'];
                       $data['image'] = $spinfo['file_name'];
                        $this->Common_model->common_update($data, $id,'id','tbl_service_center');
                    }

                 unset($config);
                    }else{
                        $student_photo = '';
                    }

                     if ($error){
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
               
                     }else{
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

                     }
                   
                    
                    redirect('web/service_center');  
                    exit(); 
                } 

   }

   public function service_center()
    {
        
        $data['service_center'] = $this->Admin_model->service_center_get_all();
        $this->load->view('web/service_center', $data);
    }

   public function service_center_save(){

     if(isPostBack())
        {               
            $data['title'] = $_POST['title'];
            $data['content'] = $_POST['content'];
            $date=date("Y-m-d");     
            $data['date'] = $date;  


            $insert = $this->Common_model->common_insert($data,'tbl_service_center');
            
            if ( $_FILES AND $_FILES['image']['name'] ) 
            {
                $config['upload_path']  =   "upload/service_center";
                $config['allowed_types']=   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']     =   "720";
                $config['max_width']    =   "1500";
                $config['max_height']   =   "1500";
                $config['overwrite']    =   true;               
                $config['file_name']    =   $insert."_photo";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('image'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                    $spinfo = $this->upload->data();
                    $student_photo = $spinfo['file_name'];
                   
                    $data['image'] = $spinfo['file_name'];
                    $this->Common_model->common_update($data, $insert,'id','tbl_service_center');
                }
                unset($config);
            }else{
                $student_photo = '';
            }

             if ($error){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
       
             }else{
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

             }
           
            
            redirect('web/service_center');  
            exit();            
        }

   }

  public function service_center_delete($id){

          $data['id'] = $id;

        $this->Common_model->common_delete($data, 'tbl_service_center');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/service_center');
        exit;

   }

 public function portfolio_edit($op_id){
       $condition['id']=$op_id;
        $data['portfolio_edit'] = $this->Admin_model->portfolio_edit_get_all($op_id);

        $this->load->view('web/portfolio_edit', $data);
    }

   public function portfolio()
    {
        $data['portfolio'] = $this->Admin_model->portfolio_get_all();
        $this->load->view('web/portfolio', $data);
    }


   public function portfolio_edit_save(){

            if(isPostBack())
        {               
              $id = $_POST['id'];
              $data['title'] = $_POST['title'];
              $data['content'] = $_POST['content'];
              $this->Common_model->common_update($data, $id,'id','tbl_portfolio');
            
             if ( $_FILES AND $_FILES['image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/portfolio";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
                    $config['overwrite']     =   true;              
                    $config['file_name']    =   $id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['title'] = $_POST['title'];
                       $id = $_POST['id'];
                        $data['content'] = $_POST['content'];
                        $data['image'] = $_POST['image'];
                       $data['image'] = $spinfo['file_name'];
                        $this->Common_model->common_update($data, $id,'id','tbl_portfolio');
                    }

                 unset($config);
                    }else{
                        $student_photo = '';
                    }

                     if ($error){
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
               
                     }else{
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

                     }
                   
                    
                    redirect('web/portfolio');  
                    exit(); 
                } 

   }

   public function portfolio_save(){

        if(isPostBack())
        {               
            $data['title'] = $_POST['title'];
            $data['content'] = $_POST['content'];
            $date=date("Y-m-d");     
            $data['date'] = $date;  


            $insert = $this->Common_model->common_insert($data,'tbl_portfolio');
            
            if ( $_FILES AND $_FILES['image']['name'] ) 
            {
                $config['upload_path']  =   "upload/portfolio";
                $config['allowed_types']=   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']     =   "720";
                $config['max_width']    =   "1500";
                $config['max_height']   =   "1500";
                $config['overwrite']    =   true;               
                $config['file_name']    =   $insert."_photo";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('image'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                    $spinfo = $this->upload->data();
                    $student_photo = $spinfo['file_name'];
                   
                    $data['image'] = $spinfo['file_name'];
                    $this->Common_model->common_update($data, $insert,'id','tbl_portfolio');
                }
                unset($config);
            }else{
                $student_photo = '';
            }

             if ($error){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
       
             }else{
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

             }
           
            
            redirect('web/portfolio');  
            exit();            
        }

   }

    public function portfolio_delete($id){

          $data['id'] = $id;

        $this->Common_model->common_delete($data, 'tbl_portfolio');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/portfolio');
        exit;

   }

    public function products_edit($op_id){
       $condition['id']=$op_id;
        $data['products_edit'] = $this->Admin_model->products_edit_get_all($op_id);

        $this->load->view('web/products_edit', $data);
    }

  public function products_edit_save(){


            if(isPostBack())
        {               
              $id = $_POST['id'];
              $data['title'] = $_POST['title'];
              $data['content'] = $_POST['content'];
              $this->Common_model->common_update($data, $id,'id','products');
            
             if ( $_FILES AND $_FILES['image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/products";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
                    $config['overwrite']     =   true;              
                    $config['file_name']    =   $id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['title'] = $_POST['title'];
                       $id = $_POST['id'];
                        $data['content'] = $_POST['content'];
                        $data['image'] = $_POST['image'];
                       $data['image'] = $spinfo['file_name'];
                        $this->Common_model->common_update($data, $id,'id','products');
                    }

                 unset($config);
                    }else{
                        $student_photo = '';
                    }

                     if ($error){
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
               
                     }else{
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

                     }
                   
                    
                    redirect('web/products');  
                    exit(); 
                } 

  }
  
   public function products()
    {
        
        $data['vrproducts'] = $this->Admin_model->products_get_all();
        $this->load->view('web/products', $data);
    }
   
   public function products_save(){

      if(isPostBack())
        {               
            $data['title'] = $_POST['title'];
            $data['content'] = $_POST['content'];
            $date=date("Y-m-d");     
            $data['date'] = $date;  


            $insert = $this->Common_model->common_insert($data,'products');
            
            if ( $_FILES AND $_FILES['image']['name'] ) 
            {
                $config['upload_path']  =   "upload/products";
                $config['allowed_types']=   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']     =   "720";
                $config['max_width']    =   "1500";
                $config['max_height']   =   "1500";
                $config['overwrite']    =   true;               
                $config['file_name']    =   $insert."_photo";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('image'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                    $spinfo = $this->upload->data();
                    $student_photo = $spinfo['file_name'];
                   
                    $data['image'] = $spinfo['file_name'];
                    $this->Common_model->common_update($data, $insert,'id','products');
                }
                unset($config);
            }else{
                $student_photo = '';
            }

             if ($error){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
       
             }else{
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

             }
           
            
            redirect('web/products');  
            exit();            
        }

   }

   public function products_delete($id){

          $data['id'] = $id;

        $this->Common_model->common_delete($data, 'products');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/products');
        exit;

   }


   public function csr_edit($op_id){
       $condition['id']=$op_id;
        $data['csr_edit'] = $this->Admin_model->csr_edit_get_all($op_id);

        $this->load->view('web/csr_edit', $data);
    }

   public function csr_edit_save(){

           if(isPostBack())
        {               
              $id = $_POST['id'];
              $data['title'] = $_POST['title'];
              $data['content'] = $_POST['content'];
              $this->Common_model->common_update($data, $id,'id','tbl_csr');
            
             if ( $_FILES AND $_FILES['image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/csr";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
                    $config['overwrite']     =   true;              
                    $config['file_name']    =   $id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['title'] = $_POST['title'];
                       $id = $_POST['id'];
                        $data['content'] = $_POST['content'];
                        $data['image'] = $_POST['image'];
                       $data['image'] = $spinfo['file_name'];
                        $this->Common_model->common_update($data, $id,'id','tbl_csr');
                    }

                 unset($config);
                    }else{
                        $student_photo = '';
                    }

                     if ($error){
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
               
                     }else{
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

                     }
                   
                    
                    redirect('web/csr');  
                    exit(); 
                } 

   }

    public function csr()
    {
        $data['csr'] = $this->Admin_model->csr_get_all();
        $this->load->view('web/csr', $data);
    }

    public function csr_save(){

      if(isPostBack())
        {               
            $data['title'] = $_POST['title'];
            $data['content'] = $_POST['content'];
            $date=date("Y-m-d");     
            $data['date'] = $date;  


            $insert = $this->Common_model->common_insert($data,'tbl_csr');
            
            if ( $_FILES AND $_FILES['image']['name'] ) 
            {
                $config['upload_path']  =   "upload/csr";
                $config['allowed_types']=   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']     =   "720";
                $config['max_width']    =   "1500";
                $config['max_height']   =   "1500";
                $config['overwrite']    =   true;               
                $config['file_name']    =   $insert."_photo";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('image'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                    $spinfo = $this->upload->data();
                    $student_photo = $spinfo['file_name'];
                   
                    $data['image'] = $spinfo['file_name'];
                    $this->Common_model->common_update($data, $insert,'id','tbl_csr');
                }
                unset($config);
            }else{
                $student_photo = '';
            }

             if ($error){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
       
             }else{
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

             }
           
            
            redirect('web/csr');  
            exit();            
        }

    }

    public function csr_delete($id){

          $data['id'] = $id;

        $this->Common_model->common_delete($data, 'tbl_csr');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/csr');
        exit;

   }

     public function blog_edit($op_id){
       $condition['id']=$op_id;
        $data['blog_edit'] = $this->Admin_model->blog_edit_get_all($op_id);

        $this->load->view('web/blog_edit', $data);
    }

    public function blog_edit_save(){

      if(isPostBack())
        {               
              $id = $_POST['id'];
              $data['title'] = $_POST['title'];
              $data['content'] = $_POST['content'];
              $this->Common_model->common_update($data, $id,'id','tbl_blog');
            
             if ( $_FILES AND $_FILES['image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/blog";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
                    $config['overwrite']     =   true;              
                    $config['file_name']    =   $id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['title'] = $_POST['title'];
                       $id = $_POST['id'];
                        $data['content'] = $_POST['content'];
                        $data['image'] = $_POST['image'];
                       $data['image'] = $spinfo['file_name'];
                        $this->Common_model->common_update($data, $id,'id','tbl_blog');
                    }

                 unset($config);
                    }else{
                        $student_photo = '';
                    }

                     if ($error){
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
               
                     }else{
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

                     }
                   
                    
                    redirect('web/blog');  
                    exit(); 
                } 

    }

    public function blog()
    {
       
        $data['blog'] = $this->Admin_model->blog_get_all();
        $this->load->view('web/blog', $data);
    }

    public function blog_save(){


      if(isPostBack())
        {               
            $data['title'] = $_POST['title'];
            $data['content'] = $_POST['content'];
            $date=date("Y-m-d");     
            $data['date'] = $date;  


            $insert = $this->Common_model->common_insert($data,'tbl_blog');
            
            if ( $_FILES AND $_FILES['image']['name'] ) 
            {
                $config['upload_path']  =   "upload/blog";
                $config['allowed_types']=   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']     =   "720";
                $config['max_width']    =   "1500";
                $config['max_height']   =   "1500";
                $config['overwrite']    =   true;               
                $config['file_name']    =   $insert."_photo";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('image'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                    $spinfo = $this->upload->data();
                    $student_photo = $spinfo['file_name'];
                   
                    $data['image'] = $spinfo['file_name'];
                    $this->Common_model->common_update($data, $insert,'id','tbl_blog');
                }
                unset($config);
            }else{
                $student_photo = '';
            }

             if ($error){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
       
             }else{
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

             }
           
            
            redirect('web/blog');  
            exit();            
        }

    }

   public function blog_delete($id){

          $data['id'] = $id;

        $this->Common_model->common_delete($data, 'tbl_blog');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/blog');
        exit;

   }

    public function career_edit($op_id){
       $condition['id']=$op_id;
        $data['career_edit'] = $this->Admin_model->career_edit_get_all($op_id);

        $this->load->view('web/career_edit', $data);
    }

    public function career_edit_save(){

         if(isPostBack())
        {               
              $id = $_POST['id'];
              $data['title'] = $_POST['title'];
              $data['content'] = $_POST['content'];
              $this->Common_model->common_update($data, $id,'id','tbl_career');
            
             if ( $_FILES AND $_FILES['image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/career";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
                    $config['overwrite']     =   true;              
                    $config['file_name']    =   $id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['title'] = $_POST['title'];
                       $id = $_POST['id'];
                        $data['content'] = $_POST['content'];
                        $data['image'] = $_POST['image'];
                       $data['image'] = $spinfo['file_name'];
                        $this->Common_model->common_update($data, $id,'id','tbl_career');
                    }

                 unset($config);
                    }else{
                        $student_photo = '';
                    }

                     if ($error){
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
               
                     }else{
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

                     }
                   
                    
                    redirect('web/career');  
                    exit(); 
                } 

    }



    public function career()
    {
        $data['career'] = $this->Admin_model->career_get_all();
        $this->load->view('web/career', $data);
    }

    public function career_save(){

      if(isPostBack())
        {               
            $data['title'] = $_POST['title'];
            $data['content'] = $_POST['content'];
            $date=date("Y-m-d");     
            $data['date'] = $date;  


            $insert = $this->Common_model->common_insert($data,'tbl_career');
            
            if ( $_FILES AND $_FILES['image']['name'] ) 
            {
                $config['upload_path']  =   "upload/career";
                $config['allowed_types']=   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']     =   "720";
                $config['max_width']    =   "1500";
                $config['max_height']   =   "1500";
                $config['overwrite']    =   true;               
                $config['file_name']    =   $insert."_photo";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('image'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                    $spinfo = $this->upload->data();
                    $student_photo = $spinfo['file_name'];
                   
                    $data['image'] = $spinfo['file_name'];
                    $this->Common_model->common_update($data, $insert,'id','tbl_career');
                }
                unset($config);
            }else{
                $student_photo = '';
            }

             if ($error){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
       
             }else{
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

             }
           
            
            redirect('web/career');  
            exit();            
        }

    }

   public function career_delete($id){

          $data['id'] = $id;

        $this->Common_model->common_delete($data, 'tbl_career');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/career');
        exit;

   }


    public function virtual_constructionltd_edit($op_id){
       $condition['id']=$op_id;
        $data['virtual_constructionltd_edit'] = $this->Admin_model->virtual_constructionltd_edit_get_all($op_id);

        $this->load->view('web/virtual_constructionltd_edit', $data);
    }

   public function virtual_constructionltd_edit_save(){

         if(isPostBack())
           {               
              $id = $_POST['id'];
              $data['title'] = $_POST['title'];
              $data['content'] = $_POST['content'];
              $this->Common_model->common_update($data, $id,'id','tbl_virtual_constructionltd');
            
             if ( $_FILES AND $_FILES['image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/virtual_constructionltd";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
                    $config['overwrite']     =   true;              
                    $config['file_name']    =   $id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['title'] = $_POST['title'];
                       $id = $_POST['id'];
                        $data['content'] = $_POST['content'];
                        $data['image'] = $_POST['image'];
                       $data['image'] = $spinfo['file_name'];
                        $this->Common_model->common_update($data, $id,'id','tbl_virtual_constructionltd');
                    }

                 unset($config);
                    }else{
                        $student_photo = '';
                    }

                     if ($error){
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
               
                     }else{
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

                     }
                   
                    
                    redirect('web/virtual_constructionltd');  
                    exit(); 
                } 

   }


    public function virtual_constructionltd()
    {
        $data['virtual_constructionltd'] = $this->Admin_model->virtual_constructionltd_get_all();
        $this->load->view('web/virtual_constructionltd', $data);
    }

    public function virtual_constructionltd_save(){

       if(isPostBack())
        {               
            $data['title'] = $_POST['title'];
            $data['content'] = $_POST['content'];
            $date=date("Y-m-d");     
            $data['date'] = $date;  


            $insert = $this->Common_model->common_insert($data,'tbl_virtual_constructionltd');
            
            if ( $_FILES AND $_FILES['image']['name'] ) 
            {
                $config['upload_path']  =   "upload/virtual_constructionltd";
                $config['allowed_types']=   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']     =   "720";
                $config['max_width']    =   "1500";
                $config['max_height']   =   "1500";
                $config['overwrite']    =   true;               
                $config['file_name']    =   $insert."_photo";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('image'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                    $spinfo = $this->upload->data();
                    $student_photo = $spinfo['file_name'];
                   
                    $data['image'] = $spinfo['file_name'];
                    $this->Common_model->common_update($data, $insert,'id','tbl_virtual_constructionltd');
                }
                unset($config);
            }else{
                $student_photo = '';
            }

             if ($error){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
       
             }else{
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

             }
           
            
            redirect('web/virtual_constructionltd');  
            exit();            
        }

    }

    public function virtual_constructionltd_delete($id){

          $data['id'] = $id;

        $this->Common_model->common_delete($data, 'tbl_virtual_constructionltd');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/virtual_constructionltd');
        exit;

   }


     public function virtual_ready_mix_edit($op_id){
       $condition['id']=$op_id;
        $data['virtual_ready_mix_edit'] = $this->Admin_model->virtual_ready_mix_edit_get_all($op_id);

        $this->load->view('web/virtual_ready_mix_edit', $data);
    }

    public function virtual_ready_mix_edit_save(){

            if(isPostBack())
           {               
              $id = $_POST['id'];
              $data['title'] = $_POST['title'];
              $data['content'] = $_POST['content'];
              $this->Common_model->common_update($data, $id,'id','tbl_virtual_ready_mix');
            
             if ( $_FILES AND $_FILES['image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/virtual_ready_mix";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
                    $config['overwrite']     =   true;              
                    $config['file_name']    =   $id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['title'] = $_POST['title'];
                       $id = $_POST['id'];
                        $data['content'] = $_POST['content'];
                        $data['image'] = $_POST['image'];
                       $data['image'] = $spinfo['file_name'];
                        $this->Common_model->common_update($data, $id,'id','tbl_virtual_ready_mix');
                    }

                 unset($config);
                    }else{
                        $student_photo = '';
                    }

                     if ($error){
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
               
                     }else{
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

                     }
                   
                    
                    redirect('web/virtual_ready_mix');  
                    exit(); 
                } 

    }
  


    public function virtual_ready_mix()
    {
        $data['virtual_ready_mix'] = $this->Admin_model->virtual_ready_mix_get_all();
        $this->load->view('web/virtual_ready_mix', $data);
    }

    public function virtual_ready_mix_save(){

     if(isPostBack())
        {               
            $data['title'] = $_POST['title'];
            $data['content'] = $_POST['content'];
            $date=date("Y-m-d");     
            $data['date'] = $date;  


            $insert = $this->Common_model->common_insert($data,'tbl_virtual_ready_mix');
            
            if ( $_FILES AND $_FILES['image']['name'] ) 
            {
                $config['upload_path']  =   "upload/virtual_ready_mix";
                $config['allowed_types']=   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']     =   "720";
                $config['max_width']    =   "1500";
                $config['max_height']   =   "1500";
                $config['overwrite']    =   true;               
                $config['file_name']    =   $insert."_photo";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('image'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                    $spinfo = $this->upload->data();
                    $student_photo = $spinfo['file_name'];
                   
                    $data['image'] = $spinfo['file_name'];
                    $this->Common_model->common_update($data, $insert,'id','tbl_virtual_ready_mix');
                }
                unset($config);
            }else{
                $student_photo = '';
            }

             if ($error){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
       
             }else{
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

             }
           
            
            redirect('web/virtual_ready_mix');  
            exit();            
        }

    }

    public function virtual_ready_mix_delete($id){

          $data['id'] = $id;

        $this->Common_model->common_delete($data, 'tbl_virtual_ready_mix');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/virtual_ready_mix');
        exit;

   }


    public function virtual_marketing_tradingco_edit($op_id){
       $condition['id']=$op_id;
        $data['virtual_marketing_tradingco_edit'] = $this->Admin_model->virtual_marketing_tradingco_edit_get_all($op_id);

        $this->load->view('web/virtual_marketing_tradingco_edit', $data);
    }

    public function virtual_marketing_tradingco_edit_save(){

          if(isPostBack())
           {               
              $id = $_POST['id'];
              $data['title'] = $_POST['title'];
              $data['content'] = $_POST['content'];
              $this->Common_model->common_update($data, $id,'id','tbl_virtual_marketing_tradingco');
            
             if ( $_FILES AND $_FILES['image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/virtual_marketing_tradingco";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
                    $config['overwrite']     =   true;              
                    $config['file_name']    =   $id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['title'] = $_POST['title'];
                       $id = $_POST['id'];
                        $data['content'] = $_POST['content'];
                        $data['image'] = $_POST['image'];
                       $data['image'] = $spinfo['file_name'];
                        $this->Common_model->common_update($data, $id,'id','tbl_virtual_marketing_tradingco');
                    }

                 unset($config);
                    }else{
                        $student_photo = '';
                    }

                     if ($error){
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
               
                     }else{
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

                     }
                   
                    
                    redirect('web/virtual_marketing_tradingco');  
                    exit(); 
                } 

    }
  


    public function virtual_marketing_tradingco()
    {
        $data['virtual_marketing_tradingco'] = $this->Admin_model->virtual_marketing_tradingco_get_all();
        $this->load->view('web/virtual_marketing_tradingco', $data);
    }

    public function virtual_marketing_tradingco_save(){

         if(isPostBack())
        {               
            $data['title'] = $_POST['title'];
            $data['content'] = $_POST['content'];
            $date=date("Y-m-d");     
            $data['date'] = $date;  


            $insert = $this->Common_model->common_insert($data,'tbl_virtual_marketing_tradingco');
            
            if ( $_FILES AND $_FILES['image']['name'] ) 
            {
                $config['upload_path']  =   "upload/virtual_marketing_tradingco";
                $config['allowed_types']=   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']     =   "720";
                $config['max_width']    =   "1500";
                $config['max_height']   =   "1500";
                $config['overwrite']    =   true;               
                $config['file_name']    =   $insert."_photo";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('image'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                    $spinfo = $this->upload->data();
                    $student_photo = $spinfo['file_name'];
                   
                    $data['image'] = $spinfo['file_name'];
                    $this->Common_model->common_update($data, $insert,'id','tbl_virtual_marketing_tradingco');
                }
                unset($config);
            }else{
                $student_photo = '';
            }

             if ($error){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
       
             }else{
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

             }
           
            
            redirect('web/virtual_marketing_tradingco');  
            exit();            
        }

    }

  public function virtual_marketing_tradingco_delete($id){

          $data['id'] = $id;

        $this->Common_model->common_delete($data, 'tbl_virtual_marketing_tradingco');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/virtual_marketing_tradingco');
        exit;

   }


    public function virtual_properties_ltd_edit($op_id){
       $condition['id']=$op_id;
        $data['virtual_properties_ltd_edit'] = $this->Admin_model->virtual_properties_ltd_edit_get_all($op_id);

        $this->load->view('web/virtual_properties_ltd_edit', $data);
    }

    public function virtual_properties_ltd_edit_save(){

                  if(isPostBack())
           {               
              $id = $_POST['id'];
              $data['title'] = $_POST['title'];
              $data['content'] = $_POST['content'];
              $this->Common_model->common_update($data, $id,'id','tbl_welcome_to_virtual_properties_ltd');
            
             if ( $_FILES AND $_FILES['image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/virtual_properties_ltd";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
                    $config['overwrite']     =   true;              
                    $config['file_name']    =   $id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['title'] = $_POST['title'];
                       $id = $_POST['id'];
                        $data['content'] = $_POST['content'];
                        $data['image'] = $_POST['image'];
                       $data['image'] = $spinfo['file_name'];
                        $this->Common_model->common_update($data, $id,'id','tbl_welcome_to_virtual_properties_ltd');
                    }

                 unset($config);
                    }else{
                        $student_photo = '';
                    }

                     if ($error){
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
               
                     }else{
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

                     }
                   
                    
                    redirect('web/welcome_to_virtual_properties_ltd');  
                    exit(); 
                } 

    }


    public function welcome_to_virtual_properties_ltd()
    {
        
        $data['welcome_to_virtual_properties_ltd'] = $this->Admin_model->welcome_to_virtual_properties_ltd_get_all();
        $this->load->view('web/welcome_to_virtual_properties_ltd', $data);
    }

    public function welcome_to_virtual_properties_ltd_save(){

      if(isPostBack())
        {               
            $data['title'] = $_POST['title'];
            $data['content'] = $_POST['content'];
            $date=date("Y-m-d");     
            $data['date'] = $date;  


            $insert = $this->Common_model->common_insert($data,'tbl_welcome_to_virtual_properties_ltd');
            
            if ( $_FILES AND $_FILES['image']['name'] ) 
            {
                $config['upload_path']  =   "upload/virtual_properties_ltd";
                $config['allowed_types']=   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']     =   "720";
                $config['max_width']    =   "1500";
                $config['max_height']   =   "1500";
                $config['overwrite']    =   true;               
                $config['file_name']    =   $insert."_photo";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('image'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                    $spinfo = $this->upload->data();
                    $student_photo = $spinfo['file_name'];
                   
                    $data['image'] = $spinfo['file_name'];
                    $this->Common_model->common_update($data, $insert,'id','tbl_welcome_to_virtual_properties_ltd');
                }
                unset($config);
            }else{
                $student_photo = '';
            }

             if ($error){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
       
             }else{
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

             }
           
            
            redirect('web/welcome_to_virtual_properties_ltd');  
            exit();            
        }

    }

    public function virtual_properties_ltd_delete($id){

          $data['id'] = $id;

        $this->Common_model->common_delete($data, 'tbl_welcome_to_virtual_properties_ltd');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/welcome_to_virtual_properties_ltd');
        exit;

   }

   public function schwing_stetter_edit_save(){

                     if(isPostBack())
           {               
              $id = $_POST['id'];
              $data['title'] = $_POST['title'];
              $data['content'] = $_POST['content'];
              $this->Common_model->common_update($data, $id,'id','tbl_schwing_stetter');
            
             if ( $_FILES AND $_FILES['image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/schwing_stetter";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
                    $config['overwrite']     =   true;              
                    $config['file_name']    =   $id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['title'] = $_POST['title'];
                       $id = $_POST['id'];
                        $data['content'] = $_POST['content'];
                        $data['image'] = $_POST['image'];
                       $data['image'] = $spinfo['file_name'];
                        $this->Common_model->common_update($data, $id,'id','tbl_schwing_stetter');
                    }

                 unset($config);
                    }else{
                        $student_photo = '';
                    }

                     if ($error){
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
               
                     }else{
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

                     }
                   
                    
                    redirect('web/schwing_stetter');  
                    exit(); 
                } 

   }

     public function schwing_stetter_edit($op_id){
       $condition['id']=$op_id;
        $data['schwing_stetter_edit'] = $this->Admin_model->schwing_stetter_edit_get_all($op_id);

        $this->load->view('web/schwing_stetter_edit', $data);
    }


    public function schwing_stetter()
    {
        $data['schwing_stetter'] = $this->Admin_model->schwing_stetter_get_all();
        $this->load->view('web/schwing_stetter', $data);
    }

    public function schwing_stetter_save(){

        if(isPostBack())
        {               
            $data['title'] = $_POST['title'];
            $data['content'] = $_POST['content'];
            $date=date("Y-m-d");     
            $data['date'] = $date;  


            $insert = $this->Common_model->common_insert($data,'tbl_schwing_stetter');
            
            if ( $_FILES AND $_FILES['image']['name'] ) 
            {
                $config['upload_path']  =   "upload/schwing_stetter";
                $config['allowed_types']=   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']     =   "720";
                $config['max_width']    =   "1500";
                $config['max_height']   =   "1500";
                $config['overwrite']    =   true;               
                $config['file_name']    =   $insert."_photo";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('image'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                    $spinfo = $this->upload->data();
                    $student_photo = $spinfo['file_name'];
                   
                    $data['image'] = $spinfo['file_name'];
                    $this->Common_model->common_update($data, $insert,'id','tbl_schwing_stetter');
                }
                unset($config);
            }else{
                $student_photo = '';
            }

             if ($error){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
       
             }else{
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

             }
           
            
            redirect('web/schwing_stetter');  
            exit();            
        }

    }

    public function schwing_stetter_delete($id){

          $data['id'] = $id;

        $this->Common_model->common_delete($data, 'tbl_schwing_stetter');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/schwing_stetter');
        exit;

   }


    public function soilmec_edit($op_id){
       $condition['id']=$op_id;
        $data['soilmec_edit'] = $this->Admin_model->soilmec_edit_get_all($op_id);

        $this->load->view('web/soilmec_edit', $data);
    }

    public function soilmec_edit_save(){

         if(isPostBack())
           {               
              $id = $_POST['id'];
              $data['title'] = $_POST['title'];
              $data['content'] = $_POST['content'];
              $this->Common_model->common_update($data, $id,'id','tbl_soilmec');
            
             if ( $_FILES AND $_FILES['image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/soilmec";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
                    $config['overwrite']     =   true;              
                    $config['file_name']    =   $id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['title'] = $_POST['title'];
                       $id = $_POST['id'];
                        $data['content'] = $_POST['content'];
                        $data['image'] = $_POST['image'];
                       $data['image'] = $spinfo['file_name'];
                        $this->Common_model->common_update($data, $id,'id','tbl_soilmec');
                    }

                 unset($config);
                    }else{
                        $student_photo = '';
                    }

                     if ($error){
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
               
                     }else{
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

                     }
                   
                    
                    redirect('web/soilmec');  
                    exit(); 
                } 

    }


    public function soilmec()
    {
        
        $data['soilmec'] = $this->Admin_model->soilmec_get_all();
        $this->load->view('web/soilmec', $data);
    }

    public function soilmec_save(){

        if(isPostBack())
        {               
            $data['title'] = $_POST['title'];
            $data['content'] = $_POST['content'];
            $date=date("Y-m-d");     
            $data['date'] = $date;  


            $insert = $this->Common_model->common_insert($data,'tbl_soilmec');
            
            if ( $_FILES AND $_FILES['image']['name'] ) 
            {
                $config['upload_path']  =   "upload/soilmec";
                $config['allowed_types']=   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']     =   "720";
                $config['max_width']    =   "1500";
                $config['max_height']   =   "1500";
                $config['overwrite']    =   true;               
                $config['file_name']    =   $insert."_photo";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('image'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                    $spinfo = $this->upload->data();
                    $student_photo = $spinfo['file_name'];
                   
                    $data['image'] = $spinfo['file_name'];
                    $this->Common_model->common_update($data, $insert,'id','tbl_soilmec');
                }
                unset($config);
            }else{
                $student_photo = '';
            }

             if ($error){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
       
             }else{
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

             }
           
            
            redirect('web/soilmec');  
            exit();            
        }

    }

    public function soilmec_delete($id){

          $data['id'] = $id;

        $this->Common_model->common_delete($data, 'tbl_soilmec');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/soilmec');
        exit;

   }




    public function corporate_office_edit($op_id){
       $condition['id']=$op_id;
       $data['corporate_office_edit'] = $this->Admin_model->corporate_office_edit_get_all($op_id);

        $this->load->view('web/corporate_office_edit', $data);
    }

   public function corporate_office_edit_save(){

          if(isPostBack())
           {               
              $id = $_POST['id'];
              $data['title'] = $_POST['title'];
              $data['content'] = $_POST['content'];
              $this->Common_model->common_update($data, $id,'id','tbl_corporate_office');
            
             if ( $_FILES AND $_FILES['image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/corporate_office";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
                    $config['overwrite']     =   true;              
                    $config['file_name']    =   $id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['title'] = $_POST['title'];
                       $id = $_POST['id'];
                        $data['content'] = $_POST['content'];
                        $data['image'] = $_POST['image'];
                       $data['image'] = $spinfo['file_name'];
                        $this->Common_model->common_update($data, $id,'id','tbl_corporate_office');
                    }

                 unset($config);
                    }else{
                        $student_photo = '';
                    }

                     if ($error){
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
               
                     }else{
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

                     }
                   
                    
                    redirect('web/corporate_office');  
                    exit(); 
                } 
    
   }



    public function corporate_office()
    {
        $data['corporate_office'] = $this->Admin_model->corporate_office_get_all();
        $this->load->view('web/corporate_office', $data);
    }

    public function corporate_office_save(){

        if(isPostBack())
        {               
            $data['title'] = $_POST['title'];
            $data['content'] = $_POST['content'];
            $date=date("Y-m-d");     
            $data['date'] = $date;  


            $insert = $this->Common_model->common_insert($data,'tbl_corporate_office');
            
            if ( $_FILES AND $_FILES['image']['name'] ) 
            {
                $config['upload_path']  =   "upload/corporate_office";
                $config['allowed_types']=   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']     =   "720";
                $config['max_width']    =   "1500";
                $config['max_height']   =   "1500";
                $config['overwrite']    =   true;               
                $config['file_name']    =   $insert."_photo";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('image'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                    $spinfo = $this->upload->data();
                    $student_photo = $spinfo['file_name'];
                   
                    $data['image'] = $spinfo['file_name'];
                    $this->Common_model->common_update($data, $insert,'id','tbl_corporate_office');
                }
                unset($config);
            }else{
                $student_photo = '';
            }

             if ($error){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
       
             }else{
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

             }
           
            
            redirect('web/corporate_office');  
            exit();            
        }

    }

  public function corporate_office_delete($id){

          $data['id'] = $id;

        $this->Common_model->common_delete($data, 'tbl_corporate_office');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/corporate_office');
        exit;

   }


    public function branch_office_edit($op_id){
       $condition['id']=$op_id;
       $data['branch_office_edit'] = $this->Admin_model->branch_office_edit_get_all($op_id);

        $this->load->view('web/branch_office_edit', $data);
    }

    public function branch_office_edit_save(){

          if(isPostBack())
           {               
              $id = $_POST['id'];
              $data['title'] = $_POST['title'];
              $data['content'] = $_POST['content'];
              $this->Common_model->common_update($data, $id,'id','tbl_branch_office');
            
             if ( $_FILES AND $_FILES['image']['name'] ) 
                {
                    $config['upload_path']   =   "upload/branch_office";
                    $config['allowed_types'] =   "jpg|jpeg|png|gif"; 
                    #$config['encrypt_name']  = true;
                    $config['max_size']      =   "1720";
                    $config['max_width']     =   "15000";
                    $config['max_height']    =   "15000";
                    $config['overwrite']     =   true;              
                    $config['file_name']    =   $id."_photo";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('image'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $spinfo=$this->upload->data();
                       $data['title'] = $_POST['title'];
                       $id = $_POST['id'];
                        $data['content'] = $_POST['content'];
                        $data['image'] = $_POST['image'];
                       $data['image'] = $spinfo['file_name'];
                        $this->Common_model->common_update($data, $id,'id','tbl_branch_office');
                    }

                 unset($config);
                    }else{
                        $student_photo = '';
                    }

                     if ($error){
                        $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
               
                     }else{
                        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

                     }
                   
                    
                    redirect('web/branch_office');  
                    exit(); 
                } 

    }


    public function branch_office()
    {
        
        $data['branch_office'] = $this->Admin_model->branch_office_get_all();
        $this->load->view('web/branch_office', $data);
    }

    public function branch_office_save(){

       if(isPostBack())
        {               
            $data['title'] = $_POST['title'];
            $data['content'] = $_POST['content'];
            $date=date("Y-m-d");     
            $data['date'] = $date;  


            $insert = $this->Common_model->common_insert($data,'tbl_branch_office');
            
            if ( $_FILES AND $_FILES['image']['name'] ) 
            {
                $config['upload_path']  =   "upload/branch_office";
                $config['allowed_types']=   "jpg|jpeg|png|gif"; 
                #$config['encrypt_name']  = true;
                $config['max_size']     =   "720";
                $config['max_width']    =   "1500";
                $config['max_height']   =   "1500";
                $config['overwrite']    =   true;               
                $config['file_name']    =   $insert."_photo";

                $this->load->library('upload',$config);

                if(!$this->upload->do_upload('image'))
                {
                   echo $this->upload->display_errors();
                }
                else
                {
                    $spinfo = $this->upload->data();
                    $student_photo = $spinfo['file_name'];
                   
                    $data['image'] = $spinfo['file_name'];
                    $this->Common_model->common_update($data, $insert,'id','tbl_branch_office');
                }
                unset($config);
            }else{
                $student_photo = '';
            }

             if ($error){
                $this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Danger!</strong>' . $error . '</div>');
       
             }else{
                $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a><strong>Success!</strong> Data has been save successfully</div>');

             }
           
            
            redirect('web/branch_office');  
            exit();            
        }

    }

   public function branch_office_delete($id){

          $data['id'] = $id;

        $this->Common_model->common_delete($data, 'tbl_branch_office');
        $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
        redirect('web/branch_office');
        exit;

   }












}

?>