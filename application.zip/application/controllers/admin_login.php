<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Admin_login extends CI_Controller {

    public function __construct()
    {
        parent::__construct();        
        $this->load->model('admin_model', 'Admin_model', true);
    }
	
	public function index(){
            if(is_loggedin())
            {
                get_access_controller();
            }
            else
            {
                $this->load->view('login_admin', '');
            }
            
        }
        
        
        function login_check()
        {
            $data['username']  = $_POST['username'];
            $data['password']       = md5($_POST['password']);            
            $adminInfo = $this->Admin_model->login_check($data); 

            if($adminInfo)
            {                
                $_SESSION['id']             = $adminInfo['id'];
                $_SESSION['UserName']        = $adminInfo['UserName'];
                $_SESSION['is_loggedin']    = 1;
                
                message('Loggedin successfully');
                get_access_controller();
            }
            exception('invalid login information');
            redirect('admin_login');exit;
        }
        
        
        
        function logout()
        {
           unset($_SESSION['id'],$_SESSION['UserName'],$_SESSION['is_loggedin']); 
           message('Successfully logout');
           redirect('admin_login');exit;
        }
    
        
    
        
        
	
        	
	
	
}

