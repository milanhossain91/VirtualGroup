<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Notice extends CI_Controller {

    public function __construct()
        {            
            session_start();
            parent::__construct();
            $this->load->helper('form');
            $this->load->helper('url');
            $this->load->model('admin_model', 'Admin_model', true);
            $this->load->model('common_model', 'Common_model', true);
           if(!is_loggedin())
            {
               redirect('login');
               exit;
            }
					
        }
	
	/************** notice **************/
	
		public function notice_list()
        {               
            #$school_id = $_SESSION['school_id'];
			$s_data['school_id'] = 1;
            $data['notice_list'] = $this->Common_model->common_select_by_multycondition($s_data,'tbl_notice');
            $this->load->view('notice/notice_list',$data);
        }
		
		function notice_save()
        {
            if(isPostBack())
            {
                //$school_id = $_SESSION['school_id'];
				$school_id = 1;
				$notice_time=date('dmYHis').$school_id;
                if ($_FILES AND $_FILES['notice_attachment']['name'] ) 
                {
                    $config['upload_path']   =   "upload/notice_file";
                    $config['allowed_types'] =   "docx|doc|pdf|zip|jpg|jpeg|png|gif"; 
                    $config['max_size']      =   "5200";
                    //$config['max_width']     =   "3000";
                    //$config['max_height']    =   "2500";
                    $config['file_name']    =   $notice_time."_notice_file";

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('notice_attachment'))
                    {
                       echo $this->upload->display_errors();
                    }
                    else
                    {
                       $finfo=$this->upload->data();
                       $notice_attachment= $finfo['file_name'];

                       $data['school_id'] = $school_id;
                       $data['notice_type'] = $_POST['notice_type'];
                       $data['notice_heading'] = $_POST['notice_heading'];
                       $data['notice_details'] = $_POST['notice_details'];
                       $data['publish_date'] = $_POST['publish_date'];
                       $data['notice_attachment'] = $notice_attachment;
                       $data['status'] = 1;
                       $data['created_on'] = date('Y-m-d H:i:s',time());
                       if($this->Common_model->common_insert($data, 'tbl_notice'))
							$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
					   else
							$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
						
                       redirect('notice/notice_list');exit;
                    }
                }
                else
                {
                    $data['school_id'] = $school_id;
                    $data['notice_type'] = $_POST['notice_type'];
                    $data['notice_heading'] = $_POST['notice_heading'];
                    $data['notice_details'] = $_POST['notice_details'];
                    $data['publish_date'] = $_POST['publish_date'];
                    $data['status'] = 1;
                    $data['created_on'] = date('Y-m-d H:i:s',time());
                    if($this->Common_model->common_insert($data, 'tbl_notice'))
						$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
					else
						$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				
                    redirect('notice/notice_list');exit;
                }
            }
        }
		
		public function single_notice($notice_id)
        {               
            //$school_id = $_SESSION['school_id'];
			$s_data['school_id'] = 1;
			$s_data['notice_id'] = $notice_id;
            $data['notice_list'] = $this->Common_model->common_select_by_multycondition($s_data,'tbl_notice');
            $this->load->view('notice/single_notice', $data);
        }
        
        
        public function single_notice_edit($notice_id)
        {               
            //$school_id = $_SESSION['school_id'];
			$s_data['school_id'] = 1;
			$s_data['notice_id'] = $notice_id;
            $data['notice_list'] = $this->Common_model->common_select_by_multycondition($s_data,'tbl_notice');
            $this->load->view('notice/single_notice_edit', $data);
        }
		
		function single_notice_edit_save()
        {
            if(isPostBack())
            {
                //$school_id = $_SESSION['school_id'];
				$school_id = 1;
                $notice_id = $_POST['notice_id'];
				$notice_file_name=$_POST['old_notice_attachment'];
                if ($_FILES AND $_FILES['notice_attachment']['name'] ) 
                {   
                    $config['upload_path']   =   "upload/notice_file";
					$config['allowed_types'] =   "docx|doc|pdf|zip|jpg|jpeg|png|gif"; 
                    $config['max_size']      =   "5200";
                    $config['overwrite']      =   TRUE;
                    $config['file_name']    =   $notice_file_name;

                    $this->load->library('upload',$config);

                    if(!$this->upload->do_upload('notice_attachment'))
                    {
                       echo $this->upload->display_errors();
                    }

                    else
                    {
						$data['notice_type'] = $_POST['notice_type'];
						$data['notice_heading'] = $_POST['notice_heading'];
						$data['notice_details'] = $_POST['notice_details'];
						$data['publish_date'] = $_POST['publish_date'];
						if($this->Common_model->common_update($data, $notice_id,'notice_id','tbl_notice'))
							$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
						else
							$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
					
                       redirect('notice/notice_list');exit;
                    }                
                }
                else
                {                    
                    $data['notice_type'] = $_POST['notice_type'];
                    $data['notice_heading'] = $_POST['notice_heading'];
                    $data['notice_details'] = $_POST['notice_details'];
                    $data['publish_date'] = $_POST['publish_date'];
                    if($this->Common_model->common_update($data, $notice_id,'notice_id','tbl_notice'))
						$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
					else
						$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
						
                    redirect('notice/notice_list');exit;
                }
            }
        }
		

		function notice_delete($notice_id){
            //$school_id = $_SESSION['school_id'];
			$d_data['school_id'] = 1;
			$d_data['notice_id'] = $notice_id;
			if($this->Common_model->common_delete($d_data,'tbl_notice'))
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
			else
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been deleted. Please try again.</div>');
				
            redirect('notice/notice_list');
			exit;
        }

		
		/************** /notice **************/

}

?>