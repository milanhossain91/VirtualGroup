<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Fees extends CI_Controller {

    public function __construct()
    {            
        session_start();
        parent::__construct();
        $this->load->helper('form');
        $this->load->helper('url');
        //$this->load->model('admin_model', 'Admin_model', true);
		$this->load->model('fees_model', 'Fees_model', true);
        $this->load->model('common_model', 'Common_model', true);
        $this->load->library('form_validation');
        if(!is_loggedin())
        {
            redirect('login');
            exit;
        }
    }
	

    public function index()
    {               
        $this->load->view('fees/index');
    }
        
        
	/***fees category***/
    
    public function fees_cat(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['fees_cat'] = $this->Fees_model->get_fees_cat($school_id);
        $data['acc_head'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_fcoa_bkdn');
        $this->load->view('fees/fees_cat', $data);
    }
    
    function fees_cat_save(){
        if(isPostBack()){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $data['acc_head'] = $_POST['acc_head'];
            $data['acc_head_code'] = $_POST['acc_head_code'];
            $data['fees_particulars'] = $_POST['fees_particulars_name'];
            $data['status'] = 1;
            $data['school_id'] = $school_id;
            $data['created_on'] = date('Y-m-d H:i:s',time());
            if($this->Common_model->common_insert($data,'tbl_fees_category'))
			{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			}
            else
			{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
			}
            redirect('fees/fees_cat');exit;
            
        }
    }
    
    
	public function fees_cat_edit($fees_cat_id){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['fees_particulars'] = $this->Fees_model->get_fees_cat_info_by_id($school_id, $fees_cat_id);
		$data['acc_head'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_fcoa_bkdn');
        $this->load->view('fees/fees_cat_edit', $data);
    }
    
    public function fees_cat_edit_save(){
        if(isPostBack()){
            $fees_cat_id = $_POST['fees_cat_id'];
            $data['acc_head'] = $_POST['acc_head'];
            $data['acc_head_code'] = $_POST['acc_head_code'];
            $data['fees_particulars'] = $_POST['fees_particulars_name'];
            if($this->Common_model->common_update($data, $fees_cat_id,'fees_cat_id','tbl_fees_category'))     
            {
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			}
            else
			{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
			}
            redirect('fees/fees_cat');exit;                    
        }
    }
    
	function fees_cat_delete($fees_cat_id){
            #$school_id = $_SESSION['school_id'];
            $d_data['school_id'] = 1;
			$d_data['fees_cat_id'] = $fees_cat_id;
			if($this->Common_model->common_delete($d_data,'tbl_fees_category'))
            {
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
			}
            else
			{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been deleted. Please try again.</div>');
			}
            redirect('fees/fees_cat');exit;
    }
	
	
    /*** /fees category***/
	
	/***fees type***/
    
    public function fees_type(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['fees_type'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_fees_type');
        $this->load->view('fees/fees_type', $data);
    }
    
    function fees_type_save(){
        if(isPostBack()){
            #$school_id = $_SESSION['school_id'];
            $school_id = 1;
            $data['type'] = $_POST['type'];
            $data['status'] = 1;
            $data['school_id'] = $school_id;
            $data['created_on'] = date('Y-m-d H:i:s',time());
            if($this->Common_model->common_insert($data,'tbl_fees_type'))
			{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			}
			else
			{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
			}
            redirect('fees/fees_type');
			exit;
        }
    }
    
    
	public function fees_type_edit($id){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['type'] = $this->Common_model->common_row_by_condition($id,'id','tbl_fees_type');
        $this->load->view('fees/fees_type_edit', $data);
    }
    
    public function fees_type_edit_save(){
        if(isPostBack()){
            $id = $_POST['id'];
            $data['type'] = $_POST['type'];
            if($this->Common_model->common_update($data, $id,'id','tbl_fees_type'))
			{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been updated successfully</div>');
			}
            else
			{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been updated. Please try again.</div>');
			}
            redirect('fees/fees_type');exit;                    
        }
    }
    
	function fees_type_delete($id){
            $d_data['school_id'] = 1;
			$d_data['id'] = $id;
			if($this->Common_model->common_delete($d_data,'tbl_fees_type'))
			{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been deleted successfully</div>');
			}
            else
			{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been deleted. Please try again.</div>');
			}
          
            redirect('fees/fees_type');exit;
    }
	
	
    /*** /fees type***/
	
    /* fees management */

    public function class_wise_fees_management(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Fees_model->get_class_list($school_id);
		$data['session'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
        $this->load->view('fees/class_wise_fees', $data);
    }
    
    public function get_class_wise_fees_management_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id =$_GET['class_id'];
		$group_id =$_GET['group_id'];
		$session_id =$_GET['session_id'];
		$shift_id =$_GET['shift_id'];
		
		$data['fees_type'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_fees_type');
        
		$count = $this->Fees_model->get_class_wise_fees_management_count($school_id, $class_id, $group_id, $session_id,$shift_id);
        $c = $count['count'];
        
        if($c>0){
		$data['fee_management'] = $this->Fees_model->get_class_wise_fees_management($school_id, $class_id, $group_id,$shift_id, $session_id);
            $mainContent=$this->load->view('fees/get_class_wise_fees_management_json', $data, true);
        }
        else{
			$data['fee_management_entry'] = $this->Fees_model->get_class_wise_fees_management_entry($school_id, $class_id);
            $mainContent=$this->load->view('fees/get_class_wise_fees_management_entry_json', $data, true);
        }       
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
	
	/* /fees management */
    
    
	/* Fees management edit */
    public function fees_management_edit(){
        if(isPostBack()){
            $fees_cat_id = $_POST['fees_cat_id'];
            $fee_mngt_id = $_POST['fee_mngt_id'][$u];
            $school_id = $_POST['school_id'];
            
            for ($u = 0; $u < count($_POST['fees_amount']); $u++) {
                $data = array(
                    'amount' => $_POST['fees_amount'][$u],
                    'period' => $_POST['period'][$u]
                );
            
            //$data['amount'] = $_POST['fees_amount'];
            //$this->Common_model->common_update($data, $fee_mngt_id,'fee_mngt_id','tbl_fee_management');
                
                $where = array('fee_mngt_id' => $_POST['fee_mngt_id'][$u]);
                $this->db->where($where);
                $this->db->update('tbl_fee_management', $data);
                
            }
            
            $this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
            redirect('fees/class_wise_fees_management', 'refresh');
            
        }
    }
    /* /Fees management edit */
    
    
    /* Fees management entry */
    public function fees_management_entry(){
        if(isPostBack()){
            $fees_cat_id = $_POST['fees_cat_id'];
            $school_id = $_POST['school_id'];
			$class_id = $_POST['class_id'];
			$group_id = $_POST['group_id'];
			$shift_id = $_POST['shift_id'];
			$session_id = $_POST['session_id'];
            
            for ($u = 0; $u < count($_POST['fees_amount']); $u++){
                $data[] = array(
                    'amount' => $_POST['fees_amount'][$u],
                    'school_id' => $school_id,
                    'class_id' => $class_id,
					'group_id' => $group_id,
					'shift_id' => $shift_id,
					'session_id' => $session_id,
                    'fees_cat_id' => $_POST['fees_cat_id'][$u],
                    'period' => $_POST['period'][$u]
                );
            }
			
           if($this->Common_model->common_insert_batch($data,'tbl_fee_management'))
			{
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			}
			else
			{
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
			}
            redirect('fees/class_wise_fees_management', 'refresh');
			exit;
        }
    }
    /* /Fees management entry */
    
  
    /* Students fees generate */
    
    public function student_fees_generate(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Fees_model->get_class_list($school_id);
		$data['fees_type'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_fees_type');
		$data['session'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
        $this->load->view('fees/student_fees_generate', $data);
    }
	public function student_fees_generate_edit(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Fees_model->get_class_list($school_id);
		$data['fees_type'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_fees_type');
		$data['session'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
        $this->load->view('fees/student_fees_generate_edit', $data);
    }
    
	function get_student_list_ajax()
    {
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_POST['class_id'];
		$group_id = $_POST['group_id'];
		$shift_id = $_POST['shift_id'];
		$session_id = $_POST['session_id'];
        
		//$sectionInfo = $this->Admin_model->get_section_list_by_id($class_id, $school_id); 
        $stuInfo = $this->Fees_model->get_class_wise_student_list($school_id, $class_id, $group_id,$shift_id, $session_id,''); 
        
		$str = '<option value="">----Select Student----</option>';
        
		if($stuInfo)
        {
           foreach($stuInfo as $sInfo)
           {
              $str .= "<option value='".$sInfo['student_id']."'>".$sInfo['student_name']."</option>";
           }
        }
		
        echo $str;exit;
    }
	
    public function get_student_list_for_fees_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
	$group_id = $_GET['group_id'];
	$shift_id = $_GET['shift_id'];
	$session_id = $_GET['session_id'];
	$fees_date = $_GET['fees_year'].'-'.$_GET['fees_month'].'-01';
	$fees_type = "('" . implode("','", $_GET['fees_type']) . "')";
	if($_GET['student_id'])
		$student_id = $_GET['student_id'];
	else
		$student_id = '';
		
	$data['student_list'] = $this->Fees_model->get_class_wise_student_list($school_id, $class_id, $group_id,$shift_id, $session_id,$student_id);
        $data['fees_mngt_details'] = $this->Fees_model->get_class_wise_fees_details($school_id, $class_id, $group_id,$shift_id, $session_id, $fees_type);
        $data['class_id']=$class_id;
	$data['fees_date']=$fees_date;
		
	$count_sudents_fees = $this->Fees_model->count_sudents_fees($school_id,$class_id,$group_id,$shift_id,$session_id,$fees_date,$student_id);
        $data['old_gen_fees']=$count_sudents_fees;
		
        if(count($data['student_list'])>0){
            if(count($count_sudents_fees) == count($data['student_list'])){
		$mainContent= "Already generated for this month";
            }
            else{
                if(count($data['fees_mngt_details']) > 0){
                    $mainContent=$this->load->view('fees/get_class_wise_student_list_for_fees_generate_json', $data, true);
                }
                else{
			$mainContent= "please Assign Category wise fees first";
                }
            }
        }
        else{
             $mainContent="Student Record Not Found!";
			
            //$mainContent=$this->load->view('fees/get_class_wise_fees_management_entry_json', $data, true);
        }
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
    
    public function fees_generate(){
        if(isPostBack()){
            $mobile = $_POST['sms_contact'];
            $school_id = 1;
		$session_id = $_POST['session_id'];
		$class_id = $_POST['class_id'];
		$group_id = $_POST['group_id'];
		$shift_id = $_POST['shift_id'];
		$fees_date = $_POST['fees_date'];
			
            $fees = 0;
			$bkdn_sms = "";
			
			$student_iddfsdArr 	= $_POST['student_iddfsd'];
			//$student_nameArr 	= $_POST['student_namedfsd'];
			//$sms_contactArr 	= $_POST['sms_contact'];
			//echo count($student_iddfsdArr);
			if(count($student_iddfsdArr)>0){
				$i=0;
				foreach($student_iddfsdArr as $student_id){
					
					$bkdn_sms = "";
					//$student_name 	= $student_nameArr[$i];
					//$sms_contact 	= $sms_contactArr[$i];
					//$class_id 		= $class_idArr[$i];
					//$school_id 		= $school_idArr[$i];
					//$total_fees 	= $total_feesArr[$i];
					$billing_id   	= $student_id.str_replace('-', '',$fees_date);
					
					//echo $student_name."-".$student_id.":<br>";
					
					
					/*
					if($i==0){
						$sms_contact = "01819312570";
					}
					else if($i==1){
						$sms_contact = "01726019427";
					}
					else if($i==2){
						$sms_contact = "01912861103";
					}
					else if($i==3){
						$sms_contact = "01764929415";
					}
					else if($i==4){
						$sms_contact = "01616010000";
					}
					*/
					// Second Loop
					$fees_cat_idArr = $_POST["fees_{$student_id}"];
					$fees_amountArr = $_POST["fees_amount_{$student_id}"];
					//print_r($fees_amountArr);
					
					/*
					$fee_mngt_idArr 		= $_POST["fee_mngt_id_{$student_id}"];
					$fees_particularsArr 	= $_POST["fees_particulars_{$student_id}"];
					$fees_amountArr 		= $_POST["fees_amount_{$student_id}"];
					$fees_cat_idArr 		= $_POST["fees_cat_id_{$student_id}"];*/
					
					if(count($fees_cat_idArr)>0){
						$inc=0;
						foreach($fees_cat_idArr as $fees_cat_id){
							
							$fees_particulars 	= explode('+',$fees_cat_id)[1];
							$fees_amount 		= $fees_amountArr[$inc];
							$fees_cat_id 		= explode('+',$fees_cat_id)[0];
							
							//$bkdn_sms.= "{$fees_particulars}:  {$fees_amount}, ";
							$data[] = array(
											'billing_id' => $billing_id,
											'student_id' => $student_id,
											'fees_cat_id' => $fees_cat_id,
											'school_id' => $school_id,
											'session_id' => $session_id,
											'class_id' => $_POST['class_id'],
											'group_id' => $group_id,
											'shift_id' => $shift_id,
											'amount' => $fees_amount,
											'fees_date' => $fees_date,
											'status' => 0,
											'created_on' => date('Y-m-d H:i:s',time())
										);
							
							//echo $fees_particulars."-".$fees_amount."<br>";
							
							//$this->db->insert('tbl_students_fees', $data);
							//return $this->db->insert_id();
				
							$inc++;
						}
					}
					// Second Loop
				
				$i++;
				
				//echo $bkdn_sms."<br>";
				//$this->send_sms($student_name, $student_id, $sms_contact, $total_fees,$billing_id,$bkdn_sms);
				}
				//echo count($data); die();
				if($this->Common_model->common_insert_batch($data,'tbl_students_fees'))
				{
					$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
				}
				else
				{
					$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');
				}
				redirect('fees/student_fees_generate', 'refresh');
			}
			// if no student data found
			$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>No student found</div>');
			redirect('fees/student_fees_generate', 'refresh');
        }
		else {
			// if is post not back
			$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Something is wrong. Please try again.</div>');
			redirect('fees/student_fees_generate', 'refresh');
		}
    }
    
    
    
    /* send sms */
    //http://api.infobip.com/api/v3/sendsms/plain?user=sayemsylhet&password=2pcQhQfw&sender=Sayem&SMSText=messagetext&GSM=8801717023978
    
    public function send_sms($student_name, $student_id, $number, $total_fees, $billing_id,$bkdn_sms) {
        
		
		$phone = "88" . $number;
        $msg = "$student_name, ID : $student_id, total fees : $total_fees tk. Billing id is : $billing_id, Detail: $bkdn_sms
		Powered by weblinkltd.com";
        $encode = urlencode($msg);
		
		//$url = "http://api.infobip.com/api/v3/sendsms/plain?user=sayemsylhet&password=2pcQhQfw&sender=Ashik&SMSText={$encode}&GSM={$phone}&type=longSMS";
        
		//$url = "http://api.infobip.com/api/v3/sendsms/plain?user=bisectg&password=leWU7EXj&sender=AHIS&SMSText={$encode}&GSM={$phone}&type=longSMS";
		
        $datas = file_get_contents($url);
      
        $data = array(
                    'msg' => $msg,
                    'std_id' => $student_id
                     );
        
        $this->db->insert('tbl_fees_msg', $data);
        
		
         
    }
	
	/* /Students fees generate */
	
	/* Students fees collect */
	public function fees_collect_edit(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Fees_model->get_class_list($school_id);
		$data['session'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
        $this->load->view('fees/fees_collect_edit', $data);
    }
	public function fees_collect(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $data['class_list'] = $this->Fees_model->get_class_list($school_id);
		$data['session'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
        $this->load->view('fees/fees_collect', $data);
    } 
    
	public function get_student_list_for_fees_collect_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$group_id = $_GET['group_id'];
		$shift_id = $_GET['shift_id'];
		$session_id = $_GET['session_id'];
		$edit_option = $_GET['edit_option'];
		$fees_date = $_GET['fees_year'].'-'.$_GET['fees_month'].'-01';
		
        $data['fees_details'] = $this->Fees_model->get_class_wise_generate_fees_details($school_id, $class_id, $group_id,$shift_id, $session_id, $fees_date);
        $data['class_id']=$class_id;
		$data['fees_date']=$fees_date;
		
	
		if(count($data['fees_details']) > 0)
			{
				$mainContent=$this->load->view('fees/get_class_wise_student_list_for_fees_collect_json', $data, true);
			}
		else
			{
				$mainContent= "Fees for this class or month is not generated yet. Please generate fees from ‘Student Fees Generate’ .";
			}

        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
	/*public function get_fees_recept()
	{$billing_id="('100000120161201','100000220161201')";
		
		$data['fees_details'] = $this->Fees_model->get_fees_recepit($billing_id);
		$data['school_info'] = $this->Common_model->common_select_by_condition($school_id,'school_information_id','tbl_school_information');
        $this->load->view('fees/feesreceipt', $data);
	}*/
	public function get_fees_recept()
	{
       // $billing_id = $_GET['billing_id'];
	    $school_id = 1;
	   
		$billing_id = "('" . implode("','", $_GET['billing_id']) . "')";
        $data['fees_details'] = $this->Fees_model->get_fees_recepit($billing_id);
		$data['school_info'] = $this->Common_model->common_select_by_condition($school_id,'school_information_id','tbl_school_information');
		
			$mainContent=$this->load->view('fees/feesreceipt', $data, true);
		$this->send_sms_fees_rcv($_GET['mob_no'],$_GET['total_amount']);
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit; 
	}
	
	public function send_sms_fees_rcv($number,$total_amount) {
        
        $msg_text = "You have Paid ".$total_amount." taka to MMLHS on ".date('d M, Y');
        $encode = urlencode($msg_text);
		//http://107.20.199.106/api/v3/sendsms/plain?user=test&password=test&SMSText=text heare&GSM=8801687295469&datacoding=8
       $url = 'http://107.20.199.106/api/v3/sendsms/plain?user=weblink1&password=link5566&sender=MMLHS&SMSText='.$encode.'&GSM='.$number.'&datacoding=8';
        //$url = 'http://api.infobip.com/api/v3/sendsms/plain?user=bisectg&password=leWU7EXj&sender=AHIS&SMSText=' .$encode. '&GSM='.$phone;

        $datas = file_get_contents($url);
		
       
        $data = array(
                    'msg' => $msg_text,
                    'mobile' => $number,
					'sms_datas'=>$datas,
					'sms_count' => 1,
					'created_on'=>date('Y-m-d H:i:s')
				);
        
         $this->Common_model->common_insert($data,'tbl_notice_sms');
        
    }
	// singel fees status change
	public function fees_change_status()
	{
		$status = $_POST['status'];
		$billing_id = $_POST['billing_id'];
		$data['status']=$status;
        $data['update_at']=date('Y-m-d',time());
		if($this->Common_model->common_update($data,$billing_id,'billing_id','tbl_students_fees'))
		{
			echo "success";
		}
	}
	
	// bulk fees status change
	public function fees_change_status_bulk()
	{
		$billing_ids = $_POST['billing_id'];
		
		$data['status']=$_POST['status'];
        $data['update_at']='2016-10-20';//date('Y-m-d',time());
		
		if($this->Common_model->common_update_bulk($data,$billing_ids,'billing_id','tbl_students_fees'))
		{
			echo "success";
		}
	}
	
	public function edit_student_fees($billing_id, $class_id, $group_id,$shift_id, $session_id)
	{
		#$school_id = $_SESSION['school_id'];
		$school_id = 1;
		$data['fee_management'] = $this->Fees_model->get_class_wise_fees_management($school_id, $class_id, $group_id,$shift_id, $session_id);
		$data['fees_details'] = $this->Common_model->common_select_by_condition($billing_id,'billing_id','tbl_students_fees');
        $this->load->view('fees/edit_student_fees', $data);
	}
	
	public function student_fees_edit_save()
	{
		$school_id = $_POST['school_id'];
		$class_id = $_POST['class_id'];
		$group_id = $_POST['group_id'];
		$shift_id = $_POST['shift_id'];
		$session_id = $_POST['session_id'];
		$student_id = $_POST['student_id'];
		$billing_id = $_POST['billing_id'];
		$fees_date = $_POST['fees_date'];
		$status = $_POST['status'];
		$amounts= $_POST['amount'];
		$fees_cat_id= $_POST['fees_cat_id'];
		$fees_id= $_POST['fees_id'];
		
		$success[]='0';
		$error[]='0';
		
		for($i=0; $i < count($amounts); $i++){
			
			if($amounts[$i] != 0 && $fees_cat_id[$i] != 0 && $fees_id[$i] == 0)
			{
				/*insert new data*/
				$data[] = array(
								'billing_id' => $billing_id,
								'student_id' => $student_id,
								'fees_cat_id' => $fees_cat_id[$i],
								'school_id' => $school_id,
								'class_id' => $class_id,
								'group_id' => $group_id,
								'shift_id' => $shift_id,
								'session_id' => $session_id,
								'amount' => $amounts[$i],
								'fees_date' => $fees_date,
								'status' => $status,
								'created_on' => date('Y-m-d H:i:s',time())
								);
			}
			elseif($amounts[$i] == 0 && $fees_cat_id[$i] == 0 && $fees_id[$i] != 0)
			{
				/*delete old data*/
				$d_data['school_id'] = 1;
				$d_data['fees_id'] = $fees_id[$i];
				if($this->Common_model->common_delete($d_data,'tbl_students_fees'))
				{ $success[]='delete'; }
				else
				{$error[]='delete';}
			}
			elseif($amounts[$i] != 0 && $fees_cat_id[$i] != 0 && $fees_id[$i] != 0)
			{
				/*update old data */
				$u_data['amount']=$amounts[$i];
				if($this->Common_model->common_update($u_data, $fees_id[$i],'fees_id','tbl_students_fees'))
				{ $success[]='update'; }
				else
				{$error[]='update';}
			}
			else{ /*No action*/ }
		}
		
		/* insart batch data */
		if($this->Common_model->common_insert_batch($data,'tbl_students_fees'))
			{
				$success[]='insart';
			}
		else
			{
				$error[]='insart';
			}
			
			if(count($success) > 1)
				$this->session->set_flashdata('message', '<div class="alert alert-success"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has been saved successfully</div>');
			else
				$this->session->set_flashdata('message', '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Data has not been saved. Please try again.</div>');

				redirect('fees/fees_collect', 'refresh');

	}
  	/* /Students fees collect */
	
	/* student wise fees collect */
	
	public function student_wise_fees_edit(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
		$data['session'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
        $data['class_list'] = $this->Fees_model->get_class_list($school_id);
        $this->load->view('fees/student_wise_fees_edit', $data);
    }
	public function student_wise_fees(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
		$data['session'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
		$data['shift_list'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_shift');
        $data['class_list'] = $this->Fees_model->get_class_list($school_id);
        $this->load->view('fees/student_wise_fees', $data);
    } 
	
	 public function get_section_wise_student_for_dropdown_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$group_id = $_GET['group_id'];
		$shift_id = $_GET['shift_id'];
		$session_id = $_GET['session_id'];
        $section_id = $_GET['section_id'];
        
        $student_list = $this->Fees_model->get_student_list($school_id, $class_id,$group_id,$shift_id,$session_id, $section_id);                
        if($student_list){
            $mainContent ="<option value='0'>---Select Student---</option>";
            foreach($student_list as $sl){
                $mainContent .="<option value='".$sl['student_id']."'>".$sl['student_name']."</option>";
            }            
            #$mainContent=$this->load->view('admin/get_class_wise_student_list_json', $data, true);
        }
        else{
            $mainContent .="<option>No Student Found!</option>";
        }       
        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
	
	public function student_wise_fees_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
		$student_id = $_GET['student_id'];
		$session_id = $_GET['session_id'];
		$class_id = $_GET['class_id'];
		$group_id = $_GET['group_id'];
		$shift_id = $_GET['shift_id'];
		$section_id = $_GET['section_id'];
		$fees_year = $_GET['fees_year'];
		$edit_option = $_GET['edit_option'];
		
        $data['fees_details'] = $this->Fees_model->student_wise_fees_json_details($school_id, $student_id, $session_id, $fees_year);
		
		if(count($data['fees_details']) > 0)
			{
				$mainContent=$this->load->view('fees/get_class_wise_student_list_for_fees_collect_json', $data, true);
			}
		else
			{
				$mainContent= "Fees for this stydent is not generated yet for this year. Please generate fees from ‘Student Fees Generate’ .";
			}

        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
	
	/* /student wise fees collect */
	
	
	/* report section */
	
	// paid report
	public function paid_report(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
		$data['session'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
        $data['class_list'] = $this->Fees_model->get_class_list($school_id);
        $this->load->view('fees/paid_report', $data);
    } 
	
	public function fees_collect_paid_report_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$group_id = $_GET['group_id'];
		$session_id = $_GET['session_id'];
		$fees_date = $_GET['fees_year'].'-'.$_GET['fees_month'].'-01';
		
        $data['fees_details'] = $this->Fees_model->get_class_wise_fees_report($school_id, $class_id, $group_id, $session_id, $fees_date ,'1');
		
	
		if(count($data['fees_details']) > 0)
			{
				$mainContent=$this->load->view('fees/fees_collect_paid_report_json', $data, true);
			}
		else
			{
				$mainContent= '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Fees for this class or month is ether not generated yet or not paid by anyone.</div>';
			}

        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
	
	// unpaid report
	public function unpaid_report(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
		$data['session'] = $this->Common_model->common_select_by_condition($school_id,'school_id','tbl_session');
        $data['class_list'] = $this->Fees_model->get_class_list($school_id);
        $this->load->view('fees/unpaid_report', $data);
    } 
	
	public function fees_collect_unpaid_report_json(){
        #$school_id = $_SESSION['school_id'];
        $school_id = 1;
        $class_id = $_GET['class_id'];
		$group_id = $_GET['group_id'];
		$session_id = $_GET['session_id'];
		$fees_date = $_GET['fees_year'].'-'.$_GET['fees_month'].'-01';
		
        $data['fees_details'] = $this->Fees_model->get_class_wise_fees_report($school_id, $class_id, $group_id, $session_id, $fees_date, '0');
		
	
		if(count($data['fees_details']) > 0)
			{
				$mainContent=$this->load->view('fees/fees_collect_paid_report_json', $data, true);
			}
		else
			{
				$mainContent= '<div class="alert alert-danger"><a href="#" class="close" data-dismiss="alert">&times;</a>Fees for this class or month is ether not generated yet or no unpaid fees found.</div>';
			}

        $result = 'success';
        $return = array('result' => $result, 'mainContent'=> $mainContent);
        print json_encode($return);
        exit;   
    }
	
	// student fees report
	
	
}
?>