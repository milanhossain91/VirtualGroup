<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
            
			<?php if($this->session->flashdata('message')):?>
			
				<?=$this->session->flashdata('message')?>
			
			<?php endif?>
            
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i>  Set GPA System </h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <div class="row">				
                                    <div class="col-md-12">
                                        <div class="widget">
                                            <div class="widget-content">
                                            <a class="btn btn-info" href="javascript:void(0);" onclick="toggle_insertion_box(); return false;"><i class="fa fa-plus" aria-hidden="true"></i>
Add New Class</a>
                                                <div class="insertion_div">
                                                	<div class="form-group">
                                                    	<div class="row">
                                                    		<div class="col-sm-4">
                                                         		<label>Type <span style="color:red;">*</span></label>
                                                         		<select class="form-control" name="type_id" id="type_id" required />
                                                                     <option value="">----Select----</option>
                                                                     <option value="1">Type 1</option>
                                                                     <option value="2">Type 2</option>
                                                                     <option value="3">Type 3</option>
                                                                     <option value="4">Type 4</option>
                                                                 </select>
                                                     			<br />
                                                            <strong>NB:</strong> User can create multiple type of grading system. Just choice any of this.  
                                                            </div>
                                                            <div class="col-sm-4">
                                                                <button type="button" class="btn btn-primary" style="margin-top:25px;" onclick="grd_system_json();">Get GPA Rows</button>
                                                            </div>
                                                   		</div>
                                                	</div> 
                                                     <div class="form-group">
                                                        <div class="row">
                                                            <div class="col-sm-12 col-md-8 col-md-offset-2">
                                                                <div id="display">
                                                                   
                                                                    <!-- Content will be display here--->
                                                                    
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                             	</div>
												<br />
                                                <br />
                                            </div>
                                           
                                           <div class="widget-content">
                                           		<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0">
                                                    <thead>
                                                        <tr>
                                                            <th>SLNO</th>
                                                            <th>GPA Type</th>
                                                            <th>Start Marks</th>
                                                            <th>End Marks</th>
                                                            <th>Grade Point</th>
                                                            <th>GPA</th>
                                                            <th>Comments</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php $ci=1;
                                                            foreach($gpa_list as $gl){
                                                            ?>
                                                        <tr>
                                                            
                                                            <td><?php echo $ci;?></td>
                                                            <td><?php 
                                                            if($gl['type_id']==1)
                                                            echo "Type 1";
                                                            elseif($gl['type_id']==2)
                                                            echo "Type 2";
                                                            elseif($gl['type_id']==3)
                                                            echo "Type 3";
                                                            elseif($gl['type_id']==4)
                                                            echo "Type 4";
                                                            ?></td>
                                                            <td><?php echo $gl['start_marks'];?></td>
                                                            <td><?php echo $gl['end_marks'];?></td>
                                                            <td><?php echo $gl['grd_point'];?></td>
                                                            <td><?php echo $gl['gpa'];?></td>
                                                            <td><?php echo $gl['comments'];?></td>
														</tr>
														<?php $ci++; } ?>
													</tbody>
												</table>
											</div>    
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php include 'application/views/includes/footer.php';?>
<script>
function grd_system_json()
    {
        var type_id = $('#type_id').val(); 
		
		if(!type_id)
		{
			$('#type_id').after("<div id='validation_class' style='position:absolute; background-color:#7ECCAD; width:auto; color:#fff; font-size:14px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:8px 8px 8px 8px; alignment-adjust:central; text-shadow:#FFE1FF;'> Please select a type </div>")
						$('#validation_class').fadeToggle(5000);
						return;
			
		}
		

        $.ajax({ 
        url: baseUrl+'exam/grd_system_json',
        data:
            { 
				'type_id':type_id
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#display').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
</script>