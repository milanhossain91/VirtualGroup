<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
            
          <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
            
            
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Assignment List</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                            	<div class="row">				
									<div class="col-md-12">
										<div class="widget">
                                        	<div class="widget-content padding">
											Add New Assignment - <a href="javascript:void(0);" onclick="toggle_insertion_box(); return false;">Click Here</a>
												<div class="insertion_div">
									 				<form role="form" method="POST" action="<?= base_url();?>exam/create_assignment_save">
                                   						<div class="form-group">
                                                            <div class="row">
                                                                <div class="col-sm-3">
                                                                    <label>Project/Assignment Name <span style="color:red;">*</span></label>
                                                                    <input type="text" class="form-control" name="assignment_name" id="assignment_name" required>
                                                                </div>
                                                                <div class="col-sm-3">
                                                                    <label>Project/Assignment Topic <span style="color:red;">*</span></label>
                                                                    <input type="text" class="form-control" name="assignment_topic" id="assignment_topic" required>
                                                                </div>
                                                                
                                                                <div class="col-sm-3">
                                                                    <label>Class <span style="color:red;">*</span></label>
                       												<select class="form-control" name="class_id" id="class_id" onchange="get_class_group_list(this.value); get_class_section_list(this.value);" required >
                                                                        <option value="">Select</option>
                                                                        <?php
                                                                            foreach($class_list as $cl){ ?>
                                                                             <option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option>   
                                                                        <?php    }
                                                                        ?>
                                                                    </select>
                                                                </div>
                                                                <div class="col-sm-3">
                                                                    <label>Section <span style="color:red;">*</span></label>
                                                                    <select class="form-control" name="section_id" id="section_id" required>
                                                                        <option value="">Select</option>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="row">
                                                                 <div class="col-sm-3">
                                                                   <label>Group <span style="color:red;">*</span></label>
                                                                    <select class="form-control" name="group_id" id="group_id" required onChange="get_sub_list(this.value);" >
                                                                        <option value="">Select</option>
                                                                    </select>
                                                                </div>
                                                                 <div class="col-sm-3">
                                                                    <label>Subject <span style="color:red;">*</span></label>
                                                                    <select class="form-control" name="sub_id" id="sub_id" required>
                                                                        <option value="">Select</option>
                                                                    </select>
                                                                </div>
                                                                <div class="col-sm-3">
                                                                    <label>Submission Date <span style="color:red;">*</span></label>
                                                                    <input type="text" class="form-control datepicker-input" placeholder="mm/dd/yyyy" name="submission_date" id="submission_date" required>
                                                                </div>
                                                          		<div class="col-sm-3">
                                                                    <label>Term <span style="color:red;">*</span></label>
                                                                    <select class="form-control" name="term_id" id="term_id" required>
                                                                        <option value="">Select</option>
                                                                        <?php
                                                                            foreach($term_list as $cl){ ?>
                                                                             <option value="<?php echo $cl['term_id'];?>"><?php echo $cl['term'];?></option>   
                                                                        <?php    }
                                                                        ?>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="row">        
                                                                <div class="col-sm-4">
                                                                    <label>Full Marks <span style="color:red;">*</span></label>
                                                                    <input type="text" class="form-control" name="marks" id="marks" required>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="form-group">
                                                            <div class="row">        
                                                                <div class="col-sm-4">
                                                                    <button type="submit" class="btn btn-primary">Submit</button>
                                                                </div>
                                                            </div>
                                                        </div>
													</form>
                                                </div>
                                            </div>
                   							
                                            <div class="widget-content">
												<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                    <thead>
                                                        <tr>
                                                           
                                                            <th>SLNO</th>
                                                            <th>Name</th>
                                                            <th>Topic</th>
                                                            
                                                            <th>Class</th>
                                                            <th>Section</th>
                                                            <th>Group</th>
                                                            <th>Subject</th>
                                                            <th>Term</th>
                                                            <th>Submission Date</th>
                                                            <th>Full Marks</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                            <?php 
                                                                $pai=1;
                                                                foreach($assignment_list as $tl){	 ?>
                                                            <tr>
                                                                
                                                                <td><?php echo $pai; ?></td>
                                                                <td><?php echo $tl['name']; ?></td>
                                                                <td><?php echo $tl['topic'];?></td>
                                                                
                                                                <td><?php echo $tl['class_name'];?></td>
                                                                <td><?php echo $tl['section_name'];?></td>
                                                                <td><?php echo $tl['group_name'];?></td>
                                                                <td><?php echo $tl['subject_name'];?></td>
                                                                <td><?php echo $tl['term'];?></td>
                                                                <td><?php echo $tl['submission_date'];?></td>
                                                                <td><?php echo $tl['marks'];?></td>
                                                                
                                                                <td>
                                                                    <a href="<?php echo base_url();?>exam/assignment_edit/<?php echo $tl['id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | <?=anchor("exam/assignment_delete/".$tl['id'],"<i class=\"fa fa-remove\"></i>",array('onclick' => "return confirm('Do you want delete this record')"))?> 
                                                                </td>
                                                            </tr>
                                                            <?php  $pai++;  }
                                                            ?>
													
													
									        		</tbody>
									    		</table>
											</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				

				
				

				
<?php include 'application/views/includes/footer.php';?>

<script>

function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
        }
    }
    });  
}

function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
        }
    }
    });  
}

function get_sub_list(group_id)
{
	var class_id=$('#class_id').val();
	$.ajax({
    type: "POST",
    url: baseUrl + 'academic/subject_list_ajax',
    data:
    {
        'class_id':class_id,
		'group_id':group_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
			$('#sub_id').html(html_data);
        }
    }
    });  
}

</script>