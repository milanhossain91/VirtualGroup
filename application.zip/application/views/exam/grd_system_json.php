
<form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>exam/grade_scale_save" enctype="multipart/form-data">
		<input type='hidden' name='type_id' value='<?php echo $details['type_id']; ?>' />		
						
	<table class="table table-striped">
			<thead>
            	<tr>
                	<th style="text-align:center">Start Marks</th>
                    <th style="text-align:center;">End Marks</th>
                    <th style="text-align:center;">Grade Point</th>
                    <th style="text-align:center;">GPA</th>
                    <th style="text-align:center;">Comments</th>
                </tr>
            </thead>
            <tbody class="grd_box">
					<?php
						if($old_value){
						$gi=0;
						foreach($old_value as $ov){ ?>
                    <tr>
                        <td> <input type="text" name="start_marks[]" class="form-control" required pattern="[0-9.]*" placeholder="00" value="<?=$ov['start_marks']?>" /> </td>
                        <td> <input type="text" name="end_marks[]" class="form-control" required pattern="[0-9.]*"  placeholder="00" value="<?=$ov['end_marks']?>" /> </td>
                        <td> <input type="text" name="grd_point[]" class="form-control" required pattern="[0-9.]*"  placeholder="00" value="<?=$ov['grd_point']?>" /> </td>
                        <td> <input type="text" name="gpa[]" class="form-control" required pattern="[A-Z+-]*"  placeholder="Capital Letter" value="<?=$ov['gpa']?>" /></td>
                        <td> <input type="text" name="comments[]" class="form-control" required  placeholder="Text Only" value="<?=$ov['comments']?>" /></td>
                    </tr>	
						
					
					<?php $gi++; }}
						else
						{
					 ?>
					<tr>
                        <td> <input type="text" name="start_marks[]" class="form-control" required pattern="[0-9.]*" placeholder="00"/> </td>
                        <td> <input type="text" name="end_marks[]" class="form-control" required pattern="[0-9.]*"  placeholder="00"/> </td>
                        <td> <input type="text" id="grd_point" name="grd_point[]" class="form-control" required pattern="[0-9.]*"  placeholder="00" /> </td>
                        <td> <input type="text" id="gpa" name="gpa[]" class="form-control" required pattern="[A-Z+-]*"  placeholder="Capital Letter" /> </td>
                        <td> <input type="text" name="comments[]" class="form-control" required  placeholder="Text Only" /></td>
                    </tr>	
                        <?php } ?>
					
				</tbody>
			</table>
<button type="button" class="btn btn-info pull-left" onclick="add_grd_box();">Add More Time Box</button> <input type="submit" class="btn btn-primary pull-right" name="fees_gen" value="Save"/>

	</form>
<script>

/*function validation1(end_marks,serial)
{ //alert(number+serial)
	var start_marks =parseInt($('#start_marks'+serial).val());
	//alert(start_marks+end_marks+serial)
		if(start_marks>=end_marks)
				{
					$('#end_marks'+serial).after("<div id='validation"+serial+"' style='position:absolute; margin-top:-12px; background-color:#7ECCAD; height:25px; width:auto; color:#fff; font-size:12px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:3px 3px 1px 3px; alignment-adjust:central; text-shadow:#FFE1FF;'>Start Marks Can't Be Equal Or Greater Than End Marks</div>")
						$('#validation'+serial).fadeToggle(5000);
						
					$('#end_marks'+serial).val("");
				}
}*/
function add_grd_box()
{
	$('.grd_box').append('<tr><td> <input type="text" name="start_marks[]" class="form-control" required pattern="[0-9.]*" placeholder="00" /> </td><td> <input type="text" name="end_marks[]" class="form-control" required pattern="[0-9.]*"  placeholder="00" /> </td><td> <input type="text" id="grd_point" name="grd_point[]" class="form-control" required pattern="[0-9.]*"  placeholder="00" /> </td><td> <input type="text" id="gpa" name="gpa[]" class="form-control" required pattern="[A-Z+-]*"  placeholder="Capital Letter" /> </td><td> <input type="text" name="comments[]" class="form-control" required placeholder="Text Only" /></td></tr>');
								

}
</script>