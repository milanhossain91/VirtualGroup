<div class="row">
	<div class="col-sm-8 col-md-6 col-md-offset-2">
	<form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>exam/mark_distribution_system_save">
		<input type="hidden" class="form-control" name="class_id" value="<?php echo $details['class_id']; ?>" id="class_id">
        <input type="hidden" class="form-control" name="group_id" value="<?php echo $details['group_id']; ?>" id="group_id">
        <input type="hidden" class="form-control" name="subject_id" value="<?php echo $details['subject_id']; ?>" id="subject_id">			
		<table id="datatables-1" class="table table-striped table-bordered">
			<thead>
            	<tr>
                	<th style="text-align:center">Exam Name</th>
                    <th style="text-align:center;">Marks in %</th>
                </tr>
            </thead>
            <tbody>
					<?php
					$exam_type=array('0,0'=>'---Select---','1,CA'=>'Class attendance','2,CW'=>'Class Work (CW)','3,HW'=>'Home Work (HW)','4,CT'=>'Class Test (CT)','5,AS/PJ'=>'Assignment/Project','6,TE'=>'Term Exam');
               	$a=0;
                    foreach($mark_dis_info as $sList)
                    {
                        $get_type[$a] = $sList['exam_type'].','.$sList['exam_short_name'];
						$get_mark[$get_type[$a]]= $sList['term_mark_per'];
					$a++;}
                      
                  
                    ?>
                    <tr>
                        <td>
                            <select id="start_marks1" name="exam_type[]" class="form-control">
                            <?php foreach($exam_type as $key => $value){ ?>
                            <option value="<?= $key ?>,<?= $value ?>" <?php if($get_type[0]==$key) echo 'selected'; ?>><?= $value ?></option>
                            <?php } ?>
                            </select>
                        </td>
                        <td><input type="text" id="end_marks1" name="term_mark_per[]" class="form-control" pattern="[0-9.]*"  placeholder="00" onKeyUp="validation1()" value="<?= $get_mark[$get_type[0]]; ?>"></td>
                    </tr>
                    <tr>
                    	<td>
                            <select id="start_marks2" name="exam_type[]" class="form-control">
                            
                            <?php foreach($exam_type as $key => $value){ ?>
                            <option value="<?= $key ?>,<?= $value ?>" <?php if($get_type[1]==$key) echo 'selected'; ?>><?= $value ?></option>
                            <?php } ?>
                            
                            </select>
                        </td>
                        <td><input type="text" class="form-control" id="end_marks2" name="term_mark_per[]" pattern="[0-9.]*" placeholder="00" value="<?= $get_mark[$get_type[1]]; ?>" onKeyUp="validation1()"></td>
                    </tr>
                    <tr>
                    	<td>
                            <select id="start_marks2" name="exam_type[]" class="form-control">
                            
                            <?php foreach($exam_type as $key => $value){ ?>
                            <option value="<?= $key ?>,<?= $value ?>" <?php if($get_type[2]==$key) echo 'selected'; ?>><?= $value ?></option>
                            <?php } ?>
                            
                            </select>
                        </td>
                        <td><input type="text" id="end_marks3" name="term_mark_per[]" class="form-control" pattern="[0-9.]*"  placeholder="00" value="<?= $get_mark[$get_type[2]]; ?>" onKeyUp="validation1()"></td>
                    </tr>
                    <tr>
                    	<td>
                            <select id="start_marks2" name="exam_type[]" class="form-control">
                            
                            <?php foreach($exam_type as $key => $value){ ?>
                            <option value="<?= $key ?>,<?= $value ?>" <?php if($get_type[3]==$key) echo 'selected'; ?>><?= $value ?></option>
                            <?php } ?>
                            
                            </select>
                        </td>
                        <td><input type="text" id="end_marks4" name="term_mark_per[]" class="form-control" pattern="[0-9.]*"  placeholder="00" value="<?= $get_mark[$get_type[3]]; ?>" onKeyUp="validation1()"></td>
                    </tr>
                    <tr>
                        <td>
                            <select id="start_marks2" name="exam_type[]" class="form-control">
                            
                            <?php foreach($exam_type as $key => $value){ ?>
                            <option value="<?= $key ?>,<?= $value ?>" <?php if($get_type[4]==$key) echo 'selected'; ?>><?= $value ?></option>
                            <?php } ?>
                            
                            </select>
                        </td>
                        <td><input type="text" id="end_marks5" name="term_mark_per[]" class="form-control" pattern="[0-9.]*"  placeholder="00" value="<?= $get_mark[$get_type[4]]; ?>" onKeyUp="validation1()"></td>
                    </tr>
                    <tr>
                        <td>
                            <select id="start_marks2" name="exam_type[]" class="form-control">
                            
                            <?php foreach($exam_type as $key => $value){ ?>
                            <option value="<?= $key ?>,<?= $value ?>" <?php if($get_type[5]==$key) echo 'selected'; ?>><?= $value ?></option>
                            <?php } ?>
                            
                            </select>
                        </td>
                        <td><input  type="text" id="end_marks6" name="term_mark_per[]" class="form-control" pattern="[0-9.]*"  placeholder="00" value="<?= $get_mark[$get_type[5]]; ?>" onKeyUp="validation1()"></td>
                    </tr>
                    <tr>
                        <td style="text-align:right; font-size:18px;"><strong>Total</strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; </td>
                        <td><input type="text" id="total_marks" class="form-control" value="0" readonly></td>
                    </tr>
                    <tr>
                        <td><strong>NB : </strong>Please make sure the total marks is not greater than <strong>" 100 "</strong> to get the <strong>Active Save Button</strong>. If any exam don't <strong>affect</strong> the <strong>term total marks</strong>, please don't select that exam. </td>
                        <td><input type="submit" class="btn btn-primary" disabled name="fees_gen" id="button" value="Save"/></td>
                    </tr>
				</tbody>
			</table>
		</form>
	</div>
</div>
<script>
/*function get_mark_box(valu)
{alert(valu)
		 $("#end_marks"+valu).removeAttr("disabled");
		
}
*/validation1();
function validation1()
{ 
	if($('#end_marks1').val())
		var marks1=$('#end_marks1').val();
	else
		marks1=0;
	
	if($('#end_marks2').val())
		var marks2=$('#end_marks2').val();
	else
		marks2=0;
		
	if($('#end_marks3').val())
		var marks3=$('#end_marks3').val();
	else
		marks3=0;
	
	if($('#end_marks4').val())
		var marks4=$('#end_marks4').val();
	else
		marks4=0;
	
	if($('#end_marks5').val())
		var marks5=$('#end_marks5').val();
	else
		marks5=0;
	
	if($('#end_marks6').val())
		var marks6=$('#end_marks6').val();
	else
		marks6=0;
	
	/*var marks3=$('#end_marks3').val();
	var marks4=$('#end_marks4').val();
	var marks5=$('#end_marks5').val();
	var marks6=$('#end_marks6').val();
	alert(marks1);*/
    var total=parseInt(marks1)+parseInt(marks2)+parseInt(marks3)+parseInt(marks4)+parseInt(marks5)+parseInt(marks6);
	//alert(total);
	

	if(total)
	{
		$('#total_marks').val(total);
		
		var total_marks =$('#total_marks').val();
		
		
		if(total_marks<=100)
			{
				 $("#button").removeAttr("disabled");
			}
		else
			{
				$("#button").attr("disabled", "disabled");
			}
	}
		
}
</script>