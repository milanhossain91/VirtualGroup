<body style="width:100%">
	<?php foreach($student_info as $sinfo){?>
        <div style=" page-break-inside:avoid; float: left; width:49.5%; padding-bottom:10px; border-bottom:1px dashed black;">
            <table width="96%" style="padding-top: 15px;margin-left:2.5%;border-right:1px dashed black;">
             	<tr >
                	<td align="center">
                        <span style="font-family:Algerian; font-size:22px; margin-left:10px;"><?= $school['school_name']; ?></span>
                    </td>
                </tr>
                <tr>
                    <td align="center" style="font-size:12px; padding-bottom:10px;" ><?= $school['address']; ?>, <?= $school['post_office']; ?>, <?= $school['district']; ?></td>
                </tr>
                <tr>
                    <td align="center" style="padding-bottom:5px;" >
                    	<span style=" border:1px solid black; padding:3px; font-size:12px;">&nbsp;Admit Card&nbsp;</span>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                        <?= $term[0]['term'] ?> <?= $exam_year ?>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                       <table width="100%" >
                            <tr>
                                <td>
                                    <span style=" font-size:14px;">Student Name : <?php echo $sinfo['student_name']; ?></span>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                       <table width="100%" >
                            <tr>
                                <td width="50%">
                                    <span style=" font-size:14px;">Class : <?php echo $sinfo['class_name']; ?></span>
                                </td>
                                <td width="50%">
                                    <span style=" font-size:14px;">Group : <?php echo $sinfo['group_name']; ?></span>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                       <table width="100%" >
                            <tr>
                                <td width="50%">
                                    <span style=" font-size:14px;">Section : <?php echo $sinfo['section_name']; ?></span>
                                </td>
                                <td width="50%">
                                    <span style=" font-size:14px;">Roll : <?php echo $sinfo['roll_no']; ?></span>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td align="center">
                       <table width="100%" >
                            <tr>
                                <td>&nbsp;</td>
                                <td></td>
                            </tr>
                            <tr>
                               <td align="center"><div style="padding-top:3px; border-top:1px solid black; text-align:center; width:150px; margin-top:10px; ">Principal</div></td>
                                <td align="center"><div style="padding-top:3px; border-top:1px solid black; text-align:center; width:150px; margin-top:10px; ">Principal</div></td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td >&nbsp;
                        
                    </td>
                </tr>
            </table>
        </div>
  <?php } ?>
</body>
