<form role="form" id="registerForm" method="POST" action="<?= base_url();?>exam/ca_marks_save" >
		<div class="form-group">
        	<div class="row">
            	<div class="col-sm-11" style="text-align: center;font-size:20px;font-weight:bold;">
                
                	<h2><span style="font-weight:bold;"> Class Attendence</span></h2>
                    <p>Full Marks: <span class="full_marks"> <?= $mark_dis_info['0']['term_mark_per'];?></span>&nbsp;&nbsp;</p>
												
                    <input type='hidden' name='class_id' value='<?= $details['class']; ?>' />
                    <input type='hidden' name='section_id' value='<?= $details['section']; ?>' />
                    <input type='hidden' name='term_id' value='<?= $details['term_id']; ?>' />											
                    <input type='hidden' name='group_id' value='<?= $details['group_id']; ?>' />
                    <input type='hidden' name='subject_id' value='<?= $details['subject_id']; ?>' />
                    <input type='hidden' name='exam_year' value='<?= $details['exam_year']; ?>' />
                    <input type='hidden' name='session_id' value='<?= $details['session_id']; ?>' />
				</div>
            </div>
        </div>
						
        <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
            <thead>
                <tr>
                    <th>Student ID</th>
                    <th>Student Name</th>
                    <th>Obtained Marks</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach($student_list as $sl): ?>
                <tr>
                    <td>
                    	<label><?= $sl['student_id'];?></label>
                    	<input type="hidden" name="student_iddfsd[]" value="<?= $sl['student_id'];?>">
                    </td>
                    <td><label><?= $sl['student_name'];?></label></td>
                    <td>
                    	<input type="text" class="form-control" name="obtain_marks[]" id="obtain_marks<?= $sl['student_id'];?>" value="<?= str_replace(',','',$sl['obtained_marks']);?>" onkeyup="validation(this.value,<?= $sl['student_id'];?>)" onBlur="validation(this.value,<?= $sl['student_id'];?>)">
                    	<input type="hidden" name="ca_marks_id[]" value="<?= $sl['ca_marks_id'];?>">
                    </td>
                </tr>
                <?php endforeach; ?>
                <tr>
                    <td><button type="submit" class="btn btn-primary" >Save</button></td>
                </tr>
            </tbody>
        </table>
	</form>

<script>
function validation(number,student_id)
{
	var full_marks =parseInt($('.full_marks').text());
	var numbers=/^([0-9.]*)$/;
	if (numbers.test(number))
			{
				if(number>full_marks)
				{
					$('#obtain_marks'+student_id).after("<div id='validation"+student_id+"' class='validation_js'>This number is more than Full Marks</div>")
						$('#validation'+student_id).delay(2000).hide('slow');
						
					$('#obtain_marks'+student_id).val("");
				}
			}
			else
			{
				
				$('#obtain_marks'+student_id).after("<div id='validation"+student_id+"' class='validation_js'>Please enter number only</div>")
						$('#validation'+student_id).delay(2000).hide('slow');
				$('#obtain_marks'+student_id).val("");
			}
	
	
}
</script>
