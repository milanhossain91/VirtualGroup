<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> <?= $subject_marks_list['subject_name']; ?> Term Marks Distribution</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <form role="form" id="hw_entry" name="hw_entry" method="POST" action="<?php echo base_url();?>exam/subject_wise_total_marks_edit_save">
                                   <input type="hidden" class="form-control" name="subject_marks_id" value="<?= $subject_marks_list['subject_marks_id']; ?>" id="subject_marks_id">
                                   
                                    
                                    <div class="form-group">
                                        <div class="row">
                                           <?php if($subject_marks_list['marks_type']==1):?>
											<div class="col-sm-4">
												<label>Subjective Marks</label>
												<input type="text" pattern="[0-9]*" value="<?php echo $subject_marks_list['subjective_marks']; ?>" required class="form-control" name="subjective_marks" id="subjective_marks">
											</div>
											<?php elseif($subject_marks_list['marks_type']==2):?>
											<div class="col-sm-4">
												<label>Subjective Marks</label>
												<input type="text" pattern="[0-9]*" value="<?php echo $subject_marks_list['subjective_marks']; ?>" required class="form-control" name="subjective_marks" id="subjective_marks">
											</div>
											<div class="col-sm-4">
												<label>Objective Marks</label>
												<input type="text" pattern="[0-9]*" value="<?php echo $subject_marks_list['objective_marks']; ?>" required class="form-control" name="objective_marks" id="objective_marks">
											</div>
											<?php elseif($subject_marks_list['marks_type']==3):?>
											<div class="col-sm-4">
												<label>Subjective Marks</label>
												<input type="text" pattern="[0-9]*" required value="<?php echo $subject_marks_list['subjective_marks']; ?>" class="form-control" name="subjective_marks" id="subjective_marks">
											</div>
											<div class="col-sm-4">
												<label>Objective Marks</label>
												<input type="text" pattern="[0-9]*" required value="<?php echo $subject_marks_list['objective_marks']; ?>" class="form-control" name="objective_marks" id="objective_marks">
											</div>
											<div class="col-sm-4">
												<label>Practical Marks</label>
												<input type="text" pattern="[0-9]*" required value="<?php echo $subject_marks_list['practical_marks']; ?>" class="form-control" name="practical_marks" id="practical_marks">
											</div>
											<?php endif; ?>
											<div class="col-sm-4">
                                                <label>Pass Marks in % <span style="color:red;">*</span></label>
                                                <input type="text" pattern="[0-9]*" required class="form-control" name="pass_marks" id="pass_marks" value="<?php echo $subject_marks_list['pass_marks']; ?>">
                                            </div>
											</div>

                                        </div>
                                    </div>
									<hr />
									
									<button type="submit" class="btn btn-primary">Submit</button>
								</form>
                            </div>
                        </div>
                    </div>
                </div>
				

				
<?php include 'application/views/includes/footer.php';?>