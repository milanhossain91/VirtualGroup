	<form role="form" id="registerForm" method="POST" action="<?= base_url();?>exam/term_marks_save">
		<div class="form-group">
        	<div class="row">
            	<div class="col-sm-11" style="text-align: center;font-size:20px;font-weight:bold;">
                	<p> Term: <?= $details['term_name']; ?></p>
                     	<?php $subject_box = $sml['marks_type'];
								if($subject_box==1): ?>
									<p>Subjective Marks: <span class="full_marks"><?php if($sml['subjective_marks']){echo $sml['subjective_marks'];} else {echo "0";}?></span>&nbsp;&nbsp;
                                <?php elseif($subject_box==2): ?>
                                    <p>Subjective Marks: <span class="full_marks"><?php if($sml['subjective_marks']){echo $sml['subjective_marks'];} else {echo "0";}?></span>&nbsp;&nbsp;
                                     Objective Marks: <span class="full_marks"><?php if($sml['objective_marks']){echo $sml['objective_marks'];} else {echo "0";} ?></span>&nbsp;&nbsp;
                                 <?php else: ?>
                                     <p>Subjective Marks: <span class="full_marks"><?php if($sml['subjective_marks']){echo $sml['subjective_marks'];} else {echo "0";}?></span>&nbsp;&nbsp;
                                        Objective Marks: <span class="full_marks"><?php if($sml['objective_marks']){echo $sml['objective_marks'];} else {echo "0";} ?></span>&nbsp;&nbsp;
                                        Practical Marks: <span class="full_marks"><?php if($sml['practical_marks']){echo $sml['practical_marks'];} else {echo "0";}?></span>&nbsp;&nbsp;
                                 <?php endif; ?>
								&nbsp;&nbsp;Subject Name: <?= $sml['subject_name']; ?></p>
												
                                <input type='hidden' name='class_id' value='<?= $details['class']; ?>' />
				<input type='hidden' name='section_id' value='<?= $details['section']; ?>' />
				<input type='hidden' name='term_id' value='<?= $details['term']; ?>' />
                                <input type='hidden' name='group_id' value='<?= $details['group_id']; ?>' />
                                <input type='hidden' name='shift_id' value='<?= $details['shift_id']; ?>' />
                                <input type='hidden' name='subject_id' value='<?= $details['subject_id']; ?>' />
                                <input type='hidden' name='exam_year' value='<?= $details['exam_year']; ?>' />
                                <input type='hidden' name='session_id' value='<?= $details['session_id'] ?>' />
				</div>
            </div>
        </div>
						
		<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th>Student ID</th>
					<th>Roll No</th>
                    <th>Student Name</th>
                     <?php $subject_box = $sml['marks_type'];
						if($subject_box==1): ?>
					<th>Subjective Marks</th>
                        <?php  elseif($subject_box==2): ?>
					<th>Subjective Marks</th>
                    <th>Objective Marks</th>
                        <?php else: ?>
					<th>Subjective Marks</th>
                    <th>Objective Marks</th>
                    <th>Practical Marks</th>
                        <?php endif; ?>
				</tr>
			</thead>
			<tbody>
				<?php foreach($student_list as $sl): ?>
				<tr>
					<td>
						<input type="hidden" name="student_iddfsd[]" id="student_id" value="<?= $sl['student_id'];?>">
                        <input type="hidden" name="term_marks_id[]" id="term_marks_id" value="<?php if($sl['term_marks_id']) {echo trim($sl['term_marks_id'],','); } else {echo'0';};?>">
                        <?= $sl['student_id'];?>
					</td>
					<td>
						<?= $sl['roll_no'];?>
					</td>
                    <td>
						<?= $sl['student_name'];?>
					</td>
					<td>
						<input type="text" class="form-control" name="subjective_marks[]" id="obtain_marks<?= $sl['student_id'];?>" value="<?= str_replace(',','',$sl['subjective_marks']);?>" onchange="validation(this.value,<?= $sl['student_id']; ?>,<?= $sml['subjective_marks'];?>)" />
					</td>
                    <td style="display:<?php if($sml['marks_type']==1) echo 'none';?>">
                    
						<input type="<?php if($sml['marks_type']==1) echo 'hidden'; else echo 'text'; ?>" class="form-control" name="objective_marks[]" id="objective_marks<?= $sl['student_id'];?>" value="<?= str_replace(',','',$sl['objective_marks']);?>" onchange="validation_obj(this.value,<?= $sl['student_id']; ?>,<?= $sml['objective_marks']; ?>)" />
                        
					</td>
                    <td style="display:<?php if($sml['marks_type']==2 || $sml['marks_type']==1) echo 'none';?>">
                    
						<input type="<?php if($sml['marks_type']==2 || $sml['marks_type']==1) echo 'hidden'; else echo 'text'; ?>" class="form-control" name="practical_marks[]" id="practical_marks<?= $sl['student_id'];?>" value="<?= str_replace(',','',$sl['practical_marks']);?>"  onchange="validation_prac(this.value,<?= $sl['student_id']; ?>,<?= $sml['practical_marks']; ?>)" />
                        
					</td>
                    
				</tr>
				<?php endforeach; ?>
				<tr>
					<td>
						<input type="submit" class="btn btn-primary" value="Save"/><br/>
					</td>
				</tr>
			</tbody>
		</table>
  	</form>

<style>
{
	margin:auto auto;
}
</style>
<script>
function validation(number,student_id,marks)
{
	///var full_marks =parseInt($('.full_marks').text());
	var numbers=/^([0-9.]*)$/;
		if (numbers.test(number))
			{
				if(number>marks)
				{
					$('#obtain_marks'+student_id).after("<div id='validation"+student_id+"' class='validation_js_small'>This number is more than Full Marks</div>")
						$('#validation'+student_id).delay(2000).hide('slow');
						
					$('#obtain_marks'+student_id).val("");
				}
			}
		else
			{
				
				$('#obtain_marks'+student_id).after("<div id='validation"+student_id+"' class='validation_js_small'>Please enter number only</div>")
						$('#validation'+student_id).delay(2000).hide('slow');
				$('#obtain_marks'+student_id).val("");
			}
	
	
}
function validation_obj(number,student_id,marks)
{
	///var full_marks =parseInt($('.full_marks').text());
	var numbers=/^([0-9.]*)$/;
		if (numbers.test(number))
			{
				if(number>marks)
				{
					$('#objective_marks'+student_id).after("<div id='validation_obj"+student_id+"' class='validation_js_small'>This number is more than Full Marks</div>")
						$('#validation_obj'+student_id).delay(2000).hide('slow');
						
					$('#objective_marks'+student_id).val("");
				}
			}
		else
			{
				
				$('#objective_marks'+student_id).after("<div id='validation_obj"+student_id+"' class='validation_js_small'>Please enter number only</div>")
						$('#validation_obj'+student_id).delay(2000).hide('slow');
				$('#objective_marks'+student_id).val("");
			}
	
	
}
function validation_prac(number,student_id,marks)
{
	///var full_marks =parseInt($('.full_marks').text());
	var numbers=/^([0-9.]*)$/;
		if (numbers.test(number))
			{
				if(number>marks)
				{
					$('#practical_marks'+student_id).after("<div id='validation_prac"+student_id+"' class='validation_js_small'>This number is more than Full Marks</div>")
						$('#validation_prac'+student_id).delay(2000).hide('slow');
						
					$('#practical_marks'+student_id).val("");
				}
			}
		else
			{
				
				$('#practical_marks'+student_id).after("<div id='validation_prac"+student_id+"' class='validation_js_small'>Please enter number only</div>")
						$('#validation_prac'+student_id).delay(2000).hide('slow');
				$('#practical_marks'+student_id).val("");
			}
	
	
}
</script>