<?php $subject_box = $subject_info[0]['marks_type'];

if($subject_box==1)
{
 ?>
<div class="col-sm-4">
    <label>Subjective Marks</label>
    <input type="text" pattern="[0-9]*" required class="form-control" name="subjective_marks" id="subjective_marks">
</div>
<?php } 
elseif($subject_box==2)
{
 ?>
<div class="col-sm-4">
    <label>Subjective Marks</label>
    <input type="text" pattern="[0-9]*" required class="form-control" name="subjective_marks" id="subjective_marks">
</div>
<div class="col-sm-4">
    <label>Objective Marks</label>
    <input type="text" pattern="[0-9]*" required class="form-control" name="objective_marks" id="objective_marks">
</div>
<?php } 
else
{
 ?>
<div class="col-sm-4">
    <label>Subjective Marks</label>
    <input type="text" pattern="[0-9]*" required class="form-control" name="subjective_marks" id="subjective_marks">
</div>
<div class="col-sm-4">
    <label>Objective Marks</label>
    <input type="text" pattern="[0-9]*" required class="form-control" name="objective_marks" id="objective_marks">
</div>
<div class="col-sm-4">
    <label>Practical Marks</label>
    <input type="text" pattern="[0-9]*" required class="form-control" name="practical_marks" id="practical_marks">
</div>
<?php } ?>
<div class="col-sm-4">
	<label>Pass Marks in % <span style="color:red;">*</span></label>
    <input type="text" pattern="[0-9]*" required class="form-control" name="pass_marks" id="pass_marks">
</div>
