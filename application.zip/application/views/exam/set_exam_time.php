<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
<style>
.calendar-table{display:none;}
</style>
				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
             <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Exam Time Assign</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <div class="row">				
                                    <div class="col-md-12">
                                        <div class="widget">
                                            <div class="widget-content">
                                                <form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>exam/save_exam_timing">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <label>Exam Time</label>
                                        					<input type="text" name="timerange" class="form-control"/>
                                                            <input type="hidden" name="id"/>
                                                        </div>
                                                        <div class="col-sm-4">
                                 						<button type="submit" class="btn btn-primary update" style="margin-top:25px;">save</button>
                                                        </div>
                                                    </div>
                                                </div> 
                                                </form>
                                            </div>
                                        </div>
                                    </div>
								</div>
				
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                <thead>
                                                    <tr>
                                                        <th>SLNO</th>
                                                        <th>Exam Time</th>
                                                        <th>Exam Hour</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach($exam_time as $et){ ?>
                                                    <tr>
                                                        <td><?= $et['id'];?></td>
                                                        <td><?= $et['exam_time'];?></td>
                                                        <td><?php 
																$time=explode('-',$et['exam_time']);
																$start=strtotime(trim($time[1]))-strtotime(trim($time[0]));
																echo $start/60/60;
																echo ' H';
															 ?></td>
                                                         <td><a href="#" onClick="edit('<?= $et['exam_time'];?>',<?= $et['id'];?>)" title="Edit"><i class="fa fa-edit"></i></a></td>
                                                    </tr>
                                                    <?php } ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
			
				
<?php include 'application/views/includes/footer.php';?>

<script type="text/javascript">
function timerange(){
    $('input[name="timerange"]').daterangepicker({
        timePicker: true,
		 autoUpdateInput: false,
        locale: {
            format: 'h:mm A'
        }
    });
	$('input[name="timerange"]').on('apply.daterangepicker', function(ev, picker) {
      $(this).val(picker.startDate.format('h:mm A') + ' - ' + picker.endDate.format('h:mm A'));
  });
}
timerange();

function edit(time,id)
{
	 $('input[name="timerange"]').val(time);
	 $('input[name="id"]').val(id);
	 $('.update').text('Update');
	 timerange();
	 $('input[name="timerange"]').focus();
	
}
</script>