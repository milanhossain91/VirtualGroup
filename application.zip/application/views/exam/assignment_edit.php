<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Assignment Information Edit</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>exam/assignment_edit_save">    
									                                                                      
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-3">
                                                <label>Assignment Name:</label>
												<input type="hidden" class="form-control" name="assignment_id" id="assignment_id" value="<?= $assignment_info[0]['id'];?>" >
                                                <input type="text" class="form-control" name="assignment_name" id="assignment_name" value="<?= $assignment_info[0]['name'];?>" required >
                                            </div>
                                            
                                            <div class="col-sm-3">
                                                <label>Assignment Topic</label>
                                                <input type="text" class="form-control" name="assignment_topic" id="assignment_topic" value="<?= $assignment_info[0]['topic'];?>" required >
                                            </div>
                                          	<div class="col-sm-3">
                                                <label>Assignment Submission Date</label>
                                                <input type="text" class="form-control datepicker-input" name="submission_date" id="submission_date" value="<?= $assignment_info[0]['submission_date'];?>" required >
                                            </div>
                                            <div class="col-sm-3">
                                                <label>Full Marks</label>
                                                <input type="text" class="form-control" name="marks" id="marks" value="<?= $assignment_info[0]['marks'];?>" required >
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    
									<div class="form-group">
                                        <div class="row">
                                         	<div class="col-sm-4">
                                               <button type="submit" class="btn btn-primary">Update</button>  
                                            </div>
											
                                        </div>
                                    </div>   
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
				
				
<?php include 'application/views/includes/footer.php';?>
