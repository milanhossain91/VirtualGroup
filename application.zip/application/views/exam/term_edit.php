<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Edit Term</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <form role="form" id="hw_entry" name="hw_entry" method="POST" action="<?php echo base_url();?>exam/term_edit_save">
                                   
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Term Name</label>
						<input type="hidden" class="form-control" name="term_id" id="term_id" value="<?php echo $term_list[0]['term_id']; ?>">
                                     <input type="text" class="form-control" name="term_name" id="term_name" value="<?php echo $term_list[0]['term']; ?>">
                                            </div>
                                        </div>
                                    </div>
                                    
                                 	<div class="form-group">
                                        <div class="row">
											<div class="col-sm-4">
                                                <input type="checkbox" class="form-control" name="year_end_exam" value="1" <?php if($term_list[0]['year_end_exam']==1) echo 'checked'; ?> >
                                                <label>Year Ending Exam</label>
                                                <br/>
                                                <b>NB:</b> Check this if this is the final.
                                            </div>
                                        </div>
                                    </div>
								
									<button type="submit" class="btn btn-primary">Update</button>
								</form>
                            </div>
                        </div>
                    </div>
                </div>
				

				
<?php include 'application/views/includes/footer.php';?>
 