<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
	<div class="content-page" style="overflow:visible;" id="loadfunction">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content" style="overflow:visible;">
			<div class="page-heading">
            	<h1><i class='fa fa-table'></i> Set Exam Routine </h1>
			</div>
             <div class="message"></div>       	            	
			<div class="row" style="overflow:auto;">
            	<div class="col-md-12">
                	<div class="widget" style="min-height: 400px">
                    	<div class="widget-content">
                        	<div class="widget-content padding">
                            	<div class="form-group">
                                	<div class="row">
                                    	<div class="col-sm-4" >
                                        	<label>Exam <span style="color:red;">*</span></label>
                      						<select class="form-control" name="term_id" id="term_id">
                                            	<option value="">----Select Exam----</option>
                                                <?php foreach($term_list as $tl){ ?>
                                                <option value="<?php echo $tl['term_id'];?>"><?php echo $tl['term'];?></option>   
                                                <?php    } ?>
                                            </select>
                                        </div>
                                        <div class="col-sm-4" >
                                        	<label>Class <span style="color:red;">*</span></label>
                      						<select class="form-control" name="class_id" id="class_id">
                                            	<option value="">----Select Class----</option>
                                                <?php foreach($class_list as $cl){ ?>
                                                <option value="<?= $cl['class_id'];?>"><?= $cl['class_name'];?></option>   
                                                <?php    } ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                	<div class="row">
                                    	<div class="col-sm-12">
                                        	<button type="button" class="btn btn-primary" onclick="exam_routine_json();">Get Routine</button>
                                        </div>
                                	</div>
                                </div>
                                <div class="form-group">
                                	<div class="row">
                                    	<div class="col-sm-12" id="display">
                                        	<!-- routine will be displayed here -->
                                        </div>
                                	</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
		</div>
				
<?php include 'application/views/includes/footer.php';?>
 
<script type="text/javascript">
function get_day(exam_date,id)
{
	 var dayNames = new Array( 'Sunday' , 'Monday' , 'Tuesday' , 'Wednesday' , 'Thursday' , 'Friday' , 'Saturday' );
     var nData = new Date (exam_date);
	 
	 $('.date'+id).next('td').html(dayNames[nData.getDay()]);
	
}

function exam_routine_json()
{
	var term_id=$('#term_id').val();
	var class_id=$('#class_id').val();
	$.ajax({ 
        url: baseUrl+'exam/exam_routine_json',
        data:
            {                  
                'term_id':term_id,
				'class_id':class_id
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {      
                    $('#display').html(mainContent);  
					// call the routine if created before
					get_old_exam_routine(term_id,class_id);
                }                
            }
        });
        return false; // keeps the page from not refreshing     
}
							

</script>
<script>

function get_old_exam_routine(term_id,class_id)
{//1
	
	 $.getJSON(//6
				baseUrl + 'exam/get_old_exam_routine_by_term',
				{ 
					'exam_term_id':term_id,
					'class_id':class_id
				},
				function(jd) {
						
				for(i=0; i<jd.length; i++)
				{
					$("td[id='"+jd[i].row_no+"'] input.timerange").val(jd[i].exam_date);
					$("td[id='wkday"+jd[i].row_no+"']").html(jd[i].exam_day);
					$("td[id='"+jd[i].row_no+jd[i].column_no+"'] select").val(jd[i].exam_subject_id);
				}
									
			});////6					
}////1
</script>
<script>
 function save_class_routine()
{//1
	var final_routine = new Array();
	var class_id=$('#class_id').val();  
	var term_id=$('#term_id').val();
	
	// get exam time as array
	var exam_time=new Array();  
	var iexam_time=0;	
	$( ".class_time").each(function()
		{
			exam_time[iexam_time]=$(this).val();
			iexam_time++;
	});	
		
							
	//get exam date as array
	var date_value=new Array();  
	var idate=0;	
	$( "input.timerange").each(function()
	{
		date_value[idate]=$(this).val();
		idate++;
	});
	//alert(date_value);
						
	//get exam day as array
	var day_value=new Array();  
	var iday=0;	
	$( "td.wday").each(function()
	{
		day_value[iday]=$(this).html();
		iday++;
	});
	//alert(day_value);
							
	var subName=new Array();
	var rsl=1;
	//exam_time value =15
	for(itsc=0; itsc<iexam_time;)
		{//5
			//get subject name
			var subName=new Array();
			var icid=0;	
			$( 'select.subject_name'+itsc).each(function()
			{
				subName[icid]=$(this).val();
				icid++;
			});
			//alert(subName)
			var iwday=0;	
			$( 'select.subject_name'+itsc).each(function()
			{
				iwday++;
			});
			var count=iwday;// value = 19
								
								
			// routine object create program
			
			for(var isave=0; isave<count; isave++)
				{//6
				//alert(' class_id ='+class_id+' exam_time ='+exam_time[itsc]+' day ='+day_value[isave]+' date ='+date_value[isave]+' subname ='+subName[isave]);
					if(subName[isave]!='' && day_value[isave]!='' && exam_time[itsc]!='')
					{//7
						final_routine.push({'school_id':'1',
											'exam_term_id':term_id,
											'class_id':class_id,
											'exam_time':exam_time[itsc],
											'exam_date':date_value[isave],
											'exam_day':day_value[isave],
											'exam_subject_id':subName[isave],
											'column_no':itsc,
											'row_no':isave});
					}////7
										
					//	alert(isave)
				}////6
			itsc++;
		}//
									$.ajax({//4
										type: "POST",
										url: baseUrl + 'exam/save_exam_routine',
										data:
											{
												'class_id':class_id,
												'term_id':term_id,
												'final_routine':final_routine
											}, 
										success: function(html_data)
											{
												if (html_data != '')
													{
														$('.message').html(html_data);
													}
											}
									});//4
				
 }////1
</script>