<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">
	<div class="content">
	<?php if($this->session->flashdata('message')):?>
		<?=$this->session->flashdata('message')?>
	<?php endif?>
    <!-- Page Heading Start -->
		<div class="page-heading">
			<h1><i class='fa fa-check'></i> Term Marks Distribution List</h1>
		</div>
		<!-- Page Heading End-->
		<!-- Your awesome content goes here -->
		<div class="row">
			<div class="col-sm-12">
				<div class="widget" style="min-height:500px;">
					<div class="widget-content padding">
						<div class="row">				
							<div class="col-md-12">
								<div class="widget">
									<div class="widget-content padding">
									Add New subject - <a href="javascript:void(0);" onclick="toggle_insertion_box(); return false;">Click Here</a>
										<div class="insertion_div">
											<form name="sb_entry" method="POST" action="<?= base_url();?>exam/subject_wise_total_marks_save">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <label>Class <span style="color:red;">*</span></label>
                                                            <select class="form-control" name="class_id" id="class_id" onchange="get_class_group_list(this.value);" required >
                                                                <option value="">Select</option>
                                                                <?php foreach($class_list as $cl){ ?>
                                                                <option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option><?php } ?>
                                                            </select>
                                                        </div>
														<div class="col-sm-4">
															<label>Group <span style="color:red;">*</span></label>
															<select class="form-control" name="group_id" id="group_id" required >
																<option value="">Select</option>
                                                            </select>
														</div>
														<div class="col-sm-4">
                                                            <label>Term</label>
                                                            <select class="form-control" name="term_id" id="term_id" onChange="get_sub_list(this.value);" >
                                                                <option value="0">Select</option>
                                                                <?php foreach($term_list as $tl){ ?>
                                                                <option value="<?= $tl['term_id'];?>"><?= $tl['term'];?></option>   
                                                                <?php } ?>
                                                            </select>
                                                        </div>
													</div>
												</div>
                                    			<div class="form-group">
													<div class="row">
                                                        <div class="col-sm-4">
															<label>Subject <span style="color:red;">*</span></label>
															<select class="form-control" name="subject_id" id="subject_id" required onChange="get_mark_box_json(this.value)" >
																<option value="">Select</option>
															</select>
														</div>
                                                        <div id="display">
                                                        
                                                        </div>
                                                    </div>
                                                </div>
                                                <hr />
													<button type="submit" class="btn btn-primary">Submit</button>
                                            </form>
										</div>
									</div>
									<div class="widget-content">
                                        <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>SLNO</th>
                                                    <th>Subject Name</th>
													<th>Class</th>
													<th>Group</th>
													<th>Term</th>
													<th>Subjective</th>
													<th>Objective</th>
													<th>Practical</th>
													<th>Total</th>
													<th>Pass Mark %</th>
													<th>Action</th>
												</tr>
											</thead>
											<tbody>
												<?php $ci=1; foreach($subject_marks_list as $sml){  ?>
                                                <tr>
                                                    <td><?= $ci;?></td>
													<td><?= $sml['subject_name'];?></td>
													<td><?= $sml['class_name'];?></td>
													<td><?= $sml['group_name'];?></td>
													<td><?= $sml['term'];?></td>
													<td><?= $sml['subjective_marks'];?></td>
													<td><?php if($sml['objective_marks']==0) echo '--'; else echo $sml['objective_marks']; ?></td>
													<td><?php if($sml['practical_marks']==0) echo '--'; else echo $sml['practical_marks']; ?></td>
													<td><?= $sml['practical_marks']+$sml['objective_marks']+$sml['subjective_marks'];?></td>
													<td><?= $sml['pass_marks'];?></td>
													<td>
                                                           <a href="<?= base_url();?>exam/subject_wise_total_marks_edit/<?= $sml['subject_marks_id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | <?=anchor("exam/subject_wise_total_marks_delete/".$sml['subject_marks_id'],"<i class=\"fa fa-remove\"></i>",array('onclick' => "return confirm('Do you want delete this record')"))?> 
                                                    </td>
                                                </tr>
                                                <?php   $ci++; } ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
					</div>
                </div>
            </div>
        </div>			
<?php include 'application/views/includes/footer.php';?>
<script type="text/javascript">


function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
        }
    }
    });  
}

function get_sub_list(term_id)
{
	var class_id=$('#class_id').val();
	var group_id=$('#group_id').val();
   $.ajax({
    type: "POST",
    url: baseUrl + 'exam/subject_list_mark_ajax',
    data:
    {
        'class_id':class_id,
		'group_id':group_id,
		'term_id':term_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
			$('#subject_id').html(html_data);
        }
    }
    });  
}


function get_mark_box_json(subject_id)
	{
		$.ajax({ 
			url: baseUrl+'exam/get_mark_box_json',
			data:
				{                  
					'subject_id':subject_id
				}, 
				dataType: 'json',
				success: function(data)
				{
					result                = ''+data['result']+'';
					mainContent           = ''+data['mainContent']+'';
	
					if(result == 'success')
					{            
						$('#display').html(mainContent);     
					}                
				}
		});
	}
		
</script>  