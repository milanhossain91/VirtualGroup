<?php include 'application/views/includes/admin_header.php';?>
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
	<div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content">
			<div class="page-heading">
				<h1><i class='fa fa-table'></i> Income Report</h1>
			</div>       
			
			<?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
				
			<div class="row">					
				<div class="col-md-12">
					<div class="widget">							
						<div class="widget-content">
							<form role="form" id="registerForm" method="POST">
                            	<div class="widget-content padding">
                                	<div class="form-group">
                                    	<div class="row">
                                        	<div class="col-sm-3 col-md-3">
                                            	<label>Month , Year <span style="color:red;">*</span></label>
                                              	<input type="month" id="month" class="form-control" value="<?= date('F')?>" />
                                            </div>
										</div>
                                    </div>
									<div class="form-group">
										<div class="row">
											<div class="col-sm-4">
                                            	<button type="button" class="btn btn-primary" onclick="tabulation_marks_json()">Show Report</button>
											</div>
										</div>
									</div>
                                </div>
                            </form>
						</div>
						<div class="widget-content">
							<div class="table-responsive">
									
								<form class='form-horizontal' role='form'>	
								<table class="table table-striped table-bordered" cellspacing="0" width="100%">
										<thead>
											<tr>
												<th>SL #</th>
												<th>Date</th>
												<th>Voucher No</th>
												<th>Income Details</th>
												<th>Total Amount</th>
												<th>General Fund</th>
												<th>Building Fund</th>
												<th>Private Salary</th>
												<th>Debt Recovery <br/> Borrowing </th>
												<th>Gov. Salary Fund</th>
												<th>Electricity</th>
												<th>Science Fund</th>
												<th>Tiffin Fund</th>
												<th>Future Fund</th>
												<th>Sports Fund</th>
												<th>Poor Fund</th>
												<th>Paper Bill</th>
												<th>Scholarship Fund</th>
												<th>Library Fund</th>
												<th>Other Fund <br/> & <br/> Permanent Savings </th>
												<th>Exam Fund</th>
												<th>Action</th>
											</tr>
										</thead>
										<tbody>
											<tr>
												<td>1</td>
												<td></td>
												<td></td>
												<td>Primary Balance</td>
												<td>93,677</td>
												<td>43,677</td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td>50,000</td>
												<td></td>
												<td>Action</td>
											</tr>
											<tr>
												<td>2</td>
												<td>1-10-2016</td>
												<td>1001</td>
												<td>Student Fees</td>
												<td>13,700</td>
												<td>13,700</td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td>Action</td>
											</tr>
											<tr>
												<td>4</td>
												<td>2-10-2016</td>
												<td>1002</td>
												<td>Student Fees</td>
												<td>44,700</td>
												<td>44,700</td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td>Action</td>
											</tr>
											<tr>
												<td>5</td>
												<td>3-10-2016</td>
												<td>1003</td>
												<td>Gov. Salary</td>
												<td>2,68,272</td>
												<td>2,68,272</td>
												<td></td>
												<td></td>
												<td></td>
												<td>2,68,272</td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td>Action</td>
											</tr>
											<tr>
												<td></td>
												<td></td>
												<td></td>
												<td>Total Income</td>
												<td>4,20,349</td>
												<td>3,70,349</td>
												<td></td>
												<td></td>
												<td></td>
												<td>2,68,272</td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td></td>
												<td>50,000</td>
												<td></td>
												<td>Action</td>
											</tr>
										</tbody>
									</table>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php include 'application/views/includes/footer.php';?>