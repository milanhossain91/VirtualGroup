<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>      
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Credit Voucher Edit/View</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
								
								<div class="form-group" style="margin-bottom: 0px;">
									<div class="row">
									<div class="col-sm-4">
									<ul class="list-inline">
										<li><a href="<?php echo base_url();?>accounts/credit_voucher_list" class="text-muted small">Credit Voucher List</a> </li> |
										<li><a href="<?php echo base_url();?>accounts/credit_voucher_entry" class="text-muted small">Credit Voucher Create</a> </li>
									</ul>
									</div>
									
									<div class="col-sm-4"></div>
									<div class="col-sm-4" style="text-align:right;">
										<a href="<?php echo base_url();?>accounts/credit_voucher_print/<?php echo $credit_voucher_row_edit['credit_voucher_id']; ?>" class="text-muted small">
										<img width='24' border='0' style='' title='Print Credit Voucher' src='<?php echo base_url();?>template/img/pdf.png'>
										</a>
									</div>
									</div>
								</div>
								
                                <form role="form" id="detvoucherform" name="detvoucherform" method="POST" action="<?php echo base_url();?>accounts/credit_voucher_edit/<?php echo $credit_voucher_row_edit['credit_voucher_id'];?>" enctype="multipart/form-data">

									<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Voucher No:</label>
                                                <input type="text" class="form-control" name="voucher_no" id="nationality" value="<?php echo $credit_voucher_row_edit["voucher_no"];?>" readonly>
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Date:</label>
												<?php 
												$current_date = $credit_voucher_row_edit["current_date"];
												$current_dateArr=explode("-",$current_date);
												$current_date = $current_dateArr[1]."/".$current_dateArr[2]."/".$current_dateArr[0]; 
												?>
                                                <input type="text" class="form-control" name="current_date" id="current_date" value="<?php echo $current_date;?>" readonly> 
                                            </div>
                                        </div>
                                    </div>	
									
                                    <div class="form-group">
                                        <label>Pay To: <span style="color:red;">*</span> </label>
                                        <input type="text" class="form-control" name="pay_to" id="pay_to" value="<?php echo $credit_voucher_row_edit["pay_to"];?>" required>
                                    </div>
                                    
									<div class="form-group">
                                        <label>Purpose: <span style="color:red;">*</span> </label>
                                        <input type="text" class="form-control" name="purpose" id="purpose" value="<?php echo $credit_voucher_row_edit["purpose"];?>" required>
                                    </div>
									
									<div class="table-responsive">
										<table class="table table-striped table-bordered" id='area' cellspacing="0" width="100%">
											<thead>
												<tr>
													<th>SN#</th>
													<th>Particulars <span style="color:red;">*</span></th>
													<th>A/C Name</th>
													<th>Debit (Tk)</th>
													<th>Credit (Tk)</th>
												</tr>
											</thead>
											
											<tfoot>
												<tr>
													<th style="text-align:right;" colspan="3">Total Amount Tk.</th>
													<th>
														<?php echo $credit_voucher_row_edit["debit_sum"];?>
													</th>
													<th>
														<?php echo $credit_voucher_row_edit["credit_sum"];?>
														<input type='hidden' name='credit_voucher_id' value='<?php echo $credit_voucher_row_edit['credit_voucher_id']; ?>' />
													</th>
												</tr>
											</tfoot>
										
											<tbody>
													<?php
													$inc=1;
													foreach($crvoucher_bkdn_row_edit as $row2){ 
														
													?>
													<tr>
														<td style='text-align:center;' id='increment_1'><?php echo $inc; ?></td>
														<td style='text-align:left;'>
															<input type='text' name='particulars[]' value="<?php echo $row2['particulars'];?>" maxlength='50' style='text-align:left;border:none;' required />
														</td>
														
														<td style='text-align:left;'><?php echo $row2['account_code'];?></td>
														
														<td style='text-align:left;'><?php echo $row2['debit'];?></td>
														<td style='text-align:left;'><?php echo $row2['credit'];?>
															<input type='hidden' name='bkdn_id[]' value='<?php echo $row2['crvoucher_bkdn_id']; ?>' />
														</td>
													</tr>
													<?php 
													$inc++;
													} ?>
											</tbody>
										</table>
									</div>
									<br>
									<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <label>Cheque No:</label>
                                                <input type="text" class="form-control" name="cheque_no" id="cheque_no" value="<?php echo $credit_voucher_row_edit["cheque_no"];?>">
                                            </div>
                                            <div class="col-sm-4">
                                                <label>Cheque Date:</label>
												<?php 
												$cheque_dt = $credit_voucher_row_edit["cheque_dt"];
												if(!empty($cheque_dt)){
												$cheque_dtArr=explode("-",$cheque_dt);
												$cheque_dt = $cheque_dtArr[1]."/".$cheque_dtArr[2]."/".$cheque_dtArr[0]; 
												}
												else {
													$cheque_dt='';
												}
												?>
                                                <input type="text" class="form-control datepicker-input" name="cheque_dt" id="cheque_dt" value="<?php echo $cheque_dt;?>" placeholder="mm/dd/yyyy"> 
                                            </div>
											<div class="col-sm-4">
                                                <label>Bank:</label>
                                                <input type="text" class="form-control" name="bank" id="bank" value="<?php echo $credit_voucher_row_edit["bank"];?>">
                                            </div>
                                        </div>
                                    </div>
									<button type="button" class="btn btn-primary" onClick="return entry_validation(this.form)">Update</button>
								</form>
                            </div>
                        </div>
                    </div>
                </div>
				

				
<?php include 'application/views/includes/footer.php';?>

<script>
(function($){
	$(function(){
		$('#ksselect').selectToAutocomplete(); 
	});
})(jQuery);
</script>
	
<script type="text/javascript">
function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
        }
    }
    });  
}
</script>

<!--For only numeric value can be typeable-->		
<script type="text/javascript">
	var specialKeys = new Array();
	specialKeys.push(8); //Backspace
	function IsNumeric(e) {
		var keyCode = e.which ? e.which : e.keyCode
		var ret = ((keyCode >= 48 && keyCode <= 57) || specialKeys.indexOf(keyCode) != -1);
		return ret;
	}
</script>

<!--For Calculating Age---->
<script> 
function myAgeValidation() { 
    var lre = /^\s*/;
    var datemsg = "";    
    var inputDate = document.registerForm.birth_date.value;
    inputDate = inputDate.replace(lre, "");
    document.registerForm.birth_date.value = inputDate;
    datemsg = isValidDate(inputDate);
        if (datemsg != "") {
            alert(datemsg);
            return;
        }
        else {
            //Now find the Age based on the Birth Date
            getAge(new Date(inputDate));
        }
 
}
 
function getAge(birth) { 
    var today = new Date();
    var nowyear = today.getFullYear();
    var nowmonth = today.getMonth();
    var nowday = today.getDate();
 
    var birthyear = birth.getFullYear();
    var birthmonth = birth.getMonth();
    var birthday = birth.getDate();
 
    var age = nowyear - birthyear;
    var age_month = nowmonth - birthmonth;
    var age_day = nowday - birthday;
    
    if(age_month < 0 || (age_month == 0 && age_day <0)) {
            age = parseInt(age) -1;
        }		
    //alert(age);
	document.getElementById('age').value=age;	
}
 
function isValidDate(dateStr) {
    var msg = "";    
    var datePat = /^(\d{1,2})(\/|-)(\d{1,2})\2(\d{4})$/;
 
    var matchArray = dateStr.match(datePat); // is the format ok?
    if (matchArray == null) {
        msg = "Date is not in a valid format.";
        return msg;
    }
 
    month = matchArray[1]; // parse date into variables
    day = matchArray[3];
    year = matchArray[4]; 
    
    if (month < 1 || month > 12) { // check month range
        msg = "Month must be between 1 and 12.";
        return msg;
    }
 
    if (day < 1 || day > 31) {
        msg = "Day must be between 1 and 31.";
        return msg;
    }
 
    if ((month==4 || month==6 || month==9 || month==11) && day==31) {
        msg = "Month "+month+" doesn't have 31 days!";
        return msg;
    }
 
    if (month == 2) { // check for february 29th
    var isleap = (year % 4 == 0 && (year % 100 != 0 || year % 400 == 0));
    if (day>29 || (day==29 && !isleap)) {
        msg = "February " + year + " doesn't have " + day + " days!";
        return msg;
    }
    }
 
    if (day.charAt(0) == '0') day= day.charAt(1);
    return msg;  // date is valid
}
 
</script>