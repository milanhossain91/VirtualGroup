<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
				
				
            
            <div class="left-footer">
                <div class="progress progress-xs">
                  <div class="progress-bar bg-green-1" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                    <span class="progress-precentage">80%</span>
                  </div>
                  
                  <a data-toggle="tooltip" title="See task progress" class="btn btn-default md-trigger" data-modal="task-progress"><i class="fa fa-inbox"></i></a>
                </div>
            </div>
        </div>
        <!-- Left Sidebar End -->		    <!-- Right Sidebar Start -->
    
    <!-- Right Sidebar End -->		
		<!-- Start right content -->
        <div class="content-page">
			<!-- ============================================================== -->
			<!-- Start Content here -->
			<!-- ============================================================== -->
            <div class="content">
				<!-- Start info box -->
				<div class="row top-summary" style="min-height:400px;">
					<a href="">
						<div class="col-lg-3 col-md-3">
							<div class="widget green-1 animated fadeInDown">
								<div class="widget-content padding">
									<div class="text-box" style="text-align:center;">
									<br/>
									<i class="fa fa-user" style="font-size:35px;"></i>
									<br/>
										TEACHER MANAGEMENT
										<br/><br/>
										
									</div>
								</div>
								<div class="widget-footer">
									<div class="row">
										<div class="col-sm-12">
											
										</div>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
						</div>
					</a>
					
					
					
					<a href="">
						<div class="col-lg-3 col-md-3">
							<div class="widget darkblue-2 animated fadeInDown">
								<div class="widget-content padding">
									<div class="text-box" style="text-align:center;">
									<br/>
									<i class="fa fa-users" style="font-size:35px;"></i>
									<br/>
										STUDENT MANAGEMENT
										<br/><br/>
										
									</div>
								</div>
								<div class="widget-footer">
									<div class="row">
										<div class="col-sm-12">
											
										</div>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
						</div>
					</a>
					
					
					
					
					<a href="">
						<div class="col-lg-3 col-md-3">
							<div class="widget orange-4 animated fadeInDown" style="color:#fff;">
								<div class="widget-content padding">									
									<div class="text-box" style="text-align:center;">
									<br/>
									<i class="fa fa-money" style="font-size:35px;"></i>
									<br/>
										FEES MANAGEMENT
										<br/><br/>
										
									</div>
								</div>
								<div class="widget-footer">
									<div class="row">
										<div class="col-sm-12">
											
										</div>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
						</div>
					</a>
					
					
					<a href="">
						<div class="col-lg-3 col-md-3">
							<div class="widget lightblue-1 animated fadeInDown">
								<div class="widget-content padding">									
									<div class="text-box" style="text-align:center;">
									<br/>
									<i class="fa fa-pencil-square-o" style="font-size:35px;"></i>
									<br/>
										RESULT MANAGEMENT
										<br/><br/>
										
									</div>
								</div>
								<div class="widget-footer">
									<div class="row">
										<div class="col-sm-12">
											
										</div>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
						</div>
					</a>
					
					
					
					
					<a href="">
						<div class="col-lg-3 col-md-3">
							<div class="widget darkblue-2 animated fadeInDown">
								<div class="widget-content padding">
									<div class="text-box" style="text-align:center;">
									<br/>
									<i class="fa fa-calculator" style="font-size:35px;"></i>
									<br/>
										ACCOUNTS MANAGEMENT
										<br/><br/>
										
									</div>
								</div>
								<div class="widget-footer">
									<div class="row">
										<div class="col-sm-12">
											
										</div>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
						</div>
					</a>
					
					
					<a href="">
						<div class="col-lg-3 col-md-3">
							<div class="widget green-1 animated fadeInDown">
								<div class="widget-content padding">
									<div class="text-box" style="text-align:center;">
									<br/>
									<i class="fa fa-building" style="font-size:35px;"></i>
									<br/>
										LIBRARY MANAGEMENT
										<br/><br/>
										
									</div>
								</div>
								<div class="widget-footer">
									<div class="row">
										<div class="col-sm-12">
											
										</div>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
						</div>
					</a>
					
					
					
					<a href="">
						<div class="col-lg-3 col-md-3">
							<div class="widget lightblue-1 animated fadeInDown">
								<div class="widget-content padding">									
									<div class="text-box" style="text-align:center;">
									<br/>
									<i class="fa fa-shopping-cart" style="font-size:35px;"></i>
									<br/>
										INVENTORY MANAGEMENT
										<br/><br/>
										
									</div>
								</div>
								<div class="widget-footer">
									<div class="row">
										<div class="col-sm-12">
											
										</div>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
						</div>
					</a>
					
					
					
					<a href="">
						<div class="col-lg-3 col-md-3">
							<div class="widget orange-4 animated fadeInDown" style="color:#fff;">
								<div class="widget-content padding">									
									<div class="text-box" style="text-align:center;">
									<br/>
									<i class="fa fa-envelope" style="font-size:35px;"></i>
									<br/>
										SMS ALERT
										<br/><br/>
										
									</div>
								</div>
								<div class="widget-footer">
									<div class="row">
										<div class="col-sm-12">
											
										</div>
									</div>
									<div class="clearfix"></div>
								</div>
							</div>
						</div>
					</a>				
				</div>
				<!-- End of info box -->

				
				

				<?php include 'application/views/includes/footer.php';?>