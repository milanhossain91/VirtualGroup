<?php include 'application/views/includes/admin_header.php';?>
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
	<div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content">
			<div class="page-heading">
				<h1><i class='fa fa-table'></i> Credit Voucher List</h1>
			</div>       
			
			<?php if($this->session->flashdata('message')):?>
			<div class="alert alert-success">
				<a href="#" class="close" data-dismiss="alert">&times;</a>
				<?=$this->session->flashdata('message')?>
			</div>
			<?php endif?>
				
			<div class="row">					
				<div class="col-md-12">
					<div class="widget">							
						<div class="widget-content">
							<div class="form-group" style="padding-left:10px;">
								<ul class="list-inline">
									<li><a class="btn btn-info" href="<?php echo base_url();?>accounts/credit_voucher_entry" class="text-muted small"><i class="fa fa-plus" aria-hidden="true"></i>
Credit Voucher Create</a> </li>
								</ul>
							</div>					
							<div class="table-responsive">
									
								<form class='form-horizontal' role='form'>	
								<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
										<thead>
											<tr>
												<th>SL #</th>
												<th>Voucher No</th>
												<th>Date</th>
												<th>Pay To</th>
												<th>Purpose</th>
												<th>Amount</th>
												<th>Action</th>
											</tr>
										</thead>
								 
										<tfoot>
											<tr>
												<th>SL #</th>
												<th>Voucher No</th>
												<th>Date</th>
												<th>Pay To</th>
												<th>Purpose</th>
												<th>Amount</th>
												<th>Action</th>
											</tr>
										</tfoot>
								 
										<tbody>
											<?php
												foreach($credit_voucher_list as $row){
											?>
												<tr>
													<td><?php echo $row['debit_voucher_id'];?></td>
													<td><?php echo $row['voucher_no'];?></td>
													<td><?php echo $row['current_date'];?></td>
													<td><?php echo $row['pay_to'];?></td>
													<td><?php echo $row['purpose'];?></td>
													<td><?php echo $row['debit_sum'];?></td>
													<td>
														<a href="<?php echo base_url();?>accounts/credit_voucher_edit/<?php echo $row['credit_voucher_id'];?>" title="Edit"><i class="fa fa-edit"></i></a>
													</td>
												</tr>
											<?php 	} ?>
										</tbody>
									</table>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
<?php include 'application/views/includes/footer.php';?>