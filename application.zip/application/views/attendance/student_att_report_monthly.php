<button type="button" class="btn btn-default pull-right print_button" title="Print This Attendance" onclick="printPageArea('display')"><i class="fa fa-print"></i> Print</button>
<div class="clear"></div>
<div style="text-align:center;">
	<h4><b>Class : <?= $class_name; ?></b></h4>
	<h4><b>Year : <?= date('Y'); ?> &nbsp;&nbsp;&nbsp;&nbsp; Month: <?= $month_name; ?></b></h4>
</div>
<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
	<thead>
		<tr>
        	<th>SLNO</th>
            <th>Student ID</th>
            <th>Student Name</th>
            <th>Present</th>
			<th>Absent</th>
		</tr>
	</thead>
	<tbody>
		<?php $i=1; foreach($att_details as $adl): ?>
		<tr>
        	<th><?= $i ?></th>
            <td><?= $adl['student_id'] ?></td>
            <td><?= $adl['student_name'] ?></td>
            <td><?= $adl['present']; ?></td>
            <td><?= $adl['absent']; ?></td>
		</tr>
		<?php $i++; endforeach; ?>
	</tbody>
</table>