<form method="POST" action="save_student_attendance">
<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
	<thead>
		<tr>
        	<th>SLNO</th>
            <th>Student ID</th>
            <th>Student Name</th>
			<th>Class Roll</th>
            <th>Status</th>
		</tr>
	</thead>
	<tbody>
		<?php $i=1; foreach($student_details as $fdl): ?>
		<tr>
        	<th><?= $i ?></th>
            <td>
				<?= $fdl['student_id'] ?>
				<input type="hidden" name="student_id[]" value="<?= $fdl['student_id'] ?>" />
			</td>
            <td><?= $fdl['student_name'] ?></td>
            <td><?= $fdl['roll_no'] ?></td>
            <td>
				<?php if(isset($fdl['status'])): ?>
				
					<button type="button" class="btn <?php if($fdl['status']==1) {echo "btn-info";}else { echo "btn-danger";} ?>" id="status_change<?= $fdl['student_id'] ?>" onclick="change_att_status('<?= $fdl['student_id'] ?>')"><?php if($fdl['status']==1) {echo "Present";}else { echo "Absent";} ?></button>
					<input type="hidden" id="status<?= $fdl['student_id'] ?>" name="status[]" value="<?= $fdl['status'] ?>" />
					<input type="hidden" name="att_id[]" value="<?= $fdl['att_id'] ?>" />
				
				<?php else: ?>
				
					<button type="button" class="btn btn-info" id="status_change<?= $fdl['student_id'] ?>" onclick="change_att_status('<?= $fdl['student_id'] ?>')">Present</button>
					<input type="hidden" id="status<?= $fdl['student_id'] ?>" name="status[]" value="1" />
				
				<?php endif; ?>
            </td>
		</tr>
		<?php $i++; endforeach; ?>
		<tr>
			<td colspan="5"><button type="submit" class="btn btn-primary">Save</button></td>
		</tr>
	</tbody>
</table>
<input type="hidden" name="class_id" value="<?= $class_id ?>" />
<input type="hidden" name="section_id" value="<?= $section_id ?>" />
<input type="hidden" name="session_id" value="<?= $session_id ?>" />
</form>


<script>
function change_att_status(student_id)
{
	if($("#status_change"+student_id).hasClass('btn-info'))
	{
		$("#status_change"+student_id).removeClass("btn-info").addClass('btn-danger');
		$("#status"+student_id).val('0'); // absent
		$("#status_change"+student_id).text('Absent');
	}
	else
	{
		$("#status_change"+student_id).removeClass("btn-danger").addClass('btn-info');
		$("#status"+student_id).val('1');  // present
		$("#status_change"+student_id).text('Present');
	}
}

</script>