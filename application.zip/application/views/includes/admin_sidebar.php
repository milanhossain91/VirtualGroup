
    <div class="left side-menu">
        <div class="sidebar-inner slimscrollleft" style="background:#35363A;">
            <div id="sidebar-menu">
                <ul class="menu_active_class" style="display:none;">
                    <li class="web_db"><a href='<?= base_url();?>admin'><i class='fa fa-dashboard animated-hover fa-slow'></i><span>Dashboard</span></a>
                    </li>
                    <li><a href='http://virtualbd.net/' target="_blank"><i class='icon-home-3'></i><span>Visit Site</span> <span class="pull-right"></span></a>
                    </li>
           
                    <li class=''><a href='javascript:void(0);'><i class="fa fa-list"></i><span>Services</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                    <ul>
                     <li class="message">
                        <a href="<?= base_url();?>web/mechanical_support" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">Mechanical Support</span>
                        </a>
                    </li>
                     <li class="message">
                        <a href="<?= base_url();?>web/spares_stores" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">Spares stores</span>
                        </a>
                    </li>
                    <li class="message">
                        <a href="<?= base_url();?>web/equipment_rental" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">Equipment Rental</span>
                        </a>
                    </li>
                  
                  
                
            
                    <li class="about">
                            <a href="<?= base_url();?>web/service_center" title="About">
                                <i class="fa fa-file-text-o"></i>
                                <span class="hidden-xs">Service Center</span>
                            </a>
                        </li>
                    </ul>
                    </li>


                <li class=''><a href='javascript:void(0);'><i class="fa fa-list"></i><span>About us</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                    <ul>

                     <li class="message">
                        <a href="<?= base_url();?>admin/institute_information" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">Institute Information</span>
                        </a>
                    </li>

                    <li class="message">
                        <a href="<?= base_url();?>web/md_message" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">MD Message</span>
                        </a>
                    </li>

                       <li class="message">
                        <a href="<?= base_url();?>web/portfolio" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">Portfolio</span>
                        </a>
                    </li>


                     
                     <li class="message">
                        <a href="<?= base_url();?>web/products" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">Products</span>
                        </a>
                    </li>
                     <li class="message">
                        <a href="<?= base_url();?>web/csr" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">CSR</span>
                        </a>
                    </li>
                    <li class="message">
                        <a href="<?= base_url();?>web/blog" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">ONGOING PROJECT</span>
                        </a>
                    </li>
                  
                  
                
            
                    <li class="about">
                            <a href="<?= base_url();?>web/career" title="About">
                                <i class="fa fa-file-text-o"></i>
                                <span class="hidden-xs">Career</span>
                            </a>
                        </li>
                    </ul>
                    </li>

         <li class=''><a href='javascript:void(0);'><i class="fa fa-list"></i><span>Business Concerns</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                    <ul>
                     <li class="message">
                        <a href="<?= base_url();?>web/virtual_constructionltd" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">Virtual constructionltd</span>
                        </a>
                    </li>
                     <li class="message">
                        <a href="<?= base_url();?>web/virtual_ready_mix" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">Virtual Ready-Mix</span>
                        </a>
                    </li>
                    <li class="message">
                        <a href="<?= base_url();?>web/virtual_marketing_tradingco" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">Virtual Marketing & TradingCo.</span>
                        </a>
                    </li>
                  
                  
                
            
                    <li class="about">
                            <a href="<?= base_url();?>web/welcome_to_virtual_properties_ltd" title="About">
                                <i class="fa fa-file-text-o"></i>
                                <span class="hidden-xs">Welcome to Virtual Properties Ltd</span>
                            </a>
                        </li>
                    </ul>
                    </li>

                   <li class=''><a href='javascript:void(0);'><i class="fa fa-list"></i><span>Concrete Technology</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                    <ul>
                     <li class="message">
                        <a href="<?= base_url();?>web/schwing_stetter" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">Schwing Stetter</span>
                        </a>
                    </li>
                     <li class="message">
                        <a href="<?= base_url();?>web/soilmec" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">Soilmec</span>
                        </a>
                    </li>
            
                    </ul>
                    </li>

                   <li class=''><a href='javascript:void(0);'><i class="fa fa-list"></i><span>Contact Us</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                    <ul>
                     <li class="message">
                        <a href="<?= base_url();?>web/corporate_office" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">Corporate Office</span>
                        </a>
                    </li>
                     <li class="message">
                        <a href="<?= base_url();?>web/branch_office" title="Message">
                            <i class="fa fa-file-text-o"></i>
                            <span class="hidden-xs">Branch office</span>
                        </a>
                    </li>
            
                    </ul>
                    </li>




                    <li class='has_sub photos'><a href='javascript:void(0);'><i class="fa fa-picture-o"></i><span>Gallery</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <li><a href="<?= base_url();?>web/picture_gallery">Photo Gallery</a></li>
                            <li><a href="<?= base_url();?>web/catagory_list">Photo Catagory</a></li>
                            <li class="slide">
                                <a href="<?= base_url();?>web/slide" title="Slide">
                                    <i class="fa fa-picture-o"></i>
                                    <span class="hidden-xs">Slide</span>
                                </a>
                            </li>
<!-- <li>
                                <a href="<?= base_url();?>web/freedom_fighter" title="freedom_fighter">
                                    <span class="hidden-xs">Freedom Fighter</span>
                                </a>
                            </li> -->

                        </ul>
                    </li>

            <!--         <li class='has_sub teacher'><a href='javascript:void(0);'><i class='fa fa-user'></i><span>Employee Management</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <li class="tea_reg"><a href="<?= base_url();?>admin/teacher_registration"><span>Employee Registration</span></a></li>
                            <li class="tea_list"><a href="<?= base_url();?>admin/teacher_list"><span>Employee List</span></a></li>
                     
                     
                        </ul>

                    </li>-->

                

                   
                   




                  

                   <!-- <li class='has_sub sett'><a href='javascript:void(0);'><i class='fa fa-wrench'></i><span>Settings</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                        <ul>
                            <li class='has_sub gen_sett'>
                                <a href='javascript:void(0);'><span>General Settings</span> <span class="pull-right"><i class="fa fa-angle-down"></i></span></a>
                                <ul>
                                    <li><a href="<?= base_url();?>admin/institute_information"><span>Institute Information</span></a></li>
                                </ul>
                            </li>

                            
                        </ul>
                    </li>-->
                </ul>

                <div class="clearfix"></div>
            </div>
            <div class="clearfix"></div>
            <div class="clearfix"></div>
            <br>
            <br>
            <br>
        </div>