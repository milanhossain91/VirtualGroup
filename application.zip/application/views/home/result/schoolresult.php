

<?php include 'application/views/home/inc/header.php';?>
<div class="container">
   <div class="row">
      <div class="col-md-12">
         <div class="panel widget-main">
            <div class="panel-heading">
               <h1> পরীক্ষার ফলাফল </h1>
            </div>
            <div class="panel-body">
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-3 col-md-3">
                        <label>Class <span style="color:red;">*</span></label>
                        <select class="form-control" name="class_id" id="class_id" onchange="get_class_section_list(this.value); get_class_group_list(this.value);">
                           <option value="">-----Select Class-----</option>
                           <option value="1" id="6">Six</option>
                           <option value="2" id="7">Seven</option>
                           <option value="3" id="8">Eight</option>
                           <option value="4" id="9">Nine</option>
                           <option value="5" id="10">Ten</option>
                        </select>
                     </div>
                     <div class="col-sm-3 col-md-3">
                        <label>Session <span style="color:red;">*</span></label>
                        <select class="form-control" name="session_id" id="session_id" onchange="get_student_list_marksheet(this.value)">
                           <option value="">-----Select Session-----</option>
                           <option value="2">2016</option>
                           <option value="3">2017</option>
                           <option value="4">2018</option>
                           <option value="5">2019</option>
                           <option value="6">2020</option>
                           <option value="7">2021</option>
                           <option value="8">2022</option>
                           <option value="9">2023</option>
                        </select>
                     </div>
                     <div class="col-sm-3 col-md-3">
                        <label>Student ID <span style="color:red;">*</span></label>
                        <select name="student_id" required="" id="student_id" class="form-control">
                           <option value="">---- Select student ----</option>
                           <option value="1000942">1000942-Md. Monir Hossan</option>
                           <option value="1000943">1000943-Showmitro Barman</option>
                           <option value="1000944">1000944-Tanvir Ahmmed Tonmoy</option>
                           <option value="1000945">1000945-Abdulla al Mahmud Sowad</option>
                           <option value="1000946">1000946-Yousuf Jamil</option>
                           <option value="1000947">1000947-Asif Hossain</option>
                           <option value="1000948">1000948-Md. Sagar Hossain</option>
                           <option value="1000949">1000949-Md. Shohag</option>
                           <option value="1000950">1000950-Md. Seaim</option>
                           <option value="1000951">1000951-Md. Ashifur Rahman (Provas)</option>
                           <option value="1000952">1000952-Md. Mafuj Hasan</option>
                           <option value="1000953">1000953-Md. Fahad Ahmmed (Ratul)</option>
                           <option value="1000954">1000954-Rifat Islam</option>
                           <option value="1000955">1000955-Sabbir</option>
                           <option value="1000956">1000956-Habibur Rahman Mamun</option>
                        </select>
                        <div id="validation_stu" class="validation_js" style="display: none;">Please select a student.</div>
                     </div>
                     <div class="col-sm-3 col-md-3">
                        <label>Term Name <span style="color:red;">*</span></label>
                        <select class="form-control" required="" name="term_id" id="term_id" onchange="term_marks_json()">
                           <option value="">Select</option>
                           <option value="1">Mid Term (Jun-Jul)</option>
                           <option value="2">Final Term (Nov-dec)</option>
                        </select>
                     </div>
                  </div>
               </div>
               <br>
               <button class="button btn btn-info" onclick="mark_sheet_json()" type="button"> Result View </button>
               <hr>
               <div id="display">
                  <div class="table-responsive">
                     <div style="width:100%">
                        <div style="width:100% float:left; text-align: center">
                           <div style="width:15%; float:left;">
                              <img src="http://mawnamlhighschool.edu.bd/template/homeassets/images/logo.png" alt="" width="100" height="100">
                           </div>
                           <p><b style="font-size:20px;">MAWNA ML HIGH SCHOOL</b></p>
                           <p>Mawna, Mawna, Gazipur</p>
                           <p>Contact : 01706691503, 01827573636,<br> E-mail: mawnahs@gmail.com, Website: www.mawnamlhighschool.edu.bd</p>
                        </div>
                     </div>
                     <div style="height:36px; width:100%">&nbsp;</div>
                     <table id="datatables-1" class="table table-striped table-bordered" width="100%" cellspacing="0" border="1">
                        <thead>
                           <tr>
                              <td>Student ID : 1000942</td>
                              <td>Student Name : Md. Monir Hossan</td>
                              <td>Class Roll : 1</td>
                           </tr>
                           <tr>
                              <td>Group : None</td>
                              <td>Section : A</td>
                              <td>Shift : Day</td>
                           </tr>
                           <tr>
                              <td>class : Six</td>
                              <td>term : Mid Term (Jun-Jul)</td>
                              <td>Exam Year : 2017</td>
                           </tr>
                        </thead>
                     </table>
                     <br><br>
                     <table class="table table-striped table-bordered" width="100%" cellspacing="0" border="1">
                        <thead>
                           <tr>
                              <th>Subject Name</th>
                              <th>Full Marks</th>
                              <th>Pass Marks</th>
                              <th>Sub</th>
                              <th>Obj</th>
                              <th>Prac</th>
                              <th>Total</th>
                              <th>Highest Marks</th>
                              <th>G P</th>
                              <th>Grede</th>
                           </tr>
                        </thead>
                        <tbody>
                           <tr>
                              <td><b> Total </b></td>
                              <td colspan="5"></td>
                              <td>
                                 0							
                              </td>
                              <td></td>
                              <td>0.0			</td>
                              <td>F			</td>
                           </tr>
                        </tbody>
                     </table>
                     <div style="width:50%; float:left; margin-top:10px;">
                        <table class="table table-striped table-bordered" width="100%" cellspacing="0" border="1">
                           <tbody>
                              <tr>
                                 <th>Obtained GPA</th>
                                 <td>0.0</td>
                              </tr>
                              <tr>
                                 <th>Obtained Grede</th>
                                 <td>F</td>
                              </tr>
                              <tr>
                                 <th>Position in Class</th>
                                 <td>1</td>
                              </tr>
                              <tr>
                                 <th>Total Student</th>
                                 <td>0</td>
                              </tr>
                              <tr>
                                 <th>Total working Day</th>
                                 <td>0</td>
                              </tr>
                              <tr>
                                 <th>Total Present</th>
                                 <td>0</td>
                              </tr>
                           </tbody>
                        </table>
                     </div>
                     <div style="width:48%; float:right; margin-top:10px;">
                        <table class="table table-striped table-bordered" cellspacing="0" border="1">
                           <thead>
                              <tr>
                                 <th>Grade</th>
                                 <th>Marks Range</th>
                                 <th>GP</th>
                              </tr>
                           </thead>
                           <tbody>
                              <tr>
                                 <td>A+</td>
                                 <td>100% - 80%</td>
                                 <td>5</td>
                              </tr>
                              <tr>
                                 <td>A</td>
                                 <td>79% - 70%</td>
                                 <td>4</td>
                              </tr>
                              <tr>
                                 <td>A-</td>
                                 <td>69% - 60%</td>
                                 <td>3.5</td>
                              </tr>
                              <tr>
                                 <td>B</td>
                                 <td>59% - 50%</td>
                                 <td>3</td>
                              </tr>
                              <tr>
                                 <td>C</td>
                                 <td>49% - 40%</td>
                                 <td>2</td>
                              </tr>
                              <tr>
                                 <td>D</td>
                                 <td>39% - 33%</td>
                                 <td>1</td>
                              </tr>
                              <tr>
                                 <td>F</td>
                                 <td>32% - 0%</td>
                                 <td>0</td>
                              </tr>
                           </tbody>
                        </table>
                     </div>
                     <div class="print_button pull-left padding">
                        <br>
                        <input class="btn btn-primary" onclick="printPageArea('display')" value="Print This Tabulation Sheet" type="button">
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php include 'application/views/home/inc/footer.php';?>

