<?php include 'application/views/home/inc/header.php';?>
<!-- **Full-width-section - Starts** -->
<div class="full-width-section grey1">
<div class="dt-sc-margin65"></div>
<div id="main">
<!-- **Full-width-section - Starts** -->
<div class="full-width-section grey1">
   <div class="container">
      <div class="dt-sc-margin20"></div>
      <div class="hr-title">
         <h3><i class="fa fa-list" aria-hidden="true"></i> এসএসসি পরীক্ষা সংক্রান্ত তথ্য</h3>
         <div class="title-sep">
         </div>
      </div>
      <p style="font-size:28px; color:#000000;" class="aligncenter"></p>
      <div class="table-responsive">
         <table class="table table-bordered table-striped" width="100%">
            <thead>
               <tr>
                  <th colspan="8"></th>
                  <th colspan="3">জিপিএ প্রাপ্ত সংখ্যা</th>
               </tr>
               <tr>
                  <th rowspan="2">সন</th>
                  <th colspan="3"> এসএসসি পরীক্ষার্থী</th>
                  <th colspan="3"> উত্তীর্ন</th>
                  <th>পাসের হার</th>
                  <th colspan="3">জিপিএ ৫ প্রাপ্ত</th>
               </tr>
            </thead>
            <tbody>
               <tr>
                  <td></td>
                  <td>বালক</td>
                  <td>বালিকা</td>
                  <td>মোট</td>
                  <td>বালক</td>
                  <td>বালিকা</td>
                  <td>মোট</td>
                  <td></td>
                  <td>বালক</td>
                  <td>বালিকা</td>
                  <td>মোট</td>
               </tr>
               <tr>
                  <td>২০১৬</td>
                  <td>১৭১</td>
                  <td>১৬৪</td>
                  <td>৩৫৫</td>
                  <td>১৬১</td>
                  <td>১৫১</td>
                  <td>৩১২</td>
                  <td>৯৩.১৩%</td>
                  <td></td>
                  <td></td>
                  <td>২৯</td>
               </tr>
               <tr>
                  <td>২০১৫</td>
                  <td>১৬২</td>
                  <td>১৩১</td>
                  <td>২৯৩</td>
                  <td>১৪৯</td>
                  <td>১১৫</td>
                  <td>২৬৪</td>
                  <td>৯০.১০%</td>
                  <td></td>
                  <td></td>
                  <td>২১</td>
               </tr>
               <tr>
                  <td>২০১৪</td>
                  <td>১২৯</td>
                  <td>১২৩</td>
                  <td>২৫২</td>
                  <td>১২৪</td>
                  <td>১২১</td>
                  <td>২৪৫</td>
                  <td>৯৭.২২%</td>
                  <td></td>
                  <td></td>
                  <td>৫৩</td>
               </tr>
               <tr>
                  <td>২০১৩</td>
                  <td>৮৪</td>
                  <td>৮১</td>
                  <td>১৬৫</td>
                  <td>৮২</td>
                  <td>৮০</td>
                  <td>১৬২</td>
                  <td>৯৮.১৮%</td>
                  <td></td>
                  <td></td>
                  <td>১৪</td>
               </tr>
               <tr>
               <tr>
                  <td>২০১২</td>
                  <td>১০৩</td>
                  <td>৭৫</td>
                  <td>১৭৮</td>
                  <td>১০৩</td>
                  <td>৭৪</td>
                  <td>১৭৭</td>
                  <td>৯৯.৪৩%</td>
                  <td></td>
                  <td></td>
                  <td>২৬</td>
               </tr>
               <tr>
                  <td>২০১১</td>
                  <td>৫৯</td>
                  <td>৪৯</td>
                  <td>১০৮</td>
                  <td>৫৮</td>
                  <td>৪৯</td>
                  <td>১০৭</td>
                  <td>৯৯.০৭%</td>
                  <td></td>
                  <td></td>
                  <td>৩৬</td>
               </tr>
               <tr>
                  <td>২০১০</td>
                  <td>৬২</td>
                  <td>৬৯</td>
                  <td>১৩১</td>
                  <td>৫৬</td>
                  <td>৬২</td>
                  <td>১১৮</td>
                  <td>৯০.৮৪</td>
                  <td></td>
                  <td></td>
                  <td>১১</td>
               </tr>
               <tfoot></tfoot>
            </tbody>
         </table>
         <br>
      </div>
   </div>
   </div--> <!-- **Full-width-section - Ends** -->
</div>
<?php include 'application/views/home/inc/footer.php';?>

