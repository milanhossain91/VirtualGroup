<?php include 'application/views/home/inc/header.php';?>
<section id="primary" class="content-full-width grey1">     

    <div class="full-width-section">
            <div class="dt-sc-margin30"></div>

        <div class="container">
            <!-- **col-1 - Starts** -->  
                    <div class="hr-title dt-sc-hr-invisible-small">
                        <h3>সকল শিক্ষার্থীদের তথ্য</h3>
                        <div class="title-sep"> </div>
                    </div>
                     
                                           <div class="dt-sc-margin20"></div>  <div class="dt-sc-margin20"></div>
                    <form name="checkout" method="post" class="dt-sc-reservation-form" action="http://www.tmhs.edu.bd/demo/result/search_result">  
                           
                            <p class="dt-sc-one-fifth column first validate-required" id="billing_first_name_field">
                                <label class="dt-sc-margin10">Class</label>
                                                                    <select  class="country_to_state country_select" name="datax[classId]"> 
                                                                                    <option value="9"
                                                     >
                                                    ClassTen                                            </option>
                                                                                        <option value="8"
                                                     >
                                                    Class Nine                                            </option>
                                                                                        <option value="3"
                                                     >
                                                    Class Eight                                            </option>
                                                                                        <option value="2"
                                                     >
                                                    Class Seven                                            </option>
                                                                                        <option value="1"
                                                     >
                                                    Class Six                                            </option>
                                                                                </select>
                                
                            </p>

                            <p class="dt-sc-one-fifth column validate-required" id="billing_first_name_field">
                                 <label  class="dt-sc-margin10">Group &nbsp;  </label>
                                
                                     <select class="country_to_state country_select"  name="datax[groupId]">
                                                                                                                    <option value="4"
                                                                         >
                                                                            General                                                                </option>
                                                                                                
                                    </select>

                            </p> 
                            <p class="dt-sc-one-fifth column validate-required" id="billing_first_name_field">
                                <label class="dt-sc-margin10">Session </label>
                                  <select class="country_to_state country_select" class="large" name="datax[sessionId]">
                                                                                    <option value="2"
                                                     >
                                                    2016                                            </option>
                                                                                        <option value="1"
                                                     >
                                                    2015                                            </option>
                                                                                </select>
                            </p> 
                          
                        
                            <p class="dt-sc-one-fifth column validate-required" id="billing_first_name_field">
                               
                                <label class="dt-sc-margin10">&nbsp;&nbsp; </label>
                                <input type="submit" value="Search Student" name="searchBtnclass" /> 
                            </p>
                          
                       
                    </form>            

                    <div class="dt-sc-margin50"></div>

                    
                        <div class="woocommerce">
                                         
                                <div class="column  dt-sc-one-half first" data-animation="fadeInUp" data-delay="100">
                                      <!-- **events - Starts** -->
                                         <table >
                                             <tbody>
                                                <tr class="cart-subtotal">
                                                    <td><strong>Class : </strong> &nbsp;
                                                        <span>

                                                                                                                    </span>

                                                    </td>
                                                    <td>
                                                          <strong>Group :</strong> &nbsp;
                                                          <span>
                                                                                                                    </span>
                                                    </td>
                                                   
                                                </tr>                                                
                                                                                            
                                            </tbody>
                                         </table>
                                    
                                    </div> <!-- **column - Ends** --> 
                                    <div class="column  dt-sc-one-half" data-animation="fadeInUp" data-delay="100">
                                      <!-- **events - Starts** -->
                                         <table >
                                             <tbody>
                                                <tr class="cart-subtotal">                                                  
                                                    <td>
                                                      <strong>Session :</strong> &nbsp;
                                                          <span>
                                                                                                                    </span>
                                                    </td>
                                                </tr>
                                                
                                                                                            
                                            </tbody>
                                         </table>
                                    
                                    </div> <!-- **column - Ends** -->   
                                  
                       </div>   
                     <div>
                     <div id="order_review">
                        <table>
                            <thead>
                                <tr>
                                    <th>#SL</th>
                                    <th class="product-thumbnail">Image</th>
                                    <th class="product-price">Section</th>
                                    <th class="product-price">Student ID</th>
                                    <th class="product-price">Class Roll</th>
                                    <th class="product-price">Student Name</th>
                                    <th class="product-price">Father</th>
                                    <th class="product-price">Mother</th>           
                                </tr>
                            </thead>
                            <tbody>
                                                             
                            </tbody>
                        </table>
                      </div>
                  </div>
                 
                 </div>   
                  <div class="dt-sc-margin30"></div>
         </div> 
                        
    
   </section>         <!-- **Footer** -->
<?php include 'application/views/home/inc/footer.php';?>
    