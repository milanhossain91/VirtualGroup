<?php include 'application/views/home/inc/header.php';?>
 <!-- **Full-width-section - Starts** -->       
            <div class="full-width-section grey1">
                <div class="container">
                <div class="dt-sc-margin50"></div> 
                <div class="row"><div class="col-md-8">
                    <div class="panel">
                    <div class="panel-heading " style="text-align:center"><h1 class="">প্রতিষ্ঠাতা ও জমি দাতা</h1>
                    <hr></div>      
                    <div class="panel-body">
                    <div class="" style="">
                            <img class="img-thumbnail center-block" src="<?= base_url() ?>template/assets/images/founder.jpg">
                            <br>
                            <div class="clearfix"></div>
                        </div>
                        
                   <table class="table">
                       <thead>
                           <tr>
                               <th><h2>মরহুম পিয়ার আলী মাদবর</h2></th>
                           </tr>
                       </thead>
                       <tbody>
                           <tr>
                               <td>পিতাঃ মরহুম শহর আলী মাদবর</td>
                           </tr>
                           <tr>
                               <td>মাতাঃ মরহুমা সাহাজান বিবি</td>
                           </tr>
                           <tr>
                               <td>জন্মঃ ১৮৬৩ খ্রিস্টাব্দ</td>
                           </tr>
                           <tr>
                               <td>মৃতঃ ২৬ আগষ্ট ১৯৭০খ্রিস্টাব্দ</td>
                           </tr>
                       </tbody>
                   </table>
                                        
                                       
                   
                        

<table class="table">

    <thead>
        <tr>
            <th><h3>মরহুম পিয়ার আলী মাদবর কর্তৃক প্রতিষ্ঠিত শিক্ষা ও ধর্মীয় প্রতিষ্ঠানসমূহঃ</h3></th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td>মাওনা বহমুখী উচ্চ বিদ্যালয়</td>
        </tr>
        <tr>
            <td>মাওনা জে.এম. সরকারী প্রাথমিক বিদ্যালয়</td>
        </tr>
        <tr>
            <td>মাওনা বাজার কেন্দ্রীয় জামে মসজিদ</td>
        </tr>
        <tr>
            <td>মাওনা পিয়ার আলী সরাই খানা</td>
        </tr>
        <tr>
            <td>মাওনা পিয়ার আলী ঈদগাহ ময়দান</td>
        </tr>
        <tr>
            <td>মাওনা পিয়ার আলী সরাই খানা</td>
        </tr>
        <tr>
            <td>মাওনা পিয়ার আলী বিশ্ব বিদ্যালয় কলেজ (তাঁর উত্তরসূরীগন কর্তৃক প্রতিষ্ঠিত)।</td>
        </tr>
    </tbody>
</table>




                    </div>
                </div>  
                </div><div class="col-md-4"><div class="column">
            <h5 class="widgettitle"> <i class="fa fa-tags"></i> <strong>নোটিশ</strong>  </h5>
            <div class="dt-sc-team type3">
               <aside class="widget widget_product_categories">
                  <ul class="demo1">
                     <marquee id="" face="courier" behavior="SCROLL" height="" onmouseout="this.setAttribute('scrollamount', 2, 0);" onmouseover="this.setAttribute('scrollamount', 0, 0);" scrollamount="2" direction="up" style="text-align: left;">
                        <li class="news-item">
                           <a href="#" data-toggle="modal" data-target="#myModal" onclick="">২৬-০১-২০১৭ ইং তারিখে মিলাদ মাহফিল ও বিদায় অনুষ্ঠান ।</a>
                        </li>
                     </marquee>
                  </ul>
               </aside>
            </div>
            <!-- **dt-sc-team - Ends** -->
         </div></div></div>
                    
                                 
                                                               
                               
                                             </div>
            </div> <!-- **Full-width-section - Ends** --> 
               


<?php include 'application/views/home/inc/footer.php';?>
    