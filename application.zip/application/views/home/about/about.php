<?php include 'application/views/home/inc/header.php';?>
<!-- **Full-width-section - Starts** -->       
<div class="full-width-section grey1">
<div class="container">
   <div class="dt-sc-margin50"></div>
   <div class="row">
      <div class="col-md-12">
         <h2><span><strong>প্রতিষ্ঠান</strong> পরিচিতি</span></h2>
         <div class="panel">
            <div class="page-heading"></div>
            <div class="panel-body" >
               <div class="about-img">
                  <img width="250px;"  style="margin:20px;" class="img-responsive img-thumbnail" src="<?= base_url();?>upload/about_image/<?= $about[0]['about_image'];?>">
               </div>
               <div class="about-con">
                
                  <p class="text-center"><strong>
                         <?= $about[0]['about_details'] ?>
                     </strong></p>
                 
               </div>
               <strong>
                  <!-- /.widget-inner -->
               </strong>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- **Full-width-section - Ends** --> 
<?php include 'application/views/home/inc/footer.php';?>

