
<?php include 'application/views/home/inc/header.php';?>
<!-- **Full-width-section - Starts** -->       
<div class="full-width-section grey1">
  <div class="container">
    <div class="dt-sc-margin50"></div>
    <div class="hr-title dt-sc-hr-invisible-small">
      <h3> ভূমি সম্পর্কিত তথ্য </h3>
      <div class="title-sep"> </div>
    </div>
<table class="table table-striped">
    <thead>
      <tr>
      <th>ক্রমিক নং</th>
        <th>ভূমির পরিমান</th>
        <!--th>Lastname</th>
        <th>Email</th-->
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>০১</td>
        <td>৩.৪৩ একর</td>
        
      </tr>
      
    </tbody>
  </table>
  </div>
</div>
<!-- **Full-width-section - Ends** --> 
<?php include 'application/views/home/inc/footer.php';?>

