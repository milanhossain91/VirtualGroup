<?php include 'application/views/home/inc/header.php';?>

  <!-- Primary Starts -->
          <section id="primary" class="content-full-width grey1">
   <div class="container">
      <div class="dt-sc-margin20"></div>
      <div class="dt-sc-margin20"></div>
      <div class="column dt-sc-one-third first">
         <div class="dt-sc-margin50"></div>
         <div class="dt-sc-contact-info type2">
            <div class="dt-sc-contact-detail">
               <h4><i class="fa fa-address-book" aria-hidden="true"></i>ঠিকানা</h4>
               <p>
                                                         ডাকঘর - ফুটকিবাড়ি, উপজেলা - পঞ্চগড় সদর, জেলা - পঞ্চগড়
               </p>
            </div>
            <div class="contact-icon">
               <p><span class="fa fa-phone"></span> ০১৭২৪৩৯৪৫৭৯, ০১৭১৩৭০৮৬৬৯</p>
            </div>
            <div class="contact-icon">
               <p><span class="fa fa-envelope"></span> 
                  <a href="mailto:kapasia@gmail.com">info@futkibaridegreecollege.edu.bd</a>.<br>
               </p>
            </div>
            <div class="contact-icon">
               <p><span class="fa fa-globe"></span> <a href="../index.html">www.futkibaridegreecollege.edu.bd</a></p>
            </div>
         </div>
      </div>
      <div class="column dt-sc-two-third">
         <div class="hr-title dt-sc-hr-invisible-small curl">
            <h3>Write Your Message</h3>
            <div class="title-sep">
            </div>
         </div>
         <form method="post" class="dt-sc-contact-form" action="#" >
            <div class="column dt-sc-one-third first">
               <p> <span> <input type="text" placeholder="Name*" name="data[p_name]" value="" required /> </span> </p>
            </div>
            <div class="column dt-sc-one-third">
               <p> <span> <input type="email" placeholder="Email*" name="data[p_email]" value="" required /> </span> </p>
            </div>
            <div class="column dt-sc-one-third">
               <p> <span> <input type="text" placeholder="Phone*" name="data[p_phone]" required value="" /> </span> </p>
            </div>
            <p> <textarea placeholder="Write Your Message" value="" placeholder="" name="data[p_text]" required ></textarea> </p>
            <p> <input type="submit" class="btn btn-info" value="Send" name="submit" /> </p>
         </form>
         <div id="ajax_contact_msg"></div>
      </div>
   </div>
   <div class="dt-sc-margin20"></div>
   <div class="">
      <div class="container">
         <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d114358.54086883961!2d88.55246261308402!3d26.400735999796858!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39e48834d40ff959%3A0x38a6e20ce7d572a2!2sPanchagarh+Sadar+Upazila!5e0!3m2!1sen!2sbd!4v1510425455445" width="1170" height="450" frameborder="0" style="border:0" allowfullscreen></iframe> 
      </div>
   </div>
</section>
       
<?php include 'application/views/home/inc/footer.php';?>

    