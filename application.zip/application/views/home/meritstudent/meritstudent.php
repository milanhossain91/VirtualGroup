<?php include 'application/views/home/inc/header.php';?>
<!-- **container - Starts** -->
<div class="container">
   <div class="dt-sc-margin50"></div>
   <h2 class="text-center">বিভিন্ন পরীক্ষায় ঊর্ত্তীর্ণ কৃতি শিক্ষার্থীদের তালিকা</h2>
   <section id="primary" class="">
      <!-- **woocommerce - Starts** --> 
      <div class="container">
         <table class="table table-condensed">
            <thead>
               <tr>
                  <th class="">ছবি</th>
                  <th class="">শিক্ষার্থীর নাম </th>
                  <th class="">শ্রেণি</th>
                  <th class="">পরীক্ষার নাম</th>
                  <th class="">গ্রেড</th>
                  <th class="">সেশন</th>
               </tr>
            </thead>
            <tbody>
               <tr class = "">
   
                  <td class="">
                     <img class=""  src="" width="70" alt="image"/> 
                  </td>
          
                  <td class="">
                     <span class=""></span>
                  </td>
            
                  <td class="">
                                       
                  </td>
                  <!-- Quantity inputs -->
                  <td class="">
 
                  </td>
                  <!-- Product subtotal -->
                  <td class="">
                     A+                                        
                  </td>
                  <!-- Remove from cart link -->
                  <td class="">
                                     
                  </td>
               </tr>
            </tbody>
         </table>
      </div>
   </section>
</div>
<div class="dt-sc-margin50"></div>
<?php include 'application/views/home/inc/footer.php';?>

