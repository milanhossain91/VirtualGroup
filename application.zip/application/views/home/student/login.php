<?php include 'application/views/home/inc/header.php';?>
<div class="wrapper"> 
    <div class="inner-wrapper">  
        <!-- **Main - Starts** --> 
        <div id="main">
            
            <div class="dt-sc-margin30"></div>    
            <!-- Primary Starts -->
            <section id="primary" class="content-full-width">
                
                <div class="full-width-section parallax full-section-bg">
                    <div class="container">
                        <h4 style="color: red">
						<?php if($this->session->flashdata('message')):?>
			
				<?=$this->session->flashdata('message')?>
			
			<?php endif?>
						</h4>
                        <h4 style="color:green"></h4>
                        <div class="page_info aligncenter">
                            <div class="page_info"> 
                                <h3 class="aligncenter"> <span> <i class="fa fa-user"></i></span>
                                  Student/Parents Login </h3>
                            </div>
                        </div>                         
                        <div class="form-wrapper_login login">
                            <form class="mws-form" action="<?= base_url() ?>home/guardian_panle_login_check" method="post">
                                <div class="mws-form-row">
                                    <div class="mws-form-item">
									<input type="text" autocomplete='off' class="mws-login-username required" name="student_id" placeholder="ছাত্র / ছাত্রী আইডি">
                                    </div>
                                </div>
                                <div class="mws-form-row">
                                    <div class="mws-form-item">
									<input type="password" class="mws-login-password required" name="password" placeholder="পাসওয়ার্ড">
                                    </div>
                                </div>
                                
                                <div class="mws-form-row">
                                    <div class="page_info"> 
                                        <input type="submit" value="Login" class="btn btn-success mws-login-button">
                                    </div>
                                </div>
                            </form>  
                        </div>
                        <div class="dt-sc-margin70"></div>

                    </div>
                </div>
              
                
            </section>  
        
        </div> <!-- **Main - Ends** --> 
        
        
        
    </div><!-- **inner-wrapper - End** -->
    
</div><!-- **Wrapper - End** -->
        
<?php include 'application/views/home/inc/footer.php';?>

