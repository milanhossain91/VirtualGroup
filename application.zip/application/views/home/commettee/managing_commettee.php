<?php include 'application/views/home/inc/header.php';?> 
<!-- **Full-width-section - Starts** -->
<div class="full-width-section grey1">
   <div class="dt-sc-margin65"></div>
   <div class="container">
      <p style="font-size:28px; color:#000000;" class="aligncenter">ম্যানেজিং কমিটির সদস্য </p>
   
      <div class="dt-sc-hr-invisible-small"></div>
      <!-- **portfolio-container - Starts** -->
      <div class="portfolio-container with-space">


      <table class="table table-hover table-dark">
              <thead>
                <tr>
                  <th scope="col">SL</th>
                  <th scope="col">Name</th>
                  <th scope="col">Designation</th>
                  <th scope="col">Photo</th>
                </tr>
              </thead>
              <tbody>
              <?php $i=1; foreach($member_list as $member){ ?>
                <tr>
                  <th scope="row"><?php echo $i;?></th>
                  <td><?= $member['member_name']?></td>
                  <td><?= $member['member_desig']?></td>
                  <td> 
                  <img class="lazy" data-original="<?= base_url() ?>upload/managing_committee/<?= $member['member_image']?>" src="<?= base_url() ?>upload/managing_committee/<?= $member['member_image']?>" width="100" height="100" alt="<?= $member['member_name']?>"/>
                          
                       
                  </td>
                </tr>
             <?php $i++; } ?> 
               
              </tbody>
            </table>

            		 
		 
		 
		 
		 
		 
		 
         </div>
         </div>  
      </div>
  

<!-- **Full-width-section - Ends** -->
<?php include 'application/views/home/inc/footer.php';?>

