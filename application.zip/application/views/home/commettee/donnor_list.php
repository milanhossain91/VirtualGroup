<?php include 'application/views/home/inc/header.php';?>
<div class="container">
<div class="panel widget-main">
            		<div class="panel-heading text-center" style="">
            		<h1>আজীবন দাতা সদস্যদের নামের তালিকা</h1>
            		</div>	 	
            		<div class="panel-body">						
						<table class="table table-striped table-hover">
						    <thead>
								<tr>
									<th>সদস্যদের নাম</th>
									<th>ফোন নম্বর</th>
									<th>ঠিকানা</th>
								</tr>
						    </thead>
						    <tbody>
						    <?php foreach($donor_list as $sl){ ?>
								<tr>
								<td><?= $sl['donnor_name'];?></td>
								<td><?= $sl['donnor_phone'];?></td>
								<td><?= $sl['donnor_address'];?></td>
								</tr>
								<?php 	} ?>			
						    </tbody>
					  	</table>
					</div>
				</div></div>
<?php include 'application/views/home/inc/footer.php';?>