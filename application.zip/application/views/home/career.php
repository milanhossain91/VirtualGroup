<?php include 'application/views/home/inc/header.php';?>
<?php include 'pending.php';?>

<?php include 'application/views/home/inc/footer.php';?>