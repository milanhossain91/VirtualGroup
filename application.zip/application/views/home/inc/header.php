<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  
  <title>Virtual Group || Bangladesh Construction</title>
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <meta name="google-site-verification" content="A4eZLgUoKwWGZcwdj0DaTya9uDA2Xvv9--JYoD9cyUQ" />
  <meta name="description" content="VIRTUAL developed a business of manufacturing of RMC by using a factory based production, with that spirit VIRTUAL started business with GBB Limited.We conduct our Business openly, with honesty, integrity and trust. We respect human rights in all our activities. We provide a safe and secure working environment. We are committed to operating with a consistent set of values that represent the highest standards of quality, integrity, excellence, compliance with the law. VIRTUAL is committed to full compliance with all applicable health, environmental and safety laws and regulations. We expect our employees to share this commitment. In the form of Corporate Social Responsibility (CSR) VIRTUAL tries to serve the victim people and saving the environment.In 2009, Concrete Technology was employed as an authorized Dealer of a Global Brand on Concrete Equipment namely Schwing Stetter India Pvt. Ltd. to market their product in Bangladesh. Now Concrete Technology is a respectable name to the Concrete Equipments users.Concrete Technology was employed by Soilmec Foundation Equipments India Pvt. Ltd. in 2012 for Hydraulic Rotary Rig Concrete Technology has an expert marketing team to handle Global Machinery Brands ">
  <meta name="Keywords" content="virtual, virtualgroup, virtualbangladesh, virtualbd, groupvirtaul, ConcreteTechnology, PharmaSolution, virtual PharmaSolution, virtalConcreteTechnology, CSR, Construction Industry of Bangladesh, ConcreteTechnologybangladesh, schwingstetterbanladesh, schwingstetterindia, soilmecbanladesh, soilmecindia, bangladeshvirtual, bangladeshvirtualgroup, groupvirtual, Virtual Group, construction company in bangladesh, Virtual, Concrete Technology, Virtual Bangladesh" />
            <!-- favicon links -->

  <!-- main stylesheet -->
  <link rel="stylesheet" href="<?= base_url() ?>template/assets/css/style.css">
  <!-- responsive stylesheet -->
  <link rel="stylesheet" href="<?= base_url() ?>template/assets/css/responsive.css">
  <link rel="shortcut icon" href="<?php echo base_url();?>upload/logo/vf.png">


  <!--[if lt IE 9]>
    <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
  <![endif]-->
  <!--[if lt IE 9]>
    <script src="js/respond.js"></script>
  <![endif]-->

</head>
<body>
  


  <!-- #topbar -->
  <section id="topbar" class="construct">
    <div class="container">
      <div class="row">
        <div class="social pull-right">
          <ul>
            <li><a href="#"><i class="fa fa-facebook-square"></i></a></li>
            <li><a href="#"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#"><i class="fa fa-pinterest"></i></a></li>
            <li><a href="#"><i class="fa fa-skype"></i></a></li>
            <li><a href="#"><i class="fa fa-dribbble"></i></a></li>
          </ul>
        </div> <!-- /.social -->
        <div class="contact-info pull-left">
          <ul>
           
            <li><a href="<?= $school_info['email'];?>"><i class="fa fa-envelope"></i><?= $school_info['email'];?></a></li>
            <li><a href="<?= $school_info['contact_no'];?>"><i class="fa fa-phone"></i><?= $school_info['contact_no'];?></a></li>
          </ul>
        </div> <!-- /.contact-info -->
      </div>
    </div>
  </section> <!-- /#topbar -->

  <!-- header -->
  <header class="construct header-curvy">

    <div class="container">
      <div class="clearfix">
        <div class="pull-left logo">
          <a href="<?= base_url();?>">
            <img src="<?php echo base_url();?>upload/institute_logo/<?= $school_info['logo'];?>" alt="<?php echo base_url();?>upload/institute_logo/<?= $school_info['logo'];?>" height="75" width="100">
          </a>
        </div>
        <nav class="pull-right mainmenu-container clearfix">
   
          <button class="mainmenu-toggler">
            <i class="fa fa-bars"></i>
          </button>
          <ul class="mainmenu pull-right">
           
            <li><a href="<?= base_url(); ?>">Home</a></li>
                      
            <li class="dropdown">
              <a href="#">About us</a>
              <ul class="submenu">
                <li><a href="http://virtualbd.net/virtualgroupprofile.pdf" target="_blank">Company Profile</a></li>
                <li><a href="<?= base_url(); ?>home/corporate_office">Corporate Office</a></li>
                <li><a href="<?= base_url(); ?>home/branch_office">Branch office</a></li>
                 <!-- <li><a href="<?= base_url(); ?>home/portfolio">portfolio</a></li>
                                 <li><a href="<?= base_url(); ?>home/csr">CSR</a></li> -->
                <li><a href="<?= base_url(); ?>home/blog">Onging Project</a></li>
                <li><a href="<?= base_url(); ?>home/products">products</a></li>
                <li><a href="<?= base_url(); ?>home/career">Career</a></li>
                 <li><a href="<?= base_url(); ?>home/md_message">MD Message</a></li>
               
              </ul>
            </li>
            <li>
              <a href="http://ct.virtualbd.net/" target="_blank">Concrete Technology</a>
         
            </li>
              <li>
              <a href="http://vps.virtualbd.net/" target="_blank">Pharma Solution</a>
         
            </li>
            <li class="dropdown"><a href="#">Business Concerns</a>
              <ul class="submenu">
                <li><a href="<?= base_url(); ?>home/virtual_constructionltd">Constructionltd</a></li>
                <li><a href="<?= base_url(); ?>home/virtual_ready_mix">Ready-Mix</a></li>
                <li><a href="<?= base_url(); ?>home/virtual_marketing_tradingco">Marketing TradingCo.</a></li>
                <li><a href="<?= base_url(); ?>home/welcome_to_virtual_properties_ltd">Properties Ltd</a></li>
                
              </ul>
            </li>
  
            <li class="dropdown">
              <a href="#">Services</a>
              <ul class="submenu">
                <li><a href="<?= base_url(); ?>home/mechanical_support">Mechanical Support</a></li>
                <li><a href="<?= base_url(); ?>home/spares_stores">Spares stores</a></li>
                <li><a href="<?= base_url(); ?>home/equipment_rental">Equipment Rental</a></li>
                <li><a href="<?= base_url(); ?>home/service_center">Service Center</a></li>
              </ul>
            </li>
            <li><a href="https://mail.yandex.com/" target="_blank">Web-Mail</a></li>
          </ul>
        </nav>
      </div>
    </div>
  </header> <!-- /header -->