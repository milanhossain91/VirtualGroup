   <section id="great-construct-team">
    <div class="container">
      <div class="row">
        <div class="col-lg-6">
          <h2>OUR PARTNERS</h2>
         
             <a href="<?= base_url();?>home/schwing_stetter"><img src="<?= base_url();?>/upload/client/p1.png" alt="schwing-stetter" heigh="80"></a> 
            
              <a href="<?= base_url();?>home/soilmec"><img src="<?= base_url();?>/upload/client/p2.png" alt="soilmec" heigh="80"></a>
            
        </div>
      </div>
    </div>
  </section>


  <footer class="construct">
    <div class="container">
      <div class="row">
        <!-- .widget -->
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 widget">
          <img class="positioned wow slideInUp " src="<?= base_url();?>upload/imge/1.png" alt="">
        </div> <!-- /.widget -->
        <!-- .widget -->
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 widget">
          <h3 style="text-align: justify; color:#fff;">About Us</h3>
          <p style="text-align: justify; color:#fff;">Virtual Group is formed by a bunch of talented Engineers, professional and associates. Â Virtual Group is proud of its associates and employees works that are working for the company for its growth. Virtual Group has commenced its venture on the October 2003 by its Parent Company Concrete Technology. </p>
         
          <ul class="social">
            <li><a href="#" class="hvr-radial-out"><i class="fa fa-facebook"></i></a></li>
            <li><a href="#" class="hvr-radial-out"><i class="fa fa-twitter"></i></a></li>
            <li><a href="#" class="hvr-radial-out"><i class="fa fa-google-plus"></i></a></li>
            <li><a href="#" class="hvr-radial-out"><i class="fa fa-linkedin"></i></a></li>
          </ul>
        </div> <!-- /.widget -->
        <!-- .widget -->
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 widget clearboth-tab clearboth-480">
          <h3 style="text-align: justify; color:#fff;">COMPANY LINKS</h3>
          <ul class="our-services">
            <li><a style="text-align: justify; color:#fff;" href="<?= base_url(); ?>home/virtual_constructionltd">Virtual construction ltd</a></li>
            <li><a style="text-align: justify; color:#fff;" href="<?= base_url(); ?>home/virtual_ready_mix">Virtual Ready-Mix</a></li>
            <li><a style="text-align: justify; color:#fff;" href="<?= base_url(); ?>home/virtual_marketing_tradingco">Virtual Marketing & Trading Co.</a></li>
            <li><a style="text-align: justify; color:#fff;" href="<?= base_url(); ?>home/welcome_to_virtual_properties_ltd">Virtual Properties Ltd</a></li>
            <li><a style="text-align: justify; color:#fff;" href="<?= base_url(); ?>home/schwing_stetter">Schwing Stetter</a></li>
            <li><a style="text-align: justify; color:#fff;" href="<?= base_url(); ?>home/soilmec">Soilmec</a></li>
          </ul>
        </div> <!-- /.widget -->
        <!-- .widget -->
        <div class="col-lg-3 col-md-3 col-sm-6 col-xs-6 widget">
          <h3 style="text-align: justify; color:#fff;">Get in Touch</h3>
          <ul class="contact-info">
            <li><i class="fa fa-map-marker"></i> <span style="color:#fff;" class="text"><?= $school_info['address'];?></span></li>
            <li><i class="fa fa-phone"></i> <span style="color:#fff;" class="text"><?= $school_info['contact_no'];?></span></li>
            <li><i class="fa fa-envelope-o"></i> <span style="color:#fff;" class="text"><?= $school_info['email'];?></span></li>
            <li><i class="fa fa-globe"></i> <span style="color:#fff;" class="text"><?= $school_info['website'];?></span></li>
          </ul>
        </div> <!-- /.widget -->
        
      </div>
    </div>
  </footer> <!-- /footer -->
  
  <!-- #bottom-bar -->
  <section id="bottom-bar" class="construct">
    <div class="container">
      <div class="row">
        <!-- .copyright -->
        <div class="copyright pull-left">
          <p>Copyright &copy; Virtual Group <?php echo date('Y');?>. All rights reserved. </p>
        </div> <!-- /.copyright -->
        <!-- .credit -->
        <div class="copyright pull-right">
        <a href="https://www.facebook.com/taibur.rahman.56"><p>Design and Development by : Taibur Rahman Milon</p></a>
        </div> <!-- /.credit -->
      </div>
    </div> 
  </section><!-- /#bottom-bar -->


  
  <script src="<?= base_url() ?>template/assets/js/jquery-1.11.3.min.js"></script> <!-- jQuery JS -->
  <script src="<?= base_url() ?>template/assets/js/bootstrap.min.js"></script> <!-- BootStrap JS -->
  <script src="<?= base_url() ?>template/assets/js/wow.js"></script> <!-- WOW JS -->
  <script src="<?= base_url() ?>template/assets/js/isotope.pkgd.min.js"></script> <!-- iSotope JS -->
  <script src="<?= base_url() ?>template/assets/js/owl.carousel.min.js"></script> <!-- OWL Carousle JS -->
  <script src="<?= base_url() ?>template/assets/js/revolution-slider/jquery.themepunch.tools.min.js"></script> <!-- Revolution Slider Tools -->
  <script src="<?= base_url() ?>template/assets/js/revolution-slider/jquery.themepunch.revolution.min.js"></script> <!-- Revolution Slider -->
  <script type="text/javascript" src="<?= base_url() ?>template/assets/js/revolution-slider/extensions/revolution.extension.actions.min.js"></script>
  <script type="text/javascript" src="<?= base_url() ?>template/assets/js/revolution-slider/extensions/revolution.extension.carousel.min.js"></script>
  <script type="text/javascript" src="<?= base_url() ?>template/assets/js/revolution-slider/extensions/revolution.extension.kenburn.min.js"></script>
  <script type="text/javascript" src="<?= base_url() ?>template/assets/js/revolution-slider/extensions/revolution.extension.layeranimation.min.js"></script>
  <script type="text/javascript" src="<?= base_url() ?>template/assets/js/revolution-slider/extensions/revolution.extension.migration.min.js"></script>
  <script type="text/javascript" src="<?= base_url() ?>template/assets/js/revolution-slider/extensions/revolution.extension.navigation.min.js"></script>
  <script type="text/javascript" src="<?= base_url() ?>template/assets/js/revolution-slider/extensions/revolution.extension.parallax.min.js"></script>
  <script type="text/javascript" src="<?= base_url() ?>template/assets/js/revolution-slider/extensions/revolution.extension.slideanims.min.js"></script>
  <script type="text/javascript" src="<?= base_url() ?>template/assets/js/revolution-slider/extensions/revolution.extension.video.min.js"></script>
  <script src="<?= base_url() ?>template/assets/js/jquery.fancybox.pack.js"></script> <!-- FancyBox -->
  <script src="<?= base_url() ?>template/assets/js/validate.js"></script> <!-- Form Validator JS -->
  <script src="<?= base_url() ?>template/assets/js/jquery.easing.min.js"></script> <!-- jquery easing JS -->
  <script src="<?= base_url() ?>template/assets/js/jquery.mixitup.min.js"></script> <!-- MixIt UP JS -->
  <script src="<?= base_url() ?>template/assets/js/custom.js"></script> <!-- Custom JS -->



</body>
</html>