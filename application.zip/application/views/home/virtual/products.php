<?php include 'application/views/home/inc/header.php';?>
 <section id="page-title">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<!-- .title -->
					<div class="title pull-left">
						<h1>Products</h1>
					</div> <!-- /.title -->
					<!-- .page-breadcumb -->
					<div class="page-breadcumb pull-right">
						<i class="fa fa-home"></i> <a href="<?= base_url();?>">Home</a> <i class="fa fa-angle-right"></i> <span>Products</span>
					</div> <!-- /.page-breadcumb -->
				</div>
			</div>
		</div>
	</section> <!-- /#page-title -->

 <section id="project-version-one" class="construct home">
    <div class="container">
    <div class="container-fluid">
      <div class="row">
        <div class="col-lg-12">
          <ul class="gallery-filter">
            <li data-filter="all">
              <span>All</span>
            </li>
            <?php foreach($catagory_list as $cat_name){ ?>
            <li data-filter=".<?= $cat_name['catagory_id']?>">
              <span><?= $cat_name['catagory_name']?></span>
            </li>
            <?php } ?>
          </ul>
        </div>
      </div>
      <div class="row normal-gallery gallery-v4" id="image-gallery-mix">

       <?php foreach($photo_gallery as $images){ ?>
        <div class="single-project-item mix  tank <?= $images['catagory_id']?>">
          <div class="img-wrap">
            <img src="<?= base_url() ?>upload/photo_gallery/<?= $images['gallery_image_name']?>" alt="<?= $images['photo_caption']?>">
            <div class="content-wrapper hvr-sweep-to-right">
              <div class="content">
                <div class="button-box">
                  <a class="fancybox" data-fancybox-group="home-gallery" title="<?= $images['photo_caption']?>" href="<?= base_url() ?>upload/photo_gallery/<?= $images['gallery_image_name']?>"><i class="fa fa-search-plus"></i></a>
                </div>
              
              </div>
            </div>
          </div>
        </div>
       <?php } ?>
      </div>
      
    </div>
  </section>  

<?php include 'application/views/home/inc/footer.php';?>