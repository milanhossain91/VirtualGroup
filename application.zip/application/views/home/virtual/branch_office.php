<?php include 'application/views/home/inc/header.php';?>

	<section id="page-title">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<!-- .title -->
					<div class="title pull-left">
						<h1>Branch Office</h1>
					</div> <!-- /.title -->
					<!-- .page-breadcumb -->
					<div class="page-breadcumb pull-right">
						<i class="fa fa-home"></i> <a href="index-2.html">Home</a> <i class="fa fa-angle-right"></i> <span>Branch Office</span>
					</div> <!-- /.page-breadcumb -->
				</div>
			</div>
		</div>
	</section> <!-- /#page-title -->
	
	<!-- #contact-content -->
	<section id="contact-content">
		<div class="container">
			<div class="row">
				
				<div class="col-md-12">
					<div class="section-title">
						<h1>Feel Free to Drop Us A Line To Contact Us</h1>
						<p>You can talk to our online representative at any time. Please use our Live Chat System on our website or Fill up below instant messaging programs. <br>Please be patient, We will get back to you. Our 24/7 Support, General Inquireies Phone: + 8801686768207</p>
					</div>
				</div>
				<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 ">
					<form action="#" class="contact-form">
						<p><input type="text" name="name" placeholder="Name"></p>
						<p><input type="text" name="email" placeholder="Email"></p>
						<p><input type="text" name="subject" placeholder="Subject"></p>
						<p><textarea name="message" placeholder="Message"></textarea></p>
						<p><button type="submit">Submit Now</button></p>
					</form>
				</div>
				<div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 contact-info">
					<ul>
						<li>
							<div class="icon-box">
								<i class="fa fa-map-marker"></i>
							</div>
							<div class="text-box">
								<p><b>Agargaon Office : </b> Darul Yusuf Apartment Bhaban 102/1, West Agargaon (1st Floor) Sher-E-Banglanagar, Dhaka-1207  <br> 
								
								<b>Chittagong Office : </b> Ananna Abashik Quaish, Chittagong.

</p>
							</div>
						</li>
						<li>
							<div class="icon-box">
								<i class="fa fa-envelope-o"></i>
							</div>
							<div class="text-box">
								<p>alamin.vcl@virtualbd.net, tarek.vcl@virtualbd.net </p>
							</div>
						</li>
						<li>
							<div class="icon-box">
								<i class="fa fa-phone"></i>
							</div>
							<div class="text-box">
								<p> +08801614099906, +8801686768207, +8801716382297</p>
							</div>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</section> <!-- /#contact-content -->

<iframe src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d14604.313215276123!2d90.367231!3d23.7802258!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0xbe02e9ff1dce2dfd!2sVirtual%20Group!5e0!3m2!1sbn!2sbd!4v1588235550430!5m2!1sbn!2sbd" width="100%" height="500" frameborder="0" style="border:1;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>

<?php include 'application/views/home/inc/footer.php';?>