<?php include 'application/views/home/inc/header.php';?>

 <section id="page-title">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<!-- .title -->
					<div class="title pull-left">
						<h1>Virtual Properties Ltd</h1>
					</div> <!-- /.title -->
					<!-- .page-breadcumb -->
					<div class="page-breadcumb pull-right">
						<i class="fa fa-home"></i> <a href="<?= base_url();?>">Home</a> <i class="fa fa-angle-right"></i> <span>Virtual Properties Ltd</span>
					</div> <!-- /.page-breadcumb -->
				</div>
			</div>
		</div>
	</section> <!-- /#page-title -->
	


		<section id="blog-post">
		<div class="container">
			<div class="row">

				<!-- .blog-content -->
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 blog-content">
					<?php foreach($welcome_to_virtual_properties_ltd as $welcome_to_virtual_properties_ltds){ ?>
					<article>
					<!-- 	<div class="img-holder">
						<img src="<?= base_url() ?>upload/virtual_properties_ltd/<?= $welcome_to_virtual_properties_ltds['image']?>" alt="<?= $welcome_to_virtual_properties_ltds['title']?>">
						
					</div>
					<h2><?= $welcome_to_virtual_properties_ltds['title']?></h2> -->
						
						<?= $welcome_to_virtual_properties_ltds['content']?>
						
					</article>
			
					<?php } ?>

				</div> <!-- /.blog-content -->

		<div class="row normal-gallery two-col-gallery" id="image-gallery-mix">
 
            <a href="<?= base_url() ?>template/images/properties/1.jpg" class="fancybox">
                <div class="col-lg-4 col-sm-4 col-xs-12 plumbing  single-project-item hvr-float-shadow mix" style="padding: 20px;">
                    <div class="img-wrap">
                        <div class="overlay"><img src="<?= base_url() ?>template/images/properties/1.jpg" height="250" alt="VIRTUAL CONSTRUCTION LTD"></div>
                    </div>
                    
                </div>
            </a>

            <a href="<?= base_url() ?>template/images/properties/2.png" class="fancybox">
                <div class="col-lg-4 col-sm-4 col-xs-12 plumbing  single-project-item hvr-float-shadow mix" style="padding: 20px;">
                    <div class="img-wrap">
                        <div class="overlay"><img src="<?= base_url() ?>template/images/properties/2.png" height="250" alt="VIRTUAL CONSTRUCTION LTD"></div>
                    </div>
                    
                </div>
            </a>

           <a href="<?= base_url() ?>template/images/properties/3.png" class="fancybox">
                <div class="col-lg-4 col-sm-4 col-xs-12 plumbing  single-project-item hvr-float-shadow mix" style="padding: 20px;">
                    <div class="img-wrap">
                        <div class="overlay"><img src="<?= base_url() ?>template/images/properties/3.png" height="250" alt="VIRTUAL CONSTRUCTION LTD"></div>
                    </div>
                    
                </div>
            </a>

       <br>
              <a href="<?= base_url() ?>template/images/properties/4.jpg" class="fancybox">
                <div class="col-lg-4 col-sm-4 col-xs-12 plumbing  single-project-item hvr-float-shadow mix" style="padding: 20px;">
                    <div class="img-wrap">
                        <div class="overlay"><img src="<?= base_url() ?>template/images/properties/4.jpg" height="250" alt="VIRTUAL CONSTRUCTION LTD"></div>
                    </div>
                    
                </div>
            </a>

            <a href="<?= base_url() ?>template/images/properties/5.jpg" class="fancybox">
                <div class="col-lg-4 col-sm-4 col-xs-12 plumbing  single-project-item hvr-float-shadow mix" style="padding: 20px;">
                    <div class="img-wrap">
                        <div class="overlay"><img src="<?= base_url() ?>template/images/properties/5.jpg" height="250" alt="VIRTUAL CONSTRUCTION LTD"></div>
                    </div>
                    
                </div>
            </a>

           <a href="<?= base_url() ?>template/images/properties/6.jpg" class="fancybox">
                <div class="col-lg-4 col-sm-4 col-xs-12 plumbing  single-project-item hvr-float-shadow mix" style="padding: 20px;">
                    <div class="img-wrap">
                        <div class="overlay"><img src="<?= base_url() ?>template/images/properties/6.jpg" height="250" alt="VIRTUAL CONSTRUCTION LTD"></div>
                    </div>
                    
                </div>
            </a>

        </div>

				<!-- .sidebar -->

			</div>
		</div>
	</section> <!-- /#blog-post -->

<?php include 'application/views/home/inc/footer.php';?>