<?php include 'application/views/home/inc/header.php';?>

 <section id="page-title">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<!-- .title -->
					<div class="title pull-left">
						<h1>Virtual Construction Ltd</h1>
					</div> <!-- /.title -->
					<!-- .page-breadcumb -->
					<div class="page-breadcumb pull-right">
						<i class="fa fa-home"></i> <a href="index-2.html">Home</a> <i class="fa fa-angle-right"></i> <span>Virtual Construction Ltd</span>
					</div> <!-- /.page-breadcumb -->
				</div>
			</div>
		</div>
	</section> <!-- /#page-title -->
	
	<!-- #blog-post -->
	<section id="blog-post">
		<div class="container">
			<div class="row">

				<!-- .blog-content -->
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 blog-content">
				<?php foreach($virtual_constructionltd as $virtual_constructionltds){ ?>
					<article>
					<!-- 	<div class="img-holder">
						<img src="<?= base_url() ?>upload/virtual_constructionltd/<?= $virtual_constructionltds['image']?>" alt="<?= $virtual_constructionltds['title']?>">
						
					</div> -->
						<!-- <h2><?= $virtual_constructionltds['title']?></h2> -->
						
						<?= $virtual_constructionltds['content']?>
						
					</article>
			
					<?php } ?>
			

				</div> <!-- /.blog-content -->

		<div class="row normal-gallery two-col-gallery" id="image-gallery-mix">
 
            <a href="<?= base_url() ?>template/images/v_constration/1.png" class="fancybox">
                <div class="col-lg-3 col-sm-3 col-xs-12 plumbing  single-project-item hvr-float-shadow mix">
                    <div class="img-wrap">
                        <div class="overlay"><img src="<?= base_url() ?>template/images/v_constration/1.png" height="200" alt="VIRTUAL CONSTRUCTION LTD"></div>
                    </div>
                    
                </div>
            </a>
            <a href="<?= base_url() ?>template/images/v_constration/2.png" class="fancybox">
                <div class="col-lg-3 col-sm-3 col-xs-12  kitchen  single-project-item hvr-float-shadow mix">
                    <div class="img-wrap">
                        <div class="overlay"><img src="<?= base_url() ?>template/images/v_constration/2.png" height="200" alt="VIRTUAL CONSTRUCTION LTD"></div>
                    </div>
                   
                </div>
            </a>
            <a href="<?= base_url() ?>template/images/v_constration/3.jpg" class="fancybox">
                <div class="col-lg-3 col-sm-3 col-xs-12  outside  bathroom single-project-item hvr-float-shadow mix">
                    <div class="img-wrap">
                        <div class="overlay"><img src="<?= base_url() ?>template/images/v_constration/3.jpg" height="200" alt="VIRTUAL CONSTRUCTION LTD"></div>
                    </div>
                  
                </div>
            </a>
            <a href="<?= base_url() ?>template/images/v_constration/4.jpg" class="fancybox">
                <div class="col-lg-3 col-sm-3 col-xs-12  drain  single-project-item hvr-float-shadow mix">
                    <div class="img-wrap">
                        <div class="overlay"><img src="<?= base_url() ?>template/images/v_constration/4.jpg" height="200" alt="VIRTUAL CONSTRUCTION LTD"></div>
                    </div>
                   
                </div>
            </a>
            
        </div>

				<!-- .sidebar -->

			</div>
		</div>
	</section> <!-- /#blog-post -->

<?php include 'application/views/home/inc/footer.php';?>