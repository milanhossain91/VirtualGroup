<?php include 'application/views/home/inc/header.php';?>

	<section id="page-title">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<!-- .title -->
					<div class="title pull-left">
						<h1>Managing Director Message</h1>
					</div> <!-- /.title -->
					<!-- .page-breadcumb -->
					<div class="page-breadcumb pull-right">
						<i class="fa fa-home"></i> <a href="index-2.html">Home</a> <i class="fa fa-angle-right"></i> <span>Managing Director Message</span>
					</div> <!-- /.page-breadcumb -->
				</div>
			</div>
		</div>
	</section> <!-- /#page-title -->

	 <section id="construction-welcome">
    <div class="container">
      <div class="row">
      <?php foreach($md_message as $md_messages){ ?>
        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 single-construction-welcome">
          <div class="img-holder hvr-rectangle-out">
          <img src="<?= base_url() ?>upload/md_message/<?= $md_messages['image']?>" alt="<?= $md_messages['title']?>" height="260" width="260">
          
          </div>
          <h2><?= $md_messages['title'];?></h2>
          <h4>Managing Director Virtual Group</h4>
          

        
          
        </div>
       
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 single-construction-welcome">


          <div class="accrodion-wrap">
            <div class="accrodion clearfix active">
      
              <div class="accrodion-content" style="display: block;">
                <p><?= $md_messages['content']; ?></p>
              </div>
            </div>

    
        

       
          </div>
        </div>

         <?php } ?>

 


    </div>
  </section>

	



<?php include 'application/views/home/inc/footer.php';?>