<?php include 'application/views/home/inc/header.php';?>

 <section id="page-title">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<!-- .title -->
					<div class="title pull-left">
						<h1>Virtual Marketing TradingCo.</h1>
					</div> <!-- /.title -->
					<!-- .page-breadcumb -->
					<div class="page-breadcumb pull-right">
						<i class="fa fa-home"></i> <a href="index-2.html">Home</a> <i class="fa fa-angle-right"></i> <span>Virtual Marketing TradingCo.</span>
					</div> <!-- /.page-breadcumb -->
				</div>
			</div>
		</div>
	</section> <!-- /#page-title -->
	
	<!-- #blog-post -->

		<section id="blog-post">
		<div class="container">
			<div class="row">

				<!-- .blog-content -->
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 blog-content">
					<?php foreach($virtual_marketing_tradingco as $virtual_marketing_tradingcos){ ?>
					<article>
					<!-- 	<div class="img-holder">
						<img src="<?= base_url() ?>upload/virtual_marketing_tradingco/<?= $virtual_marketing_tradingcos['image']?>" alt="<?= $virtual_marketing_tradingcos['title']?>">
						
					</div>
					<h2><?= $virtual_marketing_tradingcos['title']?></h2> -->
						
						<?= $virtual_marketing_tradingcos['content']?>
						
					</article>
			
					<?php } ?>
			

				</div> <!-- /.blog-content -->

		<div class="row normal-gallery two-col-gallery" id="image-gallery-mix">
 
            <a href="<?= base_url() ?>template/images/marketing/1.jpg" class="fancybox">
                <div class="col-lg-3 col-sm-3 col-xs-12 plumbing  single-project-item hvr-float-shadow mix">
                    <div class="img-wrap">
                        <div class="overlay"><img src="<?= base_url() ?>template/images/marketing/1.jpg" height="200" alt="VIRTUAL CONSTRUCTION LTD"></div>
                    </div>
                    
                </div>
            </a>
            <a href="<?= base_url() ?>template/images/marketing/4.jpg" class="fancybox">
                <div class="col-lg-3 col-sm-3 col-xs-12  kitchen  single-project-item hvr-float-shadow mix">
                    <div class="img-wrap">
                        <div class="overlay"><img src="<?= base_url() ?>template/images/marketing/4.jpg" height="200" alt="VIRTUAL CONSTRUCTION LTD"></div>
                    </div>
                   
                </div>
            </a>
            <a href="<?= base_url() ?>template/images/marketing/3.jpg" class="fancybox">
                <div class="col-lg-3 col-sm-3 col-xs-12  outside  bathroom single-project-item hvr-float-shadow mix">
                    <div class="img-wrap">
                        <div class="overlay"><img src="<?= base_url() ?>template/images/marketing/3.jpg" height="200" alt="VIRTUAL CONSTRUCTION LTD"></div>
                    </div>
                  
                </div>
            </a>
            <a href="<?= base_url() ?>template/images/marketing/2.jpg" class="fancybox">
                <div class="col-lg-3 col-sm-3 col-xs-12  drain  single-project-item hvr-float-shadow mix">
                    <div class="img-wrap">
                        <div class="overlay"><img src="<?= base_url() ?>template/images/marketing/2.jpg" height="200" alt="VIRTUAL CONSTRUCTION LTD"></div>
                    </div>
                   
                </div>
            </a>
            
        </div>

				<!-- .sidebar -->

			</div>
		</div>
	</section> <!-- /#blog-post -->

<?php include 'application/views/home/inc/footer.php';?>