<?php include 'application/views/home/inc/header.php';?>

 <section id="page-title">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<!-- .title -->
					<div class="title pull-left">
						<h1>Equipment Rental</h1>
					</div> <!-- /.title -->
					<!-- .page-breadcumb -->
					<div class="page-breadcumb pull-right">
						<i class="fa fa-home"></i> <a href="<?= base_url();?>">Home</a> <i class="fa fa-angle-right"></i> <span>Equipment Rental</span>
					</div> <!-- /.page-breadcumb -->
				</div>
			</div>
		</div>
	</section> <!-- /#page-title -->
	
	<!-- #blog-post -->
	<section id="blog-post">
		<div class="container">
			<div class="row">

				<!-- .blog-content -->
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 blog-content">
				<?php foreach($equipment_rental as $equipment_rentals){ ?>
					<article>
						<div class="img-holder">
							<img src="<?= base_url() ?>upload/equipment_rental/<?= $equipment_rentals['image']?>" alt="<?= $equipment_rentals['title']?>">
							
						</div>
						<h2><?= $equipment_rentals['title']?></h2>
						
						<?= $equipment_rentals['content']?>
						
					</article>
			
					<?php } ?>
			

				</div> <!-- /.blog-content -->

				<!-- .sidebar -->

			</div>
		</div>
	</section> <!-- /#blog-post -->

<?php include 'application/views/home/inc/footer.php';?>