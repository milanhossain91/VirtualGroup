<?php include 'application/views/home/inc/header.php';?>

 <section id="page-title">
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<!-- .title -->
					<div class="title pull-left">
						<h1>Portfolio</h1>
					</div> <!-- /.title -->
					<!-- .page-breadcumb -->
					<div class="page-breadcumb pull-right">
						<i class="fa fa-home"></i> <a href="index-2.html">Home</a> <i class="fa fa-angle-right"></i> <span>Portfolio</span>
					</div> <!-- /.page-breadcumb -->
				</div>
			</div>
		</div>
	</section> <!-- /#page-title -->
	
	<!-- #blog-post -->
	<section id="blog-post">
		<div class="container">
			<div class="row">

				<!-- .blog-content -->
				<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 blog-content">
				<?php foreach($portfolio as $portfolios){ ?>
					<article>
						<div class="img-holder">
							<img src="<?= base_url() ?>upload/portfolio/<?= $portfolios['image']?>" alt="<?= $portfolios['title']?>">
							
						</div>
						<h2><?= $portfolios['title']?></h2>
						
						<?= $portfolios['content']?>
						
					</article>
			
					<?php } ?>
			

				</div> <!-- /.blog-content -->

				<!-- .sidebar -->

			</div>
		</div>
	</section> <!-- /#blog-post -->

<?php include 'application/views/home/inc/footer.php';?>