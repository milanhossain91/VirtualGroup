<?php include 'application/views/home/inc/header.php';?>
     
  <section class="rev_slider_wrapper construct-banner-wrapper">
    <div id="slider1" class="rev_slider"  data-version="5.0">
      <ul>

      <?php foreach($slide_image as $img){ ?>
        <li data-transition="fade">
          <img src="<?= base_url();?>upload/slides/<?= $img['slide_image_name'];?>"  alt="<?= $img['slide_caption'];?>" data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">


              <div class="tp-caption sfb tp-resizeme construct-banner-caption" 
                data-x="left" data-hoffset="270" 
                data-y="top" data-voffset="255" 
                data-whitespace="nowrap"
                data-transform_idle="o:1;" 
                data-transform_in="o:0" 
                data-transform_out="o:0" 
                data-start="500">
            <h2 style="text-align: center;"><b>Welcome to Virtual Group</b></h2>
            </div>
          <div class="tp-caption sfb tp-resizeme construct-banner-caption" 
                data-x="left" data-hoffset="150" 
                data-y="top" data-voffset="335" 
                data-whitespace="nowrap"
                data-transform_idle="o:1;" 
                data-transform_in="o:0" 
                data-transform_out="o:0" 
                data-start="1000">
            <h2 style="text-align: center;"><?= $img['slide_caption'];?></h2>
            </div>

 
          <div class="tp-caption sfb tp-resizeme construct-banner-caption" 
                data-x="left" data-hoffset="490" 
                data-y="top" data-voffset="440" 
                data-whitespace="nowrap"
                data-transform_idle="o:1;" 
                data-transform_in="o:0" 
                data-transform_out="o:0" 
                data-start="2500">
            <a href="<?php echo base_url();?>home/virtual_constructionltd" style="text-align: center;" class="hvr-bounce-to-right">Learn More</a>
            </div>
        </li>

 <?php   } ?>
      </ul>
    </div>
  </section>

    <section id="service-we-provide">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 single-construction-welcome">


          <div class="accrodion-wrap">
            <div class="accrodion clearfix active">
              <div class="accrodion-header">
                <h4>About Virtual Group</h4>
                <div class="expander minus"></div>
              </div>
              <div class="accrodion-content" style="display: block;">
                <p>VIRTUAL GROUP was founded with a vision of working for modulization in the country.  
                VIRTUAL GROUP is formed by a Bunch of talented Engineers, Professional and associated. Virtual Is proud of its associates and employees who are working for the Company for its growth. Virtual has commenced its venture on the October 2003 by its parent Company Concrete Technology. The Primary Objective was to Introduce Modern Technology in Construction Industry of Bangladesh.  It was our utmost try to provide honest service for Construction works and to the customer. With the spirit of modern construction works the company got the opportunity to work with so many Global construction companies namely Lersen and Toubro, SHIMUJI and OBAYSHI Corporation. On the way of journey, we started work as an authorized dealer of Global Brand Schwing Stetter, Soilmec and SPARTAN Engineering Industries Pvt. dealership for marketing their products in Bangladesh. 
                In 2010 we also formed VIRTUAL Construction Ltd. to serve construction industry of the country. Concrete is a imperative material for construction, primarily we started Concrete manufacturing business in Dhaka city in the Brand namely VIRTUAL RMC to serve the customer in Dhaka and around Dhaka. We have extended our RMC Business to Chittagong city to serve the users by supplying quality concrete. 
                In 2020 we launched our new venture namely " Virtual Pharma solution " under a team consist of renowned Scientists, Pharmacists, and Engineers to solve this prevailing crisis of the health sector. Virtual Pharma Solution will contribute to the country's health sectors with the equipment "Made in Bangladesh ".
                 Our motto is to contribute the nation by introducing modern and new technologies in the Construction, Pharma, Medical & Laboratory industry of Bangladesh and to develop skill and unskilled manpower of this country. Moreover, we are trying to Developed a Corporate Company which will serve this Nation and Globe Generation by Generation.
                </p>
              </div>
            </div>

        </div>

 


    </div>
  </section>


  <section id="construction-welcome">
    <div class="container">
      <div class="row">
      <?php foreach($md_message as $md_messages){ ?>
        <div class="col-lg-4 col-md-4 col-sm-6 col-xs-12 single-construction-welcome">
          <div class="img-holder hvr-rectangle-out">
          <img src="<?= base_url() ?>upload/md_message/<?= $md_messages['image']?>" alt="<?= $md_messages['title']?>" height="160" width="160">
          
          </div>
          <h2><?= $md_messages['title'];?></h2>
          <h4>Managing Director Virtual Group</h4>
            <?php

                 $string = $md_messages['content']; echo substr($string, 0, 85);
                  ?>
          <a href="<?= base_url(); ?>home/md_message" class="read-more"> Read More <i class="fa fa-angle-double-right"></i></a>
        
          
        </div>
        <?php } ?>
        <div class="col-lg-8 col-md-8 col-sm-8 col-xs-12 single-construction-welcome">


          <div class="accrodion-wrap">
            <div class="accrodion clearfix active">
              <div class="accrodion-header">
                <h4>Ethics and Values</h4>
                <div class="expander minus"></div>
              </div>
              <div class="accrodion-content" style="display: block;">
                <p>We conduct our Business openly, with honesty, integrity and trust. We respect human rights in all our activities. We provide a safe and secure working environment. We are committed to operating with a consistent set of values that represent the highest standards of quality, integrity, excellence, compliance with the law. VIRTUAL is committed to full compliance with all applicable health, environmental and safety laws and regulations. We expect our employees to share this commitment. In the form of Corporate Social Responsibility (CSR) VIRTUAL tries to serve the victim people and saving the environment.</p>
              </div>
            </div>
            <div class="accrodion clearfix">
              <div class="accrodion-header">
                <h4>Why Us?</h4>
                <div class="expander plus"></div>
              </div>
              <div class="accrodion-content">
                <p>In 2009, Concrete Technology was employed as an authorized Dealer of a Global Brand on Concrete Equipment namely Schwing Stetter India Pvt. Ltd. to market their product in Bangladesh. Now Concrete Technology is a respectable name to the Concrete Equipments users.Concrete Technology was employed by Soilmec Foundation Equipments India Pvt. Ltd. in 2012 for Hydraulic Rotary Rig Concrete Technology has an expert marketing team to handle Global Machinery Brands </p>
            </div>
    
        

       
          </div>
        </div>

 


    </div>
  </section>





  <!-- #service-we-provide -->
  <section id="service-we-provide" class="construct">
    <div class="container">
      <div class="section-title">
        <h1>Services that we offers</h1>
      </div>
      <div class="row">
        <div class="col-lg-3 col-md-3 wow slideInLeft">
          <div class="service-tab-title">
            <ul class="clearfix">
              <li class="active" data-tab-name="construction">constructionltd</li>
              <li data-tab-name="renovation">Ready-Mix</li>
              <li data-tab-name="interior">Marketing TradingCo.</li>
              <li data-tab-name="isolatoin">Properties Ltd</li>
              
            </ul>
          </div>
        </div>
        <div class="col-lg-9 col-md-9 wow slideInRight">
          <div class="row">
            <div class="service-tab-content clearfix">

            <?php foreach($virtual_constructionltd as $virtual_constructionltds){ ?>
              <div id="construction">
                <div class="col-md-8 col-sm-8">

                 <?php

                 $string = $virtual_constructionltds['content']; echo substr($string, 0, 380);
                  ?>
                <div class="view-all-btn text-center" style="padding:20px;"><a href="<?= base_url(); ?>home/virtual_constructionltd" class="virtualbtncolor btn btn-warning">View All Project</a></div>
                </div>
                <div class="col-md-4 col-sm-4">
                  <img src="<?= base_url() ?>upload/virtual_constructionltd/<?= $virtual_constructionltds['image']?>" alt="<?= $virtual_constructionltds['title']?>">
                </div>

              </div>
            <?php } ?>

            <?php foreach($virtual_ready_mix as $virtual_ready_mixs){ ?>
              <div id="renovation">
                <div class="col-md-8 col-sm-8">
                   <?php

                 $string = $virtual_ready_mixs['content']; echo substr($string, 0, 350);
                  ?>
                  <div class="view-all-btn text-center" style="padding:20px;"><a href="<?= base_url(); ?>home/virtual_ready_mix" class="virtualbtncolor btn btn-warning">View All Project</a></div>
              
                </div>
                <div class="col-md-4 col-sm-4">
                  <img src="<?= base_url() ?>upload/virtual_ready_mix/<?= $virtual_ready_mixs['image']?>" alt="<?= $virtual_ready_mixs['title']?>">
                </div>
              </div>
            <?php } ?>

             <?php foreach($virtual_marketing_tradingco as $virtual_marketing_tradingcos){ ?>
              <div id="interior">
                <div class="col-md-8 col-sm-8">
                        <?php

                 $string = $virtual_marketing_tradingcos['content']; echo substr($string, 0, 350);
                  ?>
              <div class="view-all-btn text-center" style="padding:20px;"><a href="<?= base_url(); ?>home/virtual_marketing_tradingco" class="virtualbtncolor btn btn-warning">View All Project</a></div>
                </div>
                <div class="col-md-4 col-sm-4">
                  <img src="<?= base_url() ?>upload/virtual_marketing_tradingco/<?= $virtual_marketing_tradingcos['image']?>" alt="<?= $virtual_marketing_tradingcos['title']?>">
                </div>
              </div>
            <?php } ?>

             <?php foreach($welcome_to_virtual_properties_ltd as $welcome_to_virtual_properties_ltds){ ?>
              <div id="isolatoin">
                <div class="col-md-8 col-sm-8">
                  <?php

                 $string = $welcome_to_virtual_properties_ltds['content']; echo substr($string, 0, 350);
                  ?>
                
               <div class="view-all-btn text-center" style="padding:20px;"><a href="<?= base_url(); ?>home/welcome_to_virtual_properties_ltd" class="virtualbtncolor btn btn-warning">View All Project</a></div>
              
                </div>
                 <div class="col-md-4 col-sm-4">
                  <img src="<?= base_url() ?>upload/virtual_properties_ltd/<?= $welcome_to_virtual_properties_ltds['image']?>" alt="<?= $welcome_to_virtual_properties_ltds['title']?>">
                </div>
              </div>
            <?php } ?>

             
            </div>
          </div>
        </div>
      </div>
    </div>
  </section> <!-- /#service-we-provide -->





  <section id="project-version-one" class="construct home">
    <div class="container">
      <div class="section-title">
        <h1>our latest CSR</h1>
      </div>
    </div>
    <div class="container-fluid">

      <div class="row normal-gallery gallery-v4" id="image-gallery-mix">

       <?php foreach($photo_gallery as $images){ ?>
        <div class="single-project-item mix  tank <?= $images['catagory_id']?>">
          <div class="img-wrap">
            <img src="<?= base_url() ?>upload/photo_gallery/<?= $images['gallery_image_name']?>" alt="<?= $images['photo_caption']?>">
            <div class="content-wrapper hvr-sweep-to-right">
              <div class="content">
                <div class="button-box">
                  <a class="fancybox" data-fancybox-group="home-gallery" title="<?= $images['photo_caption']?>" href="<?= base_url() ?>upload/photo_gallery/<?= $images['gallery_image_name']?>"><i class="fa fa-search-plus"></i></a>
                </div>
              
              </div>
            </div>
          </div>
        </div>
       <?php } ?>
      </div>
      <div class="view-all-btn text-center"><a href="<?= base_url();?>home/portfolio" class="virtualbtncolor view-all hvr-bounce-to-right">view all</a></div>
    </div>
  </section>  

    <section id="welcome-to-construct">
    <div class="container">
      <div class="row">
        <div class="col-lg-5 col-md-5 col-sm-12 col-xs-12">
          <div class="img-holder hvr-rectangle-out pull-right">
            <img src="<?= base_url();?>template/img/photo.jpg" alt="">
          </div>
        </div>
        <div class="col-lg-7 col-md-7 col-sm-12 col-xs-12">
          
          <h3>We are available for 24/7 for you requirements</h3>
          <div class="list-box clearfix">
            <ul>
              <li><i class="fa fa-hand-o-right"></i> COMPLETE SAFETY ANALYSIS</li>
              <li><i class="fa fa-hand-o-right"></i> DRIVABILITY PROBLEMS</li>
            </ul>
            <ul>
              <li><i class="fa fa-hand-o-right"></i> COMPLETE SAFETY ANALYSIS</li>
              <li><i class="fa fa-hand-o-right"></i> DRIVABILITY PROBLEMS</li>
            </ul>
          </div>
        </div>        
      </div>
    </div>
  </section>




  <section id="blog-construct">
    <div class="container">
      <div class="section-title">
        <h1>ONGOING PROJECT</h1>
      </div>
      <div class="row">


      <?php foreach($blog as $blogs){ ?>
        <div class="col-lg-4 col-md-4 col-sm-4 col-xs-12 single-blog-post">
          <div class="img-holder hvr-rectangle-out">
            <img src="<?= base_url() ?>upload/blog/<?= $blogs['image']?>" alt="<?= $blogs['title']?>">
            <div class="date">
             <?= $blogs['date']?>
            </div>
          </div>
          <a href="<?= base_url(); ?>home/blog"><h2><?= $blogs['title']?></h2></a>
          <?php

        $string = $blogs['content'];

        // Starts at the beginning of the string and ends after 100 characters 
        echo substr($string, 0, 150);

        ?> 

         
        </div>
      <?php } ?>
      </div>
      <div class="view-all-btn text-center" style="margin-top:30px; padding:10px;"><a href="<?= base_url(); ?>home/blog" class="virtualbtncolor btn btn-warning">View All Project</a></div>
    </div>

  </section>


  <section id="our-team-construct">
    <div class="container">
        <div class="section-title">
            <h1>SOME OF OUR PROJECTS</h1>
        </div>
        <div class="owl-carousel owl-theme">
            <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/1.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/1.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
            <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/2.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/2.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/3.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/3.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
            <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/4.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/4.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/5.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/5.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
            <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/6.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/6.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

                    <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/7.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/7.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
            <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/8.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/8.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

                    <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/9.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/9.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
            <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/10.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/10.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

                    <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/11.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/11.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
            <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/12.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/12.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                    <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/13.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/13.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
            <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/14.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/14.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                    <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/15.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/15.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
            <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/16.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/16.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                    <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/17.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/17.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
            <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/18.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/18.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                    <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/19.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/19.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
            <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/20.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/20.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                    <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/21.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/21.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
            <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/22.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/22.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                    <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/23.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/23.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
            <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/24.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/24.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                    <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/25.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/25.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
         
            <div class="item">
                <div class="single-project-item mix kitchen drain bathroom">
                    <div class="img-wrap">
                        <img src="<?= base_url() ?>template/images/pro/26.png" height="200" alt="Interior Design package">
                        <div class="content-wrapper hvr-sweep-to-right">
                            <div class="content">
                                <div class="button-box">
                                    <a class="fancybox" data-fancybox-group="home-gallery" title="Interior Design package" href="<?= base_url() ?>template/images/pro/26.png" height="200"><i class="fa fa-search-plus"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</section>


  <!-- #clients -->
  <section id="clients" class="construct">
    <div class="container">
      <div class="section-title">
        <h1>We worked with awesome clients</h1>
      </div>
      <div class="row">
        <div class="col-lg-12 col-md-12">
          <div class="owl-carousel owl-theme">
            <div class="item">
              <img src="<?= base_url();?>/upload/client/1.png" alt="">
            </div>
            <div class="item">
              <img src="<?= base_url();?>/upload/client/2.jpg" alt="">
            </div>
            <div class="item">
              <img src="<?= base_url();?>/upload/client/3.jpg" alt="">
            </div>
            <div class="item">
              <img src="<?= base_url();?>/upload/client/4.jpg" alt="">
            </div>
            <div class="item">
              <img src="<?= base_url();?>/upload/client/5.jpg" alt="">
            </div>
            <div class="item">
              <img src="<?= base_url();?>/upload/client/6.png" alt="">
            </div>
            <div class="item">
              <img src="<?= base_url();?>/upload/client/7.jpg" alt="">
            </div>
            <div class="item">
              <img src="<?= base_url();?>/upload/client/8.png" alt="">
            </div>
            <div class="item">
              <img src="<?= base_url();?>/upload/client/9.jpg" alt="">
            </div>
          </div>
        </div>
      </div>
    </div>
  </section> <!-- /#clients -->





<!-- **Main - Ends** --> <!-- **Main - Ends** --> 
<!-- **dt-sc-team - Starts** -->
<?php include 'application/views/home/inc/footer.php';?>

