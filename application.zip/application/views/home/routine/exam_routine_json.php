<table border="1" class="table table-striped table-bordered" style="text-align:center;">
	<thead >
    	<tr style="border-top:1px;">
        	<th style="min-width:125px;">Exam Date</th>
            <th style="min-width:125px;">Exam Day</th>
            	<?php  foreach($exam_time as $et){ ?>
    		<th style="min-width:125px;"><span ><?= $et['exam_time'];?></span>
            	<input type="hidden" class="class_time" value="<?= $et['id'] ?>" />
            </th>  
                  <?php }?>
        </tr>
    </thead>
    <tbody>
    	<?php for($s=0; $s<count($subject); $s++){ ?>
        <tr>
            <td class="date<?= $s ?>" id="d<?= $s ?>"><span class="timerange"></span></td>
            <td class="wday" id="wkday<?= $s ?>"></td>
            <?php   for($i=0; $i<count($exam_time); $i++){ ?>
            <td id="<?= $s ?><?= $i ?>">
            	 <span class="subject_name<?= $i ?>"></span>
            </td>
            <?php }?>
        </tr>
         <?php }?>
    </tbody>
</table>
<div class="print_button" style="padding-left:20px;">
	<input type="submit" class="button" value="প্রিন্ট করুন" name="searchBtnclass_result" onclick="printPageArea('display')"/>
</div>