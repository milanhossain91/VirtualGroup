<?php include 'application/views/home/inc/header.php';?>
               <!-- **Main - Starts** --> 
        <div id="main">
        
            <!-- **Full-width-section - Starts** -->
            <div class="full-width-section grey1"> 
            <div class="dt-sc-margin20"></div>
                <div class="container">
                    <p style="font-size:28px; color:#000000;" class="aligncenter">ছবি গ্যালারি</p>
                    <div class="sorting-container">
						<a data-filter=".all-sort" class="active-sort">সবগুলো দেখুন</a>
							<?php foreach($catagory_list as $cat_name){ ?>
                            <a class="filter" data-filter=".<?= $cat_name['catagory_id']?>"><?= $cat_name['catagory_name']?></a>
							<?php } ?>
                    </div>
                    <div class="dt-sc-hr-invisible-small"></div>
                    <!-- **portfolio-container - Starts** -->
                    <div class="portfolio-container with-space">
                         <?php foreach($photo_gallery as $images){ ?>
                        <div class="portfolio dt-sc-one-fifth with-space column all-sort <?= $images['catagory_id']?>">
                            <!-- **portfolio-thumb - Starts** -->
                            <div class="portfolio-thumb">
                               
                                <img class="lazy" data-original="<?= base_url() ?>upload/photo_gallery/<?= $images['gallery_image_name']?>" src="<?= base_url() ?>upload/photo_gallery/<?= $images['gallery_image_name']?>" alt="<?= $images['photo_caption']?>"/>
                               
                                <div class="image-overlay">
                                    <a class="zoom" href="<?= base_url() ?>upload/photo_gallery/<?= $images['gallery_image_name']?>" data-gal="prettyPhoto[gallery]" title="<?= $images['photo_caption']?>"><span class="fa fa-search-plus"></span></a>
                                    
                                </div>
                            </div> <!-- **portfolio-thumb - Ends** -->
                            <!-- **portfolio-detail - Starts** -->
                            <div class="portfolio-detail">
                               
                                <div class="portfolio-title">
                                    <p><?= $images['photo_caption']?></p>
                                </div>
                            </div> <!-- **portfolio-detail - Ends** -->
                        </div>
                        
                         <?php } ?>
                       
                    </div><!-- **portfolio-container - Ends** -->
                    <div class="dt-sc-hr-invisible-small"></div>    
                </div>
            </div--> <!-- **Full-width-section - Ends** -->
            
       </div>     

<?php include 'application/views/home/inc/footer.php';?>