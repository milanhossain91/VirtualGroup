<?php include 'application/views/home/inc/header.php';?>

  <!-- Primary Starts -->
            <section id="primary" class="content-full-width grey1">
              
                <div class="dt-sc-margin20"></div>
                <div class="entry-meta-data"> 
                             <h2 class="aligncenter">ইভেন্ট সমূহ</h2>
                        </div>
                <div class="container">
                   
<?php include 'pending.php';?>

                              
                </div>      
      </section>
	  <?php include 'application/views/home/inc/footer.php';?>

    