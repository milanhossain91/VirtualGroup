<?php include 'application/views/home/inc/header.php';?>
<div class="container">
	<div>
		<a href="<?= base_url() ?>"><img class="img-responsive center-block" src="<?= base_url() ?>template/assets/images/404.jpg" alt=""></a>
	</div>
</div>
<?php include 'application/views/home/inc/footer.php';?>