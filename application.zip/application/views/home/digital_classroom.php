<?php include 'application/views/home/inc/header.php';?>
<!-- Primary Starts -->
<section id="primary" class="content-full-width grey1">
   <div class="dt-sc-margin20"></div>
   <h2 class="text-center">মাল্টিমিডিয়া ক্লাসরুম</h2>
   <div class="container">
      <table class="table table-condensed" >
              
      </table>
   </div>
</section>
<?php include 'application/views/home/inc/footer.php';?>

