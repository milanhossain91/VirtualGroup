<?php include 'application/views/home/inc/header.php';?>
<section id="primary" class="content-full-width grey1">     

    <div class="container-fluid">

        <div class="container text-center" style="background:#FFF;">
<div class="dt-sc-margin20"></div>  
        <div class="dt-sc-margin30"></div>

                    <!-- **col-1 - Starts** -->  
                    <div class="hr-title dt-sc-hr-invisible-small">
                        <h3>বিদ্যালয়ের শিক্ষার্থীদের উপস্থিতির ফলাফল</h3>
                        <div class="title-sep"> </div>
                    </div>
                    <div class="widget-content padding">
						<div class="daily">
							<div class="form-group">
								<div class="row">
											<div class="col-sm-4 col-md-4">
												<form class="dt-sc-search-form" method="post" action="">
													 <input class="date-picker" id="datepicker" type="text" name="input_date" placeholder="YY-MM-DD" />
													 <div class="dt-sc-margin10"></div>
													 <button style="color:#FFF;" class="button btn btn-info" value="Check available time" type="button"  onclick="student_for_att_report_daily_json()">Search Student Attendance </button>
												  </form>
											</div>
										</div>
                                    </div>
                                </div>
							</div>
								<hr/>
							<div class="widget-content padding">
                                <div id="display">
                                	<!---JSON Content will be displayed here--->
                                </div>
                            </div>

                        <div class="dt-sc-margin30"></div>
                              
                    </div>   
<div class="dt-sc-margin50"></div>  
         </div> 
                         
    
   </section>         <!-- **Footer** -->

<?php include 'application/views/home/inc/footer.php';?>
<script>
// get the student daily att report
	function student_for_att_report_daily_json()
	{
		var att_date = $('[name=input_date]').val();
		
        $.ajax({ 
        url: baseUrl+'home/student_for_att_report_daily_json',
        data:
            {                  
                'att_date':att_date
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#display').html(mainContent);     
                }                
            },
			error: function(e){
			   alert(e.message);
			}
        });
        return false; // keeps the page from not refreshing     
    }
    
    //print all report
	function printPageArea(areaID){
		var printContent = document.getElementById(areaID);
		var WinPrint = window.open('', '', 'width=900,height=650');
		WinPrint.document.write('<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/libs/bootstrap/css/bootstrap.min.css" media="print" />');
		WinPrint.document.write('<style type="text/css" media="print"> @page { font-size:12px; } table{font-size:12px;} table td{padding:3px;} .print_button{ display:none;} .header-div-box{display:inline-block;} .header-div-box.box-left{float:left; margin-bottom:10px;} .header-div-box.box-right{float:right;}</style>');
		WinPrint.document.write(printContent.innerHTML);
		WinPrint.document.close();
		WinPrint.focus();
		WinPrint.print();
		WinPrint.close();
	}
	</script>