<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Fees Type Edit</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:300px;">
                           
                            <div class="widget-content padding">
                                <form role="form" method="POST" action="<?= base_url();?>fees/fees_type_edit_save">
                                    <br/><br/><br/>
                                    
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-2"></div>
                                            <div class="col-sm-4">
                                                <label>Fees Particulars Name </label>
                                                <input type="text" class="form-control" name="type" id="type" value="<?= $type['type']; ?>">
                                                <input type="hidden" class="form-control" name="id" id="id" value="<?= $type['id']; ?>">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-2"></div>
                                            <div class="col-sm-4">
                                                <button type="submit" class="btn btn-primary">Update</button>
                                            </div>
                                        </div>
                                    </div>
                                    
                                  </form>
                            </div>
                        </div>
                    </div>
                </div>
				
				
<?php include 'application/views/includes/footer.php';?>