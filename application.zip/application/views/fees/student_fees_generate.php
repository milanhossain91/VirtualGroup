<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">
	<!-- Start Content here -->
	<div class="content">
		<?php if($this->session->flashdata('message')):?>
			<?=$this->session->flashdata('message')?>
		<?php endif?> 
		<div class="page-heading">
        	<h1><i class='fa fa-table'></i> Fees Generate</h1>
		</div>            	
		<div class="row">
			<div class="col-md-12">
				<div class="widget" style="min-height: 400px">
					<div class="widget-content">
						<form role="form" id="registerForm" method="POST">
							<div class="widget-content padding">
								<div class="form-group">
									<div class="row">
										<div class="col-sm-6 col-md-3">
											<label>Class</label>
											<select class="form-control" id="class_id" onchange="get_class_group_list(this.value);">
												<option value="">-----Select Class-----</option>
                                                <?php foreach($class_list as $cl){ ?>
                                                <option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option>
                                                <?php } ?>
                                            </select>
                                        </div>
										<div class="col-sm-6 col-md-3">
											<label>Group</label>
											<select class="form-control" id="group_id" required />
												<option value="">-----Select Group-----</option>
											</select>
										</div>
										<div class="col-sm-6 col-md-3">
                                            <label>Shift</label>
                                            <select class="form-control" name="shift_id" id="shift_id" required />
                                                <option value="">----Select Shift----</option>
												<?php foreach($shift_list as $shl){ ?>
												<option value="<?= $shl['shift_id']?>"><?= $shl['shift_name']?></option>
												<?php } ?>
                                            </select>
                                        </div>
										<div class="col-sm-6 col-md-3">
											<label>Session</label>
											<select class="form-control" id="session_id" onchange="get_student_list()">
												<option value="">----Select Session----</option>
												<?php foreach($session as $sl){ ?>
												<option value="<?= $sl['session_id'];?>"><?= $sl['session_name'];?></option>
												<?php } ?>
											</select>
										</div>
									</div>
								</div>
								<div class="form-group">
									<div class="row">
										<div class="col-sm-6 col-md-3">
											<?php  $month = array(1=>'January',2=>'February',3=>'March',4=>'April',5=>'May',6=>'June',7=>'July',8=>'August',9=>'September',10=>'October',11=>'November',12=>'December');
																 ?>
											<label>Month </label>
											<select class="form-control" required id="fees_month">
												<?php foreach($month as $key => $value){ ?>
												<option value="<?= $key;?>"<?php if($key==date("m")) echo "selected"?>><?= $value;?></option>
												<?php } ?>
											</select>
										</div>
										<div class="col-sm-6 col-md-3">
											<?php  $currentDate = date("Y"); 
													for ($edb=0; $edb<=1; $edb++)
                                                    {
														$examdate[$edb]=$currentDate-$edb;
                                                    }
                                                    $examdate=array_reverse($examdate);
                                                    $count=6;
                                                    for ($eda=1; $eda<=2; $eda++)
                                                    {
                                                        $examdate[$count]=$currentDate+$eda;
                                                        $count++; 
                                                    }
                                            ?>
                                            <label>Year </label>
                                            <select class="form-control" required id="fees_year">
                                                <option value="">Select</option>
                                                <?php foreach($examdate as $ed){ ?>
                                                <option value="<?= $ed;?>"<?php if($ed==$currentDate) echo "selected"?>><?= $ed;?></option>
                                                <?php } ?>
                                            </select>
										</div>
										<div class="col-sm-6 col-md-3">
											<label>Student Name </label>
											<select class="selectpicker" id="student_id">
												<option value="">----Select Student----</option>
											</select>
											<b>NB:</b> Select student if you want to generate fees for single student. 
										</div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <label>Fees Type :</label>
                                            <?php foreach($fees_type as $ftl): ?>
                                            <label class="checkbox-inline"><input name="fees_type" type="checkbox" value="<?= $ftl['id'];?>"><?= $ftl['type'];?></label>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="row">
					<div class="col-sm-4">
						<button type="button" class="btn btn-primary" onclick="ready_query_item()">Show Students</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form><hr/>
                        <div id="display">
                        
                            <!---JSON Content will be displayed here--->
                        
                        </div>
                    </div>
                </div>
			</div>
		</div>

<?php include 'application/views/includes/footer.php';?>

<script>
	function get_class_group_list(class_id)
	{
	   $.ajax({
		type: "POST",
		url: baseUrl + 'academic/group_list_ajax',
		data:
		{
			'class_id':class_id
		}, 
		success: function(html_data)
		{
			if (html_data != '')
			{
				$('#group_id').html(html_data);
			}
		}
		});  
	}
	function get_student_list()
	{
		var class_id = $('#class_id').val();
		var group_id = $('#group_id').val();
		var shift_id = $('#shift_id').val();
		var session_id = $('#session_id').val();
		//alert(class_id+' '+group_id+' '+shift_id+' '+session_id);
	   $.ajax({
			type: "POST",
			url: baseUrl + 'fees/get_student_list_ajax',
			data:
			{
				'class_id':class_id,
				'group_id':group_id,
				'shift_id':shift_id,
				'session_id':session_id
			}, 
			success: function(html_data)
			{
				if (html_data != '')
				{
					$('#student_id').html(html_data);
				}
			}
		});  
	}
    
	function ready_query_item()
    {
        var class_id = $('#class_id').val();
		var group_id = $('#group_id').val();
		var shift_id = $('#shift_id').val();
		var session_id = $('#session_id').val();
		var fees_month = $('#fees_month').val();
		var fees_year = $('#fees_year').val();
		var student_id = $('#student_id').val();
		var fees_type=new Array;
		
		$.when($('input[name="fees_type"]:checked').each(function(){			
			fees_type.push($(this).val());
		})).done(generate_fees_json(class_id,group_id,shift_id,session_id,fees_month,fees_year,fees_type,student_id));
		
	}
	
	// get the student list and fees list 
	function generate_fees_json(class_id,group_id,shift_id,session_id,fees_month,fees_year,fees_type,student_id)
	{
        $.ajax({ 
        url: baseUrl+'fees/get_student_list_for_fees_json',
        data:
            {                  
                'class_id':class_id,
				'group_id':group_id,
				'shift_id':shift_id,
				'session_id':session_id,
				'fees_month':fees_month,
				'fees_year':fees_year,
				'fees_type':fees_type,
				'student_id':student_id
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#display').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
	
	// fill amount field
	 function amount(student_id,fees_aid,aid_amount)
	{
		$('#amount_html'+student_id).html('');
		
		$('.fees_class_'+student_id).each(function(){
			 if ($(this).is(":checked")){
				if($(this).val().split("+")[0] == fees_aid){
					cat_amount=$(this).val().split("+")[2] - aid_amount;
				}
				else{
					cat_amount=$(this).val().split("+")[2];
				}
				$('#amount_html'+student_id).append('<div style="padding:5px; width:120px; float:left;"><div class="input-group"><span class="input-group-addon">'+$(this).val().split("+")[0]+'</span><input type="text" class="form-control fees_amount_'+student_id+'" name="fees_amount_'+student_id+'[]" onkeyup="total_fees(\''+student_id+'\')" readonly="true" value="'+cat_amount+'"></div></div>');
			}
			total_fees(student_id);
		})
	}
	// count the total fees
	function total_fees(student_id)
	{
		$('#amount_total'+student_id).html('');
		var total_fees=0;
		$('.fees_amount_'+student_id).each(function(){
				if($(this).val())
				{
					value=parseInt($(this).val());
				}
				else{ value=0; }
				 total_fees+=value;
				
		})
		$('#amount_total'+student_id).html('<div style="padding:5px;"><div style="font-size:16px; margin:0 30%; padding:10px 20px;" class="label label-default"><b>'+total_fees+'</b></div> </div>');
	}
	
	// make change all student fees at a time
	function bulk_check(fees_cat_id)
	{
		
		if($('input[class="bulk_check_class'+fees_cat_id+'"]').is(':checked'))
			{
				$('.fees_'+fees_cat_id).each(function(){
					if($(this).is(':checked'))
					{}
					else
					{
						$(this).click();
					}
				
				});
			}
		else
			{
				$('.fees_'+fees_cat_id).each(function(){
					if($(this).is(':checked'))
					{$(this).click();}
				
				});
			}
	}
</script>