<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Fees Type</h1>
                </div>
            	<!-- Page Heading End-->
                <?php if($this->session->flashdata('message')):?>
					<?=$this->session->flashdata('message')?>
				<?php endif?>
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <div class="row">				
                                    <div class="col-md-12">
                                        <div class="widget">
                                            <div class="widget-content padding">Add New Fee Type - <a href="javascript:void(0);" onclick="toggle_insertion_box(); return false;">Click Here</a>
                                                <div class="insertion_div">
                                                    <form class='form-horizontal' role='form' method="POST" action="<?php echo base_url();?>fees/fees_type_save">
                                                        <div class="form-group">
                                                            <div class="row">
                                                                <div class="col-sm-1"></div>
                                                                    <div class="col-sm-3" style="margin-right:10px;">
                                                                        <div class="form-group">
                                                                            <label>Fees Type</label>
                                                                            <input type="text" class="form-control" name="type" id="type">
                                                                        </div>
                                                                    </div>
                                                                           <br/>
                                                                           <button type="submit" class="btn btn-primary" style="margin-top:3px;margin-left:10px;">Save</button>
                                                            </div>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                            
                                            <div class="widget-content">
                                                <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="90%">
                                                    <thead>
                                                        <tr>
                                                            <th>ID</th>
                                                            <th>Type</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php if($fees_type):
                                                            foreach($fees_type as $ftl):
                                                        ?>
                                                        <tr>
                                                            <td><?php echo $ftl['id'];?></td>
                                                            <td><?php echo $ftl['type'];?></td>
                                                            <td>
                                                                <a href="<?php echo base_url();?>fees/fees_type_edit/<?php echo $ftl['id'];?>" title="Edit"><i class="fa fa-edit"></i></a> |
                                                                <?=anchor("fees/fees_type_delete/".$ftl['id'],"<i class=\"fa fa-remove\"></i>",array('onclick' => "return confirm('Do you want delete this record')"))?>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; endif; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
				
<?php include 'application/views/includes/footer.php';?>