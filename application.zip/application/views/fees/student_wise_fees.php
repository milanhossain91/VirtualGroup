<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
	<div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content">
			<div class="page-heading">
            	<h1><i class='fa fa-table'></i> Student Wise Fees</h1>
			</div>
             <?php if($this->session->flashdata('message')):?>
					<?=$this->session->flashdata('message')?>
				<?php endif?> 
			<div class="row">
            	<div class="col-md-12">
                    <div class="widget" style="min-height: 400px">
                        <div class="widget-content">
                            <form role="form" id="registerForm" method="POST">
                                <div class="widget-content padding">
                                     <div class="form-group">
                                    	<div class="row">
                                            <div class="col-sm-6 col-md-3">
                                                <label>Class</label>
                                                    <select class="form-control" name="class_id" id="class_id" onchange="get_class_section_list(this.value); get_class_group_list(this.value);">
                                                        <option value="">Select</option>
                                                        <?php foreach($class_list as $cl){ ?>
                                                        <option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option>
                                                        <?php  } ?>
                                                    </select>
                                            </div>
                                            <div class="col-sm-6 col-md-3">
                                            	<label>Section</label>
                                                	<select class="form-control" name="section_id" id="section_id">
                                                    	<option value="">Select</option>
                                                    </select>
                                            </div>
                                            <div class="col-sm-6 col-md-3">
                                             	<label>Group</label>
                                                	<select class="form-control" name="group_id" id="group_id" required />
                                                    	<option value="">-----Select Group-----</option>
                                                    </select>
                                            </div>
											<div class="col-sm-6 col-md-3">
												<label>Shift</label>
												<select class="form-control" name="shift_id" id="shift_id" required />
													<option value="">----Select Shift----</option>
													<?php foreach($shift_list as $shl){ ?>
													<option value="<?= $shl['shift_id']?>"><?= $shl['shift_name']?></option>
													<?php } ?>
												</select>
                                        </div>
                                         </div>
                                     </div>
                                     <div class="form-group">
                                    	<div class="row">
                                            <div class="col-sm-6 col-md-3">
                                            	<label>Session</label>
                                                <select class="form-control" name="session_id" id="session_id" onchange="get_section_wise_student_for_dropdown_json()">
                                                	<option value="">-----Select Session-----</option>
                                                    <?php foreach($session as $sl){ ?>
                                                    <option value="<?= $sl['session_id'];?>"><?= $sl['session_name'];?></option>
                                                    <?php } ?>
                                                </select>
                                             </div>
                                            <div class="col-sm-6 col-md-3">
                                            	<label>Student Name</label>
                                                <select class="form-control" name="student_id" id="student_id" onchange="get_student_wise_subject_view()">
													<option value="">Select</option>
                                                </select>
                                            </div>     
                                            <div class="col-sm-6 col-md-3">
												<label>Year</label>
												<input type="text" class="form-control" value="<?= date('Y')?>" required name="fees_year" id="fees_year">
                                            </div>
                                        </div>
                                    </div>
                                     
                                    <div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-4">
                                                <button type="button" class="btn btn-primary" onclick="student_wise_fees_json()">Show Students</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </form>
								 <hr/>
                                <div id="display">
                                	<!---JSON Content will be displayed here--->
                                </div>
                            </div>
                        </div>
                    </div>
				</div>

				
				
<?php include 'application/views/includes/footer.php';?>

<script>

function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
        }
    }
    });
}

function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
        }
    }
    });  
}

function get_section_wise_student_for_dropdown_json()
    {
        var class_id = $('#class_id').val();  
		var group_id = $('#group_id').val();
		var shift_id = $('#shift_id').val();
		var session_id = $('#session_id').val();        
        var section_id = $('#section_id').val();        
        $.ajax({ 
        url: baseUrl+'fees/get_section_wise_student_for_dropdown_json',
        data:
            {                  
                'class_id':class_id,
				'group_id':group_id,
				'shift_id':shift_id,
				'session_id':session_id,
                'section_id':section_id
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#student_id').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
	
	// get the student list and fees list 
	function student_wise_fees_json()
	{
		var student_id = $('#student_id').val();
		var fees_year = $('#fees_year').val();
		var session_id = $('#session_id').val();
		var class_id = $('#class_id').val();  
		var group_id = $('#group_id').val();
		var shift_id = $('#shift_id').val();        
        var section_id = $('#section_id').val();      
        $.ajax({ 
        url: baseUrl+'fees/student_wise_fees_json',
        data:
            {
				'student_id':student_id,
				'session_id':session_id,
				'fees_year':fees_year,
				'class_id':class_id,
				'group_id':group_id,
				'shift_id':shift_id,
                'section_id':section_id,
				'edit_option':0
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#display').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
	// change the billing status
	function fees_change_status(status,billing_id)
	{
        $.ajax({
			type: "POST",
			 url: baseUrl+'fees/fees_change_status',
			data:
			{
				'status':status,
				'billing_id':billing_id
			}, 
			success: function(html_data)
			{
				if (html_data != '')
				{
					if(status==1)
					{
						$('.status'+billing_id).html('<label>Paid</label>');
						$('#status_change'+billing_id).html('<button type="button" class="btn btn-danger" onclick="fees_change_status(\'0\',\''+billing_id+'\')">Unpaid</button>');
					}
					else
					{
						$('.status'+billing_id).html('<label>Unpaid</label>');
						$('#status_change'+billing_id).html('<button type="button" class="btn btn-info" onclick="fees_change_status(\'1\',\''+billing_id+'\')">Paid</button>');
					}
				}
			}
			});  
		
        return false; // keeps the page from not refreshing     
	}
	
	function fees_change_status_bulk(status)
	{
		var billing_id=new Array();
		
		$('.bulk_check').each(function(){
			 if ($(this).is(":checked")){
				billing_id.push($(this).val());
			}
		});
		
		if(billing_id.length <= 0)
		{
			alert("You didn't select any item. ");
			return;	
		}
		
        $.ajax({
			type: "POST",
			 url: baseUrl+'fees/fees_change_status_bulk',
			data:
			{
				'status':status,
				'billing_id':billing_id
			}, 
			success: function(html_data)
			{
				if (html_data != '')
				{
					if(status==1)
					{
						for(var i=0; i < billing_id.length; i++)
						{
							$('.status'+billing_id[i]).html('<label>Paid</label>');
							$('#status_change'+billing_id[i]).html('<button type="button" class="btn btn-danger" onclick="fees_change_status(\'0\',\''+billing_id+'\')">Unpaid</button>');
						}
					}
					else
					{
						for(var i=0; i < billing_id.length; i++)
						{
							$('.status'+billing_id[i]).html('<label>Unpaid</label>');
							$('#status_change'+billing_id[i]).html('<button type="button" class="btn btn-info" onclick="fees_change_status(\'1\',\''+billing_id+'\')">Paid</button>');
						}
					}
				}
			}
			});  
		
        return false; // keeps the page from not refreshing     
	}
	
	// get the student fees recept
	function get_fees_recept(bulk,bill_id,mob_no,total_amount)
	{
		if(bulk){
			billing_id = $('#fees_year').val();
		}
		else{
			billing_id =new Array(bill_id);
		}

	        $.ajax({
	        url: baseUrl+'fees/get_fees_recept',
	        data:
	            {                  
					'billing_id':billing_id,
					'total_amount':total_amount,
					'mob_no':mob_no
	            }, 
	            dataType: 'json',
	            success: function(data)
	            {
	                result                = ''+data['result']+'';
	                mainContent           = ''+data['mainContent']+'';
	
	                if(result == 'success')
	                {         
	                    var WinPrint = window.open('', '', 'width=900,height=650');
						WinPrint.document.write(mainContent);
						WinPrint.document.close();
						WinPrint.focus();
						WinPrint.print();
						WinPrint.close();
	                }                
	            }
	        });
	        return false; // keeps the page from not refreshing     
    }
	
</script>