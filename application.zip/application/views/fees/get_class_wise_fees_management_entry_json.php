<div class="table-responsive">
	<form class='form-horizontal' role='form' method="POST" action="<?php echo base_url();?>fees/fees_management_entry">
			<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="60%">
				<thead>
					<tr>
						<th>Fees Cat ID</th>
						<th>Particulars</th>
						<th>Amount</th>
						<th>period</th>
					
					</tr>
				</thead>

			   <tbody>
                     <?php foreach($fee_management_entry as $fee_entry){ ?>
                     <tr>
                     	<td>
							<input type="text" class="form-control" name="fees_cat_id[]" id="fees_cat_id" value="<?= $fee_entry['fees_cat_id'];?>" readonly>
                        </td>
                        <td><?= $fee_entry['fees_particulars'];?></td>
                        <td> <input type="text" class="form-control" name="fees_amount[]" id="fees_amount" value="0"> </td>
                        <td>	
							<select class="form-control" name="period[]" id="period">
								<?php foreach($fees_type as $ftl){ ?>
                                	<option value="<?= $ftl['id']; ?>"> <?= $ftl['type'] ?></option>
                                <?php } ?>
                            </select>
                        </td>
                    </tr>
                    <?php 	} ?>
				</tbody>
			</table>
            	<input type="hidden" class="form-control" name="school_id" id="school_id" value="<?= $fee_entry['school_id'];?>">
	 			<input type="hidden" class="form-control" name="class_id" id="class_id" value="<?= $_GET['class_id'];?>">
                <input type="hidden" class="form-control" name="group_id" id="group_id" value="<?= $_GET['group_id'];?>">      
                <input type="hidden" class="form-control" name="shift_id" id="shift_id" value="<?= $_GET['shift_id'];?>">      
                <input type="hidden" class="form-control" name="session_id" id="session_id" value="<?= $_GET['session_id'];?>">      
			<br/>
			<button type="submit" class="btn btn-primary" style="margin-top:3px;margin-left:10px;">Save</button>
	</form>
</div>