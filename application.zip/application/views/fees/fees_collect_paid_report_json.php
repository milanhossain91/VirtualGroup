<div class="pull-left col-sm-4">
<button type="button" class="btn btn-primary" title="Print this report" onclick="printPageArea('display')"> Print </button>
<hr/>
</div>
<table id="datatables-1" class="table table-striped table-bordered" border="1" width="100%">
	<thead>
		<tr>
			<th>Billing ID</th>
            <th>Student ID</th>
			<th>Fee Details</th>
            <th>Total</th>
            <th>Status</th>
		</tr>
	</thead>
	<tbody>
		<?php foreach($fees_details as $fdl): ?>
		<tr>
			<td><?= $fdl['billing_id'] ?></td>
            <td><?= $fdl['student_id'] ?></td>
            <td><?= $fdl['fees_details'] ?></td>
            <td><?= $fdl['total_amount'] ?></td>
            <td>
				<?php if($fdl['status']==0): ?>
                	<label>Unpaid</label>
                <?php else: ?>
                	<label>Paid</label>
                <?php endif; ?>
            </td>
		</tr>
		<?php endforeach; ?>
	</tbody>
</table>