<!DOCTYPE html>
<html>
   <head>
      <style>
@media print {
.money-reciept{
        width:210mm; 
        height: 148.5mm;
        border-bottom: 1px dotted gray; 
}
.btn-reciept{
    clear: both;
    margin: 0px 0px;
    padding: 3px 5px;
    border: 1px solid black;
    font-weight: bold;
    text-transform: uppercase;
    /*border-radius: 15px;*/
    box-shadow: 0!important;
    outline: 0;
    font-size:14px;
    border-radius: 10px;
    text-align: center;
    background-color: rgb(255, 255, 255);
    //color: rgb(255, 255, 255);
    /*outline: 2px solid black;*/
}
.school-part{
  width: 50%;
  height: 148.5mm;
  float: left;
  position: relative;
  padding-bottom: 0px;
  /*background-color: rgba(255, 222, 20, .5);*/
}
.reciept-container{
  margin: 5px;
}

.stu-part{
  width: 49%;
  height: 148.5mm;
  float: left;
  border-left:dotted gray; 
  position: relative;
  padding-bottom: 0px;
  /*background-color:rgba(0,0,0,.2)*/


}
.schoo-add{
  position: relative;
}
.logo-reciept-form{
  position: absolute;
  z-index: 1;
  top: 33px;
  left:0px;
  margin-left: -36px;
}
table.tbl-border th,
table.tbl-border td {
    border: 0.5px solid black;
    padding: 4px;
}
.center-text{
   text-align: center;
}
.left-text{
   text-align: left;
}
.right-text{
   text-align: right;
}
td span{
   text-align: right;
   right: 0;
}
.right-border{
   border-right: 2px solid white;
}
.left-border{
   border-left: 2px solid white;
}
.reciept-address{
   text-align: center;
   text-transform: uppercase;
}
.reciept-address h2{
   font-weight: bold;
   font-size: 18px;
   margin-top: 0px;
   margin-bottom:0px !important;
   text-align: center;
   display: block;
   padding-bottom:0px !important;
}
.reciept-address p{
   margin:2px;
   font-size:12px;
}
.tbl-recipt tr td{
   padding: 2px 5px;
   font-size: 13px;
	  }
tr th{
   font-size: 12px;
	  }
.footer_sign{
	position: absolute;
	bottom: 0;
}
.border_bottom{
	border-bottom:1px dotted #000 !important;
}
@page { margin:0px; }
}
      </style>
   </head>
   <body>
   <?php 
   function processRowData($row) {
		$number = $row;
		$no = round($number);
		$point = round($number - $no, 2) * 100;
		$hundred = null;
		$digits_1 = strlen($no);
		$i = 0;
		$str = array();
		$words = array('0' => '', '1' => 'One', '2' => 'Two',
			'3' => 'Three', '4' => 'Four', '5' => 'Five', '6' => 'Six',
			'7' => 'Seven', '8' => 'Eight', '9' => 'Nine',
			'10' => 'Ten', '11' => 'Eleven', '12' => 'Twelve',
			'13' => 'Thirteen', '14' => 'Fourteen',
			'15' => 'Fifteen', '16' => 'Sixteen', '17' => 'Seventeen',
			'18' => 'Eighteen', '19' =>'Nineteen', '20' => 'Twenty',
			'30' => 'Thirty', '40' => 'Forty', '50' => 'Fifty',
			'60' => 'Sixty', '70' => 'Seventy',
			'80' => 'Eighty', '90' => 'Ninety');
		$digits = array('', 'Hundred', 'Thousand', 'Lakh', 'Crore');
		while ($i < $digits_1) {
			 $divider = ($i == 2) ? 10 : 100;
			 $number = floor($no % $divider);
			 $no = floor($no / $divider);
			 $i += ($divider == 10) ? 1 : 2;
			 if ($number) {
				$plural = (($counter = count($str)) && $number > 9) ? 's' : null;
				$hundred = ($counter == 1 && $str[0]) ? ' And ' : null;
				$str [] = ($number < 21) ? $words[$number] .
					" " . $digits[$counter] . $plural . " " . $hundred
					:
					$words[floor($number / 10) * 10]
					. " " . $words[$number % 10] . " "
					. $digits[$counter] . $plural . " " . $hundred;
			 } else $str[] = null;
		  }
		  $str = array_reverse($str);
		  $result = implode('', $str);
		  $points = ($point) ?
			"." . $words[$point / 10] . " " . 
				  $words[$point = $point % 10] : '';
				  if($points)
					  $poysha=$points . " Paise Only";
				  else
					  $poysha="Only";
		  return $result . "Taka  " .$poysha;
			//return $row;
		}

   
   
   
		foreach($fees_details as $key => $value){
		   $billing_idarr[$value['billing_id']][$key] = $value;
		   $stuinfo_idarr[$value['billing_id']] = $value;
		   $bill_id[]=$value['billing_id'];
		}
		//print_r(array_unique$bill_id);
		//print_r($stuinfo_idarr);
		foreach($billing_idarr as $key => $value){
   ?>
      <section class="money-reciept">
         <div class="school-part">
         <div class="reciept-container">
            <div class="reciept-address">
               <h2><?php print_r($school_info[0]['school_name']) ?></h2>
               <p><span>PO : <?php print_r($school_info[0]['post_office']) ?>, Dist: <?php print_r($school_info[0]['district']) ?></span></p>
               <p>Est:<?php print_r($school_info[0]['established']) ?></p>
               <button type="button" class="btn-reciept">Money Reciept</button>
            </div>
            <table width="100%">
                  <tr>
                     <th style="width:60px" >SL No:</th>
                     <th class="border_bottom"><?= $key; ?></th>
                     <th style="width:60px" >Date:</th>
                     <th class="border_bottom"><?= date('d-m-Y'); ?></th>
                  </tr>
            </table>
            <table width="100%">
                  <tr>
                     <th style="width:60px">Name:</th>
                     <td class="border_bottom"><?= $stuinfo_idarr[$key]['student_name'] ?></td>
                  </tr>
            </table>
			<table width="100%">
                  <tr>
                     <th style="width:60px" >Class:</th>
                     <td class="border_bottom"><?= $stuinfo_idarr[$key]['class_name'] ?></td>
                     <th style="width:60px" >Section:</th>
                     <td class="border_bottom"><?= $stuinfo_idarr[$key]['section_name'] ?></td>
                     <th style="width:60px" >Roll No:</th>
                     <td class="border_bottom"><?= $stuinfo_idarr[$key]['roll_no'] ?></td>
                  </tr>
            </table>
            <table width="100%" class="tbl-border tbl-recipt" style="margin-top:10px;  border-collapse: collapse;" border="0">
				<thead class="center-text">
					<tr>
						<th style="width:60px">SL. No.</th>
						<th>Description</th>
						<th style="width:80px">Taka</th>
					</tr>
				</thead>
				<tbody>
					<?php $i=1; $total=0; foreach($value as $v){ ?>
					<tr>
						<td><?= $i; ?></td>
						<td><?= $v['fees_particulars']; ?></td>
						<td><?= $v['amount']; ?></td>
					</tr>
					<?php $i++; $total+=$v['amount']; } ?>
					<tr>
						<td> In words</td>
						<td><?= processRowData($total); ?> </td>
						<td><?= $total; ?></td>
					</tr>
				</tbody>
            </table>
            </div>
			<div class="footer_sign" style="width:100%;">
				<div class="right-text" style="padding:0px 80px 20px 0px;">Collector</div>
				<div class="right-text" style="padding:0px 40px 10px 0px;">---------------------------</div>
			</div>
         </div>

         <div class="stu-part">
          <div class="reciept-container">
            <div class="reciept-address">
               <h2><?php print_r($school_info[0]['school_name']) ?></h2>
               <p><span>PO : <?php print_r($school_info[0]['post_office']) ?>, Dist: <?php print_r($school_info[0]['district']) ?></span></p>
               <p>Est:<?php print_r($school_info[0]['established']) ?></p>
               <button type="button" class="btn-reciept">Money Reciept</button>
            </div>
            
            <table width="100%">
                  <tr>
                     <th style="width:60px" >SL No:</th>
                     <th class="border_bottom"><?= $key; ?></th>
                     <th style="width:60px" >Date:</th>
                     <th class="border_bottom"><?= date('d-m-Y'); ?></th>
                  </tr>
            </table>
            <table width="100%">
                  <tr>
                     <th style="width:60px">Name:</th>
                     <td class="border_bottom"><?= $stuinfo_idarr[$key]['student_name'] ?></td>
                  </tr>
            </table>
			<table width="100%">
                  <tr>
                     <th style="width:60px" >Class:</th>
                     <td class="border_bottom"><?= $stuinfo_idarr[$key]['class_name'] ?></td>
                     <th style="width:60px" >Section:</th>
                     <td class="border_bottom"><?= $stuinfo_idarr[$key]['section_name'] ?></td>
                     <th style="width:60px" >Roll No:</th>
                     <td class="border_bottom"><?= $stuinfo_idarr[$key]['roll_no'] ?></td>
                  </tr>
            </table>
            
            <table width="100%" class="tbl-border tbl-recipt" style="margin-top:10px;  border-collapse: collapse;" border="0">
				<thead class="center-text">
					<tr>
						<th style="width:60px">SL. No.</th>
						<th>Description</th>
						<th style="width:80px">Taka</th>
					</tr>
				</thead>
				<tbody>
					<?php $i=1; $total=0; foreach($value as $v){ ?>
					<tr>
						<td><?= $i; ?></td>
						<td><?= $v['fees_particulars']; ?></td>
						<td><?= $v['amount']; ?></td>
					</tr>
					<?php $i++; $total+=$v['amount']; } ?>
					<tr>
						<td> In words</td>
						<td><?= processRowData($total); ?> </td>
						<td><?= $total; ?></td>
					</tr>
				</tbody>
            </table>
            </div>
			<div class="footer_sign" style="width:100%;">
				<div class="right-text" style="padding:0px 80px 20px 0px;">Collector</div>
				<div class="right-text" style="padding:0px 40px 10px 0px;">---------------------------</div>
			</div>
         </div>
		</section>
		<?php } ?>
	</body>
</html>