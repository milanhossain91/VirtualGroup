<div class="table-responsive">
	<form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>school/ct_marks_save" enctype="multipart/form-data">
				
					<div class="form-group">
                                        <div class="row">
                                           
                                            <div class="col-sm-11" style="text-align: center;font-size:20px;font-weight:bold;">
                                               <h2><span style="font-weight:bold;"> Class Test </span></h2>
                                               
                                                
                                                <p>Full Marks: <span class="full_marks"><?php foreach($mark_dis_info as $mdi)
												{
												if($mdi['exam_type']==4)
												{
												echo $mdi['term_mark_per'];
												}
												}?></span>&nbsp;&nbsp;
                                               
												</p>
												
                 <input type='hidden' name='class_id' value='<?php echo $details['class']; ?>' />
				<input type='hidden' name='section_id' value='<?php echo $details['section']; ?>' />
                <input type='hidden' name='term_id' value='<?php echo $details['term_id']; ?>' />											
				<input type='hidden' name='group_id' value='<?php echo $details['group_id']; ?>' />
                <input type='hidden' name='shift_id' value='<?php echo $details['shift_id']; ?>' />
                <input type='hidden' name='subject_id' value='<?php echo $details['subject_id']; ?>' />
                <input type='hidden' name='exam_year' value='<?php echo $details['exam_year']; ?>' />
											</div>
                                        </div>
                                    </div>
				
	<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
				<thead>
					<tr>
						<th>Student ID</th>
                        <th>Roll No</th>
						<th>Student Name</th>
						<th>Obtained Marks</th>
						<th>Remarks</th>
					</tr>
				</thead>

				<tbody>
					
					<?php
						
						foreach($student_list as $sl){ ?>
						
						<tr>
							<td>
							<input type="hidden"  readonly class="form-control" name="student_iddfsd[]" id="student_id" value="<?php echo $sl['student_id'];?>">
                            <?php echo $sl['student_id'];?>
							</td>
                            <td>
							<input type="hidden" readonly class="form-control" id="student_roll" value="<?php echo $sl['roll_no'];?>">
                            <?php echo $sl['roll_no'];?>
							</td>
							<td>
							<input type="hidden" readonly class="form-control" id="student_name" value="<?php echo $sl['student_name'];?>">
                            <?php echo $sl['student_name'];?>
							</td>
							<?php
							
							$ss =$sl['student_id'];
							$class_id=$details['class'];
							$section_id=$details['section'];
							$group_id=$details['group_id'];
							$shift_id=$details['shift_id'];
							$subject_id =$details['subject_id'];
							$term_id =$details['term_id'];
							$exam_year =$details['exam_year'];
		$sql = "SELECT * FROM tbl_ct_marks where student_id='$ss' and class_id='$class_id' and section_id='$section_id' and group_id='$group_id' and shift_id='$shift_id' and exam_year='$exam_year' and subject_id='$subject_id' and term_id = '$term_id'";
		$query = mysql_query($sql);
        $row= mysql_fetch_array($query);
							?>
							<td>
			<input type="text" class="form-control" name="obtain_marks[]" id="obtain_marks<?php echo $sl['student_id'];?>" value="<?php echo $row['obtained_marks'];?>" onchange="validation(this.value,<?php echo $sl['student_id'];?>)">
							</td>
							<td>
							<input type="text" class="form-control" name="remarks[]" id="remarks" >
							</td>
						</tr>
					<?php 	} ?>
						
					<tr>
                    <td></td>
                     <td></td>
					<td>
                    <?php if($row['status']!=0) { 
					echo "<strong>NB :</strong>You are not allowed to save or edit marks";
					}
					else{
					?>
					<input type="submit" class="btn btn-primary" name="fees_gen" value="Save"/>
                    <?php } ?>
					</td>
                     <td></td>
                      <td></td>
					</tr>
				</tbody>
			</table>


	</form>
</div>
<script>
function validation(number,student_id)
{
	var full_marks =parseInt($('.full_marks').text());
	var numbers=/^([0-9.]*)$/;
	if (numbers.test(number))
			{
				if(number>full_marks)
				{
					$('#obtain_marks'+student_id).after("<div id='validation"+student_id+"' style='position:absolute; background-color:#7ECCAD; height:25px; width:auto; color:#fff; font-size:12px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:3px 3px 1px 3px; alignment-adjust:central; text-shadow:#FFE1FF;'>This number is more than Full Marks</div>")
						$('#validation'+student_id).fadeToggle(5000);
						
					$('#obtain_marks'+student_id).val("");
				}
			}
			else
			{
				
				$('#obtain_marks'+student_id).after("<div id='validation"+student_id+"' style='position:absolute; background-color:#7ECCAD; height:25px; width:auto; color:#fff; font-size:12px; font-weight:bold; border-radius:0px 15px 0px 15px; box-shadow:1px 1px 1px 1px #5DAF8F; padding:3px 3px 1px 3px; alignment-adjust:central; text-shadow:#FFE1FF;'>Please enter number only</div>")
						$('#validation'+student_id).fadeToggle(5000);
				$('#obtain_marks'+student_id).val("");
			}
	
	
}
</script>