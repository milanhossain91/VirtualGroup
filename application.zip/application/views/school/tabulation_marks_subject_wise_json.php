
<div class="table-responsive">
<table style="width:100%;">
<tr>
    <td>&nbsp;
    
    </td>
	<td>&nbsp;
    
    </td>
	<td colspan="6" style="text-align:center;">
    <span style="font-weight:bold; font-size:22px;">
    <?php foreach($school_infos as $school_info) {echo $school_info['school_name'];} ?>
    </span>
    </td>
    <td>&nbsp;
    
    </td>
    <td>&nbsp;
    
    </td>
</tr><?php  ?>
<tr>
	<td>&nbsp;
    
    </td>
    <td>&nbsp;
    
    </td>
    <td  colspan="6" style="text-align:center;">
     <span style=" font-weight:bold; font-size:18px;">
    Subject Name : <?php foreach($subject_infos as $subject_info) {echo $subject_info['subject_name'];} ?>
    </span>
    </td>
    <td>&nbsp;
   
    </td>
     <td>&nbsp;
    
    </td>
    
</tr>
<tr>
	<td>&nbsp;
    
    </td>
   <td>&nbsp;
    
    </td>
    <td>&nbsp;
    
    </td>
    <td>
     <span style="font-size:18px;">
    Class Name :
    </span>
    </td>
     <td>
     <span style="font-size:18px;">
   <?php foreach($subject_infos as $subject_info) {echo $subject_info['class_name'];} ?>
    </span>
    </td>
    <td>
    <span style="font-size:18px;">
    Section Name :
    </span>
    </td>
     <td>
    <span style="font-size:18px;">
    <?php foreach($subject_infos as $subject_info) {echo $subject_info['section_name'];} ?>
    </span>
    </td>
     <td>&nbsp;
    
    </td>
    <td>&nbsp;
    
    </td>
    <td>&nbsp;
    
    </td>
</tr>
<tr>
	<td>&nbsp;
    
    </td>
    <td>&nbsp;
    
    </td>
    <td>&nbsp;
    
    </td>
    <td>
     <span style="font-size:18px;">
    	Group Name :
    </span>
    </td>
    <td>
     <span style="font-size:18px;">
    	<?php foreach($subject_infos as $subject_info) {echo $subject_info['group_name'];} ?>
    </span>
    </td>
    <td>
     <span style="font-size:18px;">
    	Shift Name :
    </span>
    </td>
    <td>
    <span style="font-size:18px;">
    <?php foreach($subject_infos as $subject_info) {echo $subject_info['shift_name'];} ?>
    </span>
    </td>
    <td>&nbsp;
   
    </td>
     <td>&nbsp;
    
    </td>
    <td>&nbsp;
    
    </td>
</tr>
<tr>
	<td>&nbsp;
    
    </td>
    <td>&nbsp;
    
    </td>
    <td>&nbsp;
    
    </td>
    <td>
     <span style="font-size:18px;">
    	Term Name :
    </span>
    </td>
    <td>
     <span style="font-size:18px;">
    	<?php foreach($subject_infos as $subject_info) {echo $subject_info['term'];} ?>
    </span>
    </td>
    <td>
     <span style="font-size:18px;">
    	Exam Year :
    </span>
    </td>
    <td>
    <span style="font-size:18px;">
    <?php foreach($subject_infos as $subject_info) {echo $subject_info['exam_year'];} ?>
    </span>
    </td>
    <td>&nbsp;
   
    </td>
     <td>&nbsp;
    
    </td>
    <td>&nbsp;
    
    </td>
</tr>
</table>
	<table width="100%"><tr><td>&nbsp;</td></tr></table><br />

	<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
				<thead>
                    <tr>
						<th>Student ID</th>
                        <th>Roll No</th>
                        <th>Student Name</th>
                        <th>Full Marks</th>
                        <th>Pass Marks</th>
                        <?php
							$school_id= $details['school_id'];
							$passing_id= $details['passing_id'];
							$term_id= $details['term_id'];
							$exam_year= $details['exam_year'];
							$class_id= $details['class_id'];
							$section_id= $details['section_id'];
							$group_id= $details['group_id'];
							$subject_id= $details['subject_id'];
$sql1 = "SELECT distinct(subject_name) as `subject_name`, sub_id as `subject_id`  FROM tbl_subject inner join tbl_term_marks on tbl_term_marks.sub_id = tbl_subject.subject_id inner join tbl_mark_distribution on tbl_mark_distribution.subject_id = tbl_subject.subject_id where tbl_term_marks.term_id='$term_id' and tbl_term_marks.exam_year='$exam_year' and tbl_term_marks.class_id='$class_id' and tbl_term_marks.section_id='$section_id' and tbl_term_marks.sub_id='$subject_id' and tbl_term_marks.school_id='$school_id' order by tbl_subject.subject_id";
		$query1 = mysql_query($sql1);
		 while($resu= mysql_fetch_array($query1))
		{
			$subject1[]=$resu;
			
		}
		$sub_count=0;
		$testmd=0;
		foreach($subject1 as $sub1)
		{
			$sub_count++;
			$testmd=0;
			$mark_distribution='';
			$subject_id1=$sub1['subject_id'];
			$sqlmd = "SELECT * FROM `tbl_mark_distribution` as A WHERE A.school_id = '$school_id' and A.class_id = '$class_id' and A.group_id='$group_id' and A.subject_id='$subject_id1' and A.exam_type!=0 order by A.exam_type";
			$querymd = mysql_query($sqlmd);
			while($mark_distributionsss= mysql_fetch_assoc($querymd))
				{
					$mark_distribution[$testmd]=$mark_distributionsss;
					$testmd++;
				}
			foreach($mark_distribution as $md)
				{
					if($md['exam_type']!=6)
						{
				?>
							<th><?php echo $md['term_mark_per']."%<br/>".$md['exam_short_name']; ?></th>
					<?php }
					else
						{
							$subject_id1=$sub1['subject_id'];
							$sqlsi1 = "SELECT * FROM tbl_subject where subject_id=$subject_id1 order by subject_id limit 1";
							$querysi1 = mysql_query($sqlsi1);
							$sub_num1 = mysql_fetch_array($querysi1);
							if($sub_num1['marks_type']==1)
								{
							?>
                                	<th>Sub</th>
                                    <th><?php echo $md['term_mark_per']."%<br/>"; ?>Sub Total</th>
                                    <th>Total</th>
                                    <th>Grede Point</th>
                            <?php
								}
							elseif($sub_num1['marks_type']==2)
								{
							?>
                           			<th>Sub</th>
                        			<th>Obj</th>
                                    <th><?php echo $md['term_mark_per']."%<br/>"; ?>Sub Total</th>
                                    <th>Total</th>
                                    <th>Grede Point</th>
                            <?php
								}
							else
								{
							?>
                                    <th>Sub</th>
                                    <th>Obj</th>
                                    <th>Prac</th>
                                    <th><?php echo $md['term_mark_per']."%<br/>"; ?>Sub Total</th>
                                    <th>Total</th>
                                    <th>Grede Point</th>
                            <?php }
						}
				}
						?>
     <?php } ?>
					</tr>
				</thead>
				<tbody>
               
					<?php foreach($student_list as $sl){ ?>
						<tr>
							<td>
							<input type="hidden" readonly class="form-control" name="student_id[]" id="student_id" value="<?php echo $sl['student_id'];?>">
                            <?php echo $sl['student_id'];?>
							</td>
                            <td>
                            <?php echo $sl['roll_no'];?>
							</td>
							<td>
                            <?php echo $sl['student_name'];?>
							</td>
							<?php
							$student_id =$sl['student_id'];
							$term_id= $details['term_id'];
							$exam_year= $details['exam_year'];
		$sql = "SELECT * FROM `tbl_term_marks` where student_id='$student_id' and term_id='$term_id' and exam_year='$exam_year' and sub_id=$subject_id order by sub_id";
		$query = mysql_query($sql);
		$i=0;
        while($numbers= mysql_fetch_array($query))
		{
			$results[$i]=$numbers;
			$i++;
		}
		
								$grand_total=0;
								$grand_total_point=0;
								$testmdss=0;
								$testmdm=0;
								$ct_term_add=0;
							foreach($results as $rs)
							{
								$ct_marks=0;
								$sub_ct=0;
								$ct_term_add=0;
								$result_status=$rs['status'];
								
								$type_id= $details['type_id'];
								$class_id= $details['class_id'];
								$school_id= $details['school_id'];
								$shift_id= $details['shift_id'];
								$subject_id = $rs['sub_id'];
								$class_id= $rs['class_id'];
								$section_id= $rs['section_id'];
								$group_id= $rs['group_id'];
								$exam_year= $rs['exam_year'];
								$student_id = $sl['student_id'];
								
								//********* CA *******/
								$sqlca = "SELECT * FROM `tbl_ca_marks` WHERE school_id = '$school_id' and class_id='$class_id' and section_id='$section_id' and group_id='$group_id' and subject_id= '$subject_id' and student_id= '$student_id' and exam_year='$exam_year' and term_id='$term_id'";
								$queryca = mysql_query($sqlca);
								$ca_mrk= mysql_fetch_array($queryca);
								if($ca_mrk)
								{
									$sub_ca=$ca_mrk['obtained_marks'];
								}
								else
								{
									$sub_ca=0;
								}
								//********* / CA *******/
								
								//********* CW *******/
								$sqlcw = "SELECT * FROM `tbl_cw_marks` WHERE school_id = '$school_id' and class_id='$class_id' and section_id='$section_id' and group_id='$group_id' and student_id= '$student_id' and exam_year='$exam_year' and subject_id='$subject_id' and term_id='$term_id'";
								$querycw = mysql_query($sqlcw);
								$cw_mrk= mysql_fetch_array($querycw);
								if($cw_mrk)
								{
									$sub_cw=$cw_mrk['obtained_marks'];
								}
								else
								{
									$sub_cw=0;
								}
								//********* / CW *******/
								//********* HW *******/
								$sqlhw = "SELECT * FROM `tbl_hw_marks` WHERE school_id = '$school_id' and class_id='$class_id' and section_id='$section_id' and group_id='$group_id' and student_id= '$student_id' and exam_year='$exam_year' and subject_id='$subject_id' and term_id='$term_id'";
								$queryhw = mysql_query($sqlhw);
								$hw_mrk= mysql_fetch_array($queryhw);
								if($hw_mrk)
								{
									$sub_hw=$hw_mrk['obtained_marks'];
								}
								else
								{
									$sub_hw=0;
								}
								//********* / HW *******/

								//********* CT *******/
								$sqlct = "SELECT * FROM `tbl_ct_marks` as A WHERE A.school_id = '$school_id'  and A.term_id=$term_id and A.exam_year = '$exam_year' and A.subject_id= '$subject_id' and A.class_id= '$class_id' and A.section_id= '$section_id' and A.group_id = '$group_id' and A.shift_id= '$shift_id' and A.student_id= '$student_id'";
								$queryct = mysql_query($sqlct);
								$ct_mrk= mysql_fetch_array($queryct);
								
								$ct_marks=$ct_mrk['obtained_marks'];
								if($ct_marks)
								{
									$sub_ct=$ct_marks;
								}
								else
								{
									$sub_ct=0;
								}
								//********* / CT *******/
								
								//********* AS/P *******/
								$sqlasp = "SELECT sum(obtained_marks) as obtained_marks FROM `tbl_project_marks` as A WHERE A.school_id = '$school_id' and A.subject_id= '$subject_id' and A.student_id= '$student_id' and exam_year='$exam_year' A.term_id='$term_id'";
								$queryasp = mysql_query($sqlasp);
								$asp_mrk= mysql_fetch_array($queryasp);
								
								
								$sqlasp1 = "SELECT * FROM `tbl_project_assignment` as A WHERE A.school_id = '$school_id' and A.sub= '$subject_id' and A.class= '$class_id' and A.section='$section_id' and A.term = '$term_id' and A.group_id = '$group_id'";
								$queryasp1 = mysql_query($sqlasp1);
								$asp_full_mrk= mysql_fetch_array($queryasp1);
								$asp_num_row= mysql_num_rows($queryasp1);
								
								$asp_marks=$asp_mrk['obtained_marks']/$asp_num_row;
								if($asp_marks)
								{
									$sub_asp=$asp_marks;
								}
								else
								{
									$sub_asp=0;
								}
								//print_r($rs);
								$sqletful = "SELECT * FROM `tbl_subject_wise_total_marks` as A WHERE A.school_id = '$school_id' and A.subject_id= '$subject_id' and A.class_id= '$class_id' limit 1";
								$queryetful = mysql_query($sqletful);
        						$et_full_mrk= mysql_fetch_array($queryetful);
								
								$et_sub_full_marks=$et_full_mrk['subjective_marks'];
								$et_obj_full_marks=$et_full_mrk['objective_marks'];
								$et_prac_full_marks=$et_full_mrk['practical_marks'];
								
								$et_total_full_marks=$et_sub_full_marks+$et_obj_full_marks+$et_prac_full_marks;
								$sub_marks=$rs['subjective_marks'];
								
											if($sub_marks)
											{
												$sub_sub=$sub_marks;
											}
											else
											{
												$sub_sub=0;
											}
								
								$obj_marks=$rs['objective_marks'];
								
											if($obj_marks)
											{
												$sub_obj = $obj_marks;
											}
											else
											{
												$sub_obj = 0;
											}
								
								$prac_marks=$rs['practical_marks'];
								
											if($prac_marks)
											{
												$sub_prac=$prac_marks;
											}
											else
											{
												$sub_prac= 0;
											}
				
							$sub_total=$sub_marks+$obj_marks+$prac_marks;
							$testmdss=0;
							$mark_distss='';
						$sqlmds = "SELECT * FROM `tbl_mark_distribution` as A WHERE A.school_id = '$school_id' and A.class_id = '$class_id' and A.group_id='$group_id' and A.subject_id='$subject_id' and A.exam_type!=0 order by A.exam_type";
			$querymds = mysql_query($sqlmds);
			while($mark_dis= mysql_fetch_array($querymds))
				{
					$mark_distss[$testmdss]=$mark_dis;
					$testmdss++;
				}
				$sub_wise_mark_dis_mark=0;
				$sub_wise_mark_dis_mark_sub=0;
				$ca_per=0;
				$cw_per=0;
				$hw_per=0;
				$ct_per=0;
				$asp_per=0;
				$et_per=0;
							 foreach($mark_distss as $mdmc)
							 {
								 if($mdmc['exam_type']==1)
									{
										$ca_per=$mdmc['term_mark_per']; 
									}
								elseif($mdmc['exam_type']==2)
									{
										$cw_per= $mdmc['term_mark_per'];
									}
								elseif($mdmc['exam_type']==3)
									{
										$hw_per= $mdmc['term_mark_per'];
									}
								elseif($mdmc['exam_type']==4)
									{
										$ct_per= $mdmc['term_mark_per'];//echo  $mdmc['term_mark_per'];
										//$ct_pass_marks = $ct_full_mrk['pass_marks']*$ct_full_mrk['ct_marks']/100;
										//$ct_term_add=($sub_ct*$ct_per)/$ct_full_mrk['ct_marks'];
										//echo  $ct_term_add;
									}
								elseif($mdmc['exam_type']==5)
									{
										$asp_per= $mdmc['term_mark_per'];
										$asp_term_add=($sub_asp*$asp_per)/$asp_full_mrk['marks'];
									}
								elseif($mdmc['exam_type']==6)
									{
										$et_per= $mdmc['term_mark_per'];
										$term_add=($sub_total*$et_per)/$et_total_full_marks;
									}
								 }
			
							$sub_wise_total=$term_add+$sub_ca+$sub_cw+$sub_hw+$sub_ct+$asp_term_add;
							$sub_wise_mark_dis_mark_sub=$ca_per+$cw_per+$hw_per+$ct_per+$asp_per+$et_per;
							$sub_wise_mark_dis_mark=($sub_wise_total*100)/$sub_wise_mark_dis_mark_sub;
							//echo $sub_wise_mark_dis_mark."<br/>";
							$sqlgs = "SELECT * FROM `tbl_grd_system` as A WHERE A.school_id = '$school_id' and A.type_id='$type_id'";
							$querygs = mysql_query($sqlgs);
							$igs=0;
							while($gread_scale= mysql_fetch_array($querygs))
								{
									$gread_scales[$igs]=$gread_scale;
									$igs++;
								}
								$itgp=0;
								
							//print_r($gread_scales);echo "000000000000";
							foreach($gread_scales as $gss)
							{
								$start_marks=$gss['start_marks'];
								if($sub_wise_mark_dis_mark>=$start_marks)
								{
									$total_grade_point[$itgp]=$gss['grd_point'];
									$itgp++;
								}
							}
							$grand_total_point+=$total_grade_point[0];
							$grand_total+=$sub_wise_total;
							
							$testmdm=0;
							$mark_distmdm='';
                          $sqlmdm = "SELECT * FROM `tbl_mark_distribution` as A WHERE A.school_id = '$school_id' and A.class_id = '$class_id' and A.group_id='$group_id' and A.subject_id='$subject_id' and A.exam_type!=0 order by A.exam_type";
			$querymdm = mysql_query($sqlmdm);
			while($mark_dismdm= mysql_fetch_array($querymdm))
				{
					$mark_distmdm[$testmdm]=$mark_dismdm;
					$testmdm++;
				}
                 $ct_flag=0;
				 $sub_flag=0;
				 $obj_flag=0;
				 $prac_flag=0;
				 
				 
				 $et_pass_mrk=0;
							$sqletpass = "SELECT * FROM `tbl_term_subject` as A WHERE A.school_id = '$school_id' and A.subject_id= '$subject_id' and A.class_id= '$class_id' and A.group_id='$group_id' and A.term_id='$term_id' limit 1";
							$queryetpass = mysql_query($sqletpass);
        					$et_pass_mrk= mysql_fetch_array($queryetpass);
								//print_r($et_pass_mrk); 
							$term_pass_mark_sub = $et_pass_mrk['pass_marks']*$et_sub_full_marks/100;
							$term_pass_mark_obj = $et_pass_mrk['pass_marks']*$et_obj_full_marks/100;
							$term_pass_mark_prac = $et_pass_mrk['pass_marks']*$et_prac_full_marks/100;
							$ct_pass_marks = $et_pass_mrk['pass_marks']*$ct_per/100;
							$term_pass_mark = $et_pass_mrk['pass_marks']*$et_pass_mrk['sub_full_marks']/100;
						?>
							<td>
            				<?php echo $et_pass_mrk['sub_full_marks'];?>
							</td>
                            <td>
            				<?php echo $et_pass_mrk['pass_marks'];?>
							</td>
                     <?php		
							
				            foreach($mark_distmdm as $mdss)
				{
					if($mdss['exam_type']==1)
						{
				?>
							 <td>
            				<?php echo round(($sub_ca),1);?>
							</td>
					<?php
						 }
					elseif($mdss['exam_type']==2)
					{
						?>
                         <td>
            			<?php echo round(($sub_cw),1);?>
						</td>
                        <?php
					}
					elseif($mdss['exam_type']==3)
					{
						?>
                         <td>
            			<?php echo round(($sub_hw),1);?>
						</td>
                        <?php
					}
					elseif($mdss['exam_type']==4)
					{
						?>
                         <td>
            <span <?php if($ct_pass_marks >$sub_ct && $passing_id==1){ $ct_flag=1; echo 'style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"' ;} else {echo 'style="width:100%; border-bottom:0px solid #43CD80; color:#000; font-weight:bold;"' ;} ?>>
							<?php echo round(($sub_ct),1);?>
							</span>
            			
						</td>
                        <?php
					}
					elseif($mdss['exam_type']==5)
					{
						?>
                         <td>
            <?php echo round(($sub_asp),1);?>
							</td>
                        <?php
					}
					elseif($mdss['exam_type']==6)
						{
							$sqlsi1 = "SELECT * FROM tbl_subject where subject_id=$subject_id order by subject_id limit 1";
							$querysi1 = mysql_query($sqlsi1);
							$sub_num1 = mysql_fetch_array($querysi1);
							if($sub_num1['marks_type']==1)
								{
							?>
                                	<td>
 <span <?php if($term_pass_mark_sub >round(($sub_marks),1) && $passing_id==1){ $sub_flag=1; echo 'style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"' ;} else {echo 'style="width:100%; border-bottom:0px solid #43CD80; color:#000; font-weight:bold;"' ;} ?>>
            				<?php echo round(($sub_marks),1);?>
                            </span>
							</td>
                            <?php
								}
							elseif($sub_num1['marks_type']==2)
								{
							?>
                           			<td>
             <span <?php if($term_pass_mark_sub >round(($sub_marks),1) && $passing_id==1){ $sub_flag=1; echo 'style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"' ;} else {echo 'style="width:100%; border-bottom:0px solid #43CD80; color:#000; font-weight:bold;"' ;} ?>>
            				<?php echo round(($sub_marks),1);?>
                            </span>
							</td>
                        		 <td>
             <span <?php if($term_pass_mark_obj >round(($obj_marks),1) && $passing_id==1){ $obj_flag=1; echo 'style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"' ;} else {echo 'style="width:100%; border-bottom:0px solid #43CD80; color:#000; font-weight:bold;"' ;} ?>>
            				<?php echo round(($obj_marks),1);?>
                            </span>
							</td>
                            <?php
								}
							else
								{
							?>
                                    <td>
             <span <?php if($term_pass_mark_sub >round(($sub_marks),1) && $passing_id==1){ $sub_flag=1; echo 'style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"' ;} else {echo 'style="width:100%; border-bottom:0px solid #43CD80; color:#000; font-weight:bold;"' ;} ?>>
            				<?php echo round(($sub_marks),1);?>
                            </span>
							</td>
                              <td>
             <span <?php if($term_pass_mark_obj >round(($obj_marks),1) && $passing_id==1){ $obj_flag=1; echo 'style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"' ;} else {echo 'style="width:100%; border-bottom:0px solid #43CD80; color:#000; font-weight:bold;"' ;} ?>>
            				<?php echo round(($obj_marks),1);?>
                            </span>
							</td>
                            <td>
             <span <?php if($term_pass_mark_prac > round(($prac_marks),1) && $passing_id==1){ $prac_flag=1; echo 'style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"' ;} else {echo 'style="width:100%; border-bottom:0px solid #43CD80; color:#000; font-weight:bold;"' ;} ?>>
            				<?php echo round(($prac_marks),1);?>
                            </span>
							</td>
                            <?php } ?>
                            
							<td>
             <span <?php if( $term_pass_mark > round(($sub_total),1) || $prac_flag==1 || $obj_flag==1 || $sub_flag==1){echo 'style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"' ;} else {echo 'style="width:100%; border-bottom:0px solid #43CD80; color:#000; font-weight:bold;"' ;} ?>>
            				<?php echo round(($sub_total),1);?>
                            </span>
							</td>
                            <td>
             <span <?php if($term_pass_mark > round(($sub_wise_total),1) || $ct_flag==1 || $prac_flag==1 || $obj_flag==1 || $sub_flag==1){echo 'style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"' ;} else {echo 'style="width:100%; border-bottom:0px solid #43CD80; color:#000; font-weight:bold;"' ;} ?>>
            				<?php echo round(($sub_wise_total),1);?>
                            </span>
							</td>
                             <td>
             <span <?php if($total_grade_point[0] == 0 || $ct_flag==1  || $prac_flag==1 || $obj_flag==1 || $sub_flag==1){echo 'style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"' ;} else {echo 'style="width:100%; border-bottom:0px solid #43CD80; color:#000; font-weight:bold;"' ;} ?>>
            				<?php
							if($total_grade_point[0] == 0 || $ct_flag==1  || $prac_flag==1 || $obj_flag==1 || $sub_flag==1)
							{
							 echo "0";
							}
							else
							{
								echo $total_grade_point[0];
							}
							 ?>
                            </span>
							</td>
			<?php } ?>
            <?php
				}
             } ?>
						</tr>
					<?php	} ?>
					<tr>
					<td>
					<input type="submit" class="btn btn-primary" name="fees_gen" value="Print Tabulation Sheet"/>
                    </form>
					</td>
                    <td>  </td>
                    <td> <?php if($ct_mrk['status']==1 || $result_status==1) { ?>
                    		<form role="form" method="POST" action="<?php echo base_url();?>school/marks_status_change">
                            <input type="hidden" name="status" value="0" />
                            <input type='hidden' name='school_id' value='<?php echo $details['school_id']; ?>' />
                             <input type='hidden' name='class_id' value='<?php echo $details['class_id']; ?>' />
                            <input type='hidden' name='section_id' value='<?php echo $details['section_id']; ?>' />
                            <input type='hidden' name='group_id' value='<?php echo $details['group_id']; ?>' />											
                            <input type='hidden' name='shift_id' value='<?php echo $details['shift_id']; ?>' />
                            <input type='hidden' name='subject_id' value='<?php echo $details['subject_id']; ?>' />
                            <input type='hidden' name='exam_year' value='<?php echo $details['exam_year']; ?>' /> 
                            <input type='hidden' name='term_id' value='<?php echo $details['term_id']; ?>' />
                             
                    		<input type="submit" class="btn btn-danger" name="fees_gen" value="Final Submit"/><br />
                            </form>

                            <strong>NB :</strong> After final submit only admin can edit marks.
                            <?php } ?>
                    </td>
					</tr>
				</tbody>
			</table>
</div>
