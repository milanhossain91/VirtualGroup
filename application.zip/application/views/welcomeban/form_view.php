<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">Form</h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here:</li>
                            <li><a href="<?php echo base_url();?>">Home</a><i class="fa fa-angle-right"></i></li>
                            <li class="current">Form</li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                <div class="page-content">
                    <div class="row notice_view">
                        <?php
                            foreach($form_list as $nl){ ?>
                            <article class="contact-form col-md-12 col-sm-12  page-row">                            

                                <div class="details col-md-10 col-sm-10 col-xs-10">
                                    
                                    
                                    <p>
                                        <?php echo $nl['notice_heading'];?>
                                   
								
                                                                    <?php
                                        if($nl['notice_attachment']!=''){ ?>
                                            <a href="<?php echo base_url();?>template/upload/notice_file/<?php echo $nl['notice_attachment'];?>" target="_blank" title="Attachment File"><i class="fa fa-paperclip" style="font-size:50px;"></i></a>
                                    <?php    } ?>
                                
                                    </p>
                                </div>
                            </article>
                        <hr />
                        <?php    } ?>
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper--> 
        </div><!--//content-->
        
    </div><!--//wrapper-->

    
<?php require 'application/views/welcome/includes/footer.php';?>    
    
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/plugins/gmaps/gmaps.js"></script>            
    <script type="text/javascript" src="<?php echo base_url();?>template/js/map.js"></script>