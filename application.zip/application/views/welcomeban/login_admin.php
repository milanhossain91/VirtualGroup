<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->  
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->  
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]--> 
<?php
    $sql = "SELECT * FROM tbl_school_information LIMIT 1";
    $query = $this->db->query($sql);
    $s_info = $query->row_array();
?>
<head>
    <title><?php echo $s_info['school_name'];?></title>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">    
    <link rel="shortcut icon" href="<?php echo base_url();?>template/images/favicon.ico">  
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css'>   
    <!-- Global CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>template/plugins/bootstrap/css/bootstrap.min.css">   
    <!-- Plugins CSS -->    
    <link rel="stylesheet" href="<?php echo base_url();?>template/plugins/font-awesome/css/font-awesome.css">
    <link rel="stylesheet" href="<?php echo base_url();?>template/plugins/flexslider/flexslider.css">
    <link rel="stylesheet" href="<?php echo base_url();?>template/plugins/pretty-photo/css/prettyPhoto.css"> 
    <!-- Theme CSS -->  
    <link id="theme-style" rel="stylesheet" href="<?php echo base_url();?>template/css/styles.css">
    <link id="theme-style" rel="stylesheet" href="<?php echo base_url();?>template/css/custom.css">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->   
</head>
<body class="home-page">
    <div class="wrapper" style="margin-bottom:0px">
        <!-- ******HEADER****** --> 
        <header class="header">
            <div class="top-bar">
                <div class="container">
                    <ul class="social-icons col-md-6 col-sm-6 col-xs-12 hidden-xs">
                        <li style="min-height: 80px;"></li>
                    </ul>
                </div>      
            </div><!--//to-bar-->
            <div class="header-main container" style="padding: 10px 0;">
                <div  class="col-md-8 col-sm-8">
                </div>
                
            </div><!--//header-main-->
        </header><!--//header-->
        
       
        
        

    <!-- ******CONTENT****** --> 
        <div class="content container">
            <div class="page-wrapper">
                <div class="page-content">
                    <div class="row page-row">
                        <div class="news-wrapper col-md-10 col-sm-10">
                            <article class="news-item">
                                
                                <class class="row">
                                    <div class="col-md-3"></div>
                                    <div class="col-md-7">
                                        <h1>Admin Login</h1>
                                        <form action="<?php echo base_url();?>admin_login/login_check" method="POST">
                                            <div class="form-group name">
                                                <label for="name">User Name</label>
                                                <input id="username" type="text" name="username" class="form-control" placeholder="Enter your user name">
                                            </div><!--//form-group-->
                                            <div class="form-group email">
                                                <label for="password">Password</label>
                                                <input name="password" type="password" id="password" class="form-control" placeholder="Enter your password">
                                            </div><!--//form-group-->

                                            <button type="submit" class="btn btn-theme">Login</button>
                                        </form>
                                    </div>
                                    <div class="col-md-2"></div>
                                </class>
                               
                                 
                                    
                            </article><!--//news-item-->
                        </div><!--//news-wrapper-->
                        <aside class="page-sidebar  col-md-3 col-md-offset-1 col-sm-4 col-sm-offset-1 col-xs-12">
                        </aside>
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper-->
        </div><!--//content-->
    </div><!--//wrapper-->
    
    <!-- ******FOOTER****** --> 
    <footer class="footer" style="height: 100px;">
        
        <div class="bottom-bar">
            <div class="container">
                <div class="row">
                    <div class="" align="center">
                        <a target="_blank" href="http://copotronic.com">
                            <img width="140" height="70" src="<?php echo base_url();?>template/admin/img/logo.png">
                        </a>
                        <br>
                        © Government College of Commerce, Chittagong 2014.
                    </div>
                </div>
            </div><!--//container-->
        </div><!--//bottom-bar-->
    </footer><!--//footer-->
    
    
 
    <!-- Javascript -->          
    <script type="text/javascript" src="<?php echo base_url();?>template/plugins/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/plugins/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/plugins/bootstrap/js/bootstrap.min.js"></script> 
    <script type="text/javascript" src="<?php echo base_url();?>template/plugins/bootstrap-hover-dropdown.min.js"></script> 
    <script type="text/javascript" src="<?php echo base_url();?>template/plugins/back-to-top.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/plugins/jquery-placeholder/jquery.placeholder.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/plugins/pretty-photo/js/jquery.prettyPhoto.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/plugins/flexslider/jquery.flexslider-min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/plugins/jflickrfeed/jflickrfeed.min.js"></script> 
    <script type="text/javascript" src="<?php echo base_url();?>template/js/main.js"></script>            
</body>

</html> 

