<?php require 'application/views/welcome/includes/header.php';?>
    <!-- ******CONTENT****** --> 
        
    <?php require 'application/views/welcome/includes/slide.php';?>
   
        
<!--start section-->
<!--<section class="nicdark_section nicdark_margintop45_negative">

    <!--start nicdark_container-->
    <!--<div class="nicdark_container nicdark_clearfix">
		
		<div class="grid grid_12 percentage nomargin">    
			<div class="nicdark_textevidence center">
			    <div class="nicdark_textevidence nicdark_width_percentage25 nicdark_bg_blue nicdark_shadow nicdark_radius_left">
			        <div class="nicdark_textevidence">
			            <div class="nicdark_margin30">
			                <h2 class="white subtitle"><a class="white" href="courses.html">COURSES</a></h2>
			           </div>
			            <i class="nicdark_zoom icon-pencil-2 nicdark_iconbg left extrabig blue nicdark_displaynone_ipadland nicdark_displaynone_ipadpotr"></i>
			        </div>
			    </div>
			    <div class="nicdark_textevidence nicdark_width_percentage25 nicdark_bg_yellow nicdark_shadow">
			        <div class="nicdark_textevidence">
			            <div class="nicdark_margin30">
			                <h2 class="white subtitle"><a class="white" href="prices.html">PRICES</a></h2>
			           </div>
			            <i class="nicdark_zoom icon-money-1 nicdark_iconbg left extrabig yellow nicdark_displaynone_ipadland nicdark_displaynone_ipadpotr"></i>
			        </div>
			    </div>
			    <div class="nicdark_textevidence nicdark_width_percentage25 nicdark_bg_orange nicdark_shadow">
			        <div class="nicdark_textevidence">
			            <div class="nicdark_margin30">
			                <h2 class="white subtitle"><a class="white" href="events.html">EVENTS</a></h2>
			           </div>
			            <i class="nicdark_zoom icon-music-2 nicdark_iconbg left extrabig orange nicdark_displaynone_ipadland nicdark_displaynone_ipadpotr"></i>
			        </div>
			    </div>
			    <div class="nicdark_textevidence nicdark_width_percentage25 nicdark_bg_green nicdark_shadow nicdark_radius_right">
			        <div class="nicdark_textevidence">
			            <div class="nicdark_margin30">
			                <h2 class="white subtitle"><a class="white" href="<?php echo base_url();?>teacher">TEACHERS</a></h2>
			           </div>
			            <i class="nicdark_zoom icon-graduation-cap-1 nicdark_iconbg left extrabig green nicdark_displaynone_ipadland nicdark_displaynone_ipadpotr"></i>
			        </div>
			    </div>
			    <div class="nicdark_space5"></div>
			</div>
		</div>

	</div>
    <!--end nicdark_container
     
</section>
<!--end section--><!--start section-->
<section class="nicdark_section">

    <!--start nicdark_container-->
    <div class="nicdark_container nicdark_clearfix">


        <div class="nicdark_space50"></div>


        <div class="grid grid_12">
            <h1 class="subtitle greydark"> About School </h1>
            <div class="nicdark_space20"></div>
            <div class="nicdark_divider left big"><span class="nicdark_bg_yellow nicdark_radius"></span></div>
            <div class="nicdark_space10"></div>
        </div>


        <div class="grid grid_12 nicdark_relative">
          
        <?= $about['about_details'];?>
        </div>

        <div class="nicdark_space50"></div>

    </div>
    <!--end nicdark_container-->
            
</section>
<!--end section-->
<!--start section-->
<section id="nicdark_parallax_countdown" class="nicdark_section nicdark_imgparallax nicdark_parallaxx_img-teachers-1">

    <div class="nicdark_filter greydark">

        <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix">

            <div class="nicdark_space40"></div>
            <div class="nicdark_space50"></div>

            <div class="grid grid_12">
                <h1 class="white center subtitle">First Day at School!</h1>
                <div class="nicdark_space10"></div>
                <h3 class="subtitle center white">Are you ready ?</h3>
                <div class="nicdark_space20"></div>
                <div class="nicdark_divider center big"><span class="nicdark_bg_white nicdark_radius"></span></div> 
                <div class="nicdark_space20"></div>    
            </div>

            <div class="nicdark_countdown"></div>   

            <div class="nicdark_space40"></div>
            <div class="nicdark_space50"></div>

        </div>
        <!--end nicdark_container-->

    </div>
            
</section>
<!--end section--><!--start section-->
<section class="nicdark_section">

    <!--start nicdark_container-->
    <div class="nicdark_container nicdark_clearfix">


        <div class="nicdark_space50"></div>


        <div class="grid grid_12">
            <h1 class="subtitle greydark">MESSAGES </h1>
            <div class="nicdark_space20"></div>
            <div class="nicdark_divider left big"><span class="nicdark_bg_orange nicdark_radius"></span></div>
            <div class="nicdark_space10"></div>
        </div>



        <div class="grid grid_6">
                    
            <div class="nicdark_archive1 nicdark_bg_green nicdark_radius nicdark_shadow">

                <div class="nicdark_textevidence nicdark_width_percentage30 nicdark_width100_responsive">
                    <img alt=""  class="nicdark_radius_left nicdark_opacity nicdark_radius" src="<?= base_url() ?>template/upload/principal_image/<?= $principal_message['principal_image']; ?>" style="border-radius:100px;">
                </div>
                
                <div class="nicdark_textevidence nicdark_width_percentage50 nicdark_width100_responsive">
                    <div class="nicdark_margin20" style="color:#fff !important;">
                    
                        <h4 class="white"><a class="white" href="">Chairman’s message</a></h4>                        
                        <div class="nicdark_space20"></div>
                        <div class="nicdark_divider left small"><span class="nicdark_bg_white nicdark_radius"></span></div>
                        <div class="nicdark_space20"></div>
                        <p class="white"><?php $pmsg= explode(' ' , $principal_message['principal_message']);
											for($i=0; $i<=20; $i++)
											{
											echo $pmsg[$i]." " ;
											}
											?>
                        </p>
                        <div class="nicdark_space20"></div>
                        <a href="<?php echo base_url();?>welcome/principal_message/<?php echo $principal_message['message_id'];?>" class="white nicdark_btn"><i class="icon-graduation-cap-1"></i> Read More :)</a>

                    </div>
                </div>

                <!--<div class="nicdark_textevidence nicdark_width_percentage10 nicdark_displaynone_responsive">
                    <div class="nicdark_space20"></div>
                    <div class="nicdark_space5"></div>
                    <a title="CURRICULUM" href="single-teacher.html" class="nicdark_rotate nicdark_tooltip nicdark_btn_icon small nicdark_bg_orangedark nicdark_radius_circle white"><i class="icon-download-outline"></i></a>
                    <div class="nicdark_space20"></div>
                    <a title="DOCUMENTS" href="single-teacher.html" class="nicdark_rotate nicdark_tooltip nicdark_btn_icon small nicdark_bg_orangedark nicdark_radius_circle white"><i class="icon-attach-outline"></i></a>
                    <div class="nicdark_space20"></div>
                    <a title="COURSES" href="single-teacher.html" class="nicdark_rotate nicdark_tooltip nicdark_btn_icon small nicdark_bg_orangedark nicdark_radius_circle white"><i class="icon-mic-outline"></i></a>
                    <div class="nicdark_space20"></div>
                </div>-->

            </div>

        </div>

        <div class="grid grid_6">
            
            <div class="nicdark_archive1 nicdark_bg_blue nicdark_radius nicdark_shadow">

                <div class="nicdark_textevidence nicdark_width_percentage30 nicdark_width100_responsive">
                     <img alt=""  class="nicdark_radius_left nicdark_opacity nicdark_radius" src="<?= base_url() ?>template/upload/principal_image/<?= $vice_principal_message['principal_image']; ?>" style="border-radius:100px;">
                </div>
                
                <div class="nicdark_textevidence nicdark_width_percentage50 nicdark_width100_responsive">
                    <div class="nicdark_margin20">
                    
                        <h4 class="white"><a class="white" href="">Headmaster’s Message</a></h4>                        
                        <div class="nicdark_space20"></div>
                        <div class="nicdark_divider left small"><span class="nicdark_bg_white nicdark_radius"></span></div>
                        <div class="nicdark_space20"></div>
                        <p class="white"><?php $pmsg= explode(' ' , $vice_principal_message['principal_message']);
											for($i=0; $i<=20; $i++)
											{
											echo $pmsg[$i]." " ;
											}
											?></p>
                        <div class="nicdark_space20"></div>
                        <a href="<?php echo base_url();?>welcome/principal_message/<?php echo $vice_principal_message['message_id'];?>" class="white nicdark_btn"><i class="icon-graduation-cap-1"></i> Read More :)</a>

                    </div>
                </div>

                <!--<div class="nicdark_textevidence nicdark_width_percentage10 nicdark_displaynone_responsive">
                    <div class="nicdark_space20"></div>
                    <div class="nicdark_space5"></div>
                    <a title="CURRICULUM" href="single-teacher.html" class="nicdark_rotate nicdark_tooltip nicdark_btn_icon small nicdark_bg_bluedark nicdark_radius_circle white"><i class="icon-download-outline"></i></a>
                    <div class="nicdark_space20"></div>
                    <a title="DOCUMENTS" href="single-teacher.html" class="nicdark_rotate nicdark_tooltip nicdark_btn_icon small nicdark_bg_bluedark nicdark_radius_circle white"><i class="icon-attach-outline"></i></a>
                    <div class="nicdark_space20"></div>
                    <a title="COURSES" href="single-teacher.html" class="nicdark_rotate nicdark_tooltip nicdark_btn_icon small nicdark_bg_bluedark nicdark_radius_circle white"><i class="icon-mic-outline"></i></a>
                    <div class="nicdark_space20"></div>
                </div>
-->
            </div>

        </div>
        <div class="nicdark_space50"></div>


	</div>
	<!--end nicdark_container-->
            
</section>
<!--end section-->
<!--start section-->
<div id="nicdark_parallax_2_btns" class="nicdark_section nicdark_imgparallax nicdark_parallax_img2">


    <!--start nicdark_container-->
    <div class="nicdark_container nicdark_clearfix">

        <div class="nicdark_space40"></div>
        <div class="nicdark_space50"></div>

        <div class="grid grid_6 nicdark_aligncenter_iphoneland nicdark_aligncenter_iphonepotr">
            <a href="<?php echo base_url();?>admin" class="nicdark_disable_floatright_iphoneland nicdark_disable_floatright_iphonepotr nicdark_btn nicdark_bg_blue medium right nicdark_shadow nicdark_radius white nicdark_press"><i class="icon-mobile-2"></i>&nbsp;&nbsp;&nbsp;SMS Gateway</a>
        </div>
        <div class="grid grid_6 nicdark_aligncenter_iphoneland nicdark_aligncenter_iphonepotr">
            <a href="http://www.wristsup.com/webmail" class=" nicdark_btn nicdark_bg_blue medium nicdark_shadow nicdark_radius white nicdark_press"><i class="icon-mail-2"></i>&nbsp;&nbsp;&nbsp;Webmail Login</a>
        </div>

        <div class="nicdark_space40"></div>
        <div class="nicdark_space50"></div>

    </div>
    <!--end nicdark_container-->

            
</div>
<!--end section-->

<!--start section-->
<section class="nicdark_section">

    <!--start nicdark_container-->
    <div class="nicdark_container nicdark_clearfix">


        <div class="nicdark_space50"></div>

        <div class="grid grid_12">
            <h1 class="subtitle greydark">OUR NEWS</h1>
            <div class="nicdark_space20"></div>
            <h3 class="subtitle grey">FOLLOW OUR MOST IMPORTANT NEWS</h3>
            <div class="nicdark_space20"></div>
            <div class="nicdark_divider left big"><span class="nicdark_bg_blue nicdark_radius"></span></div>
            <div class="nicdark_space10"></div>
        </div>

        
        <div class="nicdark_masonry_btns">
            <div class="nicdark_margin10">
                <a data-filter="*" class="nicdark_bg_grey2_hover nicdark_transition nicdark_btn nicdark_bg_grey small nicdark_shadow nicdark_radius grey">ALL</a>
            </div>
            <div class="nicdark_margin10">
                <a data-filter=".GeneralNotice" class="nicdark_bg_grey2_hover nicdark_transition nicdark_btn nicdark_bg_grey small nicdark_shadow nicdark_radius grey">General Notice</a>
            </div>
            <div class="nicdark_margin10">
                <a data-filter=".AdmissionNotice" class="nicdark_bg_grey2_hover nicdark_transition nicdark_btn nicdark_bg_grey small nicdark_shadow nicdark_radius grey">Admission Notice</a>
            </div>
            <div class="nicdark_space10"></div>
        </div>

 <!--start nicdark_masonry_container-->
        <div class="nicdark_masonry_container">
 <?php
                                        $i=1;
                                        foreach($notice_list_first as $nl){ ?>	 
                                                
                                                <?php 
                                                   $string= $nl['notice_details'];
                                                        if (strlen($string) > 550) {
                                                        $stringCut = substr($string, 0, 550);

                                                        $string = substr($stringCut, 0, strrpos($stringCut, ' '));
                                                        }
                                                        //echo $string;
														?>
			<div class="grid grid_4 nicdark_masonry_item <?php if($nl['notice_type']==1){ echo "GeneralNotice";} else{ echo "AdmissionNotice";}?>">
                <div class="nicdark_archive1 nicdark_bg_blue nicdark_radius nicdark_shadow">
                    
                   <!-- <a href="single-post-right-sidebar.html" class="nicdark_zoom nicdark_btn_icon nicdark_bg_blue nicdark_border_bluedark white medium nicdark_radius_circle nicdark_absolute_left"><i class="icon-link-outline"></i></a>-->

                    
                    <div class="nicdark_margin20">
                        <h4 class="white"><a href="<?= base_url();?>welcome/single_notice/<?= $nl['notice_id'];?>"><?= $nl['notice_heading'];?></a></h4>
                        <div class="nicdark_space20"></div>
                        <div class="nicdark_divider left small"><span class="nicdark_bg_white nicdark_radius"></span></div>
                        <div class="nicdark_space20"></div>
                        <p class="white"><?= $string ?></p>
                        <div class="nicdark_space20"></div>
                        <a href="<?php echo base_url();?>welcome/single_notice/<?php echo $nl['notice_id'];?>" class="white nicdark_btn"><i class="icon-doc-text-1 "></i> Read more</a>                  
                    </div>

                    <i class="icon-camera-outline nicdark_iconbg right medium blue"></i>

                </div>
            </div>
                                               
                                        <?php    $i++; } ?>


        </div>
        <!--end nicdark_masonry_container-->

    </div>
    <!--end nicdark_container-->
            
</section>
<!--end section-->

<!--start section-->
<section class="nicdark_section">


    <!--start nicdark_container-->
    <div class="nicdark_container nicdark_clearfix">

        <div class="nicdark_space30"></div>

        <div class="grid grid_12">
            <div class="nicdark_textevidence center">
                <a href="#" class="nicdark_zoom nicdark_btn nicdark_bg_blue medium nicdark_shadow nicdark_radius white nicdark_margin10"><i class="icon-th-outline"></i>&nbsp;&nbsp;&nbsp;View More</a>
            </div>
        </div>

        <div class="nicdark_space40"></div>

    </div>
    <!--end nicdark_container-->

            
</section>
<!--end section-->



<!--start section-->
<section id="nicdark_parallax_counter" class="nicdark_section nicdark_imgparallax nicdark_parallax_img1">

    <div class="nicdark_filter greydark">

        <!--start nicdark_container-->
        <div class="nicdark_container nicdark_clearfix">

            <div class="nicdark_space40"></div>
            <div class="nicdark_space50"></div>


            <div class="grid grid_3">
                <div class="nicdark_textevidence center">
                    <a href="#" class="nicdark_width50 white nicdark_btn nicdark_bg_blue nicdark_bg_bluedark_hover nicdark_transition nicdark_shadow extrasize nicdark_radius_circle subtitle nicdark_counter" data-to="69" data-speed="1000">69</a>
                    <div class="nicdark_space20"></div>
                    <h4 class="white">TEACHERS</h4>
                </div>
            </div>
            <div class="grid grid_3">
                <div class="nicdark_textevidence center">
                    <a href="#" class="nicdark_width50 white nicdark_btn nicdark_bg_green nicdark_bg_greendark_hover nicdark_transition nicdark_shadow extrasize nicdark_radius_circle subtitle nicdark_counter" data-to="32" data-speed="1000">32</a>
                    <div class="nicdark_space20"></div>
                    <h4 class="white">STUDENTS</h4>
                </div>
            </div>
            <div class="grid grid_3">
                <div class="nicdark_textevidence center">
                    <a href="#" class="nicdark_width50 white nicdark_btn nicdark_bg_yellow nicdark_bg_yellowdark_hover nicdark_transition nicdark_shadow extrasize nicdark_radius_circle subtitle nicdark_counter" data-to="48" data-speed="1000">48</a>
                    <div class="nicdark_space20"></div>
                    <h4 class="white">LESSONS</h4>
                </div>
            </div>
            <div class="grid grid_3">
                <div class="nicdark_textevidence center">
                    <a href="#" class="nicdark_width50 white nicdark_btn nicdark_bg_violet nicdark_bg_violetdark_hover nicdark_transition nicdark_shadow extrasize nicdark_radius_circle subtitle nicdark_counter" data-to="72" data-speed="1000">72</a>
                    <div class="nicdark_space20"></div>
                    <h4 class="white">ACTIVITIES</h4>
                </div>
            </div>

            <div class="nicdark_space40"></div>
            <div class="nicdark_space50"></div>

        </div>
        <!--end nicdark_container-->

    </div>
            
</section>
<!--end section-->
<!--start section-->
<section class="nicdark_section">

    <!--start nicdark_container-->
    <div class="nicdark_container nicdark_clearfix">


        <div class="nicdark_space20"></div>

        <div class="grid grid_12">
                    
            <!--archive1-->
            <div class="nicdark_archive1 nicdark_radius nicdark_shadow">
                <div class="nicdark_textevidence nicdark_bg_green">
                    <h4 class="white nicdark_margin20">Find us on map</h4>
                </div>
                 
                <div class="nicdark_margin5" style="width:100%;">
               <section class="maps" style="max-height:250px; width:100%; text-align:center;">
                        
						<div id="map"></div>
                    </section>
                    <!--<h5 class="white"><i class="icon-pin-outline"></i> New York, Times Square</h5>
                    <div class="nicdark_space10"></div>
                    <h5 class="white"><i class="icon-clock-1"></i> 9:00 To 14:00</h5>
                    <div class="nicdark_space20"></div>
                    <div class="nicdark_divider left small"><span class="nicdark_bg_white nicdark_radius"></span></div>
                    <div class="nicdark_space20"></div>
                    <p class="white">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque tincidunt rutrum.</p>
                    <div class="nicdark_space20"></div>
                    <a href="single-event.html" class=" nicdark_press nicdark_btn nicdark_bg_greendark white nicdark_radius nicdark_shadow medium">CHECK IT</a>-->
                </div>

            </div>
            <!--archive1-->

        </div>


        <div class="nicdark_space50"></div>

   </div>
   <!--end nicdark_container-->
            
</section>
<!--end section-->
       
    <?php require 'application/views/welcome/includes/footer.php';?>    