<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container" style="width:95%; margin:0px auto; background-color:#FFF; ">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left"> ছাত্র/ছাত্রী তালিকা </h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">আপনি এখানে আছেন :</li>
                            <li><a href="<?php echo base_url();?>">হোম </a><i class="fa fa-angle-right"></i></li>
                            <li class="current"> ছাত্র/ছাত্রী তালিকা </li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                
                
                <div class="page-content">
                    <div class="row page-row">
                        <div class="news-wrapper col-md-10 col-sm-10 ">
                            <article class="news-item" style="min-height: 200px;">
                                
                                <?php 
                                    foreach($class_list as $cl){  
                                    $class_id = $cl['class_id'];
                                    $class_query = "SELECT * FROM tbl_class where class_id = $class_id limit 1";
                                    $class = $this->db->query($class_query);
                                    $class_list= $class->row_array();
                                ?> 
                                
                                
                                <h3 class="has-divider text-highlight"><?php echo $class_list['class_name'];?></h3> 
                                    <div class="table-responsive">
                                        <table class="table table-condensed">
                                            <thead>
                                                <tr>
                                                    <th>Department Name</th>
                                                    <th>Total Students</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                    $cl=  "SELECT * FROM tbl_class_assign where class_id = $class_id order by class_assign_id asc";
                                                    $cl_query = $this->db->query($cl);
                                                    $cl_list= $cl_query->result_array();
                                                    foreach($cl_list as $cl_l){ ?>
                                                <tr>
                                                    <td>
                                                        <?php  
                                                            $department_id = $cl_l['department_id']; 
                                                            $department_query = "SELECT * FROM tbl_group where group_id = $department_id limit 1";
                                                            $department= $this->db->query($department_query);
                                                            $department_list= $department->row_array();
                                                            echo $department_list['group_name'];
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php
                                                            $total_student_query = "SELECT * FROM `tbl_student` inner join `tbl_student_class` on `tbl_student_class`.student_id =`tbl_student`.student_id WHERE tbl_student_class.class_id=$class_id and tbl_student_class.group_id = $department_id";
                                                            $t_student= $this->db->query($total_student_query);
                                                            $total_stu= $t_student->num_rows();
                                                            echo $total_stu;
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo base_url();?>student_details?cid=<?php echo $class_id;?>&did=<?php echo $department_id;?>">Details</a>
                                                    </td>
                                                </tr>
                                                <?php    } ?>
                                            </tbody>
                                        </table><!--//table-->
                                    </div><!--//table-responsive-->
                                   <hr />
                                    <br/>
                                   
                                     
                                <?php   } ?>
                                    
                            </article><!--//news-item-->
                        </div><!--//news-wrapper-->
                        <aside class="page-sidebar  col-md-3 col-md-offset-1 col-sm-4 col-sm-offset-1 col-xs-12">
                        </aside>
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper-->
        </div><!--//content-->
    <?php require 'application/views/welcome/includes/footer.php';?> 
    </div><!--//wrapper-->
    
   
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/plugins/gmaps/gmaps.js"></script>            
    <script type="text/javascript" src="<?php echo base_url();?>template/js/map.js"></script>