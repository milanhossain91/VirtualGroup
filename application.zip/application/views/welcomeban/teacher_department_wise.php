    <!-- ******CONTENT****** --> 
        <div class="content container">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left"><?php foreach($department_name as $d ) {echo strtoupper($d['department_name']);}?></h1>
                    					
                </header> 
					

								
                <div class="page-content">
                    <div class="row page-row">
                        <div class="news-wrapper col-md-12 col-sm-12">
                            <article class="news-item" style="min-height: 200px;">
                                <div class="table-responsive">
                                    <table class="table table-condensed" id="display">
                                        <thead>
                                            <tr>
                                                <th>Teacher ID</th>
                                                <th>Teacher Name</th>
                                                <th>Designation</th>
                                                <th>Phone</th>
                                                <th>Picture</th>
						</tr>
                                        </thead>
                                        <tbody>
                                            <?php										
                                                foreach($tt as $tl){ ?>
                                                <tr>
                                                    <td id='teacher_id'><?php echo $tl['teacher_id'];?></td>
                                                    <td id='teacher_name'><?php echo $tl['teacher_name'];?></td>
                                                    <td id='designation'> <?php
                                                    $des_id = $tl['designation_id']; 
                                                    		$sql = "SELECT designation_name FROM tbl_designation WHERE designation_id = '$des_id' LIMIT 1";
			                                        $query = $this->db->query($sql);
			                                        $row = $query->row_array();
                                                    		echo $row['designation_name'];
                                                    ?></td>
                                                    <td id='mobile'><?php echo $tl['present_contact'];?></td>
                                                    <td>
                                                        <img src="<?php echo base_url();?>upload/teacher_image/<?php echo $tl['teacher_image'];?>" alt="" style="width:100px"/>
                                                    </td>
                                                </tr>
                                            <?php    }
                                            ?>
                                        </tbody>
                                    </table><!--//table-->
									
									
                                </div><!--//table-responsive-->
                               <hr />
                                <br/>
                             
                            </article><!--//news-item-->
                        </div><!--//news-wrapper-->
                        <aside class="page-sidebar  col-md-3 col-md-offset-1 col-sm-4 col-sm-offset-1 col-xs-12">
                        </aside>
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper-->
        </div><!--//content-->
    </div><!--//wrapper-->
    
