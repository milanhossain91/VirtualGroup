<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container" style="width:95%; margin:0px auto; background-color:#FFF; ">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">স্কুল সম্পর্কে </h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">আপনি এখানে আছেন :</li>
                            <li><a href="<?php echo base_url();?>">হোম </a><i class="fa fa-angle-right"></i></li>
                            <li class="current">স্কুল সম্পর্কে</li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                <div class="page-content">
                    <div class="row">
                        <article class="contact-form col-md-12 col-sm-12  page-row">
                            <section class="about_portion">
                        
                            <img src="<?php echo base_url();?>template/upload/about_image/<?php echo $about['about_image'];?>" alt="" />
                            
                            <?php echo $about['about_details'];?>
						
                    </section><!--//course-finder-->
                        </article><!--//contact-form-->
                        
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper--> 
        </div><!--//content-->
        <?php require 'application/views/welcome/includes/footer.php';?>
    </div><!--//wrapper-->

    

    
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/plugins/gmaps/gmaps.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/js/map.js"></script>