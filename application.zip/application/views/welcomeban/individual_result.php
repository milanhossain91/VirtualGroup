<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">Individual Result Search</h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here:</li>
                            <li><a href="<?php echo base_url();?>">Home</a><i class="fa fa-angle-right"></i></li>
                            <li class="current">Individual Result Search</li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                
                
                
                
                <div class="page-content">
                    <div class="row page-row">
                        <div class="news-wrapper col-md-10 col-sm-10 ">
                            <article class="news-item" style="min-height: 200px;">
                                
                                <div class="section-content">
                                    <form class="form-horizontal row-fluid" action="<?php echo base_url();?>welcome/result_view" method="POST" enctype="multipart/form-data" id="message-form">
                                    <div class="row page-row">
                                        <div class="col-md-4 col-sm-4">
                                            <select name="exam_id" id="exam_id" class="form-control">
                                                <option value="">Select Exam</option>
                                                <?php
                                                foreach($exam_list as $cl){ ?>       
                                                <option value="<?php echo $cl['exam_id']; ?>"><?php echo $cl['exam_name']; ?></option>
                                            <?php } ?>
                                            </select>
                                        </div>
                                        
                                        
                                        <div class="col-md-4 col-sm-4">
                                            <select name="session_id" id="session_id" class="form-control">
                                                <option value="">Select Session</option>
                                                <?php
                                                foreach($session_list as $sl){ ?>       
                                                <option value="<?php echo $sl['session_id']; ?>"><?php echo $sl['session_name']; ?></option>
                                            <?php } ?>
                                            </select>
                                        </div>
                                        
                                        
                                        <div class="col-md-4 col-sm-4">
                                            <input class="form-control pull-left" type="text" name="student_id" id="student_id" placeholder="Student ID" />
                                        </div>
                                        
                                        
                                       
                                     
                                    </div>
                                        <button class="btn btn-primary btn-label-left" type="submit"> Result View </button>
                                    
                                 </form>
                                </div><!--//section-content--> 
                                
                                    
                            </article><!--//news-item-->
                        </div><!--//news-wrapper-->
                        <aside class="page-sidebar  col-md-3 col-md-offset-1 col-sm-4 col-sm-offset-1 col-xs-12">
                        </aside>
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper-->
        </div><!--//content-->
    </div><!--//wrapper-->
    
<?php require 'application/views/welcome/includes/footer.php';?>    


<script>
    function check_student_list()
    {
        var class_id = $('#class_id').val();
        var department_id = $('#department_id').val();
        var session_id = $('#session_id').val();
        var exam_id = $('#exam_id').val();
        if(class_id==0){
            alert("Select Class First");
        }
        
       
        $.ajax({ 
        url: baseUrl+'welcome/get_student_list_for_result_view',
        data:
            {                  
                'class_id':class_id,
                'department_id':department_id,
                'session_id':session_id,
                'exam_id':exam_id
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#display').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
</script>  