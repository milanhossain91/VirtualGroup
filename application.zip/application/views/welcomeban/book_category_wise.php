    <!-- ******CONTENT****** --> 
        <div class="content container">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left"><?php foreach($category_name as $d ) {echo $d['category_name'];}?></h1>
                </header> 
								
                <div class="page-content">
                    <div class="row page-row">
                        <div class="news-wrapper col-md-12 col-sm-12">
                            <article class="news-item" style="min-height: 200px;">
                                <div class="table-responsive">
                                    <table class="table table-condensed">
                                        <thead>
                                            <tr>
                                                <th>Register No</th>
                                                <th>Register SL No</th>
                                                <th>Book Name</th>
                                                <th>Writer Name</th>
                                                <th>Category Name</th>
                                                <th>Remarks</th>
											</tr>
                                        </thead>
                                        <tbody>
                                            <?php										
                                                foreach($tt as $t){ ?>
                                                <tr>
                                                    <td><?php echo $t['register_no'];?></td>
                                                    <td><?php echo $t['register_sl_no'];?></td>
                                                    <td><?php echo $t['book_name'];?></td>
                                                    <td><?php echo $t['writer_name'];?></td>
                                                    <td>
                                                    <?php
                                                    $cat_id = $t['category_id']; 
                                                    		$sql = "SELECT category_name FROM tbl_book_category WHERE category_id = '$cat_id' LIMIT 1";
			                                        $query = $this->db->query($sql);
			                                        $row = $query->row_array();
                                                    		echo $row['category_name'];
                                                    ?>
                                                    </td>
                                                    <td><?php echo $t['remarks'];?></td>
                                                </tr>
                                            <?php    }
                                            ?>
                                        </tbody>
                                    </table><!--//table-->
									
                                </div><!--//table-responsive-->
                               	<hr />
                                <br/>
                             
                            </article><!--//news-item-->
                        </div><!--//news-wrapper-->
                        <aside class="page-sidebar  col-md-3 col-md-offset-1 col-sm-4 col-sm-offset-1 col-xs-12">
                        </aside>
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper-->
        </div><!--//content-->
    </div><!--//wrapper-->
    
	
