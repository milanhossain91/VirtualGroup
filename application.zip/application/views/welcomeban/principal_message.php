<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">
                        <?php
                            if($principal_message['type']==1){
                                echo "Chairman Message";
                            }
                            else{
                                echo "Headmaster Message";
                            }
                        ?>
                    </h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here:</li>
                            <li><a href="<?php echo base_url();?>">Home</a><i class="fa fa-angle-right"></i></li>
                            <li class="current">
                            <?php
	                            if($principal_message['type']==1){
	                                echo "Chairman Message";
	                            }
	                            else{
	                                echo "Headmaster Message";
	                            }
	                        ?>
                        </li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                <div class="page-content">
                    <div class="row">
                        <article class="contact-form col-md-12 col-sm-12  page-row">
                            <section class="principal_message">
                        <h1 class="section-heading text-highlight"><span class="line"><?php
                            if($principal_message['type']==1){
                                echo "Chairman Message";
                            }
                            else{
                                echo "Headmaster Message";
                            }
                        ?></span></h1>
                            <img src="<?php echo base_url();?>template/upload/principal_image/<?php echo $principal_message['principal_image'];?>" alt="" />
                            <?php echo $principal_message['principal_message'];?>
                    </section><!--//course-finder-->        
                        </article><!--//contact-form-->
                        
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper--> 
        </div><!--//content-->
        
    </div><!--//wrapper-->

    
<?php require 'application/views/welcome/includes/footer.php';?>    
    
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/plugins/gmaps/gmaps.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/js/map.js"></script>