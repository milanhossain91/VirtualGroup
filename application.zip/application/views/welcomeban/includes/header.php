<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->  
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->  
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->  
<?php
    $sql = "SELECT * FROM tbl_school_information where status=2 LIMIT 1";
    $query = $this->db->query($sql);
    $sc_info = $query->row_array();
?>
<head>
    <title><?= $sc_info['school_name'];?></title>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">    
    <link rel="shortcut icon" href="<?php echo base_url();?>template/template/images/favicon.ico">  
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css'>   
    <!-- Global CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>template/template/plugins/bootstrap/css/bootstrap.min.css">   
    <!-- Plugins CSS -->    
    <link rel="stylesheet" href="<?php echo base_url();?>template/template/plugins/font-awesome/css/font-awesome.css">
    <link rel="stylesheet" href="<?php echo base_url();?>template/template/plugins/flexslider/flexslider.css">
    <link rel="stylesheet" href="<?php echo base_url();?>template/template/plugins/pretty-photo/css/prettyPhoto.css"> 
    <!-- Theme CSS -->  
    <link id="theme-style" rel="stylesheet" href="<?php echo base_url();?>template/template/css/styles.css">
    <link id="theme-style" rel="stylesheet" href="<?php echo base_url();?>template/template/css/custom.css">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    
    
    <link rel="stylesheet" href="<?php echo base_url();?>template/template/css/font_end/nicdark_style.css"> <!--style-->
    <link rel="stylesheet" href="<?php echo base_url();?>template/template/css/font_end/nicdark_responsive.css"> <!--nicdark_responsive-->
    <link rel="stylesheet" href="<?php echo base_url();?>template/template/css/font_end/nicdark_shortcodes.css"> <!--nicdark_responsive-->
    <link rel="stylesheet" href="<?php echo base_url();?>template/template/css/font_end/nicdark_menu.css"> <!--nicdark_responsive-->
    <link rel="stylesheet" href="<?php echo base_url();?>template/template/css/font_end/fontello.css"> <!--nicdark_responsive-->
    <link rel="stylesheet" href="<?php echo base_url();?>template/template/css/font_end/animate.css"> <!--nicdark_responsive-->
    <link rel="stylesheet" href="<?php echo base_url();?>template/template/css/font_end/magnific-popup.css"> <!--nicdark_responsive-->
    <link rel="stylesheet" href="<?php echo base_url();?>template/template/css/font_end/revslider/settings.css"> <!--revslider-->
		<script>var baseUrl='<?php echo BASEURL;?>';</script>
</head> 

<body id="start_nicdark_framework" class="nicdark_boxed_pattern" style="background-image:url(<?= base_url()?>template/template/img/patterns/img1.jpg);">

<div class="nicdark_site">
    <div class="nicdark_site_boxed nicdark_clearfix"><div class="nicdark_overlay"></div>



<div class="nicdark_section nicdark_navigation">
    
    <div class="nicdark_menu_boxed">

        <div class="nicdark_section nicdark_bg_greydark nicdark_displaynone_responsive">
            <div class="nicdark_container nicdark_clearfix">
                <div class="grid grid_4">
                    <div class="nicdark_focus">
                        <h6 class="white">
                            <a href="#" class="nicdark_facebook nicdark_press nicdark_btn_icon small nicdark_radius white"><i class="icon-facebook-1"></i></a>
                            <a href="#" class="nicdark_press nicdark_btn_icon nicdark_bg_red nicdark_shadow small nicdark_radius white"><i class="icon-gplus"></i></a>
                             <a href="#" class="nicdark_press nicdark_btn_icon nicdark_bg_blue nicdark_shadow small nicdark_radius white"><i class="icon-twitter-1"></i></a>
                                </span>&nbsp;&nbsp;&nbsp;&nbsp;
                            <i class="icon-phone-outline"></i>&nbsp;&nbsp;<?= $sc_info['contact_no'];?>
                        </h6>
                        
                    </div>
                </div>
                <div class="grid grid_5">
                    <div class="nicdark_focus">
                        <h3 class="white center"><?= $sc_info['school_name'];?></h3>
                        
                    </div>
                </div>
                <div class="grid grid_3 right">
                    <div class="nicdark_focus right">
                        <h6 class="white">
                            <i class="icon-globe-alt-outline"></i>&nbsp;&nbsp;<a class="white nicdark_mpopup_window" href="#nicdark_window">Language</a>
                            &nbsp;&nbsp;&nbsp;&nbsp;<span class="grey">·</span>&nbsp;&nbsp;&nbsp;&nbsp;
                            <i class="icon-lock-1"></i>&nbsp;&nbsp;<a class="white nicdark_mpopup_ajax" href="form-login.html">Log In</a>
                        </h6>
                    </div>
                </div>

                <!--info window for languages-->
                <div id="nicdark_window" class="nicdark_bg_white nicdark_radius zoom-anim-dialog mfp-hide">
                    
                    <div class="nicdark_textevidence nicdark_bg_red nicdark_radius_top">
                        <div class="nicdark_margin20">
                            <h4 class="white">Language</h4>
                        </div>
                    </div>

                    <div class="nicdark_margin20">
                        
                        <ul class="nicdark_list border">
                        
                            <li class="nicdark_border_grey">
                                <p><a class="grey" href="index-2.html">ENGLISH</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="index-2.html" class="nicdark_btn right nicdark_opacity"><img alt="" width="30" src="img/flag/img1.png"></a></p>
                                <div class="nicdark_space15"></div>
                            </li>

                            <li class="nicdark_border_grey">
                                <div class="nicdark_space15"></div>
                                <p><a class="grey" href="index-2.html">বাংলা</a><a href="index-2.html" class="nicdark_btn right nicdark_opacity"><img alt="" width="30" src="img/flag/img2.png"></a></p>   
                                <div class="nicdark_space15"></div>
                            </li>
                                
                           
                                
                        </ul>

                    </div>
                </div>
                <!--end window-->

            </div>
        </div>

        <div class="nicdark_space3 nicdark_bg_gradient"></div>
                    
        <div class="nicdark_section nicdark_bg_grey nicdark_shadow nicdark_radius_bottom fade-down">
            <div class="nicdark_container nicdark_clearfix">

                <div class="grid grid_12 percentage">
                        
                        <div class="nicdark_space20"></div>

                        <div class="nicdark_logo nicdark_marginleft10">
                            <a href="index-2.html"><img src="" alt="Logo"></a>
                        </div>
                        
                        <nav>
                            <ul class="nicdark_menu nicdark_margin010 nicdark_padding50">

                                <li class="yellow">
                                    <a href="<?php echo base_url();?>">Home</a>
                                   <!-- <ul class="sub-menu">
                                        <li><a href="index-2.html">Home Default</a></li>
                                        <li><a href="index-3.html">Color Sections</a></li>
                                        <li><a href="index-4.html">Boxed Version</a></li>
                                    </ul>-->
                                </li>
                                <li class="yellow">
                                    <a href="#">Institute</a>
                                    <ul class="sub-menu">
                                        <li><a href="<?php echo base_url();?>about_college">About Institute</a></li>
                                        <li><a href="<?php echo base_url();?>">Class Wise Subject</a></li>
                                        <li><a href="<?php echo base_url();?>">Cultural Information</a></li>
                                        <li><a href="<?php echo base_url();?>">Managing Committee</a></li>
                                    </ul>
                                </li>
                                <li class="red">
                                    <a href="#">Institutional Activities </a>
                                    <ul class="sub-menu">
                                        <li><a href="<?php echo base_url();?>welcome/library">Library</a></li>
                                        <li><a href="#">Attendance Report </a></li>
                                        <li><a href="#">Account Report</a></li>
                                    </ul>
                                </li>
                                <li class="blue nicdark_megamenu">
                                    <a href="#">Academic</a>
                                    <ul class="sub-menu">
                                        <li class="mm_grid mm_grid_3">
                                            <a href="shop.html">Routine</a>
                                            <ul class="sub-menu">
                                                <li><a href="<?php echo base_url();?>class_routine">Class Routine</a></li>
                                                <li><a href="<?php echo base_url();?>central_routine">Central Routine</a></li>
                                                <li><a href="<?php echo base_url();?>exam_routine">Exam Routine</a></li>
                                            </ul>
                                        </li>
                                        <li class="mm_grid mm_grid_3">
                                            <a href="#">Exam Results</a>
                                            <ul class="sub-menu">
                                                <li><a href="<?php echo base_url();?>welcome/result_view">Combined Results</a></li> 
                                                <li><a href="<?php echo base_url();?>welcome/mark_sheet">Individual Results</a></li>
                                                <li><a href="#">Marti List</a></li>
                                            </ul>
                                        </li>
                                        <li class="mm_grid mm_grid_3">
                                            <a href="components.html">Rules & Others</a>
                                            <ul class="sub-menu">
                                                <li><a href="<?php echo base_url();?>rules_regulations">Institutional Rules & Regulation</a></li>
                                                <li><a href="<?php echo base_url();?>facilities">Institutional Facilities</a></li>
                                                 <li><a href="<?php echo base_url();?>steps">Clark & Other Employees List</a></li>
                                            </ul>
                                        </li>
                                        <li class="mm_grid mm_grid_3">
                                            <a href="#">Holidays & Other</a>
                                            <ul class="sub-menu">
                                                <li><a href="#">Testimonial & T.C</a></li>
                                                <li><a href="<?php echo base_url();?>important_information">Academic Calendar</a></li>
                                        		<li><a href="<?php echo base_url();?>">Annual Holiday List</a></li>
		                                        <!--<li><a href="<?php echo base_url();?>department">ডিপার্টমেন্ট</a></li>  -->                              
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                 <li class="orange">
                                    <a href="#">Panel</a>
                                    <ul class="sub-menu">
                                        <li>
                                            <a href="#">Teachers</a>
                                            <ul class="sub-menu">
                                                <li><a href="<?php echo base_url();?>teacher">Teachers Information</a></li>
                                                <li><a href="<?php echo base_url();?>welcome/vacant_post">Vacancy for Teachers</a></li>
                                                <li><a href="<?php echo base_url();?>welcome/teacher_panel">Teachers Panel</a></li>
                                                <li><a href="<?php echo base_url();?>welcome/teacher_archive">Teachers Archive</a></li>
                                            </ul>
                                        </li>
                                        <li>
                                            <a href="#"> Students </a>
                                            <ul class="sub-menu">
                                                <li><a href="<?php echo base_url();?>student">Student's Information</a></li>
                                                <li><a href="<?php echo base_url();?>welcome/student_panel">Student's Panel</a></li>
                                                <li><a href="<?php echo base_url();?>welcome/guardian_panel">Guardian Panel</a></li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li class="green">
                                    <a href="#">eService</a>
                                    <ul class="sub-menu">
                                        <li><a href="http://onlineadmission.eductg.gov.bd/">Online Admission</a></li>
                                		<li><a href="#">Online Payment</a></li>
                                    </ul>
                                </li>
                                <li class="violet nicdark_displaynone_ipadland">
                                    <a href="">Notice</a>
                                    <ul class="sub-menu">
                                        <li><a href="<?php echo base_url();?>general_notice">General Notices</a></li>
                                        <li><a href="<?php echo base_url();?>admission_notice">Admission Notices</a></li>
                                        <li><a href="<?php echo base_url();?>">Circular</a></li>
                                    </ul>
                                </li>
                                <li class="yellow"><a href="<?php echo base_url();?>photo_gallery">Photo Gallery</a></li>
                            </ul>
                        </nav>
    
                        <div class="nicdark_space20"></div>

                </div>

            </div>
            <!--end container-->

        </div>
        <!--end header-->

    </div>

</div>
<!--start-->
