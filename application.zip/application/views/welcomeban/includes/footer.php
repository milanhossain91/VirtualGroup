<!--end-->

<div class="nicdark_space3 nicdark_bg_gradient"></div>

<!--start section-->
<section class="nicdark_section nicdark_bg_greydark">

    <!--start nicdark_container-->
    <div class="nicdark_container nicdark_clearfix">

        <div class="nicdark_space30"></div>

        <div class="grid grid_3 nomargin percentage">

            <div class="nicdark_space20"></div>

            <div class="nicdark_margin10">
                <h4 class="white">School Address</h4>
                <div class="nicdark_space20"></div>
                <div class="nicdark_divider left small"><span class="nicdark_bg_white nicdark_radius"></span></div>
                <div class="nicdark_space20"></div>
                <p class="white"><?php echo $sc_info['school_name'];?></p>
                <p class="white"><?php echo $sc_info['address'];?>, <?php echo $sc_info['post_office'];?></p>
                <p class="white"><?php echo $sc_info['police_station'];?> <?php echo $sc_info['district'];?></p>
                <div class="nicdark_space20"></div>
                <div class="nicdark_divider left small"><span class="nicdark_bg_white nicdark_radius"></span></div>
                <div class="nicdark_space20"></div>
                <a href="contact-1.html" class="nicdark_btn_icon nicdark_bg_orange small nicdark_shadow nicdark_radius white"><i class="icon-mail-1 nicdark_rotate"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
                <a href="contact-1.html" class="nicdark_btn_icon nicdark_bg_yellow small nicdark_shadow nicdark_radius white"><i class="icon-home nicdark_rotate"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
                <a href="contact-1.html" class="nicdark_btn_icon nicdark_bg_red small nicdark_shadow nicdark_radius white"><i class="icon-phone-outline nicdark_rotate"></i></a>&nbsp;&nbsp;&nbsp;&nbsp;
            </div>
        </div>

        <div class="grid grid_6 nomargin percentage">
            
            <div class="nicdark_space30"></div>

            <div class="nicdark_marginleft10">
                <h4 class="white">Important links</h4>
                <div class="nicdark_space20"></div>
                <div class="nicdark_divider left small"><span class="nicdark_bg_white nicdark_radius"></span></div>
            </div>
            <div class="nicdark_space10"></div>

            <a href="http://www.moedu.gov.bd/" class="nicdark_btn nicdark_bg_greydark2 small nicdark_shadow nicdark_radius white subtitle nicdark_margin10" target="_blank">Educational Ministry </a>
            <a href="http://dhakaeducationboard.gov.bd/" class="nicdark_btn nicdark_bg_greydark2 small nicdark_shadow nicdark_radius white subtitle nicdark_margin10" target="_blank">Dhaka Education Board</a>
            <a href="http://bise-ctg.gov.bd/" class="nicdark_btn nicdark_bg_greydark2 small nicdark_shadow nicdark_radius white subtitle nicdark_margin10" target="_blank">Chittagong Education Board</a>
            <a href="http://www.jessoreboard.gov.bd/" class="nicdark_btn nicdark_bg_greydark2 small nicdark_shadow nicdark_radius white subtitle nicdark_margin10" target="_blank">Jessor Education Board</a>
            <a href="http://comillaboard.gov.bd/" class="nicdark_btn nicdark_bg_greydark2 small nicdark_shadow nicdark_radius white subtitle nicdark_margin10" target="_blank">Comilla Education Board</a>
             <a href="http://infokosh.gov.bd/" class="nicdark_btn nicdark_bg_greydark2 small nicdark_shadow nicdark_radius white subtitle nicdark_margin10" target="_blank">Info Kosh</a>
            <a href="http://www.ebook.gov.bd/" class="nicdark_btn nicdark_bg_greydark2 small nicdark_shadow nicdark_radius white subtitle nicdark_margin10" target="_blank">eBook</a>
            <a href="http://www.lekhaporabd.com/" class="nicdark_btn nicdark_bg_greydark2 small nicdark_shadow nicdark_radius white subtitle nicdark_margin10" target="_blank">Lekha-Pora</a>
            <a href="http://forms.portal.gov.bd/" class="nicdark_btn nicdark_bg_greydark2 small nicdark_shadow nicdark_radius white subtitle nicdark_margin10" target="_blank">Bangladesh Forms Portal</a>
            <a href="http://bangladesh.gov.bd/" class="nicdark_btn nicdark_bg_greydark2 small nicdark_shadow nicdark_radius white subtitle nicdark_margin10" target="_blank">Bangladesh Government</a>
            <a href="http://services.portal.gov.bd/" class="nicdark_btn nicdark_bg_greydark2 small nicdark_shadow nicdark_radius white subtitle nicdark_margin10" target="_blank">Services Portal</a>
            <a href="http://www.teachers.gov.bd/" class="nicdark_btn nicdark_bg_greydark2 small nicdark_shadow nicdark_radius white subtitle nicdark_margin10" target="_blank">Teacher's Window</a>
            <a href="http://eductg.gov.bd/" class="nicdark_btn nicdark_bg_greydark2 small nicdark_shadow nicdark_radius white subtitle nicdark_margin10" target="_blank">Chittagong District Commissioner</a>
            <a href="http://www.dshe.gov.bd/" class="nicdark_btn nicdark_bg_greydark2 small nicdark_shadow nicdark_radius white subtitle nicdark_margin10" target="_blank">Directorate of Secondary and Higher Education</a>
            <a href="http://www.nctb.gov.bd/" class="nicdark_btn nicdark_bg_greydark2 small nicdark_shadow nicdark_radius white subtitle nicdark_margin10" target="_blank">NCTB</a>

        </div>

       <!-- <div class="grid grid_3 nomargin percentage">

            <div class="nicdark_space20"></div>
            
            <div class="nicdark_margin10">
                <h4 class="white">GALLERY OF SCHOOL</h4>
                <div class="nicdark_space20"></div>
                <div class="nicdark_divider left small"><span class="nicdark_bg_white nicdark_radius"></span></div>
            </div>
            

            <div class="grid nomargin grid_4 percentage">
                <div class="nicdark_margin10">
                    <img alt="" class="nicdark_radius nicdark_opacity nicdark_focus" src="img/footer/img1.jpg">
                </div>
            </div>
            
            <div class="grid nomargin grid_4 percentage">
                <div class="nicdark_margin10">
                    <img alt="" class="nicdark_radius nicdark_opacity nicdark_focus" src="img/footer/img2.jpg">
                </div>
            </div>
            
            <div class="grid nomargin grid_4 percentage">
                <div class="nicdark_margin10">
                    <img alt="" class="nicdark_radius nicdark_opacity nicdark_focus" src="img/footer/img3.jpg">
                </div>
            </div>
            
            <div class="grid nomargin grid_4 percentage">
                <div class="nicdark_margin10">
                    <img alt="" class="nicdark_radius nicdark_opacity nicdark_focus" src="img/footer/img4.jpg">
                </div>
            </div>
            
            <div class="grid nomargin grid_4 percentage">
                <div class="nicdark_margin10">
                    <img alt="" class="nicdark_radius nicdark_opacity nicdark_focus" src="img/footer/img5.jpg">
                </div>
            </div>
            
            <div class="grid nomargin grid_4 percentage">
                <div class="nicdark_margin10">
                    <img alt="" class="nicdark_radius nicdark_opacity nicdark_focus" src="img/footer/img6.jpg">
                </div>
            </div>
            

        </div>
-->
        <div class="grid grid_3 nomargin percentage">

            <div class="nicdark_space20"></div>

            <div class="nicdark_margin10 white">
                <h4 class="white">Connect us</h4>
                <div class="nicdark_space20"></div>
                <div class="nicdark_divider left small"><span class="nicdark_bg_white nicdark_radius"></span></div>
                <div class="nicdark_space20"></div>
                

                <input class="nicdark_bg_white nicdark_radius nicdark_shadow green small subtitle" type="text" value="" placeholder="EMAIL">
                <div class="nicdark_space20"></div>
                <textarea rows="3" class="nicdark_bg_white nicdark_radius nicdark_shadow green small subtitle" placeholder="MESSAGE"></textarea>
                <div class="nicdark_space20"></div>
                <!--<input class="nicdark_btn nicdark_bg_green small nicdark_shadow nicdark_radius white nicdark_press" type="submit" value="SEND">-->
                <a href="submit-message.html" class="nicdark_mpopup_ajax nicdark_btn nicdark_bg_green small nicdark_shadow nicdark_radius white nicdark_press">SEND</a>
            </div>
        </div> 

        <div class="nicdark_space50"></div> 

    </div>
    <!--end nicdark_container-->
            
</section>
<!--end section-->


<!--start section-->
<div class="nicdark_section nicdark_bg_greydark2 nicdark_copyrightlogo">

    <!--start nicdark_container-->
    <div class="nicdark_container nicdark_clearfix">

        <div class="grid grid_6 nicdark_aligncenter_iphoneland nicdark_aligncenter_iphonepotr">
            <div class="nicdark_space20"></div>
            <p class="white">© Copyright 2014 by <span class="grey"><?= $sc_info['school_name'];?> </span><a href="http://www.wristsup.com" class="green">wristsup.com</a></p>
        </div>


        <div class="grid grid_6">
            <div class="nicdark_focus right nicdark_aligncenter_iphoneland nicdark_aligncenter_iphonepotr">
                <div class="nicdark_margin10">
                    <a href="#" class="nicdark_facebook nicdark_press right nicdark_btn_icon small nicdark_radius white"><i class="icon-facebook-1"></i></a>
                </div>
                <div class="nicdark_margin10">
                    <a href="#" class="nicdark_press right nicdark_btn_icon nicdark_bg_red nicdark_shadow small nicdark_radius white"><i class="icon-gplus"></i></a>
                </div>
                <div class="nicdark_margin10">
                    <a href="#" class="nicdark_press right nicdark_btn_icon nicdark_bg_blue nicdark_shadow small nicdark_radius white"><i class="icon-twitter-1"></i></a>
                </div>
                <div class="nicdark_margin10">
                    <a href="#start_nicdark_framework" class="nicdark_zoom nicdark_internal_link right nicdark_btn_icon nicdark_bg_greydark2 small nicdark_radius white"><i class="icon-up-outline"></i></a>
                </div>
            </div>
        </div>

    </div>
    <!--end nicdark_container-->
            
</div>
<!--end section-->        
	</div>
</div>
 
    <!-- Javascript -->          
    <script type="text/javascript" src="<?php echo base_url();?>template/template/plugins/jquery-1.10.2.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/template/plugins/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/template/plugins/bootstrap/js/bootstrap.min.js"></script> 
    <script type="text/javascript" src="<?php echo base_url();?>template/template/plugins/bootstrap-hover-dropdown.min.js"></script> 
    <script type="text/javascript" src="<?php echo base_url();?>template/template/plugins/back-to-top.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/template/plugins/jquery-placeholder/jquery.placeholder.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/template/plugins/pretty-photo/js/jquery.prettyPhoto.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/template/plugins/flexslider/jquery.flexslider-min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/template/plugins/jflickrfeed/jflickrfeed.min.js"></script> 
    <script type="text/javascript" src="<?php echo base_url();?>template/template/js/main.js"></script>   
    
    <!--main-->
    <script src="<?php echo base_url();?>template/template/js/font_end/main/jquery.min.js"></script> <!--Jquery-->
    <script src="<?php echo base_url();?>template/template/js/font_end/main/jquery-ui.js"></script> <!--Jquery UI-->
    <script src="<?php echo base_url();?>template/template/js/font_end/main/excanvas.js"></script> <!--canvas need for ie-->

    <!--plugins-->
    <script src="<?php echo base_url();?>template/template/js/font_end/plugins/revslider/jquery.themepunch.tools.min.js"></script> <!--revslider-->
    <script src="<?php echo base_url();?>template/template/js/font_end/plugins/revslider/jquery.themepunch.revolution.min.js"></script> <!--revslider-->   
    
     <!--other-->
    <script src="<?php echo base_url();?>template/template/js/font_end/plugins/isotope/isotope.pkgd.min.js"></script> <!--isotope-->
    <script src="<?php echo base_url();?>template/template/js/font_end/plugins/mpopup/jquery.magnific-popup.min.js"></script> <!--mpopup-->
    <script src="<?php echo base_url();?>template/template/js/font_end/plugins/scroolto/scroolto.js"></script> <!--Scrool To-->
    <script src="<?php echo base_url();?>template/template/js/font_end/plugins/nicescrool/jquery.nicescroll.min.js"></script> <!--Nice Scroll-->
    <script src="<?php echo base_url();?>template/template/js/font_end/plugins/inview/jquery.inview.min.js"></script> <!--inview-->
    <script src="<?php echo base_url();?>template/template/js/font_end/plugins/parallax/jquery.parallax-1.1.3.js"></script> <!--parallax-->
    <script src="<?php echo base_url();?>template/template/js/font_end/plugins/countto/jquery.countTo.js"></script> <!--jquery.countTo-->
    <script src="<?php echo base_url();?>template/template/js/font_end/plugins/countdown/jquery.countdown.js"></script> <!--countdown-->
    
     <!--menu-->
    <script src="<?php echo base_url();?>template/template/js/font_end/plugins/menu/superfish.min.js"></script> <!--superfish-->
    <script src="<?php echo base_url();?>template/template/js/font_end/plugins/menu/tinynav.min.js"></script> <!--tinynav--> 
    
    
    <!--settings-->
    <script src="<?= base_url();?>template/template/js/font_end/settings.js"></script> <!--settings-->
    
    <!-- map -->
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script type="text/javascript" src="<?= base_url();?>template/template/plugins/gmaps/gmaps.js"></script>  
<!--custom js-->
<script type="text/javascript">
	jQuery(document).ready(function() {
		
		map = new GMaps({
        div: '#map',
        lat: 22.35906,
        lng: 91.81556,
    });
    map.addMarker({
        lat: 22.35906,
        lng: 91.81556,
        title: 'Address',      
        infoWindow: {
            content: '<h5 class="title"><?= $sc_info['school_name'];?></h5><p><span class="region"><?= $sc_info['district'];?></span><br><span class="postal-code"><?= $sc_info['post_office'];?></span><br><span class="country-name">Bangladesh</span></p>'
        }
    });

		//START SLIDE
		jQuery('.nicdark_slide1').show().revolution(
		{
			dottedOverlay:"none",
			delay:16000,
			startwidth:1170,
			startheight:650,
			hideThumbs:200,
			
			thumbWidth:100,
			thumbHeight:50,
			thumbAmount:5,
			
			navigationType:"none",
			navigationArrows:"solo",
			navigationStyle:"preview2",
			
			touchenabled:"on",
			onHoverStop:"on",
			
			swipe_velocity: 0.7,
			swipe_min_touches: 1,
			swipe_max_touches: 1,
			drag_block_vertical: false,
									
			parallax:"mouse",
			parallaxBgFreeze:"on",
			parallaxLevels:[7,4,3,2,5,4,3,2,1,0],
									
			keyboardNavigation:"off",
			
			navigationHAlign:"center",
			navigationVAlign:"bottom",
			navigationHOffset:0,
			navigationVOffset:20,

			soloArrowLeftHalign:"left",
			soloArrowLeftValign:"center",
			soloArrowLeftHOffset:20,
			soloArrowLeftVOffset:0,

			soloArrowRightHalign:"right",
			soloArrowRightValign:"center",
			soloArrowRightHOffset:20,
			soloArrowRightVOffset:0,
					
			shadow:0,
			fullWidth:"on",
			fullScreen:"off",

			spinner:"spinner4",
			
			stopLoop:"off",
			stopAfterLoops:-1,
			stopAtSlide:-1,

			shuffle:"off",
			
			autoHeight:"off",						
			forceFullWidth:"off",						
									
			hideTimerBar: "on",					
									
			hideThumbsOnMobile:"off",
			hideNavDelayOnMobile:1500,						
			hideBulletsOnMobile:"off",
			hideArrowsOnMobile:"off",
			hideThumbsUnderResolution:0,
			
			hideSliderAtLimit:0,
			hideCaptionAtLimit:0,
			hideAllCaptionAtLilmit:0,
			startWithSlide:0,
			videoJsPath:"rs-plugin/videojs/",
			fullScreenOffsetContainer: ""	
		});
		//END SLIDE
		
		

		//START PARALLAX SECTIONS
		$('#nicdark_parallax_big_image').parallax("50%", 0.3);
		$('#nicdark_parallax_2_btns').parallax("50%", 0.3);
		$('#nicdark_parallax_countdown').parallax("50%", 0.3);
		$('#nicdark_parallax_counter').parallax("50%", 0.3);
		//END PARALLAX SECTIONS

		
		//START COUNTDOWN GRID SECTION
		//variables
		var endDate = "January 01, "+(new Date().getFullYear()+1)+" 10:30:00";
		var grid = "grid_3";
		//insert the class nicdark_displaynone in the var if you wnat to hide the visualization
		var display_years = "nicdark_displaynone";
		var display_days = "";
		var display_hours = "";
		var display_minutes = "";
		var display_seconds = "";
		//call
		$(".nicdark_countdown").countdown({
		  date: endDate,
		  render: function(data) {
		    $(this.el).html("<div class=\"grid "+ grid +" "+ display_years +" \"><div class=\"nicdark_textevidence center\"><h1 class=\"subtitle white extrasize\">"+ this.leadingZeros(data.years, 4) +"</h1><div class=\"nicdark_space20\"></div><a class=\"nicdark_btn nicdark_bg_blue small nicdark_shadow nicdark_radius white\">YEARS</a><div class=\"nicdark_space5\"></div></div></div><div class=\"grid "+ grid +" "+ display_days +"  \"><div class=\"nicdark_textevidence center\"><h1 class=\"subtitle white extrasize\">"+ this.leadingZeros(data.days, 3) +"</h1><div class=\"nicdark_space20\"></div><a class=\"nicdark_btn nicdark_bg_blue small nicdark_shadow nicdark_radius white\">Days</a><div class=\"nicdark_space5\"></div></div></div><div class=\"grid "+ grid +" "+ display_hours +"  \"><div class=\"nicdark_textevidence center\"><h1 class=\"subtitle white extrasize\">"+ this.leadingZeros(data.hours, 2) +"</h1><div class=\"nicdark_space20\"></div><a class=\"nicdark_btn nicdark_bg_yellow small nicdark_shadow nicdark_radius white\">Hours</a><div class=\"nicdark_space5\"></div></div></div><div class=\"grid "+ grid +" "+ display_minutes +"  \"><div class=\"nicdark_textevidence center\"><h1 class=\"subtitle white extrasize\">"+ this.leadingZeros(data.min, 2) +"</h1><div class=\"nicdark_space20\"></div><a class=\"nicdark_btn nicdark_bg_green small nicdark_shadow nicdark_radius white\">Minutes</a><div class=\"nicdark_space5\"></div></div></div><div class=\"grid "+ grid +" "+ display_seconds +"  \"><div class=\"nicdark_textevidence center\"><h1 class=\"subtitle white extrasize\">"+ this.leadingZeros(data.sec, 2) +"</h1><div class=\"nicdark_space20\"></div><a class=\"nicdark_btn nicdark_bg_violet small nicdark_shadow nicdark_radius white\">Seconds</a><div class=\"nicdark_space5\"></div></div></div>");
		  }
		});
		//END COUNTDOWN GRID SECTION

	});
</script>
<!--custom js-->



<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','../../../../../www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-49425562-7', 'auto');
  ga('send', 'pageview');

</script>

     
</body>

</html> 

