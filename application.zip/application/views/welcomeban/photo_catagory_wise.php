    <!-- ******CONTENT****** --> 
        <div class="content container">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left"><?php foreach($catagory_name as $d ) {echo strtoupper($d['catagory_name']);}?></h1>
                    					
                </header> 
                <div class="page-content">
                    <div class="row page-row">
                        <?php
                            foreach($tt as $pg){ ?>
                            <a class="prettyphoto col-md-3 col-sm-3 col-xs-6" rel="prettyPhoto[gallery]" href="<?php echo base_url();?>template/upload/photo_gallery/<?php echo $pg['gallery_image_name'];?>"><img class="img-responsive img-thumbnail" src="<?php echo base_url();?>template/upload/photo_gallery/<?php echo $pg['gallery_image_name'];?>" alt="" /></a>
                        <?php    }
                        ?>
                        
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper--> 
        </div><!--//content-->
    </div><!--//wrapper-->
