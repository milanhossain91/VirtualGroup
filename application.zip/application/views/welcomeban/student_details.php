<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container" style="width:95%; margin:0px auto; background-color:#FFF; ">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left"> ছাত্র/ছাত্রী বিস্তারিত তথ্য </h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">আপনি এখানে আছেন :</li>
                            <li><a href="<?php echo base_url();?>">হোম </a><i class="fa fa-angle-right"></i></li>
                            <li class="current"> ছাত্র/ছাত্রী বিস্তারিত তথ্য </li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                
                
                
                <div class="page-content">
                    <div class="row page-row">
                        <div class="news-wrapper col-md-10 col-sm-10 ">
                            <article class="news-item" style="min-height: 200px;">
                                <h3 class="has-divider text-highlight"><a href="javascript:history.go(-1)" >Back</a></h3> 
                                    <div class="table-responsive">
                                        <table class="table table-condensed">
                                            <thead>
                                                <tr>                    
                                                    <th>Student ID</th>
                                                    <th>Student Name</th>
                                                    <th>Father Name</th>
                                                    <th>Class</th>
                                                    <th>Department</th>
                                                    <th>Session</th>
                                                    <th>Photo</th>
													</tr>
                                            </thead>
                                            <tbody>
                                                <?php 
                                                foreach($student_list as $sl){ ?> 
                                                <tr>
                                                    <td><?php echo $sl['student_id'];?></td>
                                                    <td><?php echo $sl['student_name'];?></td>
                                                    <td><?php echo $sl['father_name'];?></td>
                                                    <td>
                                                        <?php          
                                                            $class_id = $sl['class_id'];
                                                            $class_query = "SELECT * FROM tbl_class where class_id = $class_id limit 1";
                                                            $class = $this->db->query($class_query);
                                                            $class_list= $class->row_array();
                                                            echo $class_list['class_name'];
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php           
                                                            $department_id = $sl['department_id'];
                                                            $department_query = "SELECT * FROM tbl_department where department_id = $department_id limit 1";
                                                            $department= $this->db->query($department_query);
                                                            $department_list= $department->row_array();
                                                            echo $department_list['department_name'];
                                                        ?>
                                                    </td>
                                                    <td>
                                                        <?php           
                                                            $session_id = $sl['session_id'];
                                                            $session_query = "SELECT * FROM tbl_session where session_id = $session_id limit 1";
                                                            $session = $this->db->query($session_query);
                                                            $session_list= $session->row_array();
                                                            echo $session_list['session_name'];
                                                        ?>
                                                    </td>
													<td>
													<img id="logo" src="<?php echo base_url();?>template/upload/student_image/<?php echo $sl['photo'];?>" alt="Logo" height="60" width="60">
                                                  
                                                    </td>
                                                </tr>
                                                <?php   } ?>
                                            </tbody>
                                        </table><!--//table-->
                                    </div><!--//table-responsive-->
                            </article><!--//news-item-->
                        </div><!--//news-wrapper-->
                        <aside class="page-sidebar  col-md-3 col-md-offset-1 col-sm-4 col-sm-offset-1 col-xs-12">
                        </aside>
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper-->
        </div><!--//content-->
    
    </div><!--//wrapper-->
    
<?php require 'application/views/welcome/includes/footer.php';?>    
<script type="text/javascript" src="http://maps.google.com/maps/api/js?sensor=true"></script>
    <script type="text/javascript" src="<?php echo base_url();?>template/plugins/gmaps/gmaps.js"></script>            
    <script type="text/javascript" src="<?php echo base_url();?>template/js/map.js"></script>