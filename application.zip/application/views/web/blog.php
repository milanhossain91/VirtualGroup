<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
		<div class="content-page">
		<div class="content">
			<div class="page-heading">
            	<h1><i class="fa fa-file-text-o"></i>Blog</h1>
			</div>
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>

		<div class="row">
                <div class="col-sm-12">
                    <div class="widget" style="min-height:500px;">
                        <div class="widget-content padding">
                            <div class="row">				
                                <div class="col-md-12">
                                    <div class="widget">
										<hr/>
                                        <form action="<?php echo base_url();?>web/blog_save" method="POST" enctype="multipart/form-data">
											<div class="form-group">
											<div class="row">
											     <div class="col-sm-12 col-md-12">
														<label>Title</label>
														<input type="text" class="form-control" id="exampleInputEmail1" name="title" aria-describedby="emailHelp" placeholder="Title">
													
											        </div>
												<div class="col-sm-12 col-md-12">
														<label>Contant</label>
														<textarea rows="5" id="wysiwig_simple" class="form-control" name="content" style="min-height:300px;"></textarea>
													
													
											        </div>
												
													<div class="col-sm-12 col-md-12">
														<label>Picture</label>
															<input type="file" class="form-control" name="image" id="about_image"> 
                                                         
													</div>
												</div>
                                            </div>
											<div class="form-group">
											<button type="submit" class="btn btn-primary">Submit</button>
										
											</div>
										</form>
                                    </div>
                                </div>
                                 <div class="col-md-12">
                                            <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                <thead>
                                                    <tr>
                                                        <th>SLNO</th>
                                                        <th>Title</th>
                                                       
                                                        <th>Picture</th>
                                                       
                                                        
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $i=1; foreach($blog as $tl){ ?>
                                                    <tr>
                                                        <td style="text-align:center;"><?php echo $i;?></td>
                                                        <td><?php echo $tl['title'];?></td>
                                                       
                                                       
                                                        
                                                        <td>
                                                        <?php

                                                            $teacher_imageshow =  base_url().'upload/blog/'.$tl['image'];
                                                            if($tl['image']){ 

                                                                ?>

                                                            <img src="<?php echo $teacher_imageshow; ?>" class="img-responsive" height="80" width="80">
                                                              <?php

                                                                
                                                            }else{ ?>



                                                                <img src="<?php echo base_url()?>/upload/customer_images/head.jpg" class="img-responsive" height="80" width="80">
                                                            <?php } ?>


  


                                                       
                                                        
                                                   
                                                                                                    
                                                   <td><a href="<?php echo base_url();?>web/blog_edit/<?php echo $tl['id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | 
                <?=anchor("web/blog_delete/".$tl['id'],"<i class=\"fa fa-remove\"></i>",array('onclick' => "return confirm('Do you want delete this record')"))?>
                                                        </td>
                                                    </tr>
                                                    <?php $i++; } ?>
                                                   
                                                </tbody>
                                            </table>
                                    </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php include 'application/views/includes/footer.php';?>    

<script type="text/javascript">

window.onload = function () {
	// Create Wysiwig editor for textare
	TinyMCEStart('#wysiwig_simple', null);
	TinyMCEStart('#wysiwig_full', 'extreme');
};
</script>