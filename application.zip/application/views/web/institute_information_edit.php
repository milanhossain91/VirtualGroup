<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">			
    <div class="content">
        <!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-check'></i> Institute Information</h1>
        </div>
        <!-- Page Heading End-->
        <!-- Your awesome content goes here -->
        <div class="row">
            <div class="col-sm-12">
                <div class="widget" style="min-height:500px;">
                    <div class="widget-content padding">
                        <form method="POST" action="<?= base_url();?>admin/institute_information_edit_save" enctype="multipart/form-data">
                            <legend><i class="icon32 icon-square-plus"></i> Institute Information Edit</legend>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <label>Institute Name</label>
                                        <input type="text" class="form-control" name="school_name" id="school_name" value="<?php echo $school_info['school_name'];?>">
                                        <input type="hidden" name="school_information_id" id="school_information_id" value="<?php echo $school_info['school_information_id'];?>">
                                    </div>

                                    <div class="col-sm-6">
                                        <label> Institute Title</label>
                                        <input type="text" class="form-control" name="school_title" id="school_title" value="<?php echo $school_info['school_title'];?>">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-6 col-md-4">
                                         <label>EIIN Number</label>
                                        <input type="text" class="form-control" name="eiin_no" value="<?= $school_info['eiin_no'];?>">
                                    </div>
									<div class="col-sm-6 col-md-4">
                                         <label>Index Number</label>
                                        <input type="text" class="form-control" name="school_index_no" value="<?= $school_info['school_index_no'];?>">
                                    </div>
                                    <div class="col-sm-6 col-md-4">
                                         <label>School Code</label>
                                        <input type="text" class="form-control" name="school_code" value="<?= $school_info['school_code'];?>">
                                    </div>
                                </div>
                            </div>
							<div class="form-group">
                                <div class="row">
									<div class="col-sm-6 col-md-4">
                                         <label>Upazilla Code</label>
                                        <input type="text" class="form-control" name="upazilla_code" value="<?= $school_info['upazilla_code'];?>">
                                    </div>
									<div class="col-sm-6 col-md-4">
                                         <label>District Code</label>
                                        <input type="text" class="form-control" name="district_code" value="<?= $school_info['district_code'];?>">
                                    </div>
									<div class="col-sm-6 col-md-4">
                                         <label>Founder</label>
                                        <input type="text" class="form-control" name="founder" value="<?= $school_info['founder'];?>">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <label> Address</label>
                                        <input type="text" class="form-control" name="address" value="<?= $school_info['address'];?>">                                                
                                    </div>
                                    <div class="col-sm-6">
                                        <label> Post Office</label>
                                        <input type="text" class="form-control" name="post_office" value="<?= $school_info['post_office'];?>">
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label> Police Station</label>
                                        <input type="text" class="form-control" name="police_station" id="police_station" value="<?= $school_info['police_station'];?>">
                                    </div>

                                    <div class="col-sm-4">
                                        <label>  District</label>
                                        <input type="text" class="form-control" name="district" id="district" value="<?= $school_info['district'];?>">
                                    </div>
                                    <div class="col-sm-4">
                                        <label>  Established</label>
                                        <input type="text" class="form-control" name="established" id="established" value="<?= $school_info['established'];?>" />
                                    </div>
                                </div>
                            </div>


                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-4">
                                        <label> Contact No.</label>
                                        <input type="text" class="form-control" name="contact_no" id="contact_no" value="<?= $school_info['contact_no'];?>">
                                    </div>

                                    <div class="col-sm-4">
                                        <label>  E-Mail</label>
                                        <input type="text" class="form-control" name="email" id="email" value="<?= $school_info['email'];?>">
                                    </div>

                                    <div class="col-sm-4">
                                        <label>Website</label>
                                        <input type="text" class="form-control" name="website" id="website" value="<?= $school_info['website'];?>">
                                    </div> 
                                </div>
                            </div>


                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <label> Logo</label> <br/>
                                        <img src="<?php echo base_url();?>upload/institute_logo/<?= $school_info['logo'];?>" alt="" height="150" width="150"/>
                                    </div>

                                    <div class="col-sm-6">
                                        <label> New Logo</label> <br/>
                                        <input type="file" class="btn btn-default" title="Browse Logo" name="school_logo" id="school_logo">
                                    </div>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary">Register</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
<?php include 'application/views/includes/footer.php';?>