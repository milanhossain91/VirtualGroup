

<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">
<div class="content">
<div class="page-heading">
   <h1><i class="fa fa-desktop" aria-hidden="true"></i>
      Computer Lab
   </h1>
   
   <hr>
   <!-- Button trigger modal -->
   <button type="button" class="btn btn-info" data-toggle="modal" data-target="#myModal">
   <i class="fa fa-plus-square" aria-hidden="true"> Add New</i>
   </button>
</div>
<?php if($this->session->flashdata('message')):?>
<?=$this->session->flashdata('message')?>
<?php endif?>
<div class="row">
   <div class="col-sm-12">
      <div class="widget" style="min-height:500px;">
         <div class="widget-content padding">
            <div class="row">
               <div class="col-md-12">
                  <div class="widget">
                  
                    
                     <div class="widget-content">
                        <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                           <thead>
                              <tr>
                                 <th> ID</th>
                                 <th>Catagory Name</th>
                                 <th>Action</th>
                              </tr>
                           </thead>
                           <tbody>
                              
                              <tr>
                                 <td></td>
                                 <td></td>
                                 <td>
                                    <a href="#" onclick=""><i class="fa fa-edit"></i></a> |
                                    <a href="#" onclick=""><i class="fa fa-remove"></i></a></a> |
                                 </td>
                              </tr>
                             
                           </tbody>
                        </table>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
   <div class="modal-dialog" role="document">
      <!--Content-->
      <div class="modal-content">
         <!--Header-->
         <div class="modal-header">
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
            </button>
            <h4 class="modal-title w-100" id="myModalLabel">Computer Lab Information </h4>
         </div>
         <!--Body-->
         <div class="modal-body">
            <form  action="" role="form" method="post" enctype="multipart/form-data">
               <div class="form-group">
                  <div class="row">
                     <div class="col-sm-6 col-md-6">
                        <label>Name</label>
                        <input type="text" name="m_name" id="m_name" class="form-control" required="required"/>
                        <input type="hidden" name="member_id" id="member_id" value="0" />
                     </div>
                     <div class="col-sm-6 col-md-6">
                        <label>Designation</label>
                        <input type="text" name="m_des" id="m_des" class="form-control" required="required"/>
                     </div>
                     <div class="col-sm-6 col-md-6">
                        <label>Order</label>
                        <input type="text" name="m_order" id="m_order" class="form-control" required="required" />
                     </div>
                     <div class="col-sm-6 col-md-6">
                        <label>Photo</label>
                        <input type="file" name="m_image" id="m_image">
                     </div>
                  </div>
               </div>
         </div>
         <!--Footer-->
         <div class="modal-footer">
         <button type="reset" class="btn btn-primary reset" id="reset">Clear</button>
         <button type="button" id="alert" class="btn btn-danger pull-left" data-dismiss="modal">Close</button>
         <input type="submit" name="submit" value="submit" class="btn btn-success" id="sub"   />
         <input type="submit" value="Update" class="btn btn-success" id="update">				
         </div>
         </form>
      </div>
      <!--/.Content-->
   </div>
</div>
<!-- /.Live preview-->
<!--modal end-->
<?php include 'application/views/includes/footer.php';?>

