<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
		<div class="content-page">
		<div class="content">
			<div class="page-heading">
            	<h1><i class="fa fa-file-text-o"></i>Spares Stores Edit</h1>
			</div>
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>

		<div class="row">
                <div class="col-sm-12">
                    <div class="widget" style="min-height:500px;">
                        <div class="widget-content padding">
                            <div class="row">				
                                <div class="col-md-12">
                                    <div class="widget">
										<hr/>

                                        <form action="<?php echo base_url();?>web/spares_stores_edit_save" method="POST" enctype="multipart/form-data" id="message-form">
											<div class="form-group">
											<div class="row">
											 <div class="col-sm-12 col-md-12">
														
														<input type="hidden" class="form-control" id="exampleInputEmail1" name="id"  id="hide"  aria-describedby="emailHelp" value="<?= $spares_stores_edit[0]['id']; ?>" >
													
											        </div>
											     <div class="col-sm-12 col-md-12">
														<label>Title</label>
														<input type="text" class="form-control" id="exampleInputEmail1" name="title" aria-describedby="emailHelp" value="<?= $spares_stores_edit[0]['title']; ?>" >
													
											        </div>
												<div class="col-sm-12 col-md-12">
														<label>Contant</label>
														<textarea rows="5" id="wysiwig_simple" name="content" style="min-height:300px;" readonly><?= $spares_stores_edit[0]['content'];?></textarea>
														
														
													
													
											        </div>
												
													<div class="col-sm-12 col-md-12">
														<div class="row">
															<div class="col-sm-12 col-md-6">
																<label>Current Picture</label>
																	<img src="<?= base_url();?>upload/spares_stores/<?= $spares_stores_edit[0]['image'];?>" alt=""  width="300"/>
															</div>
															<div class="col-sm-12 col-md-6">
																<label>New Picture</label>
																	
																	<input type="file" class="form-control" name="image" id="about_image"> 
		                                                            <p>Photo must be 750 X 300 pixel (width X height) and file size not more than <b>450 KB</b>. Colour Photo is a must.</p>
															</div>
														</div>
														
                                                         
													</div>
												</div>
                                            </div>
											<div class="form-group">
											<button type="submit" class="btn btn-primary">Submit</button>
										
											</div>
										</form>
                                    </div>
                                </div>

                         
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php include 'application/views/includes/footer.php';?>    

<script type="text/javascript">

window.onload = function () {
	// Create Wysiwig editor for textare
	TinyMCEStart('#wysiwig_simple', null);
	TinyMCEStart('#wysiwig_full', 'extreme');
};
</script>