<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
	<div class="content-page">
		
		<div class="content">
			<div class="page-heading">
            	<h1><i class="fa fa-file-text-o"></i> Message </h1>
			</div>
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
			<div class="row">
                <div class="col-sm-12">
                    <div class="widget" style="min-height:500px;">
                        <div class="widget-content padding">
                            <div class="row">				
                                <div class="col-md-12">
                                    <div class="widget">
                                        <div class="widget-content padding"><a class="btn btn-info" href="javascript:void(0);" onclick="toggle_insertion_box(); return false;"><i class="fa fa-plus" aria-hidden="true"></i>
Add New Massage Type</a>
                                            <div class="insertion_div">
											<hr/>
                                                <form role="form" id="msg_entry" method="POST" action="<?= base_url();?>web/message_save">
													<div class="form-group">
														<div class="row">
														   <div class="col-sm-6 col-md-4">
																<label>Massage Type</label>
																<input type="text" class="form-control" name="type" id="type" required >
															</div>
														</div>
													</div>
													<div class="form-group">
														<button type="submit" class="btn btn-primary">Submit</button>
													</div>
												</form>
                                            </div>
                                        </div>

                                        <div class="widget-content">
                                            <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="90%">
                                                <thead>
                                                    <tr>
                                                        <th>Message Type</th>
														<th>Picture</th>
														<th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
													<?php foreach($message_list as $ml){ ?>
													<tr>
														<td><?= $ml['type'];?></td>
														<td>
															<?php if($ml['image']!=''): ?>
																<img height="100" width="100" src="<?= base_url();?>upload/message_image/<?= $ml['image'];?>" alt=""  />    
															<?php else: ?>
																<img height="100" width="100" src="<?= base_url();?>upload/message_image/no_picture.png" alt=""  />
															<?php  endif; ?>
														</td>
														<td>
															<a href="<?= base_url();?>web/message_update/<?= $ml['message_id'];?>" title="Update"><i class="fa fa-edit"></i></a> |
															
                                                            <?=anchor("web/message_delete/".$ml['message_id'],"<i class=\"fa fa-remove\"></i>",array('onclick' => "return confirm('Do you want delete this record')",'title'=>'Delete'))?>
														</td>
													</tr>
													<?php } ?>
												</tbody>
                                            </table>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

<?php include 'application/views/includes/footer.php';?>