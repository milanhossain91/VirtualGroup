<?php
    if($result_type['result_type']==1){ ?>
    <!--This portion for display A+ student list-->
    <h1>The following student has gotten "A+"</h1>
    <table class="table table-striped table-bordered" align="center" style="width: 100%">	
        <tr>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
        </tr>
            <?php
                $a=1;
                $gpa=0;
                $sub=0;
                foreach($result_list as $record) {
                /**This is for display student result in table**/
                $student_id= $record['student_id']; 
                $exam_id= $record['exam_id']; 
                $session_id= $record['session_id']; 
                $department_id= $record['department_id']; 
                
                $sql = "SELECT * FROM tbl_result WHERE student_id = $student_id and exam_id = $exam_id and session_id = $session_id and department_id = $department_id and gpa>0.00";
                $query = $this->db->query($sql);
                $row= $query->result_array();
                
                foreach($row as $r){                    
                    $gpa=$gpa+$r['gpa'];
                    $sub++;                    
                } 
                $total_gpa = number_format($gpa/$sub,2);
                if($total_gpa>=5.00){ ?>        
                <td class="text-center"><?php echo $student_id; ?></td>
                <td class="text-center">
                    <?php 
                        echo $total_gpa;
                    ?>
                </td>

                <?php     
                $gpa=0;
                $sub=0; 
                if (($a % 7) == 0) { ?>
                    </tr><tr>	
                <?php }
                $a++;  }  } ?>
    </table>    
    
    
    <hr />
        <!--This portion for display A student list-->
    <h1>The following student has gotten "A"</h1>
    <table class="table table-striped table-bordered" align="center" style="width: 100%">	
        <tr>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
        </tr>
            <?php
                $a=1;
                $gpa=0;
                $sub=0;
                foreach($result_list as $record) {
                /**This is for display student result in table**/
                $student_id= $record['student_id']; 
                $exam_id= $record['exam_id']; 
                $session_id= $record['session_id']; 
                $department_id= $record['department_id']; 
                
                $sql = "SELECT * FROM tbl_result WHERE student_id = $student_id and exam_id = $exam_id and session_id = $session_id and department_id = $department_id and gpa>0.00";
                $query = $this->db->query($sql);
                $row= $query->result_array();
                
                foreach($row as $r){
                    
                    $gpa=$gpa+$r['gpa'];
                    $sub++;                    
                } 
                $total_gpa = number_format($gpa/$sub,2);
                if($total_gpa>=4.00 AND $total_gpa<5.00){ ?>        
                <td class="text-center"><?php echo $student_id; ?></td>
                <td class="text-center">
                    <?php 
                        echo $total_gpa;
                    ?>
                </td>

                <?php     
                $gpa=0;
                $sub=0; 
                if (($a % 7) == 0) { ?>
                    </tr><tr>	
                <?php }
                $a++;  }  } ?>
    </table>
    
    
    
    <hr />
        <!--This portion for display A- student list-->
    <h1>The following student has gotten "A-"</h1>
    <table class="table table-striped table-bordered" align="center" style="width: 100%">	
        <tr>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
        </tr>
            <?php
                $a=1;
                $gpa=0;
                $sub=0;
                foreach($result_list as $record) {
                /**This is for display student result in table**/
                $student_id= $record['student_id']; 
                $exam_id= $record['exam_id']; 
                $session_id= $record['session_id']; 
                $department_id= $record['department_id']; 
                
                $sql = "SELECT * FROM tbl_result WHERE student_id = $student_id and exam_id = $exam_id and session_id = $session_id and department_id = $department_id and gpa>0.00";
                $query = $this->db->query($sql);
                $row= $query->result_array();
                
                foreach($row as $r){
                    $gpa=$gpa+$r['gpa'];
                    $sub++;                    
                } 
                $total_gpa = number_format($gpa/$sub,2);
                if($total_gpa>=3.50  AND $total_gpa<4.00){ ?>        
                <td class="text-center"><?php echo $student_id; ?></td>
                <td class="text-center">
                    <?php 
                        echo $total_gpa;
                    ?>
                </td>

                <?php     
                $gpa=0;
                $sub=0; 
                if (($a % 7) == 0) { ?>
                    </tr><tr>	
                <?php }
                $a++;  }  } ?>
    </table>
    
    
    
    <hr />
        <!--This portion for display B student list-->
    <h1>The following student has gotten "B"</h1>
    <table class="table table-striped table-bordered" align="center" style="width: 100%">	
        <tr>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
        </tr>
            <?php
                $a=1;
                $gpa=0;
                $sub=0;
                foreach($result_list as $record) {
                /**This is for display student result in table**/
                $student_id= $record['student_id']; 
                $exam_id= $record['exam_id']; 
                $session_id= $record['session_id']; 
                $department_id= $record['department_id']; 
                
                $sql = "SELECT * FROM tbl_result WHERE student_id = $student_id and exam_id = $exam_id and session_id = $session_id and department_id = $department_id and gpa>0.00";
                $query = $this->db->query($sql);
                $row= $query->result_array();
                
                foreach($row as $r){
                    $gpa=$gpa+$r['gpa'];
                    $sub++;                    
                } 
                $total_gpa = number_format($gpa/$sub,2);
                if($total_gpa>=3.00 AND $total_gpa<3.50){ ?>        
                <td class="text-center"><?php echo $student_id; ?></td>
                <td class="text-center">
                    <?php 
                        echo $total_gpa;
                    ?>
                </td>

                <?php     
                $gpa=0;
                $sub=0; 
                if (($a % 7) == 0) { ?>
                    </tr><tr>	
                <?php }
                $a++;  }  } ?>
    </table>
    
    
    
    
    <hr />
        <!--This portion for display C student list-->
    <h1>The following student has gotten "C"</h1>
    <table class="table table-striped table-bordered" align="center" style="width: 100%">	
        <tr>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
        </tr>
            <?php
                $a=1;
                $gpa=0;
                $sub=0;
                foreach($result_list as $record) {
                /**This is for display student result in table**/
                $student_id= $record['student_id']; 
                $exam_id= $record['exam_id']; 
                $session_id= $record['session_id']; 
                $department_id= $record['department_id']; 
                
                $sql = "SELECT * FROM tbl_result WHERE student_id = $student_id and exam_id = $exam_id and session_id = $session_id and department_id = $department_id and gpa>0.00";
                $query = $this->db->query($sql);
                $row= $query->result_array();
                
                foreach($row as $r){
                    $gpa=$gpa+$r['gpa'];
                    $sub++;                    
                } 
                $total_gpa = number_format($gpa/$sub,2);
                if($total_gpa>=2.00  AND $total_gpa<3.00){ ?>        
                <td class="text-center"><?php echo $student_id; ?></td>
                <td class="text-center">
                    <?php 
                        echo $total_gpa;
                    ?>
                </td>

                <?php     
                $gpa=0;
                $sub=0; 
                if (($a % 7) == 0) { ?>
                    </tr><tr>	
                <?php }
                $a++;  }  } ?>
    </table>
    
    
    
    
    <hr />
        <!--This portion for display D student list-->
    <h1>The following student has gotten "D"</h1>
    <table class="table table-striped table-bordered" align="center" style="width: 100%">	
        <tr>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
        </tr>
            <?php
                $a=1;
                $gpa=0;
                $sub=0;
                foreach($result_list as $record) {
                /**This is for display student result in table**/
                $student_id= $record['student_id']; 
                $exam_id= $record['exam_id']; 
                $session_id= $record['session_id']; 
                $department_id= $record['department_id']; 
                
                $sql = "SELECT * FROM tbl_result WHERE student_id = $student_id and exam_id = $exam_id and session_id = $session_id and department_id = $department_id and gpa>0.00";
                $query = $this->db->query($sql);
                $row= $query->result_array();
                
                foreach($row as $r){
                    $gpa=$gpa+$r['gpa'];
                    $sub++;                    
                } 
                $total_gpa = number_format($gpa/$sub,2);
                if($total_gpa>=1.00  AND $total_gpa<2.00){ ?>        
                <td class="text-center"><?php echo $student_id; ?></td>
                <td class="text-center">
                    <?php 
                        echo $total_gpa;
                    ?>
                </td>

                <?php     
                $gpa=0;
                $sub=0; 
                if (($a % 7) == 0) { ?>
                    </tr><tr>	
                <?php }
                $a++;  }  } ?>
    </table>
    
    
    
    
    <hr />
    
        <!--This portion for display F student list-->
    <h1>The following student has gotten "F"</h1>
    <table class="table table-striped table-bordered" align="center" style="width: 100%">	
        <tr>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
            <th class="text-center" >Student ID</th>
            <th class="text-center" >GPA</th>
        </tr>
            <?php
                $a=1;
                $gpa=0;
                $sub=0;
                foreach($result_list as $record) {
                /**This is for display student result in table**/
                $student_id= $record['student_id']; 
                $exam_id= $record['exam_id']; 
                $session_id= $record['session_id']; 
                $department_id= $record['department_id']; 
                
                $sql = 
                "SELECT * FROM tbl_result WHERE student_id = $student_id and exam_id = $exam_id and session_id = $session_id and department_id = $department_id and gpa=0.00";
                $query = $this->db->query($sql);
                $row= $query->result_array();
                
                foreach($row as $r){
                    $gpa=$gpa+$r['gpa'];
                    $sub++;                    
                } 
                $total_gpa = number_format($gpa/$sub,2);
                if($total_gpa>=0.00 AND $total_gpa<1.00){ ?>        
                <td class="text-center"><?php echo $student_id; ?></td>
                <td class="text-center">
                    <?php 
                        echo $total_gpa;
                    ?>
                </td>
                <?php     
                $gpa=0;
                $sub=0; 
                if (($a % 7) == 0) { ?>
                    </tr><tr>	
                <?php }
                $a++;  }  } ?>
    </table>
    
    
    
    

  <?php  }
  
  
  
  
  
                /**Below Portion for Degree Result**/
  
    else{ ?>
        
    
    <h1>The following student has First Division</h1>
    <table class="table table-striped table-bordered" align="center" style="width: 100%">	
        <tr>
                <th class="text-center" >Student ID</th>                
                <th class="text-center" >Student ID</th>                
                <th class="text-center" >Student ID</th>                
                <th class="text-center" >Student ID</th>                
                <th class="text-center" >Student ID</th>                
                <th class="text-center" >Student ID</th>                
                <th class="text-center" >Student ID</th>                
                <th class="text-center" >Student ID</th>                
        </tr>
                <?php
                        $a=1;
                        $x=0;
                ?>
                <?php 

                    foreach ($result_list as $record) {

                    $x++;
                        if (($x % 252) != 0) { ?>                
                <td class="text-center"><?php echo $record['gpa']; ?></td>
                <?php
                if (($a % 8) == 0) {
                echo "</tr><tr>";	} }
                        $a++;	 }  ?>
    </table>
    
    
<?php    } ?>









