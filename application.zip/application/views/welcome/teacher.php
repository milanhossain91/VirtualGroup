<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container" style="width:95%; margin:0px auto; background-color:#FFF; ">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left"> Teacher's List </h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here :</li>
                            <li><a href="<?php echo base_url();?>">Home</a><i class="fa fa-angle-right"></i></li>
                            <li class="current"> Teacher's List </li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                
                
                  <div class="breadcrumbs pull-right">	
									
			<div class="col-sm-12">
			<select class="form-control" placeholder="Department" data-placement="bottom" title="Department" name="department" 
                                 id="department_id" required onChange="check_teacher_list(document.getElementById('department_id').selectedIndex)">
				<option value=''>Select a department</option>
				<?php
				foreach($department_list as $row){ ?>
				<option value='<?php echo $row['department_id'];?>'><?php echo $row['department_name']; ?></option>
				<?php }
				?>
				</select>
				     
				</div>
				</div>
                
                <div class="page-content" id='display'>
                    <div class="row page-row">
                        <div class="news-wrapper col-md-12 col-sm-12 ">
                            <article class="news-item" style="min-height: 200px;">
                                <div class="table-responsive">
                                    <table class="table table-condensed">
                                        <thead>
                                            <tr>
                                                <th>Teacher ID</th>
                                                <th>Teacher Name</th>
                                                <th>Designation</th>
                                                <th>Department</th>
                                                <th>Phone</th>
                                                <th>Picture</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                foreach($teacher_list as $tl){ ?>
                                                <tr>
                                                    <td><?php echo $tl['teacher_id'];?></td>
                                                    <td><?php echo $tl['teacher_name'];?></td>
                                                    <td>
                                                    <?php
                                                    $des_id = $tl['designation_id']; 
                                                    		$sql = "SELECT designation_name FROM tbl_designation WHERE designation_id = '$des_id' LIMIT 1";
			                                        $query = $this->db->query($sql);
			                                        $row = $query->row_array();
                                                    		echo $row['designation_name'];
                                                    ?>
                                                    </td>
                                                    <td><?php echo $tl['department_name'];?></td>
                                                    <td><?php echo $tl['present_contact'];?></td>
                                                    <td>
                                                
                                                        <img src="<?php echo base_url();?>upload/teacher_image/<?php echo $tl['teacher_image'];?>" alt="" style="width:100px"/>
                                                    </td>
                                                </tr>
                                            <?php    }
                                            ?>
                                            

                                        </tbody>
                                    </table><!--//table-->
                                </div><!--//table-responsive-->
                               <hr />
                                <br/>
                             
                            </article><!--//news-item-->
                        </div><!--//news-wrapper-->
                        <aside class="page-sidebar  col-md-3 col-md-offset-1 col-sm-4 col-sm-offset-1 col-xs-12">
                        </aside>
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper-->
        </div><!--//content-->
    <?php require 'application/views/welcome/includes/footer.php';?>  
    
    
<script>
    function check_teacher_list()
    {
        var department_id = $('#department_id').val();
		
       alert(department_id);
        $.ajax({ 
        url: baseUrl+'welcome/get_teacher_list_by_department_id',
        data:
            {                  
                'department_id':department_id
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';
                if(result == 'success')
                {        
				$('#display').html(mainContent);  				
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
</script> 
