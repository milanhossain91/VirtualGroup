<!-- Page Main -->
<div role="main" class="main">

	<!-- Home Slider -->
	<div class="rs-container light rev_slider_wrapper">
		<div id="revolutionSlider" class="slider rev_slider" data-plugin-revolution-slider data-plugin-options='{"delay": 9000, "gridwidth": 1170, "gridheight": 500}'>
			<ul>
            <?php
                 foreach($slide_image as $img){ ?>
                	<li data-transition="fade" class="typo-dark heavy">
                    <img src="<?= base_url();?>template/images/slides/<?= $img['slide_image_name'];?>"  
						alt=""
						data-bgposition="center center" 
						data-bgfit="cover" 
						data-bgrepeat="no-repeat" 
						class="rev-slidebg">
					</li>
			<?php    } ?>
			</ul>
		</div>
	</div><!-- Home Slider -->
	</div><!-- Home Slider -->


				
			