<!DOCTYPE html>
<!--[if IE 8]> <html lang="en" class="ie8"> <![endif]-->  
<!--[if IE 9]> <html lang="en" class="ie9"> <![endif]-->  
<!--[if !IE]><!--> <html lang="en"> <!--<![endif]-->  
<?php
    $sql = "SELECT * FROM tbl_school_information LIMIT 1";
    $query = $this->db->query($sql);
    $sc_info = $query->row_array();
?>
<head>
    <title><?php echo $sc_info['school_name'];?></title>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">    
    <link rel="shortcut icon" href="<?php echo base_url();?>template/template/images/favicon.ico">  
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700' rel='stylesheet' type='text/css'>   
    <!-- Global CSS -->
    <link rel="stylesheet" href="<?php echo base_url();?>template/template/plugins/bootstrap/css/bootstrap.min.css">   
    <!-- Plugins CSS -->    
    <link rel="stylesheet" href="<?php echo base_url();?>template/template/plugins/font-awesome/css/font-awesome.css">
    <link rel="stylesheet" href="<?php echo base_url();?>template/template/plugins/flexslider/flexslider.css">
    <link rel="stylesheet" href="<?php echo base_url();?>template/template/plugins/pretty-photo/css/prettyPhoto.css"> 
    <!-- Theme CSS -->  
    <link id="theme-style" rel="stylesheet" href="<?php echo base_url();?>template/template/css/styles.css">
    <link id="theme-style" rel="stylesheet" href="<?php echo base_url();?>template/template/css/custom.css">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
      <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
		<script>var baseUrl='<?php echo BASEURL;?>';</script>
</head> 

<body class="home-page" style="background-image:url(<?php echo BASEURL;?>template/template/images/body_bg.jpg);">
    <div class="page-wrapper" style="width:80%; margin:0px auto; background-color:#FFF; box-shadow:0 0 8px 5px #888888;">
        <!-- ******HEADER****** --> 
        <header class="header" style="margin:0px auto;">  
            <div class="top-bar">
                <div class="container" >              
                 <span style="font-weight:bold; color:#FFF;"> <?php   echo date("d-M-Y"); ?></span>   
                </div>      
            </div><!--//to-bar-->
            <div class="header-main container" style="padding: 10px 8% 10px 0;">
                <div  class="col-md-6 col-sm-6">
                    <div  class="logo col-md-2 col-sm-2">
                       <h1>
                        <a href="<?php echo base_url();?>">
                            <img id="logo" src="<?php echo base_url();?>upload/institute_logo/<?php echo $sc_info['logo'];?>" alt="Logo" height="80" width="80">
                        </a> 
                  </h1>
                    </div>
                    <div  class="col-md-10 col-sm-10">
                        <h3 style="margin-top:45px;color:#3b3b3b;font-weight:bold; padding-left:10px;">
                            <?php
                                echo $sc_info['school_name'];
                            ?>
                        </h3>
                    </div>
                    
                    
                </div>
                <div class="info col-md-6 col-sm-6">
                    <ul class="menu-top navbar-right hidden-xs">
                        <li class="divider"><a href="<?php echo base_url();?>">হোম</a></li><!--
                        <li class="divider"><a href="faq.html">FAQ</a></li> -->
                        <li><a href="<?php echo base_url();?>admin/index" target="_blank">লগ ইন</a></li>
                    </ul><!--//menu-top-->
                    <br /><br>

                    <form class="pull-left search-form" role="search">
                        <div class="col-sm-2" style="float:left;">
                            <input class="form-control" type="text" placeholder="খুঁজুন"> 
                        </div>
                        <div class="pull-right">
                       <button type="submit" class="btn btn-theme">অনুসন্ধান</button>
                       </div>
                    </form> 
                    
                    
                    
                    <div class="socialicon pull-right" style="padding-left:40px;">
                    
                    
                            <div class="full-row">
                                <label style="color:#9E5BBA; font-size:12px;">সাথে থাকুন:</label>
                            </div>
                         <div class="full-row">
   <a target="_blank" href="https://www.facebook.com/pages/Ispahani-Public-School-College/45563605678?sk=info&tab=overview" target="_blank"><i class="fa fa-facebook"></i></a>
                                <a target="_blank" href="https://twitter.com/" ><i class="fa fa-twitter"></i></a>
                                <a target="_blank" href="https://www.youtube.com/" ><i class="fa fa-youtube"></i></a>
                                <a target="_blank" href="https://plus.google.com/107682375756108840572/about?gl=bd&hl=bn" ><i class="fa fa-google-plus"></i></a>
                    </div>
                    </div>
                    <div class="contact pull-right">
                        <p class="phone"><i class="fa fa-phone"></i>
                            <?php echo $sc_info['contact_no'];?>
                        </p> 
                        
                        <p class="email"><i class="fa fa-envelope"></i><a href="mailto:<?php echo $sc_info['email'];?>">
                            <?php echo $sc_info['email'];?>
                            </a></p>
                    </div><!--//contact-->
                </div><!--//info-->
            </div><!--//header-main-->
        </header><!--//header-->
        
        
        <!-- ******NAV****** -->
        <nav class="main-nav" role="navigation">
            <div class="container">
                <div class="navbar-header">
                    <button class="navbar-toggle" type="button" data-toggle="collapse" data-target="#navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button><!--//nav-toggle-->
                </div><!--//navbar-header-->            
                <div class="navbar-collapse collapse" id="navbar-collapse">
                    <ul class="nav navbar-nav">
                        <li class="nav-item"><a href="<?php echo base_url();?>">হোম</a></li>
                        
						<li class="nav-item dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="0" data-close-others="false" href="#">প্রতিষ্ঠান <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo base_url();?>about_college">প্রতিষ্ঠান পরিচিতি</a></li>
                                <li><a href="<?php echo base_url();?>">ক্লাস ভিত্তিক বিষয় </a></li>
                                <li><a href="<?php echo base_url();?>">সাংস্কৃতিক তথ্য</a></li>
                                <li><a href="<?php echo base_url();?>">ম্যানেজিং কমিটি</a></li>
                            </ul>
                        </li>
						
                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="0" data-close-others="false" href="#">একাডেমিক <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu">
                               <!-- <li><a href="<?php echo base_url();?>welcome/principal_list">Headmaster List</a></li>
                                <li><a href="base_urlwelcome/vice_principal_list">Vice Principal List</a></li>-->
                                <li><a href="<?php echo base_url();?>important_information">একাডেমিক ক্যালেন্ডার</a></li>
								<li><a href="<?php echo base_url();?>">বাৎসরিক ছুটির তালিকা</a></li>
								<li><a href="<?php echo base_url();?>class_routine">ক্লাস ভিত্তিক রুটিন</a></li>
								<li><a href="<?php echo base_url();?>central_routine">কেন্দ্রীয় রুটিন</a></li>
								<li><a href="<?php echo base_url();?>exam_routine">পরীক্ষার রুটিন</a></li>
								<li><a href="<?php echo base_url();?>department">ডিপার্টমেন্ট</a></li>
                                <li><a href="<?php echo base_url();?>rules_regulations">প্রাতিষ্ঠানিক আইন ও নীতিমালা</a></li>
                                <li><a href="<?php echo base_url();?>steps">তৃতীয় ও চতুর্থ শ্রেণীর কর্মচারীর তালিকা</a></li>
                                <li><a href="#">প্রশংসা পত্র ও টি.সি</a></li>
                                <li><a href="<?php echo base_url();?>facilities">সুযোগ-সু্বিধা</a></li>
                                <li class="nav-item dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="0" data-close-others="false" href="#">পরীক্ষার ফলাফল <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo base_url();?>welcome/result_view">যৌথ ফলাফল</a></li> 
                                <li><a href="<?php echo base_url();?>welcome/mark_sheet">ব্যাক্তিগত ফলাফল</a></li>
                                <li><a href="#">মেধাবী ছাত্র-ছাত্রীদের তালিকা</a></li>
                                
                            </ul>
                        </li><!--//dropdown-->
                            </ul>
                        </li>
						
                        
                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="0" data-close-others="false" href="#">প্রাতিষ্ঠানিক কার্যাবলী <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo base_url();?>welcome/library">পাঠাগার ব্যবস্থাপনা</a></li>
                                <li><a href="#">উপস্থিতি রিপোর্ট </a></li>
                                <li><a href="#">হিসাব রিপোর্ট</a></li>
                            </ul>
                        </li><!--//dropdown-->
                        
						<li class="nav-item dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="0" data-close-others="false" href="#">ই-সার্ভিস <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="#">অনলাইন ভর্তি</a></li>
                                <li><a href="#">অনলাইন পেমেন্ট</a></li>
                            </ul>
                        </li><!--//dropdown-->
						
                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="0" data-close-others="false" href="#">শিক্ষক <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo base_url();?>teacher">কর্মরত শিক্ষক/শিক্ষিকার তথ্য</a></li>
                                <li><a href="<?php echo base_url();?>welcome/vacant_post">শিক্ষক/শিক্ষিকার শূণ্যপদ</a></li>
								<li><a href="<?php echo base_url();?>welcome/teacher_panel">শিক্ষক/শিক্ষিকা প্যানেল</a></li>
								<li><a href="<?php echo base_url();?>welcome/teacher_archive">শিক্ষক/শিক্ষিকা আর্কাইভ</a></li>
                            </ul>
                        </li><!--//dropdown-->
                        
                        <!--<li class="nav-item"><a href="<?php echo base_url();?>teacher">Teacher</a></li>-->
                        <li class="nav-item dropdown">
						<a class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="0" data-close-others="false" href="#">ছাত্র/ছাত্রী<i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo base_url();?>student">ছাত্র/ছাত্রীর তথ্য</a></li>
                                <li><a href="<?php echo base_url();?>welcome/student_panel">ছাত্র/ছাত্রী প্যানেল</a></li>
								<li><a href="<?php echo base_url();?>welcome/guardian_panel">অভিভাবক প্যানেল</a></li>
                            </ul>
                        </li>
                        
                        
                        <li class="nav-item dropdown">
                            <a class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-delay="0" data-close-others="false" href="#">নোটিশ <i class="fa fa-angle-down"></i></a>
                            <ul class="dropdown-menu">
                                <li><a href="<?php echo base_url();?>general_notice">সাধারণ নোটিশ</a></li>
                                <li><a href="<?php echo base_url();?>admission_notice">ভর্তি নোটিশ</a></li>
								<li><a href="<?php echo base_url();?>">সার্কুলার</a></li>
                            </ul>
                        </li>
                        
                        <li class="nav-item"><a href="<?php echo base_url();?>photo_gallery">ছবি গ্যালারি</a></li>
						<!--<li class="nav-item"><a href="<?php echo base_url();?>welcome/forms">Forms</a></li>	
                        <li class="nav-item"><a href="<?php echo base_url();?>contact">Complain</a></li>-->
                    </ul><!--//nav-->
                </div><!--//navabr-collapse-->
            </div><!--//container-->
        </nav><!--//main-nav-->
        