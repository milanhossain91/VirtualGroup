<div class="table-responsive">



	<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
				<thead>
					<tr>
						<th>Student ID</th>
						<th>Student Name</th>
                        <th>Total Marks</th>
						<th>Total Point</th>
						<th>GPA</th>
					</tr>
				</thead>
				<tbody>
<?php
					foreach($student_list as $sl){ ?>
						<tr>
							<td>
							<input type="text" readonly class="form-control" name="student_id[]" id="student_id" value="<?php echo $sl['student_id'];?>">
							</td>
							<td>
							<input type="text" readonly class="form-control" name="student_name[]" id="student_name" value="<?php echo $sl['student_name'];?>">
							</td>
							<?php
							
							
							$student_id =$sl['student_id'];
						$term_id= $details['term_id'];
						$exam_year= $details['exam_year'];
						$sql1 = "SELECT * FROM `tbl_tabulation_marks` inner join tbl_subject on tbl_tabulation_marks.subject_id=tbl_subject.subject_id inner join tbl_term_subject on tbl_tabulation_marks.subject_id=tbl_term_subject.subject_id where tbl_tabulation_marks.student_id='$student_id' and tbl_tabulation_marks.term_id='$term_id' and tbl_tabulation_marks.exam_year='$exam_year' order by tbl_subject.subject_id";
						//echo $sql1;
						$query1 = mysql_query($sql1);
						$ins=0;
						while($numbers1= mysql_fetch_array($query1))
							{
								$results1[$ins]=$numbers1;
								$ins++;
							}
							$full_marks1=0;
							$obtained_marks=0;
							
						foreach($results1 as $rs)
						{
							$full_marks1+=$rs['sub_full_marks'];
							$obtained_marks+=$rs['sub_total_marks'];
						}
		$rows= mysql_num_rows($query);	
		
								$grand_total=0;
								$grand_total_point=0;
								$flag=0;  
							
							$school_id= $details['school_id'];
                            $sqlgs = "SELECT * FROM `tbl_grd_system` as A WHERE A.school_id = '$school_id' order by start_marks desc";
							$querygs = mysql_query($sqlgs);
							$igs=0;
							while($gread_scale= mysql_fetch_array($querygs))
								{
									$gread_scales[$igs]=$gread_scale;
									$igs++;
								}
								$itgp=0;
								
							//print_r($gread_scales);echo "000000000000";
							foreach($gread_scales as $gss)
							{
								$start_marks=$gss['start_marks'];
								if($rs['sub_total_marks']>=$start_marks)
								{
									$total_grade_point[$itgp]=$gss['gpa'];
									$itgp++;
								}
							}
							
                            ?>
					
					
                            <td>
			<input type="text" readonly class="form-control" name="total_marks[]" <?php if($flag==1){echo 'style="background-color:#CD0000; color:#fff; font-weight:bold;"' ;} ?> id="obtain_marks<?php echo $sl['student_id'];?>" value="<?php echo round(($full_marks1),0); ?>">
							</td>
							<td>
			<input type="text" readonly class="form-control" name="grand_total_point[]" <?php if($flag==1){echo 'style="background-color:#CD0000; color:#fff; font-weight:bold;"' ;} ?> id="obtain_marks<?php echo $sl['student_id'];?>" value="<?php echo $obtained_marks;?>">
							</td>
                            
                            <?php
							$student_id =$sl['student_id'];
							$term_id= $details['term_id'];
							$exam_year= $details['exam_year'];
						
		$sqlav = "SELECT * FROM tbl_tabulation_marks where student_id='$student_id' and term_id='$term_id' and exam_year='$exam_year'";
		//echo $sqlav;
		$queryav = mysql_query($sqlav);
		$i=0;
        while($numbers= mysql_fetch_array($queryav))
		{
			$results[$i]=$numbers;
			$i++;
		}
		$rows= mysql_num_rows($queryav);	
		//echo $rows;	
			foreach($term as $term_marks){
				$full_marks=$term_marks['full_marks'];
			}
			
			$total_full_marks=$full_marks*$rows;
			$total_point=0;
							
			foreach($results as $result){
				
				$obtained_marks=$result['sub_total_marks'];
				$total_marks+=$obtained_marks;
				
				$obtained_point=$result['sub_grade_point'];
				$total_point+=$obtained_point;
			} 
				$itgp=0;
				$av_point=round(($total_point/$rows),1);
				foreach($gread_scales as $gss)
							{
								$start_point=$gss['grd_point'];
								if($av_point>=$start_point)
								{
									$point[$itgp]=$gss['gpa'];
									$itgp++;
								}
							}
							?>
                            
							<td>
							<input type="text" readonly class="form-control" name="total_gpa[]" <?php if($flag==1){echo 'style="background-color:#CD0000; color:#fff; font-weight:bold;"' ;} ?> id="total_gpa" value="<?php echo $av_point;?>" >
							</td>
						</tr>
					<?php	} ?>
					
				</tbody>
			</table>


	</form>
</div>