<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">Exam Routine View</h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here:</li>
                            <li><a href="<?php echo base_url();?>">Home</a><i class="fa fa-angle-right"></i></li>
                            <li class="current">Exam Routine View</li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                
                <div class="page-content">
                    <div class="row page-row">
                        <div class="news-wrapper col-md-12 col-sm-12 routine_view">
                            <article class="news-item" style="min-height: 200px;">
                                <h3 class="has-divider text-highlight" style="margin-top:-10px;"><a href="javascript:history.go(-1)" >Back</a></h3> 
                                
                                <div class="form-group" >
                                    <center>
                                        <div class="col-sm-12">
                                            <h2>
                                                <?php echo $exam_routine_list['class_name']; ?> (<?php echo $exam_routine_list['department_name']; ?>) 
                                            </h2>

                                            <h3>Session : <?php echo $exam_routine_list['session_name']; ?></h3>
                                            <h2>Exam : <?php echo $exam_routine_list['exam_name']; ?> </h2>                                            
                                            <br/>
                                            <b><?php echo $exam_routine_list['heading']; ?></b>
                                        </div>
                                    </center>
                                    <div class="col-sm-12">
                                        <?php echo $exam_routine_list['details']; ?>
                                    </div>
                                </div>
                            </article><!--//news-item-->
                        </div><!--//news-wrapper-->
                        <aside class="page-sidebar  col-md-3 col-md-offset-1 col-sm-4 col-sm-offset-1 col-xs-12">
                        </aside>
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper-->
        </div><!--//content-->
    
<?php require 'application/views/welcome/includes/footer.php';?>    
