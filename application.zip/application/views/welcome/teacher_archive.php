<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">Teacher Archive List</h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here:</li>
                            <li><a href="<?php echo base_url();?>">Home</a><i class="fa fa-angle-right"></i></li>
                            <li class="current">Teacher Archive List</li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                
                
                                 
                <div class="page-content" id='display'>
                    <div class="row page-row">
                        <div class="news-wrapper col-md-12 col-sm-12 ">
                            <article class="news-item" style="min-height: 200px;">
                                <div class="table-responsive">
                                    <table class="table table-condensed">
                                        <thead>
                                            <tr>
                                                <th>Teacher ID</th>
                                                <th>Teacher Name</th>
                                                <th>Designation</th>
                                                <th>Department</th>
												<th>Joining Date</th>
												<th>Release Date</th>
                                                
                                                <th>Picture</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                                foreach($teacher_list as $tl){ ?>
                                                <tr>
                                                    <td><?php echo $tl['teacher_id'];?></td>
                                                    <td><?php echo $tl['teacher_name'];?></td>
                                                    <td>
                                                    <?php
                                                    $des_id = $tl['designation_id']; 
                                                    		$sql = "SELECT designation_name FROM tbl_designation WHERE designation_id = '$des_id' LIMIT 1";
			                                        $query = $this->db->query($sql);
			                                        $row = $query->row_array();
                                                    		echo $row['designation_name'];
                                                    ?>
                                                    </td>
                                                    <td><?php echo $tl['department_name'];?></td>
													<td><?php echo $tl['joining_date'];?></td>
													<td><?php echo $tl['release_date'];?></td>
                                                
                                                    <td>
                                                        <img src="<?php echo base_url();?>template/upload/teacher_image/<?php echo $tl['photo'];?>" alt="" style="width:100px"/>
                                                    </td>
                                                </tr>
                                            <?php    }
                                            ?>
                                            

                                        </tbody>
                                    </table><!--//table-->
                                </div><!--//table-responsive-->
                               <hr />
                                <br/>
                             
                            </article><!--//news-item-->
                        </div><!--//news-wrapper-->
                        <aside class="page-sidebar  col-md-3 col-md-offset-1 col-sm-4 col-sm-offset-1 col-xs-12">
                        </aside>
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper-->
        </div><!--//content-->
    
<?php require 'application/views/welcome/includes/footer.php';?>    
    
<script>
    function check_teacher_list()
    {
        var department_id = $('#department_id').val();
       // document.write(department_id);
        if(department_id==0){
            alert("Select Department First");
        }
        
        $.ajax({ 
        url: baseUrl+'welcome/get_teacher_list_by_department_id',
        data:
            {                  
                'department_id':department_id,
             
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';
                if(result == 'success')
                {        
				$('#display').html(mainContent);  				
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
</script> 
