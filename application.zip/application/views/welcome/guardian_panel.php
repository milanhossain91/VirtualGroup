<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
       <div class="content container" style="width:95%; margin:0px auto; background-color:#FFF; ">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left"> 
                     <?php
                            echo $rules_list['information_heading'];
                        ?>
                    </h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here :</li>
                            <li><a href="<?php echo base_url();?>">Home</a><i class="fa fa-angle-right"></i></li>
                            <li class="current"> <?php
                            echo $rules_list['information_heading'];
                        ?> </li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                
                <div class="page-content">
                    <div class="row page-row">
                        <div class="news-wrapper col-md-10 col-sm-10 ">
                            <article class="news-item">
                                <div class="notice_view">
                                    <?php
                                        echo $guardian_panel['information_details'];
                                    ?>
                                </div>
                                
                            </article><!--//news-item-->
                        </div><!--//news-wrapper-->
                        <aside class="page-sidebar  col-md-3 col-md-offset-1 col-sm-4 col-sm-offset-1 col-xs-12">
                        </aside>
                    </div><!--//page-row-->
                </div><!--//page-content-->
                
                
                
                
            </div><!--//page-wrapper--> 
        </div><!--//content-->
        <?php require 'application/views/welcome/includes/footer.php';?> 
