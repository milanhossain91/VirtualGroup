<?php
    if($result_type['result_type']==1){ ?> 
        <!-- This is for HSC Result -->
        <h1>The Following Student gotten 'A+' </h1>
        <table class="table table-striped table-bordered" align="center" style="width: 100%">
            <tr>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
            </tr>
            <?php
                $a=1;
                foreach($result_list as $rl){
                    $total_gpa = number_format($rl['gpa']/$rl['subject'],2);
                    if($total_gpa>=5){ ?>
                        <td class="text-center"><?php echo $rl['student_id']; ?></td>
                        <td class="text-center"><?php echo $total_gpa; ?></td>
                <?php 
                        if (($a % 7) == 0) {
                            echo "</tr><tr>";
                        }
                        $a++;
                    } 
                }
            ?>
        </table>
        
        
        
<br/>

        <h1>The Following Student gotten 'A' </h1>
        <table class="table table-striped table-bordered" align="center" style="width: 100%">
            <tr>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
            </tr>
            <?php
                $a1=1;
                foreach($result_list as $rl1){
                    $total_gpa1 = number_format($rl1['gpa']/$rl1['subject'],2);
                    if($total_gpa1>=4 AND $total_gpa1<5){ ?>
                        <td class="text-center"><?php echo $rl1['student_id']; ?></td>
                        <td class="text-center"><?php echo $total_gpa1; ?></td>
                <?php 
                        if (($a1 % 7) == 0) {
                            echo "</tr><tr>";
                        }
                        $a1++;
                    } 
                }
            ?>
        </table>
        
        
        
<br/>

        <h1>The Following Student gotten 'A-' </h1>
        <table class="table table-striped table-bordered" align="center" style="width: 100%">
            <tr>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
            </tr>
            <?php
                $a2=1;
                foreach($result_list as $rl2){
                    $total_gpa2 = number_format($rl2['gpa']/$rl2['subject'],2);
                    if($total_gpa2>=3.5 AND $total_gpa2<4){ ?>
                        <td class="text-center"><?php echo $rl2['student_id']; ?></td>
                        <td class="text-center"><?php echo $total_gpa2; ?></td>
                <?php 
                        if (($a2 % 7) == 0) {
                            echo "</tr><tr>";
                        }
                        $a2++;
                    } 
                }
            ?>
        </table>



<br/>

        <h1>The Following Student gotten 'B' </h1>
        <table class="table table-striped table-bordered" align="center" style="width: 100%">
            <tr>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
            </tr>
            <?php
                $a3=1;
                foreach($result_list as $rl3){
                    $total_gpa3 = number_format($rl3['gpa']/$rl3['subject'],2);
                    if($total_gpa3>=3 AND $total_gpa3<3.5){ ?>
                        <td class="text-center"><?php echo $rl3['student_id']; ?></td>
                        <td class="text-center"><?php echo $total_gpa3; ?></td>
                <?php 
                        if (($a3 % 7) == 0) {
                            echo "</tr><tr>";
                        }
                        $a3++;
                    } 
                }
            ?>
        </table>


<br/>

        <h1>The Following Student gotten 'C' </h1>
        <table class="table table-striped table-bordered" align="center" style="width: 100%">
            <tr>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
            </tr>
            <?php
                $a4=1;
                foreach($result_list as $rl4){
                    $total_gpa4 = number_format($rl4['gpa']/$rl4['subject'],2);
                    if($total_gpa4>=2 AND $total_gpa4<3){ ?>
                        <td class="text-center"><?php echo $rl4['student_id']; ?></td>
                        <td class="text-center"><?php echo $total_gpa4; ?></td>
                <?php 
                        if (($a4 % 7) == 0) {
                            echo "</tr><tr>";
                        }
                        $a4++;
                    } 
                }
            ?>
        </table>



<br/>

        <h1>The Following Student gotten 'D' </h1>
        <table class="table table-striped table-bordered" align="center" style="width: 100%">
            <tr>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
            </tr>
            <?php
                $a5=1;
                foreach($result_list as $rl5){
                    $total_gpa5 = number_format($rl5['gpa']/$rl5['subject'],2);
                    if($total_gpa5>=1 AND $total_gpa5<2){ ?>
                        <td class="text-center"><?php echo $rl5['student_id']; ?></td>
                        <td class="text-center"><?php echo $total_gpa5; ?></td>
                <?php 
                        if (($a5 % 7) == 0) {
                            echo "</tr><tr>";
                        }
                        $a5++;
                    } 
                }
            ?>
        </table>        
        
        

<br/>

        <h1>The Following Student gotten 'F' </h1>
        <table class="table table-striped table-bordered" align="center" style="width: 100%">
            <tr>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >GPA</th>
            </tr>
            <?php
                $a6=1;
                $total_gpa6=0;
                foreach($fail_list as $rl6){
                    ?>
                    <td class="text-center"><?php echo $rl6['student_id']; ?></td>
                    <td class="text-center"><?php echo $total_gpa6; ?></td>
                <?php 
                    if (($a6 % 7) == 0) {
                        echo "</tr><tr>";
                    }
                    $a6++;
                }
            ?>
        </table>        
        
      


    <?php }    
    
    /**Degree Result View**/
    else
        { ?>
        
        <h1>The Following Student gotten 'First Division' </h1>
        <table class="table table-striped table-bordered" align="center" style="width: 100%">
            <tr>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>                
            </tr>
            <?php
                $da=1;
                foreach($degree_result_list as $drl){
                    $total_marks = number_format($drl['marks']/$drl['subject'],2);
                    if($total_marks>=60){ ?>
                        <td class="text-center"><?php echo $drl['student_id']; ?></td>
                        <td class="text-center"><?php echo $drl['marks']; ?></td>
                <?php 
                        if (($da % 6) == 0) {
                            echo "</tr><tr>";
                        }
                        $da++;
                    } 
                }
            ?>
        </table>
        
        <br /><br />
        
        
        <h1>The Following Student gotten 'Second Division' </h1>
        <table class="table table-striped table-bordered" align="center" style="width: 100%">
            <tr>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>                
            </tr>
            <?php
                $da1=1;
                foreach($degree_result_list as $drl1){
                    $total_marks1 = number_format($drl1['marks']/$drl1['subject'],2);
                    if($total_marks1>=45 AND $total_marks1<60){ ?>
                        <td class="text-center"><?php echo $drl1['student_id']; ?></td>
                        <td class="text-center"><?php echo $drl1['marks']; ?></td>
                <?php 
                        if (($da1 % 6) == 0) {
                            echo "</tr><tr>";
                        }
                        $da1++;
                    } 
                }
            ?>
        </table>
        
        <br /><br />
        
        
        <h1>The Following Student gotten 'Third Division' </h1>
        <table class="table table-striped table-bordered" align="center" style="width: 100%">
            <tr>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>                
            </tr>
            <?php
                $da2=1;
                foreach($degree_result_list as $drl2){
                    $total_marks2 = number_format($drl2['marks']/$drl2['subject'],2);
                    if($total_marks2>=33 AND $total_marks2<45){ ?>
                        <td class="text-center"><?php echo $drl2['student_id']; ?></td>
                        <td class="text-center"><?php echo $drl2['marks']; ?></td>
                <?php 
                        if (($da2 % 6) == 0) {
                            echo "</tr><tr>";
                        }
						$da2++;
                    } 
                }
            ?>
        </table>
        
        <br /><br />
        
        <h1>The Following Student gotten 'Fail' </h1>
        <table class="table table-striped table-bordered" align="center" style="width: 100%">
            <tr>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>
                <th class="text-center" >Student ID</th>
                <th class="text-center" >Total Marks</th>                
            </tr>
            <?php
                $dfl=1;
                $total_gpa61=0;
                foreach($degree_fail_list as $dfl){
                    ?>
					<td class="text-center"><?php echo $dfl['student_id']; ?></td>
					<td class="text-center"><?php echo $total_gpa61; ?></td>
                <?php 
					if (($dfl % 6) == 0) {
						echo "</tr><tr>";
					}
					$dfl++;
                }
            ?>
        </table>
        
        
        

            
<?php    }    ?>
  