<?php require 'application/views/welcome/includes/header.php';?>    

    <!-- ******CONTENT****** --> 
        <div class="content container" style="width:95%; margin:12% auto 0px; background-color:#FFF; ">
            <div class="page-wrapper">
                <header class="page-heading clearfix">
                    <h1 class="heading-title pull-left">About School </h1>
                    <div class="breadcrumbs pull-right">
                        <ul class="breadcrumbs-list">
                            <li class="breadcrumbs-label">You are here :</li>
                            <li><a href="<?php echo base_url();?>">Home </a><i class="fa fa-angle-right"></i></li>
                            <li class="current">About School </li>
                        </ul>
                    </div><!--//breadcrumbs-->
                </header> 
                <div class="page-content">
                    <div class="row">
                        <article class="contact-form col-md-12 col-sm-12  page-row">
                            <section class="about_portion">
                        
                            <img src="<?php echo base_url();?>template/upload/about_image/<?php echo $about['about_image'];?>" alt="" />
                            
                            <?php echo $about['about_details'];?>
						
                    </section><!--//course-finder-->
                        </article><!--//contact-form-->
                        
                    </div><!--//page-row-->
                </div><!--//page-content-->
            </div><!--//page-wrapper--> 
        </div><!--//content-->
        <?php require 'application/views/welcome/includes/footer.php';?>
