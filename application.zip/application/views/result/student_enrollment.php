<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
            
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
            
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Result View </h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
								<div class="row">				
                                    <div class="col-md-12">
                                        <div class="widget">
											<div class="widget-content">
                                                
                                                <div class="form-group">
                                                    <div class="row">
                                                       <div class="col-sm-4">
                                                            <label>Class Name</label>
                                                            <select name="class_id" id="class_id" required class="form-control" />
                                                                <option value="">Select Class</option>
                                                                <?php foreach($class_list as $cl){ ?>       
                                                                <option value="<?php echo $cl['class_id']; ?>"><?php echo $cl['class_name']; ?></option>
                                                                <?php } ?>
                                                            </select>
                                                        </div>
                                                        <div class="col-sm-4">
                                                            <label>Session</label>
                                                            <select class="form-control" name="session_id" id="session_id" />
                                                                <option value="">-----Select Session-----</option>
                                                                <?php foreach($session as $sl){ ?>
                                                                <option value="<?= $sl['session_id'];?>"><?= $sl['session_name'];?></option>
                                                                <?php    } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                        
                               
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4"><br/>
                                                            <button class="btn btn-primary btn-label-center" onclick="student_enrollment_json()" type="button"> Result View </button>
                                                        </div>
                                                    </div>
                                                </div>
                                    
                                    
                                            	<hr />
                                            	<div id="display">
                          
                                            	</div>
											</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
    
<?php include 'application/views/includes/footer.php';?>

<!--Check department name based on class id--->
<script>
	function student_enrollment_json()
		{
			var class_id = $('#class_id').val();        
			var session_id = $('#session_id').val();
			
			if(!class_id)
			{
				$('#class_id').after("<div id='validation_class' class='validation_js'> Please select a class name </div>")
						$('#validation_class').delay(3000).hide('slow');
						return;
			}
			if(!session_id)
			{
				$('#session_id').after("<div id='validation_section' class='validation_js'> Please select a section name </div>")
						$('#validation_section').delay(3000).hide('slow');
						return;
			}
	
			$.ajax({ 
			url: baseUrl+'result/student_enrollment_json',
			data:
				{                  
					'class_id':class_id,
					'session_id':session_id
				}, 
				dataType: 'json',
				success: function(data)
				{
					result                = ''+data['result']+'';
					mainContent           = ''+data['mainContent']+'';
	
					if(result == 'success')
					{            
						$('#display').html(mainContent);     
					}                
				}
			});
		}
		
		

</script> 


