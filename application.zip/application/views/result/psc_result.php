<!-- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
				
<!-- Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">			
    <div class="content">
        <!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-table'></i> PSC Result </h1>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="widget" style="min-height: 400px">
					<div class="widget-content">
						<div class="widget-content padding">
							<div class="form-group">
								<div class="row">
									<div class="col-sm-3 col-md-3">
										<label>Session <span style="color:red;">*</span></label>
										<select class="form-control" name="session_id" id="session_id" onChange="get_student_list_marksheet(this.value)">
											<option value="">-----Select Session-----</option>
											<?php foreach($session_list as $sl){ ?>
											<option value="<?= $sl['session_id'];?>"><?= $sl['session_name'];?></option>
											<?php } ?>
										</select>
									</div>
									<div class="col-sm-3 col-md-3">
										<label>Student Name <span style="color:red;">*</span></label>
										<select name="student_id" required id="student_id" class="form-control">
											<option value="">-----Select student-----</option>
										</select>
									</div>
								</div>
							</div><br />
							<button class="btn btn-success btn-label-center" onclick="mark_sheet_json()" type="button"> Result View </button>
                            <hr />
							<div id="display">
								<!-- content will display here -->
							</div>
						</div><!--//section-content-->
					</div><!--//news-wrapper-->
				</div><!--//page-row-->
			</div><!--//page-content-->
		</div><!--//page-wrapper-->
		
		
<div class="container">
<table class="table">
    <thead>
        <tr>
            <th>#</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Username</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
       
        <tr>
            <th scope="row"></th>
            <td></td>
            <td></td>
            <td></td>
            <td>
                <a class="blue-text"><i class="fa fa-user"></i></a>
                <a class="teal-text"><i class="fa fa-pencil"></i></a>
                <a class="red-text"><i class="fa fa-times"></i></a>
            </td>
        </tr>
       

    </tbody>
</table>
    </div>
<?php include 'application/views/includes/footer.php';?>


