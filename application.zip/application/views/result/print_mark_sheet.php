
	<script language="javascript" type="application/javascript">
        function pr()
			{alert("a");
				window.print('print_mark_sheet.php');
			}
	</script>
<body onLoad="pr()">

						<table>
                        <?php foreach($school_info as $school_infos)
									{
							 ?>
                                <tr>
                                    <td rowspan="5">
                                    <img src="<?php echo base_url(); ?>upload/institute_logo/<?php echo $school_infos['logo']; ?>" width="100px" height="100px" alt="Logo" style="margin-bottom:-8px;">
                                     </td>
                                 </tr>
                                 <tr>
                                 	<td>&nbsp;&nbsp;&nbsp;</td>
                                 	<td> <span style="font-weight:bold; font-size:20px;"><?php echo $school_infos['school_name']; ?></span> </td>
                                 </tr>
                                 <tr>
                                 	<td>&nbsp;&nbsp;&nbsp;</td>
                                 	<td>Academic Transcript [ <?php echo $details['student_id']; ?> ] </td>
                                 </tr>
                                 <tr>
                                 	<td>&nbsp;&nbsp;&nbsp;</td>
                                 	<td><?php echo $school_infos['website']; ?></td>
                                 </tr>
                                 <tr>
                                 	<td>&nbsp;&nbsp;&nbsp;</td>
                                 	<td>  -by Copotronic InfoSys</td>
                                 </tr>
                                 <?php } ?>
						 </table><br>
<br>
                
<hr>
<div style="width:100%; text-align:center; font-size:18px; font-weight:bold;"> Academic Transcript, <?php echo $details['exam_year']; ?> </div><br>
<br>

<?php
foreach($student_information as $st_info)
{
	?>
<table border="0" width="100%">
				<thead>
					<tr>
						<td>Student ID</td>
                        <td align="center"><b> : </b></td>
						<td><?php echo $st_info['student_id']; ?></td>
                        <td>Student Name</td>
                         <td align="center"><b> : </b></td>
						<td><?php echo $st_info['student_name']; ?></td>
					</tr>
                    <tr>
						<td>Group</td>
                         <td align="center"><b> : </b></td>
						<td><?php echo $st_info['group_name']; ?></td>
                        <td>Section</td>
                        <td align="center"><b> : </b></td>
						<td><?php echo $st_info['section_name']; ?></td>
					</tr>
                    <tr>
                    	<td>class</td>
                         <td align="center"><b> : </b></td>
						<td><?php echo $st_info['class_name']; ?></td>
						<td>Gender</td>
                         <td align="center"><b> : </b></td>
						<td><?php echo $st_info['gender']; ?></td>
					</tr>
                    <tr>
						<td>term</td>
                         <td align="center"><b> : </b></td>
						<td><?php foreach($term as $tr){ echo $tr['term']; } ?></td>
                        <td>Exam Year</td>
                         <td align="center"><b> : </b></td>
						<td><?php echo $details['exam_year']; ?></td>
					</tr>
                    
				</thead>
                </table><br>
<br>

<?php  } ?>
	<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
				<thead>
					<tr>
						<th>Subject Name</th>
						<th>FM</th>
                        <th>Mark </th>
						<th>Grade point</th>
                        <th>GPA</th>
						
					</tr>
				</thead>
				<tbody>
					<?php
					$flag=0;
					foreach($student_information as $si)
					{ 
						$student_id =$si['student_id'];
						$term_id= $details['term_id'];
						$exam_year= $details['exam_year'];
						$sql1 = "SELECT * FROM `tbl_tabulation_marks` as tm inner join tbl_subject on tm.subject_id=tbl_subject.subject_id where tm.student_id='$student_id' and tm.term_id='$term_id' and tm.exam_year='$exam_year' order by tbl_subject.subject_id";
						$query1 = mysql_query($sql1);
						while($numbers1= mysql_fetch_array($query1))
							{
								$results1[]=$numbers1;
							}
							 foreach($term as $term_marks){
				$full_marks1=$term_marks['full_marks'];
			}
						foreach($results1 as $rs)
						{
					?>
						<tr>
							<td>
							<input type="text" readonly class="form-control" name="subject_name[]" id="subject_name" value="<?php echo $rs['subject_name'];?>">
							</td>
                           
							<td>
							<input type="text" readonly class="form-control" name="fm[]" id="fm" value="<?php echo $full_marks1;?>">
							</td>
                            
                            <?php
							$school_id= $details['school_id'];
                            $sqlgs = "SELECT * FROM `tbl_grd_system` as A WHERE A.school_id = '$school_id' order by start_marks desc";
							$querygs = mysql_query($sqlgs);
							$igs=0;
							while($gread_scale= mysql_fetch_array($querygs))
								{
									$gread_scales[$igs]=$gread_scale;
									$igs++;
								}
								$itgp=0;
								
							//print_r($gread_scales);echo "000000000000";
							foreach($gread_scales as $gss)
							{
								$start_marks=$gss['start_marks'];
								if($rs['sub_total_marks']>=$start_marks)
								{
									$total_grade_point[$itgp]=$gss['gpa'];
									$itgp++;
								}
							}
							
                            ?>
                             
                            <td>
							<input type="text" readonly class="form-control" <?php if($total_grade_point[0]=='F'){echo 'style="background-color:#CD0000; color:#fff; font-weight:bold;"' ;} ?> name="mark[]" id="mark" value="<?php echo $rs['sub_total_marks'];?>">
							</td>
                            
                            
                            
                             <td>
							<input type="text" readonly <?php if($total_grade_point[0]=='F'){ $flag=1;echo 'style="background-color:#CD0000; color:#fff; font-weight:bold;"' ;} ?> class="form-control" name="mark[]" id="mark" value="<?php echo $rs['sub_grade_point']; ?>">
							</td>
                           
                            <td>
							<input type="text" readonly <?php if($total_grade_point[0]=='F'){echo 'style="background-color:#CD0000; color:#fff; font-weight:bold;"' ;} ?> class="form-control" name="mark[]" id="mark" value="<?php echo $total_grade_point[0]; ?>">
							</td>
                            </tr>
                           <?php } ?>
							<?php
							$student_id =$si['student_id'];
							$term_id= $details['term_id'];
							$exam_year= $details['exam_year'];
						
		$sql = "SELECT * FROM tbl_tabulation_marks where student_id='$student_id' and term_id='$term_id' and exam_year='$exam_year'";
		$query = mysql_query($sql);
		$i=0;
        while($numbers= mysql_fetch_array($query))
		{
			$results[$i]=$numbers;
			$i++;
		}
		$rows= mysql_num_rows($query);	
			
			foreach($term as $term_marks){
				$full_marks=$term_marks['full_marks'];
			}
			
			$total_full_marks=$full_marks*$rows;
			
							
			foreach($results as $result){
				
				$obtained_marks=$result['sub_total_marks'];
				$total_marks+=$obtained_marks;
				
				$obtained_point=$result['sub_grade_point'];
				$total_point+=$obtained_point;
			} 
				$itgp=0;
				$av_point=round(($total_point/$rows),1);
				foreach($gread_scales as $gss)
							{
								$start_point=$gss['grd_point'];
								if($av_point>=$start_point)
								{
									$point[$itgp]=$gss['gpa'];
									$itgp++;
								}
							}
							?>
                            <tr>
                            <td> <input type="text" readonly class="form-control" name="mark[]" id="mark" value="Total"> </td>
                            
                            <td>
			<input type="text" readonly class="form-control" name="full_mark[]" id="full_mark" value="<?php echo $total_full_marks;?>">
							</td>
                            
                            <td>
			<input type="text" readonly class="form-control" name="total_marks[]" <?php if($flag==1){echo 'style="background-color:#CD0000; color:#fff; font-weight:bold; border-color:red;"' ;} else {echo 'style="background-color:#43CD80; color:#fff; font-weight:bold; border-color:#43CD80;"' ;} ?> id="obtain_marks<?php echo $sl['student_id'];?>" value="<?php echo round(($total_marks),1); ?>">
							</td>
							
							<td>
							<input type="text" readonly class="form-control" name="total_gpa[]" <?php if($flag==1){echo 'style="background-color:#CD0000; color:#fff; font-weight:bold; border-color:red;"' ;} else {echo 'style="background-color:#43CD80; color:#fff; font-weight:bold; border-color:#43CD80;"' ;} ?> id="total_gpa" value="<?php echo $total_point;?>" >
							</td>
                            <td>
							<input type="text" readonly class="form-control" name="total_gpa[]" <?php if($flag==1){echo 'style="background-color:#CD0000; color:#fff; font-weight:bold; border-color:red;"' ;} else {echo 'style="background-color:#43CD80; color:#fff; font-weight:bold; border-color:#43CD80;"' ;} ?> id="total_gpa" value="<?php echo $total_gpa;?>" >
							</td>
						</tr>
                        
                        
                        <tr>
                            <td> <input type="text" readonly class="form-control" name="average[]" id="average" value="Average"> </td>
                            <td>
			<input type="text" readonly class="form-control" name="average_mark[]" id="average_mark" value="<?php echo $full_marks; ?>">
							</td>
							<td>
			<input type="text" readonly class="form-control" name="total_point[]" <?php if($flag==1){echo 'style="background-color:#CD0000; color:#fff; font-weight:bold; border-color:red;"' ;} else {echo 'style="background-color:#43CD80; color:#fff; font-weight:bold; border-color:#43CD80;"' ;} ?> id="obtain_marks<?php echo $sl['student_id'];?>" value="<?php echo round(($total_marks/$rows),1);?>">
							</td>
							<td>
							<input type="text" readonly class="form-control" name="total_gpa[]" <?php if($flag==1){echo 'style="background-color:#CD0000; color:#fff; font-weight:bold; border-color:red;"' ;} else {echo 'style="background-color:#43CD80; color:#fff; font-weight:bold; border-color:#43CD80;"' ;} ?> id="total_gpa" value="<?php echo $av_point;?>" >
							</td>
                            <td>
							<input type="text" readonly class="form-control" name="total_gpa[]" <?php if($flag==1){echo 'style="background-color:#CD0000; color:#fff; font-weight:bold; border-color:red;"' ;} else {echo 'style="background-color:#43CD80; color:#fff; font-weight:bold; border-color:#43CD80;"' ;} ?> id="total_gpa" value="<?php echo $point['0'];?>" >
							</td>
						</tr>
					<?php	} ?>
					
				</tbody>
			</table>
            
            <table width="100%">
            	<tr>
            		<td style="width:30%">&nbsp;</td>
                    <td style="width:40%;">&nbsp;  </td>
                    <td style="width:30%">&nbsp;  </td>
                </tr>
                <tr>
            		<td style="width:30%">&nbsp;</td>
                    <td style="width:40%;">&nbsp;  </td>
                    <td style="width:30%">&nbsp;  </td>
                </tr>
                <tr>
                    <td align="center">--------------------</td>
                    <td>&nbsp;</td>
                    <td align="center">--------------------</td>
                </tr>
                <tr>
                    <td align="center"><b>Principal</b></td>
                    <td>&nbsp;</td>
                    <td align="center"><b>Class Teacher</b></td>
                </tr>
                
                <tr>
            		<td align="center"><?php echo $school_infos['school_name']; ?></td>
                    <td>&nbsp;</td>
                    <td align="center"><?php echo $school_infos['school_name']; ?></td>
                </tr>
            </table>

</body>