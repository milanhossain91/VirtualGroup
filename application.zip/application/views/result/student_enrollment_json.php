<div class="pull-left col-sm-4">
<button type="button" class="btn btn-info" title="Enroll all checked students" onclick="enroll()">Enroll</button>
<hr/>
</div>
<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
				<thead>
					<tr>
						<th><label><input type="checkbox" id="bulk_check"></label></th>
                        <th>Student ID</th>
						<th>Student Name</th>
                        <th>Total Marks</th>
						<th>Total Point</th>
						<th>GPA</th>
                        <th>Status</th>
					</tr>
				</thead>
				<tbody>
					
						<tr>
							<td>
                            	<input type="checkbox" class="bulk_check" checked value="1400092">
                            </td>
                            <td>
							<input type="text" readonly class="form-control" id="student_id" value="1400092">
							</td>
							<td>
							<input type="text" readonly class="form-control" id="student_name" value="OMOR FARUK">
							</td>
							<td>
								<input type="text" readonly class="form-control" value="760">
							</td>
							<td>
								<input type="text" readonly class="form-control" value="30">
							</td>
                            <td>
								<input type="text" readonly class="form-control" id="total_gpa" value="3.5" >
							</td>
                            <td>
								<h4><span class="label label-success">Pass</span></h4>
							</td>
						</tr>
                        <tr>
							<td>
                            	<input type="checkbox" class="bulk_check" checked value="1400092">
                            </td>
							<td>
							<input type="text" readonly class="form-control" id="student_id" value="1400187">
							</td>
							<td>
							<input type="text" readonly class="form-control" id="student_name" value="APURBO HASAN">
							</td>
							<td>
								<input type="text" readonly class="form-control" value="760">
							</td>
							<td>
								<input type="text" readonly class="form-control" value="30">
							</td>
                            <td>
								<input type="text" readonly class="form-control" id="total_gpa" value="3.5" >
							</td>
                            <td>
								<h4><span class="label label-success">Pass</span></h4>
							</td>
						</tr>
                         <tr>
							<td>
                            	<input type="checkbox" class="bulk_check" value="1400092">
                            </td>
							<td>
							<input type="text" readonly class="form-control" id="student_id" value="1400189">
							</td>
							<td>
							<input type="text" readonly class="form-control" id="student_name" value="MD MOIN UDDIN MAHDI">
							</td>
							<td>
								<input type="text" readonly class="form-control" value="360">
							</td>
							<td>
								<input type="text" readonly class="form-control" value="20">
							</td>
                            <td>
								<input type="text" readonly class="form-control" id="total_gpa" value="0" >
							</td>
                            <td>
								<h4><span class="label label-danger">Fail</span></h4>
							</td>
						</tr>
                         <tr>
							<td>
                            	<input type="checkbox" class="bulk_check" checked value="1400092">
                            </td>
							<td>
							<input type="text" readonly class="form-control" id="student_id" value="1400220">
							</td>
							<td>
							<input type="text" readonly class="form-control" id="student_name" value="MD ESMAM AHMED MAHIN">
							</td>
							<td>
								<input type="text" readonly class="form-control" value="860">
							</td>
							<td>
								<input type="text" readonly class="form-control" value="35">
							</td>
                            <td>
								<input type="text" readonly class="form-control" id="total_gpa" value="4" >
							</td>
                            <td>
								<h4><span class="label label-success">Pass</span></h4>
							</td>
						</tr>
					
					
				</tbody>
			</table>
            
<script>
// check all checkbox just one click
$("#bulk_check").change(function(){
    var status = $(this).is(":checked") ? true : false;
    $(".bulk_check").prop("checked",status);
});
</script>