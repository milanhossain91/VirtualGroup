<div class="table-responsive">
	<div style="width:100%">
		
		<div  style="width:100% float:left; text-align: center">
		<div style="width:15%; float:left;">
			<img src="http://mawnamlhighschool.edu.bd/template/homeassets/images/logo.png" alt="" height="100" width="100"/>
		</div>
			<p><b style="font-size:20px;"><?= $school_info['school_name'];?></b></p>
			<p><?= $school_info['address'];?>, <?= $school_info['post_office'];?>, <?= $school_info['district'];?></p>
			<p>Contact : <?= $school_info['contact_no'];?>,<br> E-mail: <?= $school_info['email'];?>, Website: <?= $school_info['website'];?></p>
		</div>
	</div>
	<div style="height:36px; width:100%">&nbsp;</div>
<?php $final_status=0; $total=0; $totalbn=0; $totalen=0; $getbn=0; $geten=0; $total_gpa=0; ?>
<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%" border="1">
	<thead>
		<tr>
			<td>Student ID : <?= $student_info['student_id']; ?></td>
            <td>Student Name : <?= $student_info['student_name']; ?></td>
			<td>Class Roll : <?= $student_info['roll_no']; ?></td>
		</tr>
        <tr>
			<td>Group : <?= $student_info['group_name']; ?></td>
            <td>Section : <?= $student_info['section_name']; ?></td>
            <td>Shift : <?= $student_info['shift_name']; ?></td>
		</tr>
        <tr>
           	<td>class : <?= $student_info['class_name']; ?></td>
			<td>term : <?= $details['term_name']; ?></td>
            <td>Exam Year : <?= $details['session']; ?></td>
		</tr>
    </thead>
</table><br /><br />
<table class="table table-striped table-bordered" cellspacing="0" border="1" width="100%">
	<thead>
		<tr>
            <th>Subject Name</th>
            <th>Full Marks</th>
            <th>Pass Marks</th>
            <th>Sub</th>	
            <th>Obj</th> 
            <th>Prac</th>
			<?php $extd=0; $ca=0; if(explode('*',$student_mark_info[0]['ca'])[0]){ $ca=1; $extd++; ?>
			<th>CA</th>
			<?php } ?>
			<?php $cw=0; if(explode('*',$student_mark_info[0]['cw'])[0]){ $cw=1; $extd++;  ?>
			<th>CW</th>
			<?php } ?>
			<?php $hw=0; if(explode('*',$student_mark_info[0]['hw'])[0]){ $hw=1; $extd++; ?>
			<th>HW</th>
			<?php } ?>
			<?php $ct=0; if(explode('*',$student_mark_info[0]['ct'])[0]){  $ct=1; $extd++; ?>
			<th>CT</th>
			<?php } ?>
			<?php $aspj=0; if(explode('*',$student_mark_info[0]['aspj'])[0]){  $aspj=1; $extd++; ?>
			<th>AS/PJ</th>
			<?php } ?>
            <th>Total</th>
            <th>Highest Marks</th>
            <th>G P</th>
            <th>Grede</th>
        </tr>
	</thead>
	<tbody>
    	<?php  foreach($student_mark_info as $sl): ?>
		<tr>
			<td><?= $sl['subject_name'];?> (<?= $sl['subject_code'];?>) </td>
            <td><?= $sl['f_mark'];?></td>
            <td><?= ($sl['p_mark']*$sl['f_mark'])/100; ?></td>
			<td>
				<?php 
					$term_pass_mark_sub = explode('*',$sl['sub'])[0]*100/explode('*',$sl['sub'])[1];
					$flag=0;
					if($sl['pass_id']==1):
						if($term_pass_mark_sub < $sl['p_mark']):
				?>
                            <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= explode('*',$sl['sub'])[0]; ?></span>
							<?php $flag=1; $final_status=1; ?>
                        <?php else: ?>
							<?= explode('*',$sl['sub'])[0]; ?>
                        <?php endif; ?>
					<?php else: ?>
                       	<?= explode('*',$sl['sub'])[0]; ?>
					<?php endif; ?>
            </td>
			<td>
				<?php 
					if(explode('*',$sl['obj'])[0]):
					
					$term_pass_mark_obj = explode('*',$sl['obj'])[0]*100/explode('*',$sl['obj'])[1];
						
					if($sl['pass_id']==1):
						if($term_pass_mark_obj < $sl['p_mark']):
				?>
                            <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= explode('*',$sl['obj'])[0]; ?></span>
							<?php $flag=1; $final_status=1; ?>
                        <?php else: ?>
							<?= explode('*',$sl['obj'])[0]; ?>
                        <?php endif; ?>
					<?php else: ?>
                       	<?= explode('*',$sl['obj'])[0]; ?>
					<?php endif; ?>
				<?php endif; ?>
            </td>
			<td>
				<?php 
					if(explode('*',$sl['prac'])[0]):
					
					$term_pass_mark_prac = explode('*',$sl['prac'])[0]*100/explode('*',$sl['prac'])[1];
						
					if($sl['pass_id']==1):
						if($term_pass_mark_prac < $sl['p_mark']):
				?>
                            <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= explode('*',$sl['prac'])[0]; ?></span>
							<?php $flag=1; $final_status=1; ?>
                        <?php else: ?>
							<?= explode('*',$sl['prac'])[0]; ?>
                        <?php endif; ?>
					<?php else: ?>
                       	<?= explode('*',$sl['prac'])[0]; ?>
					<?php endif; ?>
				<?php endif; ?>
            </td>
			<?php if($ca==1){ ?>
			<td>
				<?php 
					$term_pass_mark_ca = explode('*',$sl['ca'])[0]*100/explode('*',$sl['ca'])[1];
						if($sl['pass_id']==1){
							if($term_pass_mark_ca < $sl['p_mark']){
					 ?>
					<span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= explode('*',$sl['ca'])[0]; ?></span>
						<?php $flag=1; $final_status=1; ?>
							<?php }else{ ?>
							<?= explode('*',$sl['ca'])[0]; ?>
							<?php } ?>
						<?php }else{ ?>
                       	<?= explode('*',$sl['ca'])[0]; ?>
							<?php }; ?>
            </td>
			<?php } ?>
			<?php if($cw==1){ ?>
			<td>
				<?php 
					$term_pass_mark_cw = explode('*',$sl['cw'])[0]*100/explode('*',$sl['cw'])[1];
						if($sl['pass_id']==1){
							if($term_pass_mark_cw < $sl['p_mark']){
					 ?>
					 <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= explode('*',$sl['cw'])[0]; ?></span>
						<?php $flag=1; $final_status=1; ?>
							<?php }else{ ?>
							<?= explode('*',$sl['cw'])[0]; ?>
							<?php } ?>
						<?php }else{ ?>
                       	<?= explode('*',$sl['cw'])[0]; ?>
							<?php }; ?>
            </td>
			<?php } ?>
			<?php if($hw==1){ ?>
			<td>
				<?php 
					$term_pass_mark_hw = explode('*',$sl['hw'])[0]*100/explode('*',$sl['hw'])[1];
						if($sl['pass_id']==1){
							if($term_pass_mark_hw < $sl['p_mark']){
					 ?>
					<span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= explode('*',$sl['hw'])[0]; ?></span>
						<?php $flag=1; $final_status=1; ?>
							<?php }else{ ?>
							<?= explode('*',$sl['hw'])[0]; ?>
							<?php } ?>
						<?php }else{ ?>
                       	<?= explode('*',$sl['hw'])[0]; ?>
							<?php }; ?>
            </td>
			<?php } ?>
			<?php if($ct==1){ ?>
			<td>
				<?php 
					$term_pass_mark_ct = explode('*',$sl['ct'])[0]*100/explode('*',$sl['ct'])[1];
						if($sl['pass_id']==1){
							if($term_pass_mark_ct < $sl['p_mark']){
					 ?>
					<span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= explode('*',$sl['ct'])[0]; ?></span>
					<?php $flag=1; $final_status=1; ?>
							<?php }else{ ?>
							<?= explode('*',$sl['ct'])[0]; ?>
							<?php } ?>
						<?php }else{ ?>
                       	<?= explode('*',$sl['ct'])[0]; ?>
							<?php }; ?>
            </td>
			<?php } ?>
			<?php if($aspj==1){ ?>
			<td>
				<?php 
					$term_pass_mark_aspj = explode('*',$sl['aspj'])[0]*100/explode('*',$sl['aspj'])[1];
						if($sl['pass_id']==1){
							if($term_pass_mark_aspj < $sl['p_mark']){
					 ?>
					<span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= explode('*',$sl['aspj'])[0]; ?></span>
					<?php $flag=1; $final_status=1; ?>
							<?php }else{ ?>
							<?= explode('*',$sl['aspj'])[0]; ?>
							<?php } ?>
						<?php }else{ ?>
                       	<?= explode('*',$sl['aspj'])[0]; ?>
							<?php }; ?>
            </td>
			<?php } ?>
			<td>
				<?php
						if($sl['subject_code']==102 || $sl['subject_code']==101){
							$getbn+=$sl['sub_total'];
							$totalbn+=$sl['f_mark'];
						}
						elseif($sl['subject_code']==107 || $sl['subject_code']==108){
							$geten+=$sl['sub_total'];
							$totalen+=$sl['f_mark'];
						}
						else{
							// check if class is nine or higher
							if($details['class_short_form'] >= 9){
								if($sl['subject_code']==$optional){
									$total+=($sl['sub_total']-40 < 0 ? 0 : $sl['sub_total']-40);
									$total_gpa+=($sl['gpa']-2 < 0 ? 0 : $sl['gpa']-2);
									$total_f_mark+=0;
								}
								else{
									$total+=$sl['sub_total'];
									$total_gpa+=$sl['gpa'];
									$total_f_mark+=$sl['f_mark'];
								}
							}
							else{
								if($sl['subject_code'] == explode(',',$optional)[0] || $sl['subject_code'] == explode(',',$optional)[1]){
									$total+=($sl['sub_total']-40 < 0 ? 0 : $sl['sub_total']-40);
									$total_gpa+=($sl['gpa']-2 < 0 ? 0 : $sl['gpa']-2);
									$total_f_mark+=0;
								}
								else{
									$total+=$sl['sub_total'];
									$total_gpa+=$sl['gpa'];
									$total_f_mark+=$sl['f_mark'];
								}
							}
						}
						
						$total_term= explode('*',$sl['sub'])[1]+explode('*',$sl['obj'])[1]+explode('*',$sl['prac'])[1];
						$term_pass_mark_get_per =$sl['p_mark']*$total_term/100;
							if($sl['sub_total'] < $term_pass_mark_get_per || $flag==1): ?>
                            <span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= $sl['sub_total']; ?></span>
							<?php $final_status=1; ?>
                            <?php else: ?>
								<?= $sl['sub_total']; ?>
                            <?php endif; ?>
            </td>    
			<td>
				<?= $max_mark[array_search($sl['subject_id'], array_column($max_mark, 'subject_id'))]['max_mark']  ?>
            </td>    
			<td>
				<?php if($sl['subject_code'] == 102 || $sl['subject_code'] == 101 || $sl['subject_code']==107 || $sl['subject_code']==108){
					}else{ $f_fail=0; if($sl['gpa'] <= 0 || $flag==1){ $f_fail=1; ?>
					<span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">0</span>
					<?php $final_status=1; ?>
				<?php } else{ ?>
					<?= $sl['gpa']; ?>
				<?php } ?>
				<?php } ?>
            </td>
			<td>
				<?php if($sl['subject_code'] == 102 || $sl['subject_code'] == 101 || $sl['subject_code']==107 || $sl['subject_code']==108){
					}else{ if($f_fail==1){ ?>
					<span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">F</span>
					<?php $final_status=1; ?>
				<?php } else{ ?>
					<?= $grd_system[array_search($sl['gpa'], array_column($grd_system, 'grd_point'))]['gpa']; ?>
					<?php } ?>
					<?php } ?>
            </td>   
		</tr>
		<?php if($sl['subject_code']==102){ ?>
		<tr style="background: #ced6d2;">
			<td><b> Total </b></td>
			<td colspan="<?= $extd+5; ?>"></td>
			<td>
				<?php
						$get_mark_bn=round(($getbn*100)/$totalbn, 0, PHP_ROUND_HALF_UP);
						$total+=$get_mark_bn;
						$total_f_mark+=100;
						$bn_f=0;
							if($get_mark_bn < $sl['p_mark']){ $bn_f=1; $final_status==1; ?>
				<span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= $get_mark_bn+0; ?></span>
						<?php }else{ ?>
					<b><?= $get_mark_bn; ?></b>
						<?php } ?>
			</td>
			<td></td>
			<td><?php $gpbn='';
					if($bn_f==1){ ?>
					<span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">0 </span>
					<?php } else{
					foreach($grd_system as $gplbn):
						if($gplbn['start_marks'] <= $get_mark_bn && $gplbn['end_marks'] >= $get_mark_bn ):
							echo '<b>'.$gplbn['grd_point'].'</b>'; $total_gpa+=$gplbn['grd_point'];
							$gpabn=$gplbn['grd_point'];
						endif;
					endforeach;
					}
				?>
			</td>
			<td><?php  if($bn_f==1){ ?>
					<span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">F</span>
					<?php $final_status=1; ?>
				<?php } else{ ?>
					<b><?= $grd_system[array_search($gpabn, array_column($grd_system, 'grd_point'))]['gpa']; ?></b>
					<?php } ?>
			</td>
		</tr>
		<?php } ?>
		<?php if($sl['subject_code']==108){ ?>
		<tr style="background: #ced6d2;">
			<td><b> Total </b></td>
			<td colspan="<?= $extd+5; ?>"></td>
			<td>
				<?php 
					$get_mark_en=round(($geten*100)/$totalen, 0, PHP_ROUND_HALF_UP);
					$total+=$get_mark_en;
					$total_f_mark+=100;
					$en_f=0;
					
					if($get_mark_en < $sl['p_mark']){ $en_f=1; $final_status==1; ?>
				<span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= $get_mark_en+0; ?></span>
				<?php }else{ ?>
				<b><?= $get_mark_en; ?></b>
				<?php } ?>
			</td>
			<td></td>
			<td><?php $gpen='';
					if($en_f==1){ ?>
					<span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">0 </span>
					<?php } else{
					foreach($grd_system as $gpl):
						if($gpl['start_marks'] <= $get_mark_en && $gpl['end_marks'] >= $get_mark_en ):
							echo '<b>'.$gpl['grd_point'].'</b>'; $total_gpa+=$gpl['grd_point'];
							$gpaen=$gpl['grd_point'];
						endif;
					endforeach;}
				?>
			</td>
			<td><?php  if($en_f==1){ ?>
					<span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;">F</span>
					<?php $final_status=1; ?>
				<?php } else{ ?>
					<b><?= $grd_system[array_search($gpaen, array_column($grd_system, 'grd_point'))]['gpa']; ?></b>
					<?php } ?>
			</td>
		</tr>
		<?php } ?>
		<?php endforeach; ?>
		<tr>
			<td><b> Total </b></td>
			<td colspan="<?= $extd+5; ?>"></td>
			<td>
				<?php if($final_status==1){ ?>
				<span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= $total; ?></span>
				<?php }else{ ?>
				<?= $total; ?>
				<?php } ?>
			</td>
			<td></td>
			<td><?php if($final_status==1){ ?>
				<span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"><?= 0; ?></span>
				<?php }else{ 
							$avgpp=sprintf('%0.1f', $total_gpa/(count($student_mark_info)-3));
							$avgp=($avgpp > 5 ? 5 : $avgpp);
							echo $avgp;
				 } ?>
			</td>
			<td><?php $obtgpa="F"; if($final_status==1){ ?>
				<span style="width:100%; border-bottom:5px solid #CD0000; color:#000; font-weight:bold;"> F </span>
				<?php }else{
							foreach ($grd_system as $key => $row) {
								$mid[$key]  = $row['grd_point'];
							}
							// Sort the data with mid descending
							// Add $data as the last parameter, to sort by the common key
							array_multisort($mid, SORT_DESC, $grd_system);
							
								$i=0;
								while($i <= count($grd_system)) { 
									if ($grd_system[$i]['grd_point'] <= $avgp) { 
										$obtgpa=$grd_system[$i]['gpa'];
										echo $grd_system[$i]['gpa'];
										break;
									} 
									$i++;
								}
						} ?>
			</td>
		</tr>
	</tbody>
</table>
<div style="width:50%; float:left; margin-top:10px;">
	<table class="table table-striped table-bordered" cellspacing="0" border="1" width="100%">
		<tr>
			<th>Obtained GPA</th>
			<td><?= $avgp; ?></td>
		</tr>
		<tr>
			<th>Obtained Grede</th>
			<td><?= $obtgpa; ?></td>
		</tr>
		<tr>
			<th>Position in Class</th>
			<td><?= array_search($student_info['student_id'], array_column($ranks, 'student_id'))+1; ?></td>
		</tr>
		<tr>
			<th>Total Student</th>
			<td><?= count($ranks); ?></td>
		</tr>
		<tr>
			<th>Total working Day</th>
			<td><?= count($ranks); ?></td>
		</tr>
		<tr>
			<th>Total Present</th>
			<td><?= count($ranks); ?></td>
		</tr>
	</table>
</div>
<div style="width:48%; float:right; margin-top:10px;">
	<table class="table table-striped table-bordered" cellspacing="0" border="1" width="100%">
		<thead>
			<tr>
				<th>Grade</th>
				<th>Marks Range</th>
				<th>GP</th>
			</tr>
		</thead>
		<tbody>
		<?php foreach($grd_system as $gp){ ?>
			<tr>
				<td><?= $gp['gpa'] ?></td>
				<td><?= $gp['end_marks'].'% - '.$gp['start_marks'].'%' ?></td>
				<td><?= $gp['grd_point'] ?></td>
			</tr>
		<?php } ?>
		</tbody>
	</table>
</div>
<div class="print_button pull-left padding">
	<br/>
	<input type="button" class="btn btn-primary" onClick="printPageArea('display')" value="Print This Tabulation Sheet"/>
</div>
