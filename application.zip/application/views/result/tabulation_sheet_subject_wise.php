<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">
            <div class="content">
           
           <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
            
                <!-- Page Heading Start -->
            <div class="page-heading">
            	<h1><i class='fa fa-table'></i> Tabulation Sheet Subject Wise View </h1>
            </div>
            <div class="row">
            	<div class="col-md-12">
                	<div class="widget" style="min-height: 400px">
                    	<div class="widget-content">
                        	<form role="form" id="registerForm" method="POST">
                            	<div class="widget-content padding">
                                	<div class="form-group">
                                    	<div class="row">
                                        	<div class="col-sm-3 col-md-3">
                                            	<label>Class <span style="color:red;">*</span></label>
                                              	<select class="form-control" name="class_id" id="class_id"  onchange="get_class_section_list(this.value); get_class_group_list(this.value);">
                                                	<option value="">-----Select Class-----</option>
                                                    <?php foreach($class_list as $cl){ ?>
                                                    <option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option>
                                                    <?php    } ?>
                                                </select>
                                            </div>
											<div class="col-sm-3 col-md-3">
                                                <label>Section <span style="color:red;">*</span></label>
                                                <select class="form-control" name="section_id" id="section_id">
                                                    <option value="">-----Select Section-----</option>
                                                </select>
											</div>
											 <div class="col-sm-3 col-md-3">
                                               <label>Group <span style="color:red;">*</span></label>
                                                <select class="form-control" name="group_id" id="group_id" required onChange="get_sub_list(this.value);" >
                                                    <option value="">-----Select Group-----</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-3 col-md-3">
                                               <label>Subject <span style="color:red;">*</span></label>
                                                <select class="form-control" name="subject_id" id="subject_id">
                                                    <option value="">-----Select Subject-----</option>
                                                </select>
                                            </div>
										</div>
                                    </div>
                                    <div class="form-group">
										<div class="row">
                                        	<div class="col-sm-3 col-md-3">
												<label>Session <span style="color:red;">*</span></label>
                                                <select class="form-control" name="session_id" id="session_id" >
                                                	<option value="">-----Select Session-----</option>
                                                    <?php foreach($session_list as $sl){ ?>
                                                    <option value="<?= $sl['session_id'];?>"><?= $sl['session_name'];?></option>
                                                    <?php } ?>
                                                </select>
                                            </div>
                                            <div class="col-sm-3 col-md-3">
                                                <label>Term Name <span style="color:red;">*</span></label>
                                                <select class="form-control" name="term_id" id="term_id" >
                                                	<option value="">-----Select Term-----</option>
                                                    <?php foreach($term_list as $tl){ ?>
                                                    <option value="<?php echo $tl['term_id'];?>"><?php echo $tl['term'];?></option>
                                                    <?php    } ?>
                                                </select>
											</div>
                                            <?php if($shift_list): ?>
                                            <div class="col-sm-3 col-md-3">
                                                <label>Shift <span style="color:red;">*</span></label>
                                                <select class="form-control" name="shift_id" id="shift_id" >
                                                	<option value="">-----Select Shift-----</option>
                                                    <?php foreach($shift_list as $shl){ ?>
                                                    <option value="<?php echo $shl['shift_id'];?>"><?php echo $shl['shift_name'];?></option>
                                                    <?php    } ?>
                                                </select>
											</div>
                                            <?php else: ?>
													<input type="hidden" id="shift_id" value="0" />
											<?php endif; ?>
                                            <div class="col-sm-3 col-md-3">
												<label>Exam Year <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="exam_year" id="exam_year" value="<?= date('Y') ?>"/>
                                            </div>
                                         </div>
                                    </div>
                                    <div class="form-group">
										<div class="row">
                                        	<div class="col-sm-3 col-md-3">
												<label> Passing System <span style="color:red;">*</span></label>
                                                <select class="form-control" required name="passing_id" id="passing_id">
                                                	<option value="">----Select System----</option>
                                                    <option value="1"> Pass Every Field</option>
                                                    <option value="2"> Pass overall</option>
                                                </select>
                                            </div>
                                            <div class="col-sm-3 col-md-3">
                                                <label>Type of GPA<span style="color:red;">*</span></label>
   												<select class="form-control" name="type_id" id="type_id" required>
                                                     <option value="">----Select----</option>
                                                     <option value="1">Type 1</option>
                                                     <option value="2">Type 2</option>
                                                     <option value="3">Type 3</option>
                                                     <option value="4">Type 4</option>
                                                </select>
											</div>
                                         </div>
                                    </div>
									<div class="form-group">
										<div class="row">
											<div class="col-sm-4">
                                            	<button type="button" class="btn btn-primary" onclick="tabulation_marks_json()">Show Students</button>
											</div>
										</div>
									</div>
                                </div>
                            </form>
                            
                            <hr/>
                            <div class="widget-content padding" style="overflow: auto;">
								<div class="form-group">
									<div class="row">
										<div class="col-sm-12 col-md-12" id="display">
												<!---JSON Content will be displayed here-->
										</div>
									</div>
								</div>
							</div>
                            
                        </div>
                    </div>
                </div>
			</div>

    
<?php include 'application/views/includes/footer.php';?>

<!--Check department name based on class id -->
<script>

function get_class_section_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'admin/section_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#section_id').html(html_data);
        }
    }
    });  
}

function get_class_group_list(class_id)
{
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/group_list_ajax',
    data:
    {
        'class_id':class_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
            $('#group_id').html(html_data);
        }
    }
    });  
}

function get_sub_list(group_id)
{
	var class_id=$('#class_id').val();
   $.ajax({
    type: "POST",
    url: baseUrl + 'academic/subject_list_ajax',
    data:
    {
        'class_id':class_id,
		'group_id':group_id
    }, 
    success: function(html_data)
    {
        if (html_data != '')
        {
			$('#subject_id').html(html_data);
        }
    }
    });  
}

	function tabulation_marks_json()
		{
			
			var class_id = $('#class_id').val();        
			var section_id = $('#section_id').val(); 
			var group_id = $('#group_id').val();
			var shift_id = $('#shift_id').val();
			var subject_id = $('#subject_id').val();
			var session_id = $('#session_id').val(); 
			var term_id = $('#term_id').val(); 
			var exam_year = $('#exam_year').val();
			var passing_id = $('#passing_id').val();
			var type_id = $('#type_id').val();
			
			var details_data = {school_name:'<?= $sc_info['school_name'];?>', class_name:$('#class_id :selected').text(), section_name:$('#section_id :selected').text(),group_name:$('#group_id :selected').text(),shift_name:$('#shift_id :selected').text(),subject_name:$('#subject_id :selected').text(),term_name:$('#term_id :selected').text()};

			
			if(!class_id)
			{
				$('#class_id').after("<div id='validation_class' class='validation_js'>Please select a class.</div>")
					$('#validation_class').delay(3000).hide('slow');
					return;
				
			}
			if(!section_id)
			{
				$('#section_id').after("<div id='validation_section' class='validation_js'>Please select a section.</div>")
					$('#validation_section').delay(3000).hide('slow');
					return;
				
			}
			if(!group_id)
			{
				$('#group_id').after("<div id='validation_group' class='validation_js'>Please select a group.</div>")
					$('#validation_group').delay(3000).hide('slow');
					return;
				
			}
			if(!subject_id)
			{
				$('#subject_id').after("<div id='validation_sub' class='validation_js'>Please select a subject.</div>")
					$('#validation_sub').delay(3000).hide('slow');
					return;
				
			}
			if(!session_id)
			{
				$('#session_id').after("<div id='validation_ses' class='validation_js'>Please select a session.</div>")
					$('#validation_ses').delay(3000).hide('slow');
					return;
				
			}
			if(!term_id)
			{
				$('#term_id').after("<div id='validation_ct' class='validation_js'>Please select a term.</div>")
					$('#validation_ct').delay(3000).hide('slow');
					return;
				
			}
			if(!shift_id)
			{
				$('#shift_id').after("<div id='validation_shift' class='validation_js'>Please select a shift.</div>")
					$('#validation_shift').delay(3000).hide('slow');
					return;
				
			}
			if(!exam_year)
			{
				$('#exam_year').after("<div id='validation_ex' class='validation_js'>Please put exam year.</div>")
					$('#validation_ex').delay(3000).hide('slow');
					return;
				
			}
			if(exam_year.length<4)
			{
				$('#exam_year').after("<div id='validation_ex' class='validation_js'>Please put four digit exam year(YYYY).</div>")
					$('#validation_ex').delay(3000).hide('slow');
					return;
				
			}
			if(!passing_id)
			{
				$('#passing_id').after("<div id='validation_pass' class='validation_js'> Please select a passing system </div>")
							$('#validation_pass').delay(3000).hide('slow');
							return;
			}  
			if(!type_id)
			{
				$('#type_id').after("<div id='validation_gptyp' class='validation_js'> Please select a GPA type </div>")
							$('#validation_gptyp').delay(3000).hide('slow');
							return;
			}  
		//alert(group_id)
			$.ajax({ 
			url: baseUrl+'result/tabulation_marks_subject_wise_json',
			data:
				{                  
					'class_id':class_id,
					'section_id':section_id,
					'group_id':group_id,
					'shift_id':shift_id,
					'subject_id':subject_id,
					'term_id':term_id,
					'exam_year':exam_year,
					'session_id':session_id,
					'passing_id':passing_id,
					'type_id':type_id,
					'details_data':details_data
				}, 
				dataType: 'json',
				success: function(data)
				{
					result                = ''+data['result']+'';
					mainContent           = ''+data['mainContent']+'';
	
					if(result == 'success')
					{
						$('#display').html(mainContent);     
					}                
				}
			});
		}
		
		

function printPageArea(areaID){
		var printContent = document.getElementById(areaID);
		var WinPrint = window.open('', '', 'width=900,height=650');
		WinPrint.document.write('<link rel="stylesheet" type="text/css" href="<?= base_url();?>template/bootstrap-print/bootstrap-print.min.css" media="print" />')
		WinPrint.document.write('<style type="text/css" media="print"> @page { size: landscape; font-size:12px; } table{font-size:12px;} table td{padding:3px;} .print_button{ display:none;} </style>')
		WinPrint.document.write(printContent.innerHTML);
		WinPrint.document.close();
		WinPrint.focus();
		WinPrint.print();
		WinPrint.close();
	}
	
</script> 


