<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Digital Attendance</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
            	<!-- Page Heading End-->				<!-- Your awesome content goes here -->
				<div class="row">				
					<div class="col-md-12">
						<div class="widget">
							<div class="widget-content">
								<div class="table-responsive">
									<form class='form-horizontal' role='form'>
									<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
									        <iframe style="font-size:10px;" width="900" height="800" frameborder="0" src="http://www.rfid-cloud.com/ams/home"></iframe>
									    </table>
									</form>
								</div>
							</div>
						</div>
					</div>
				</div>

                            </div>
                        </div>
                    </div>
                </div>
				

				
				

				
<?php include 'application/views/includes/footer.php';?>