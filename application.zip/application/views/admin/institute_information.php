<!-- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!-- Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">			
    <div class="content">
         <?php if($this->session->flashdata('message')):?>
			<?=$this->session->flashdata('message')?>
		<?php endif?>
         <!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-check'></i> Institute Information</h1>
        </div>
        <!-- Page Heading End-->
		<!-- Your awesome content goes here -->
        <div class="row">
            <div class="col-sm-12">
                <div class="widget" style="min-height:500px;">
                    <div class="widget-content padding">
                        <form>
                            <legend><i class="icon32 icon-square-plus"></i> Institute Information View</legend>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-sm-6">
                                        <label>Institute Name</label>
                                        <input type="text" class="form-control" name="school_name" value="<?= $school_info['school_name'];?>" readonly="" />
                                    </div>
									<div class="col-sm-6">
										<label> Institute Title</label>
										<input type="text" class="form-control" name="school_title" value="<?= $school_info['school_title'];?>" readonly="" />
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="row">
									<div class="col-sm-6 col-md-4">
										<label>EIIN Number</label>
										<input type="text" class="form-control" name="eiin_no" value="<?= $school_info['eiin_no'];?>" readonly="" />
									</div>
									<div class="col-sm-6 col-md-4">
										<label>Index Number</label>
										<input type="text" class="form-control" name="school_index_no" value="<?= $school_info['school_index_no'];?>" readonly="" />
									</div>
									<div class="col-sm-6 col-md-4">
										<label>School Code</label>
										<input type="text" class="form-control" name="school_code" value="<?= $school_info['school_code'];?>" readonly="" />
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="row">
									<div class="col-sm-6 col-md-4">
										<label>Upazilla Code</label>
										<input type="text" class="form-control" name="upazilla_code" value="<?= $school_info['upazilla_code'];?>" readonly="" />
									</div>
									<div class="col-sm-6 col-md-4">
										<label>District Code</label>
										<input type="text" class="form-control" name="district_code" value="<?= $school_info['district_code'];?>" readonly="" />
									</div>
									<div class="col-sm-6 col-md-4">
										<label>Founder</label>
										<input type="text" class="form-control" name="founder" value="<?= $school_info['founder'];?>" readonly="" />
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="row">
									<div class="col-sm-6">
										<label> Address</label>
										<input type="text" class="form-control" name="address" value="<?php echo $school_info['address'];?>" readonly="" />
									</div>
									<div class="col-sm-6">
										<label>  Post Office</label>
										<input type="text" class="form-control" name="post_office" value="<?php echo $school_info['post_office'];?>" readonly="" />
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="row">
									<div class="col-sm-4">
										<label> Police Station</label>
										<input type="text" class="form-control" name="police_station" value="<?= $school_info['police_station'];?>" readonly="" />
									</div>
									<div class="col-sm-4">
										<label>  District</label>
										<input type="text" class="form-control" name="district" value="<?= $school_info['district'];?>" readonly="" />
                                    </div>
									<div class="col-sm-4">
										<label>  Established</label>
										<input type="text" class="form-control" name="established" value="<?= $school_info['established'];?>" readonly="" />
									</div>
								</div>
							</div>
							<div class="form-group">
								<div class="row">
									<div class="col-sm-4">
										<label> Contact No.</label>
										<input type="text" class="form-control" name="contact_no" value="<?= $school_info['contact_no'];?>" readonly="" />
									</div>
									<div class="col-sm-4">
										<label>  E-Mail</label>
										<input type="text" class="form-control" name="email" value="<?= $school_info['email'];?>" readonly="" />
                                    </div>
									<div class="col-sm-4">
										<label>Website</label>
										<input type="text" class="form-control" name="website" value="<?= $school_info['website'];?>" readonly="" />
                                    </div> 
                                </div>
                            </div>
							<div class="form-group">
								<div class="row">
									<div class="col-sm-6">
										<label> Logo</label> <br/>
										<img src="<?= base_url();?>upload/institute_logo/<?= $school_info['logo'];?>" height="150" width="150" />
                                    </div>
                                    <div class="col-sm-6"></div>
                                </div>
                            </div>
                            <a href="<?= base_url();?>admin/institute_information_edit"><button type="button" class="btn btn-primary">Edit</button></a>
                        </form>
                    </div>
				</div>
			</div>
		</div>
<?php include 'application/views/includes/footer.php';?>