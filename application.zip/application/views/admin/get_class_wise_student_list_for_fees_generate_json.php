<div class="table-responsive">
	<form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>admin/fees_generate" enctype="multipart/form-data">
	
	
	<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
				<thead>
					<tr>
						<th>Student ID/Cat_id</th>
						<th>Name/Particulars</th>
						<th>Class_id/amount</th>
					</tr>
				</thead>

				

				<tbody>
					<?php
					
					foreach($student_list as $sl){ ?>
						<tr>
							<td>
								<?php //echo $sl['student_id'];?>
								<input type="text" class="form-control" name="student_iddfsd[]" id="student_id" value="<?php echo $sl['student_id'];?>">
								<input type="hidden" class="form-control" name="student_name[]" id="student_name" value="<?php echo $sl['student_name'];?>">
							</td>
							
							<td>
								<?php $billing_id = $sl['student_id'].date("m").date("Y");
								$sms_contact = $sl['father_mobile_contact'];
								?>
								<input type="text" class="form-control" name="sms_contact[]" id="sms_contact" value="<?php echo $sms_contact;?>">
							</td>
							
							<td><?php //echo $sl['class_id'];?>
								<input type="text" class="form-control" name="class_id[]" id="class_id" value="<?php echo $sl['class_id']?>">
								<input type="hidden" class="form-control" name="school_id[]" id="school_id" value="<?php echo $sl['school_id'];?>">
							</td>
							
						</tr>
						
						<?php
						$fees = 0;
						foreach($fees_mngt_details as $fee_mngt){  #echo "Hello Imon! "; ?>
						<tr>
							<td><?php $fees = $fees + $fee_mngt['amount'];?>
								<input type="text" class="form-control" name="fee_mngt_id_<?php echo $sl['student_id'];?>[]" id="fee_mngt_id" value="<?php echo $fee_mngt['fees_cat_id'];?>">
							</td>
							<td>
								<input type="text" class="form-control" name="fees_particulars_<?php echo $sl['student_id'];?>[]" id="fees_particulars" value="<?php echo $fee_mngt['fees_particulars'];?>" readonly>
							</td>
							<td>
								<input type="text" class="form-control" name="fees_amount_<?php echo $sl['student_id'];?>[]" id="fees_amount" value="<?php echo $fee_mngt['amount'];?>">
							</td>
						</tr>
						
						<tr>
						    
						    <input type="hidden" class="form-control" name="fees_cat_id_<?php echo $sl['student_id'];?>[]" id="fees_cat_id" value="<?php echo $fee_mngt['fees_cat_id'];?>">
						   
						</tr>
					<?php 	}  ?>
					<input type="hidden" class="form-control" name="total_fees[]" id="class_id" value="<?php echo $fees;?>">
					
						
					<?php 	} ?>
					
					<input type="submit" class="btn btn-primary" name="fees_gen" value="Generate Fees"/><br/>
					
				</tbody>
			</table>


	</form>
</div>