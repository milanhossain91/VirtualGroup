<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">			
    <div class="content">
        <?php if($this->session->flashdata('message')):?>
			<?=$this->session->flashdata('message')?>
		<?php endif?>
        <!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-check'></i> Employee List</h1>
        </div>
        <!-- Page Heading End-->
        <!-- Your awesome content goes here -->
        <div class="row">
            <div class="col-sm-12">
                <div class="widget" style="min-height:500px;">
                    <div class="widget-content padding">
                        <div class="row">				
                            <div class="col-md-12">
                                <div class="widget">
                                    <div class="widget-content">
                                        <form role="form" id="send_sms" method="POST" action="<?= base_url();?>admin/send_sms_to_teacher" enctype="multipart/form-data">
                                            <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Department</th>
                                                        <th>Designation</th>
                                                        <th>Joining date</th>
                                                        <th>Mobile</th>
                                                        <th>Picture</th>
                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php foreach($teacher_list as $tl){ ?>
                                                    <tr>
                                                        <td><?php echo $tl['teacher_id'];?></td>
                                                        <td><?php echo $tl['teacher_name'];?></td>
                                                        <td><?php echo $tl['department_id'];?></td>
                                                        <td><?php echo $tl['designation_id'];?></td>
                                                        <td><?php echo $tl['joining_date'];?></td>

                                                        <td><?php echo $tl['present_contact'];?></td>
                                                        <td>
								<img src="<?php echo base_url();?>upload/teacher_image/<?php echo $tl['teacher_image'];?>" height="50" width="50"/>
                                                            <input type="hidden" class="form-control" name="sms_contact[]" id="sms_contact" value="<?php echo $tl['present_contact'];?>">
                                                            <input type="hidden" class="form-control" name="teacher_name[]" id="teacher_name" value="<?php echo $tl['teacher_name'];?>">
                                                        </td>
							<td>
                                                            <a href="<?php echo base_url();?>admin/teacher_view/<?php echo $tl['teacher_id'];?>" title="View"><i class="fa fa-retweet"></i></a> | 
								<a href="<?php echo base_url();?>admin/teacher_edit/<?php echo $tl['teacher_id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | 
								<?=anchor("admin/teacher_delete/".$tl['teacher_id'],"<i class=\"fa fa-remove\"></i>",array('onclick' => "return confirm('Do you want delete this record')"))?>
                                                        </td>
                                                    </tr>
                                                    <?php } ?>
                                                
                                                </tbody>
                                            </table>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php include 'application/views/includes/footer.php';?>