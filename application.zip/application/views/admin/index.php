<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
<style>

.teacher-sec{
	margin: 15px 0px;
	padding: 15px;
	
}
.teacher-sec p{
	
}
.teacher-sec a{
	text-decoration: none;
}
.teacher-sec a:hover{
	
}
.menu-sec-1{
	background-color: rgb(250, 104, 0);
}
.menu-sec-2{
	background-color: rgb(0, 170, 170);
}
.menu-sec-3{
	background-color: rgb(230, 113, 184);
}
.menu-sec-4{
	background-color: rgb(0, 138, 0);
}
.menu-sec-5{
	background-color: rgb(230, 33, 0);
}
.menu-sec-6{
	background-color: rgb(160, 20, 39);
}
.menu-sec-7{
	background-color: rgb(0, 80, 240);
}

.menu-sec-8{
	background-color: rgb(106, 53, 255);
}
.menu-sec-9{
	background-color: rgb(161, 53, 55);
}
.menu-sec-10{
	background-color: rgb(216, 237, 115);
}
.menu-sec-11{
	background-color: rgb(250, 104, 0);
}
.menu-sec-12{
	background-color: rgb(118, 95, 137);
}
.menu-sec-13{
	background-color: rgb(250, 104, 0);
}
.menu-sec-14{
	background-color: rgb(250, 104, 0);
}
.menu-sec-15{
	background-color: rgb(250, 104, 0);
}
.menu-sec-16{
	background-color: rgb(250, 104, 0);
}

.menu-icon{
	
}
.menu-icon i.fa{
	color: white;
	font-size: 4em;
	margin: 20px 10px;
}
.menu-icon i.fa:hover{
	color: rgb(0, 0, 0);
}
.menu-title{}
.menu-title p{
	color: rgb(255, 255, 255);
	font-size: 1.5em;
}



/* Smartphones (portrait and landscape) ----------- */
@media only screen
and (min-device-width : 320px)
and (max-device-width : 480px) {
.menu-icon i.fa{
font-size:1.5em;
}
.menu-title p{
font-size:0.8em;
}
}

/* Smartphones (landscape) ----------- */
@media only screen
and (min-width : 321px) {

}

/* Smartphones (portrait) ----------- */
@media only screen
and (max-width : 320px) {
/* STYLES GO HERE */
}

/* iPads (portrait and landscape) ----------- */
@media only screen
and (min-device-width : 768px)
and (max-device-width : 1024px) {
.menu-icon i.fa{
font-size:2em;
}
.menu-title p{
font-size:1em;
}
}

/* iPads (landscape) ----------- */
@media only screen
and (min-device-width : 768px)
and (max-device-width : 1024px) {
.menu-icon i.fa{
font-size:1.5em;
}
.menu-title p{
font-size:1em;
}
}

/* iPads (portrait) ----------- 
@media only screen
and (min-device-width : 768px)
and (max-device-width : 1024px)
and (orientation : portrait) {
.teacher-sec{
	margin: 10px 0px;
	padding: 10px;
	
}
}

/* Desktops and laptops ----------- */
@media only screen
and (max-width : 1370px) {
.menu-icon i.fa{
font-size:2em;
}
.menu-title p{
font-size:1em;
}
}

/* Large screens ----------- */
@media only screen
and (min-width : 1824px) {
/* STYLES GO HERE */
}

/* iPhone 5 (portrait & landscape)----------- */
@media only screen
and (min-device-width : 320px)
and (max-device-width : 768px) {
.menu-icon i.fa{
font-size:1.5em;
}
.menu-title p{
font-size:.8em;
}
}

/* iPhone 5 (landscape)----------- */
@media only screen
and (min-device-width : 320px)
and (max-device-width : 568px)
and (orientation : landscape) {
/* STYLES GO HERE */
}

/* iPhone 5 (portrait)----------- */
@media only screen
and (min-device-width : 320px)
and (max-device-width : 568px)
and (orientation : portrait) {
/* STYLES GO HERE */

}
</style>
            <div class="left-footer">
                <div class="progress progress-xs">
                  <div class="progress-bar bg-green-1" role="progressbar" aria-valuenow="80" aria-valuemin="0" aria-valuemax="100" style="width: 80%">
                    <span class="progress-precentage">80%</span>
                  </div>
                  
                  <a data-toggle="tooltip" title="See task progress" class="btn btn-default md-trigger" data-modal="task-progress"><i class="fa fa-inbox"></i></a>
                </div>
            </div>
        </div>
        <!-- Left Sidebar End -->
		<!-- Start right content -->
        <div class="content-page">
			<!-- ============================================================== -->
			<!-- Start Content here -->
			<!-- ============================================================== -->
            <div class="content">

            		<div class="row top-summary" style="min-height:200px;">
<section class="menu-sec">
<div class="container-fluid">
	<div class="row">
	<div class="col-md-12 col-lg-5">
		<div class="col-md-8 col-sm-8 col-lg-8 col-xs-12 text-center">
		<div class="teacher-sec menu-sec-1 has_sub teacher">
		<a href="<?= base_url();?>web/mechanical_support">
			<div class="menu-icon">
			<i class="fa fa-user-plus" aria-hidden="true"></i>
			<!--img src="src/images/teacher.png" alt=""-->
			</div>
			<div class="menu-title">
			<p>Mechanical Support</p>
			</div>
			</a>
		</div>
		</div>
		

		<div class="col-md-4 col-sm-4 col-lg-4 col-xs-12  pro1 has_sub atten">
		<div class="teacher-sec menu-sec-2 text-center">
		<a href="<?= base_url();?>web/virtual_ready_mix">
			<div class="menu-icon text-center">
			<i class="fa fa-pencil-square-o" aria-hidden="true"></i>
			</div>
			<div class="menu-title">
			<p>Virtual Ready-Mix</p>
			</div>
			</a>
		</div>
		</div>
		<div class="col-md-4 col-sm-4 col-lg-4 col-xs-12 pro0 has_sub res_report">
		<div class="teacher-sec menu-sec-7 text-center">
			<a href="<?= base_url();?>web/virtual_marketing_tradingco">
				<div class="menu-icon">
				<i class="fa fa-file-excel-o" aria-hidden="true"></i>
				</div>
				<div class="menu-title">
				<p>Virtual Marketing TradingCo.</p>
				</div>
			</a>
		</div>
		</div>
		

		<div class="col-md-4 col-sm-4 col-lg-4 col-xs-12  pro0 has_sub res_report">
		<div class="teacher-sec menu-sec-8 text-center">
			<a href="<?= base_url();?>web/welcome_to_virtual_properties_ltd">
				<div class="menu-icon">
				<i class="fa fa-file-text-o" aria-hidden="true"></i>
				</div>
				<div class="menu-title">
				<p>Welcome to Virtual Properties Ltd</p>
				</div>
			</a>
		</div>
		</div>

		<div class="col-md-4 col-sm-4 col-lg-4 col-xs-12  pro0 has_sub debit_vou">
		<div class="teacher-sec menu-sec-9 text-center">
		<a href="<?= base_url();?>web/schwing_stetter">
			<div class="menu-icon">
			<i class="fa fa-credit-card" aria-hidden="true"></i>
			</div>
			<div class="menu-title">
			<p>Schwing Stetter</p>
			</div>
			</a>
		</div>
		</div>
	</div>
	<div class="col-md-12 col-lg-7">
		
		<div class="col-md-3 col-sm-3 col-lg-3 col-xs-12  pro0 stu_reg">
		<div class="teacher-sec menu-sec-3 text-center">
		<a href="<?= base_url();?>web/blog">
			<div class="menu-icon">
			<i class="fa fa-user-o" aria-hidden="true"></i>
			</div>
			<div class="menu-title">
			<p>Onging Project</p>
			</div>
			</a>
		</div>
		</div>

		<div class="col-md-3 col-sm-3 col-lg-3 col-xs-12  pro0 has_sub att">
		<div class="teacher-sec menu-sec-4 text-center">
		<a href="<?= base_url();?>web/soilmec">
			<div class="menu-icon">
			<i class="fa fa-pencil-square-o" aria-hidden="true"></i>
			</div>
			<div class="menu-title">
			<p>Soilmec</p>
			</div>
			</a>
		</div>
		</div>

		<div class="col-md-3 col-sm-3 col-lg-3 col-xs-12 pro0 fee_gen">
		<div class="teacher-sec menu-sec-5 text-center">
		<a href="<?= base_url();?>web/mechanical_support">
			<div class="menu-icon">
			<i class="fa fa-calculator" aria-hidden="true"></i>
			</div>
			<div class="menu-title">
			<p>Mechanical Support</p>
			</div>
			</a>
		</div>
		</div>

		<div class="col-md-3 col-sm-3 col-lg-3 col-xs-12  pro0 fee_coll">
		<div class="teacher-sec menu-sec-6 text-center">
		<a href="<?= base_url();?>web/spares_stores">
			<div class="menu-icon">
			<i class="fa fa-percent" aria-hidden="true"></i>
			</div>
			<div class="menu-title">
			<p>Spares stores</p>
			</div>
			</a>
		</div>
		</div>



		

		<div class="col-md-3 col-sm-3 col-lg-3 col-xs-12 pro0 has_sub credit_vou">
		<div class="teacher-sec menu-sec-10 text-center">
		<a href="<?= base_url();?>web/equipment_rental">
			<div class="menu-icon">
			<i class="fa fa-credit-card" aria-hidden="true"></i>
			</div>
			<div class="menu-title">
			<p>Equipment Rental</p>
			</div>
			</a>
		</div>
		</div>



		<div class="col-md-3 col-sm-3 col-lg-3 col-xs-12 pro0 has_sub library">
		<div class="teacher-sec menu-sec-11 text-center">
		<a href="<?= base_url();?>web/service_center">
			<div class="menu-icon">
			<i class="fa fa-book" aria-hidden="true"></i>
			</div>
			<div class="menu-title">
			<p>Service Center</p>
			</div>
			</a>
		</div>
		</div>


		<div class="col-md-3 col-sm-3 col-lg-3  col-xs-12 pro0 has_sub class">
		<div class="teacher-sec menu-sec-12 text-center">
		<a href="<?= base_url();?>web/portfolio">
			<div class="menu-icon">
			<i class="fa fa-calendar" aria-hidden="true"></i>
			</div>
			<div class="menu-title">
			<p>portfolio</p>
			</div>
			</a>
		</div>
		</div>


		<div class="col-md-3 col-sm-3 col-lg-3  col-xs-12 pro0 has_sub sett">
		<div class="teacher-sec menu-sec-13 text-center">
		<a href="<?= base_url();?>web/csr">
			<div class="menu-icon">
			<i class="fa fa-cog" aria-hidden="true"></i>
			</div>
			<div class="menu-title">
			<p>CSR</p>
			</div>
			</a>
		</div>
		</div>
	</div>
		

	</div><!--row-->
</div><!--container-fluid-->
</section><!--menu-sec-->
	

				</div>


					<div class="row">
					<div class="col-lg-12 col-md-12 col-sm-12 admin_panel_calander_box">
						<div class="chart-box orange-bg">
							<h4>Calander</h4>
							<div id="calendar" class="admin_panel_calander">
							<!-- Calander will be displyed here -->	
							</div>
							<!-- calander description start -->
							<div id="fullCalModal" class="modal fade">
								<div class="modal-dialog">
									<div class="modal-content">
										<div class="modal-header">
											<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">×</span> <span class="sr-only">close</span></button>
											<h3 id="modalTitle" class="modal-title"></h3>
										</div>
										<div id="modalBody" class="modal-body"></div>
									</div>
								</div>
							</div>
						</div><!-- calander description end -->	
					</div><!--/.col-->
			
				</div>
				<!-- End of calender and notice box -->
				</div><!--/.col-->
			
				</div>
				
				
				

<?php include 'application/views/includes/footer.php';?>
<script src="<?= base_url();?>template/plugins/notice_ticker/js/jquery.bootstrap.newsbox.min.js" type="text/javascript"></script>
<script src="<?= base_url();?>template/plugins/fullcalendar-1.6.2/fullcalendar/fullcalendar.min.js"></script>
<script>

function CalendarInit() {
	"use strict";

    var date = new Date();
    var d = date.getDate();
    var m = date.getMonth();
    var y = date.getFullYear();

    var hdr = {};

    if ($(window).width() <= 767) {
        hdr = { left: 'prev,next', center: 'title', right: '' };
    } else {
        hdr = { left: 'prev,next', center: 'title', right: 'today,month' };
    }

    


    /* initialize the calendar
     -----------------------------------------------------------------*/

    $('#calendar').fullCalendar({
        header: hdr,
        buttonText: {
            prev: '<i class="fa fa-angle-double-left"></i>',
            next: '<i class="fa fa-angle-double-right"></i>'
        },
        editable: false,
		events: baseUrl + 'academic/get_event',

        windowResize: function (event, ui) {
            $('#calendar').fullCalendar('render');
        },
		renderEvent: function (copiedEventObject){
		alert(copiedEventObject.start)
		},
		eventAfterRender: function (event, element) {
        $(element).tooltip({title:"Click me to see description.", container: "body"});
		},
		eventClick: function(event, element) {
			$('#calendar').fullCalendar('renderEvent', event, true);
			$('#modalTitle').html(event.title);
            $('#modalBody').html(event.description);
			
            $('#fullCalModal').modal();
			
		}
		
    });
	//$(".fc-widget-content").css({"background-color": event.color});
}
// calendar initialize
CalendarInit();


 function notice_holiday() { 
       $(".notice").bootstrapNews({
            newsPerPage: 8,
            autoplay: true,
			pauseOnHover:true,
			height:'auto',
            direction: 'up',
            newsTickerInterval: 30000,
            onToDo: function () {
                //console.log(this);
            }
        });
		 /*
		$(".demo2").bootstrapNews({
            newsPerPage: 4,
            autoplay: true,
			pauseOnHover: true,
			navigation: false,
            direction: 'down',
            newsTickerInterval: 2500,
            onToDo: function () {
                //console.log(this);
            }
        });

        $("#demo3").bootstrapNews({
            newsPerPage: 3,
            autoplay: false,
            
            onToDo: function () {
                //console.log(this);
            }
        });*/
    };
	
	//notice and holiday ticker initialize
//notice_holiday();
function show_notice(id){
	var notice = <?= json_encode($notices) ?>;// don't use quotes
	for(i=0; i<notice.length; i++)
		{
			if(notice[i].notice_id == id)
			{
				$('#modalTitle').html(notice[i].notice_heading);
				$('#modalBody').html(notice[i].notice_details);
			
				$('#fullCalModal').modal();
			}	
		}
}
</script>
<script type="text/javascript">
		window.onload = function () {
			var s1 = [92, 60, 70, 82, 91, 92, 60, 70, 82, 91];
			var s2 = [8, 40, 30, 18, 9, 8, 40, 30, 18, 9,];
			var ticksx = ['ONE', 'TEO', 'THREE', 'FOUR', 'FIVE', 'SIX', 'SEVEN', 'EIGHT', 'NINE', 'TEN'];
			var ticksy = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100];
			
			plot1 = $.jqplot('day-att-chart', [s1, s2], {
				//title:"Today Student Attendance Chart",
				seriesDefaults: {
					renderer:$.jqplot.BarRenderer,
					pointLabels: { show: true }
				},
				seriesColors:['#22BAA0', '#F25656'],
				series:[
						{label:'Present'},
						{label:'Absent'}
				],
				legend: {
						show:true, 
						placement: 'outsideGrid'
				},
				axes: {
					xaxis: {
						renderer: $.jqplot.CategoryAxisRenderer,
						ticks: ticksx
					},
					yaxis: {
						ticks: ticksy,
						tickOptions: {
							formatString:'%d'
						}
					}
				}
			});
			plot2 = $.jqplot('month-att-chart', [s1, s2], {
				//title:"Today Student Attendance Chart",
				seriesDefaults: {
					renderer:$.jqplot.BarRenderer,
					pointLabels: { show: true }
				},
				seriesColors:['#22BAA0', '#F25656'],
				series:[
						{label:'Present'},
						{label:'Absent'}
				],
				legend: {
						show: true,
						placement: 'outsideGrid'
				},
				axes: {
					xaxis: {
						renderer: $.jqplot.CategoryAxisRenderer,
						ticks: ticksx
					},
					yaxis: {
						ticks: ticksy,
						tickOptions: {
							formatString:'%d'
						}
					}
				}
			});
		}
</script>
<script>
	$.fn.equalizeHeights = function(){ 
  return this.height( Math.max.apply(this, $(this).map(function(i,e){ return $(e).height() }).get() ) )
}
$('.pro1, .pro0').equalizeHeights();
</script>

<script src="<?= base_url();?>template/plugins/chartjs/jquery.jqplot.min.js" type="text/javascript"></script>
<script src="<?= base_url();?>template/plugins/chartjs/plugins/jqplot.barRenderer.min.js" type="text/javascript"></script>
<script src="<?= base_url();?>template/plugins/chartjs/plugins/jqplot.categoryAxisRenderer.js" type="text/javascript"></script>
<link href="<?= base_url();?>template/plugins/chartjs/jquery.jqplot.css" rel="stylesheet" />

