<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
<div class="content-page">			
    <div class="content">
        <?php if($this->session->flashdata('message')):?>
			<?=$this->session->flashdata('message')?>
		<?php endif?>
        <?php $marks_type=array(1=>"Subjective",2=>"Subjective, Objective",3=>"Subjective, Objective, Practical"); ?>
        <!-- Page Heading Start -->
        <div class="page-heading">
            <h1><i class='fa fa-check'></i> Subject List</h1>
        </div>
        <!-- Page Heading End-->
        <!-- Your awesome content goes here -->
        <div class="row">
            <div class="col-sm-12">
                <div class="widget" style="min-height:500px;">
                    <div class="widget-content padding">
                        <!-- Page Heading End-->	
                        <div class="row">				
                            <div class="col-md-12">
                                <div class="widget">
                                    <div class="widget-content padding">
                                   <a class="btn btn-info" href="javascript:void(0);" onclick="toggle_insertion_box(); return false;"><i class="fa fa-plus" aria-hidden="true"></i>
 Add New Subject</a>
                                        <div class="insertion_div">
                                            <div class="widget-content padding">
                                                <form class='form-horizontal' role='form' method="POST" action="<?= base_url();?>admin/subject_save">
                                                    <div class="form-group padding">
                                                        <div class="row">
                                                            <div class="col-sm-4">
                                                                <label>Subject name </label>
                                                                <input type="text" class="form-control" name="subject_name" id="subject_name" >
                                                            </div>
															<div class="col-sm-4">
                                                                <label>Subject name (বাংলায়)</label>
                                                                <input type="text" class="form-control" name="subject_bn" id="subject_bn" >
                                                            </div>
                                                            <div class="col-sm-4">
                                                                <label>Subject Code </label>
                                                                <input type="text" class="form-control" name="subject_code" id="subject_code">
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group padding">
                                                        <div class="row">
                                                            <div class="col-sm-4">
                                                                <label>Is Optional </label>
                                                                <select name="is_optional" id="is_optional" class="form-control">
                                                                    <option value="0">No</option>
                                                                    <option value="1">Yes</option>
                                                                </select>
                                                            </div>
                                                            <div class="col-sm-4">
                                                                <label>Marks Type </label>
                                                                <select name="marks_type" id="marks_type" class="form-control">
                                                                    <?php foreach($marks_type as $key => $value){ ?>
                                                                    <option value="<?= $key?>"><?= $value ?></option>
                                                                    <?php } ?>
                                                                </select>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <div class="row">
                                                            <div class="col-sm-1">
                                                                <button type="submit" class="btn btn-primary" style="margin-top:3px;margin-left:10px;">Save</button>
                                                            </div>
                                                        </div>
                                                    </div>       
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="widget-content">
                                        <table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                            <thead>
                                                <tr>
                                                    <th>Subject ID</th>
													<th>Subject Name</th>
													<th>Subject Name (বাংলায়)</th>
													<th>Subject Code</th>
													<th>Is Optional</th>
													<th>Marks Type</th>
													<th>Action</th>
												</tr>
											</thead>
											<tbody>
												<?php foreach($subject_list as $dl){ ?>
												<tr>
													<td><?= $dl['subject_id'];?></td>
													<td><?= $dl['subject_name'];?></td>
													<td><?= $dl['subject_bn'];?></td>
													<td><?= $dl['subject_code'];?></td>
													<td><?php 
															if($dl['is_optional']==0)
																echo "No";
															else
																echo "Yes";
														?>
													</td>
													<td><?= $marks_type[$dl['marks_type']] ?></td>
                                                    <td>
                                                        <a href="<?= base_url();?>admin/subject_edit/<?= $dl['subject_id'];?>" title="Edit"><i class="fa fa-edit"></i></a> |
                                                        <a href="<?= base_url();?>admin/subject_delete/<?= $dl['subject_id'];?>" title="Delete" onclick="return confirm('Are You Want to Delete it?' );"><i class="fa fa-remove"></i></a> 
                                                    </td>
                                                </tr>
                                                <?php    } ?>
                                            </tbody>
                                        </table>
                                    </div>
								</div>
							</div>
						</div>
                    </div>
                </div>
            </div>
        </div>
<?php include 'application/views/includes/footer.php';?>