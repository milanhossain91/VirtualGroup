<div class="table-responsive">
	<form role="form" id="send_sms" method="POST" action="<?php echo base_url();?>admin/send_classwise_sms_notice" enctype="multipart/form-data">
		<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
			<thead>
				<tr>
					<th>Student ID</th>
					<th>Name</th>
					<th>Class</th>
					<th>Mobile</th>
					
					
				</tr>
			</thead>

			<tbody>
				<?php
					foreach($student_list as $sl){ ?>
					<tr>
						<td><?php echo $sl['student_id'];?></td>
						<td><?php echo $sl['student_name'];?></td>
						<td><?php echo $sl['class_name'];?></td>
						<td><?php echo $sl['father_mobile_contact'];?></td>
						
						
						<input type="hidden" class="form-control" name="student_name[]" id="student_name" value="<?php echo $sl['student_name'];?>">
						<input type="hidden" class="form-control" name="sms_contact[]" id="sms_contact" value="<?php echo $sl['father_mobile_contact'];?>">
						<input type="hidden" class="form-control" name="class_name" id="class_name" value="<?php echo $sl['class_name']?>">
						
					</tr>
				<?php 	} ?>
				
				<div class="form-group">
					<div class="row">
						<div class="col-sm-4">
						   <textarea name="msg" id="note" cols="25" rows="5" style="width:80%;resize:none" maxlength="125" placeholder ="Write Message"></textarea>
				<br/><input type="submit" class="btn btn-primary" name="send_sms" value="Send SMS"/>
						</div>
					</div>
				</div>
				
				
			</tbody>
		</table>
	</form>
</div>