<div class="form-group">
    <div class="row">
        <div class="col-sm-1"></div>
            <div class="col-sm-10">
                <table class="table table-striped table-bordered dataTable"> 
                    <tr>
                        <td>Subject Name</td>
                        <td>Subject Code</td>
                        <td>Marks Type</td>
                        <td>Is Optional</td>
                    </tr>                
            <?php
                if($subject_list && $class_id)
                {
                    foreach($subject_list as $sList)
                    {
                        #$school_id = $_SESSION['school_id'];
                        $school_id = 1;
                        $subject_id = $sList['subject_id'];        

                        $sql = "SELECT class_subject_id FROM tbl_class_subject WHERE school_id = $school_id AND class_id = $class_id AND subject_id = $subject_id AND group_id=$group_id LIMIT 1";
                        $query = $this->db->query($sql);
                        $row = $query->row_array();
                        if($row['class_subject_id'])
                        {
                            $checked = 'checked="checked"';
                        }
                        else 
                        {
                            $checked = '';
                        }
                    ?>
                        <tr>
                            <td>
                                <input type="checkbox" <?php echo $checked?> id="subject_<?php echo $sList['subject_id'];?>" name="subject[<?php echo $sList['subject_id'];?>]" value="<?php echo $sList['subject_id']?>"/> <?php echo $sList['subject_name'];?>
                            </td>
                            <td>
                                <?php 
                                    echo $sList['subject_code'];
                                ?>
                            </td>
                            <td>
                                <?php 
                                    echo $sList['marks_type'];
                                ?>
                            </td>
                            <td>
                                <?php 
                                    echo $sList['is_optional'];
                                ?>
                            </td>
                        </tr>
                        <?php    }    ?>
                    </table>
                </div>
            </div>
        </div>

        <br/><br/>
        <div class="form-group">
            <div class="row">
                <div class="col-sm-2"></div>
                <div class="col-sm-4">
                    <button type="submit" class="btn btn-primary">Save</button>
                </div>
            </div>
        </div>  
        <?php } ?>