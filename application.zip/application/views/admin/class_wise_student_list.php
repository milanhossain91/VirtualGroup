<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
	<div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content">
			<div class="page-heading">
                            <h1><i class='fa fa-table'></i> Class Wise Student List</h1>
			</div>            	
			<div class="row">
                            <div class="col-md-12">
                                <div class="widget" style="min-height: 400px">
                                    <div class="widget-content">
                                        <form role="form" id="registerForm" method="POST">
                                            <div class="widget-content padding">
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <label>Class</label>
                                                            <select class="form-control" name="class_id" id="class_id">
                                                                <option value="">Select</option>
                                                                <?php
                                                                    foreach($class_list as $cl){ ?>
                                                                <option value="<?php echo $cl['class_id'];?>"><?php echo $cl['class_name'];?></option>
                                                                <?php    } ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>


                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                            <button type="button" class="btn btn-primary" onclick="get_class_wise_student_list_json()">Show</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>

                                        <hr/>
                                            
                                        <div id="display">
                                            
                                            <!---JSON Content will be display here--->
                                            
                                        </div>
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                        
                                    </div>
                                </div>
                            </div>
			</div>

				
				
<?php include 'application/views/includes/footer.php';?>

<script>
    function get_class_wise_student_list_json()
    {
        var class_id = $('#class_id').val();        
        $.ajax({ 
        url: baseUrl+'admin/get_class_wise_student_list_json',
        data:
            {                  
                'class_id':class_id
            }, 
            dataType: 'json',
            success: function(data)
            {
                result                = ''+data['result']+'';
                mainContent           = ''+data['mainContent']+'';

                if(result == 'success')
                {            
                    $('#display').html(mainContent);     
                }                
            }
        });
        return false; // keeps the page from not refreshing     
    }
</script> 