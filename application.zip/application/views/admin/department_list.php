<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
            <?php if($this->session->flashdata('message')):?>
				<?=$this->session->flashdata('message')?>
			<?php endif?>
				<!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Department List</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <!-- Page Heading End-->
                                <div class="row">				
                                    <div class="col-md-12">
                                        <div class="widget">
                                        	<div class="widget-content padding">
                                                Add New Department - <a href="javascript:void(0);" onclick="toggle_insertion_box(); return false;">Click Here</a>
                                                <div class="insertion_div">
                                                	<form class='form-horizontal' role='form' method="POST" action="<?php echo base_url();?>admin/department_save">
                                                    	<div class="form-group">
                                                        	<div class="row">
                                                            	<div class="col-sm-1"></div>
                                                                <div class="col-sm-4">
                                                                	<label>Department name </label>
                                                                    <input type="text" class="form-control" name="department_name" id="department_name">
                                                                </div>
                                                                        
                                                                <div class="col-sm-4" style="margin-top:0px;margin-left:10px;">
                                                                	<label>Department name (বাংলায়)</label>
                                                                    <input type="text" class="form-control" name="bn_department_name" id="short_department_name">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                        	<div class="row">
                                                                <button type="submit" class="btn btn-primary" style="margin-top:3px;margin-left:10px;">Save</button>
                                                            </div>
                                                        </div>   
                                                    </form>
                                                </div>
                                            </div>
                                                                                                    
                                            <div class="widget-content">
                                            	<table id="datatables-1" class="table table-striped table-bordered" cellspacing="0" width="100%">
                                                	<thead>
                                                    	<tr>
                                                        	<th>Department ID</th>
                                                            <th>Department Name</th>
                                                            <th>Department Name(বাংলায়)</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach($department_list as $dl){ ?>
                                                    	<tr>
                                                        	<td><?php echo $dl['department_id'];?></td>
                                                            <td><?php echo $dl['department_name'];?></td>
                                                            <td><?php echo $dl['bn_department_name'];?></td>
                                                            <td>
                                                                <a href="<?php echo base_url();?>admin/department_edit/<?php echo $dl['department_id'];?>" title="Edit"><i class="fa fa-edit"></i></a> | 
                                                                <?=anchor("admin/department_delete/".$dl['department_id'],"<i class=\"fa fa-remove\"></i>",array('onclick' => "return confirm('Do you want delete this record')"))?>
                                                            </td>
                                                        </tr>
                                                        <?php    } ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
<?php include 'application/views/includes/footer.php';?>