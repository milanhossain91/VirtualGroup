<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
	<div class="content-page">
		<!-- ============================================================== -->
		<!-- Start Content here -->
		<!-- ============================================================== -->
		<div class="content">
			<div class="page-heading">
                            <h1><i class='fa fa-table'></i> Student Subject Edit</h1>
			</div>            	
			<div class="row">
                            <div class="col-md-12">
                                <div class="widget" style="min-height: 400px">
                                    <div class="widget-content">
                                        <form role="form" id="registerForm" method="POST" action="<?php echo base_url();?>admin/student_subject_edit_save">
                                            <div class="widget-content padding">
                                               <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-6">
                                                            <table class="table table-bordered table-striped">
                                                                <tr>
                                                                    <th>Student ID</th>
                                                                    <th>Student Name</th>
                                                                    <th>Optional Subject</th>
                                                                    <th>Compulsory Subject</th>
                                                                </tr>
                                                           
                                                            <?php
                                                            foreach($subject_info as $sl){ ?>
                                                                <tr>
                                                                    <td><?= $sl['student_id'];?><input type="hidden" name="student_id" value="<?= $sl['student_id'] ?>" /></td>
                                                                    <td><?= $sl['student_name'];?></td>
                                                                    <td><?php foreach($subject_list as $sublist){ ?>
																			<?php
                                                                                $opts=explode(',',$sl['opt']);
																				$ck='';
                                                                                foreach($opts as $opt):
                                                                                    if($opt== $sublist['subject_id'])
																					$ck="checked";
                                                                                endforeach;
                                                                            ?>
                                                                        <input type="checkbox" name="subject_op[]" <?= $ck; ?> value="<?= $sl['student_id'];?>,<?= $sublist['subject_id'];?>,1"/>
                                                                        <?php echo $sublist['subject_name'];?>- <?php echo $sublist['subject_code'];?><br/><br/>
                                                                        <?php 	} ?>
                                                                    </td>
                                                                     <td><?php foreach($subject_list as $sublist){ ?>
                                                                     		<?php
                                                                                $coms=explode(',',$sl['com']);
																				$ck='';
                                                                                foreach($coms as $com):
                                                                                    if($com== $sublist['subject_id'])
																					$ck="checked";
                                                                                endforeach;
                                                                            ?>
                                                                        <input type="checkbox" name="subject_com[]" <?= $ck; ?> value="<?= $sl['student_id'];?>,<?= $sublist['subject_id'];?>,0"/>
                                                                        <?php echo $sublist['subject_name'];?>- <?php echo $sublist['subject_code'];?><br/><br/>
                                                                        <?php 	} ?>
                                                                    </td>
                                                                </tr>
                                                                
                                                                
                                                        <?php 	} ?>
                                                            </table>
                                                        </div>
                                                    </div>
                                                </div>
                                              
                                                <div class="form-group">
                                                    <div class="row">
                                                        <div class="col-sm-4">
                                                        	<input type="hidden" name="class_id" value="<?= $data['class_id'] ?>" />
                                                            <input type="hidden" name="group_id" value="<?= $data['group_id'] ?>" />
                                                            <input type="hidden" name="session_id" value="<?= $data['session_id'] ?>" />
                                                            <button type="submit" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>

                                        <hr/>
                                            
                                        <div id="display">
                                            
                                            <!---JSON Content will be display here--->
                                            
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
			</div>

				
				
<?php include 'application/views/includes/footer.php';?>
                    
>>