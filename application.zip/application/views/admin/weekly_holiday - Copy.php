<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i> Weekly Holiday</h1>
                </div>
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
            	<!-- Page Heading End-->				<!-- Your awesome content goes here -->
				<div class="row">				
                                    <div class="col-md-12">
                                        <div class="widget">
                                            <div class="widget-content padding">
                                                <form class='form-horizontal' role='form' method="POST" action="<?php echo base_url();?>admin/weekly_holiday_save">
                                                    <div class="form-group">
                                                        <div class="row">
                                                            <div class="col-sm-1"></div>
                                                            <div class="col-sm-4">
                                                                <div class="form-group">
                                                                    <label>Shift name </label>
                                                                    <input type="text" class="form-control" name="shift_name" id="shift_name">
                                                                </div>
                                                            </div>
                                                            <br/>
                                                            <button type="submit" class="btn btn-primary" style="margin-top:3px;margin-left:10px;">Save</button>

                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
				</div>
                            </div>
                        </div>
                    </div>
                </div>
				
<?php include 'application/views/includes/footer.php';?>