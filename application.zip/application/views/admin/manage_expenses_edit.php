<!--- Admin Header -->
<?php include 'application/views/includes/admin_header.php';?>

				
<!----Admin Sidebar -->
<?php include 'application/views/includes/admin_sidebar.php';?>
</div>
       
        <div class="content-page">			
            <div class="content">
                <!-- Page Heading Start -->
                <div class="page-heading">
                    <h1><i class='fa fa-check'></i>Expenses Edit</h1>
                </div>
				
				<?php if($this->session->flashdata('message')):?>
				<div class="alert alert-success">
					<a href="#" class="close" data-dismiss="alert">&times;</a>
					<?=$this->session->flashdata('message')?>
				</div>
				<?php endif?>

				
            	<!-- Page Heading End-->
                <!-- Your awesome content goes here -->
                <div class="row">
                    <div class="col-sm-12">
                        <div class="widget" style="min-height:500px;">
                            <div class="widget-content padding">
                                <form role="form" id="registerForm" name="registerForm" method="POST" action="<?php echo base_url();?>admin/manage_expenses_edit_save" enctype="multipart/form-data">
									
									<div class="form-group">
										<ul class="list-inline">
											<li><a href="<?php echo base_url();?>admin/manage_expenses" class="text-muted small">Expenses Create</a> </li> |
											<li><a href="<?php echo base_url();?>admin/manage_expenses_list" class="text-muted small">Expenses View</a> </li>
										</ul>
									</div>
										

									<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <label>Pay to (Name) <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="pay_to_name" id="pay_to_name" value="<?php echo $expenses_edit['pay_to_name'];?>" required />
                                            </div>
                                            
											<div class="col-sm-6">
                                                <label>Expenses Name <span style="color:red;">*</span></label>
                                                <select class="form-control" name="coa_id" id="coa_id" required>
                                                    <option value="">Select</option>
                                                    <?php
														$selected='';
														foreach($expenses_list as $row){ 
															if($row['id']== $expenses_edit['id']){
																$selected='selected="selected"';
															}
															else {
																$selected='';
															}
														?>
														<option value="<?php echo $row['id'];?>" <?php echo $selected; ?>><?php echo $row['ac_name'];?></option>
													<?php  } ?>
                                                </select>			
                                            </div>
                                        </div>
                                    </div>									
									
									<div class="form-group">
                                        <div class="row">
                                            <div class="col-sm-6">
                                                <label>Designation <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="designation" id="designation" value="<?php echo $expenses_edit['designation'];?>" required />
                                            </div>
                                            
											<div class="col-sm-6">
                                                <label>Amount <span style="color:red;">*</span></label>
                                                <input type="text" class="form-control" name="dr_amount" id="dr_amount" value="<?php echo $expenses_edit['dr'];?>" required />
                                            </div>
                                        </div>
                                    </div>
									
                                    <div class="form-group">
                                        <div class="row">
											<div class="col-sm-12">
                                                <label>Remark</label>
                                                <textarea name="remark" id="remark" cols="30" rows="5" style="width:100%;resize:none"> <?php echo $expenses_edit['remark'];?> </textarea>
                                            </div>
                                        </div>
                                    </div>
									<input type="hidden" name="gl_id" value="<?php echo $expenses_edit['general_ledger_id'];?>" />
									<button type="submit" class="btn btn-primary">Update</button>
								</form>
                            </div>
                        </div>
                    </div>
                </div>
				
				
<?php include 'application/views/includes/footer.php';?>