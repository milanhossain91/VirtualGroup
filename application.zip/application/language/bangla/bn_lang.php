<?php
$lang['email_must_be_array'] = "";
?>