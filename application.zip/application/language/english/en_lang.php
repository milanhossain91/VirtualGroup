<?php
$lang['CUS_F_NAME'] = "First Name";
?>